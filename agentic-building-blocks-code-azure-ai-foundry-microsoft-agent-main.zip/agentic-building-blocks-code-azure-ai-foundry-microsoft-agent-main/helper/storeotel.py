"""OpenTelemetry Trace Persistence to Local JSON Files

Provides functionality to persist OpenTelemetry trace data to local JSON files
for historical analysis, debugging, performance tracking, and offline review.

Purpose:
========
1. Trace Persistence: Save OpenTelemetry traces to disk for later analysis
2. Structured Storage: JSON format with metadata, summary, and formatted traces
3. Timestamp Naming: Automatic unique filenames with UTC offset support
4. Load Functionality: Read previously saved traces back into memory
5. Emitter Integration: Progress logging for UI updates

Architecture:
=============
Storage Flow:
  Collect traces (formatted strings)
       ↓
  Collect summary (statistics dict)
       ↓
  Bundle with metadata
       ↓
  Serialize to JSON
       ↓
  Write to timestamped file

JSON File Structure:
```json
{
  "timestamp": "20251110-143052",           // Filename timestamp
  "timestamp_iso": "2025-01-10T14:30:52Z",  // ISO 8601 format
  "query": "what is Claude AI",             // Operation/query name
  "trace_summary": {                        // Statistics from get_summary()
    "total_spans": 45,
    "total_duration_ms": 3247.89,
    "category_breakdown": {...}
  },
  "traces": [                               // Formatted trace lines
    "🔨 [workflow.build] workflow.build - 12.45ms",
    "  📨 [agent.send] EmailAgent.send - 234.56ms",
    ...
  ],
  "metadata": {                             // Additional context
    "executor_counts": {"workflow": 1, "agent": 3},
    "workflow_name": "BlastWebSearch"
  },
  "trace_count": 45                         // Total trace lines
}
```

Use Cases:
==========
1. Historical Analysis: Compare trace patterns over time
2. Performance Debugging: Identify slow operations in workflows
3. Offline Review: Analyze traces without running application
4. Compliance/Audit: Maintain trace records for operational review
5. Testing Validation: Compare expected vs actual trace patterns

File Naming Pattern:
====================
Format: {prefix}_YYYYMMDD-HHMMSS.json
Example: traces_20251110-143052.json

Components:
- prefix: Customizable (default: 'traces')
- YYYYMMDD: Date (local time with UTC offset)
- HHMMSS: Time (local time with UTC offset)

UTC Offset Behavior:
- Environment: UTC_OFFSET (integer hours)
- Examples: 8 (UTC+8), -5 (UTC-5), 0 (UTC)
- Purpose: User-friendly filenames in local timezone

Directory Configuration:
========================
Environment: OTEL_LOCAL_FOLDER (optional)
Default: 'opentele_local' (relative to current working directory)

Why 'opentele_local'?
- Distinguishes from other local storage (emails_local, mp3_local)
- 'otel' abbreviation matches OpenTelemetry convention
- '_local' suffix indicates offline/development storage

Integration with Trace Collection:
===================================
Typical workflow pattern:
```python
# 1. Collect traces during operation
from helper.otel_collector import get_span_collector
collector = get_span_collector()

# ... perform workflow operations ...

# 2. Get formatted traces
traces = collector.get_formatted_traces()

# 3. Get summary statistics
summary = collector.get_summary()

# 4. Get additional metadata
metadata = collector.get_metadata()

# 5. Store to disk
from helper.storeotel import store_otel_traces_to_local
file_path, log = store_otel_traces_to_local(
    traces=traces,
    trace_summary=summary,
    query="my operation",
    metadata=metadata
)
```

Comparison with Other Storage Modules:
=======================================
| Feature          | storeotel.py        | storeemail.py       | text2speech.py      |
|------------------|---------------------|---------------------|---------------------|
| Purpose          | Trace persistence   | Email storage       | Audio generation    |
| Format           | JSON                | JSON                | MP3                 |
| Default folder   | opentele_local      | emails_local        | mp3_local           |
| Env var          | OTEL_LOCAL_FOLDER   | EMAIL_LOCAL_FOLDER  | N/A                 |
| Cloud option     | No                  | Yes (Azure Blob)    | No                  |
| Load function    | Yes                 | No                  | No                  |

Pattern Consistency:
====================
All storage modules follow same patterns:
1. Timestamped filenames (YYYYMMDD-HHMMSS)
2. UTC offset support
3. Emitter integration
4. Tuple returns: (result, log)
5. Directory auto-creation
6. Error handling with detailed logs

Dependencies:
=============
- helper.emitter: Progress logging pattern
- json, os, datetime: Standard library utilities
- No cloud dependencies (local storage only)

Performance:
============
- Small traces (<100 lines): <10ms
- Large traces (1000+ lines): ~50-100ms
- Disk I/O dependent
- No network latency (local only)

Storage Considerations:
=======================
- No automatic cleanup (files accumulate)
- Consider periodic manual cleanup for long-running apps
- Typical file size: 10-100 KB per trace session
- JSON pretty-print (indent=2) for readability

Example Usage:
==============
Basic storage:
```python
from helper.storeotel import store_otel_traces_to_local

traces = ["🔨 [workflow] workflow - 12ms", "  📨 [agent] agent - 234ms"]
summary = {'total_spans': 2, 'total_duration_ms': 246.0}

file_path, log = store_otel_traces_to_local(traces, summary)
print(f"Saved to: {file_path}")
```

With metadata and custom prefix:
```python
metadata = {'workflow_name': 'BlastWebSearch', 'executor_counts': {'workflow': 1}}
file_path, log = store_otel_traces_to_local(
    traces=traces,
    trace_summary=summary,
    query="what is Claude AI",
    metadata=metadata,
    prefix="blast_traces"
)
```

Load traces back:
```python
from helper.storeotel import load_otel_traces_from_local

data, log = load_otel_traces_from_local(file_path)
print(f"Query: {data['query']}")
print(f"Traces: {len(data['traces'])}")
print(f"Duration: {data['trace_summary']['total_duration_ms']}ms")
```

With emitter for UI updates:
```python
from helper.emitter import create_emitter

emitter = create_emitter(lambda msg: print(f"[UI] {msg}"))
file_path, log = store_otel_traces_to_local(
    traces=traces,
    trace_summary=summary,
    emitter=emitter.emit
)
```

Pattern aligned with storeemail.py and text2speech.py for consistency.
"""

import os
import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Callable, Tuple
from helper.emitter import create_emitter


def store_otel_traces_to_local(
    traces: List[str],
    trace_summary: Dict,
    query: str = "",
    metadata: Optional[Dict] = None,
    prefix: str = 'traces',
    emitter: Optional[Callable[[str], None]] = None
) -> Tuple[Optional[str], str]:
    """Store OpenTelemetry traces to local JSON file with structured metadata.
    
    Saves complete trace data to a timestamped JSON file in the configured local folder.
    Includes formatted trace lines, summary statistics, query context, and metadata.
    
    Execution Flow:
    1. Initialize emitter for logging
    2. Determine target directory (env var or default)
    3. Create directory if needed
    4. Generate timestamped filename
    5. Build JSON payload with traces, summary, metadata
    6. Write to file with pretty formatting
    7. Return file path and log
    
    Args:
        traces: List of formatted trace lines (from get_formatted_traces())
                Each line is emoji-prefixed, indented string
                Example: ["🔨 [workflow.build] workflow.build - 12.45ms",
                         "  📨 [agent.send] EmailAgent.send - 234.56ms"]
                Can be empty list (creates empty traces array)
        
        trace_summary: Summary statistics dictionary (from get_summary())
                       Required keys (typical):
                       - 'total_spans': int (total span count)
                       - 'total_duration_ms': float (total duration)
                       - 'category_breakdown': dict (spans by category)
                       Example: {'total_spans': 45, 'total_duration_ms': 3247.89}
        
        query: The search query or operation name (for context/metadata)
               Example: "what is Claude AI", "build_and_test_workflow"
               Stored in JSON for later identification
               Default: "" (empty string if not provided)
        
        metadata: Additional metadata dictionary (executor counts, workflow details, etc.)
                  Optional, can be None
                  Example: {'workflow_name': 'BlastWebSearch', 'executor_counts': {...}}
                  Stored in JSON for additional context
        
        prefix: Filename prefix (default: 'traces')
                Used to categorize different trace types
                Example: 'blast_traces', 'email_traces', 'workflow_traces'
        
        emitter: Optional callback for progress updates
                 Signature: (str) -> None
                 If None, prints to console
                 Used for UI updates (e.g., Streamlit)
    
    Returns:
        Tuple[Optional[str], str]: (file_path, log)
            file_path: Absolute path to saved file (None if failed)
                       Example: "c:\\...\\opentele_local\\traces_20251110-143052.json"
            log: Complete log of operation (success or error messages)
                 Useful for displaying operation details to user
    
    Directory Configuration:
    ------------------------
    Environment: OTEL_LOCAL_FOLDER (optional)
    Default: 'opentele_local' (relative to current working directory)
    Created automatically if doesn't exist
    
    File Naming:
    ------------
    Pattern: {prefix}_YYYYMMDD-HHMMSS.json
    Timezone: Uses UTC + UTC_OFFSET environment variable
    Example: traces_20251110-143052.json
    
    JSON Structure:
    ---------------
    The saved file contains:
    ```json
    {
      "timestamp": "20251110-143052",          // For filename reference
      "timestamp_iso": "2025-01-10T14:30:52Z", // ISO 8601 format
      "query": "what is Claude AI",            // Operation name/context
      "trace_summary": {                       // From get_summary()
        "total_spans": 45,
        "total_duration_ms": 3247.89,
        "category_breakdown": {...}
      },
      "traces": [                              // From get_formatted_traces()
        "🔨 [workflow.build] workflow.build - 12.45ms",
        "  📨 [agent.send] EmailAgent.send - 234.56ms",
        ...
      ],
      "metadata": {                            // Additional context
        "executor_counts": {"workflow": 1, "agent": 3},
        "workflow_name": "BlastWebSearch"
      },
      "trace_count": 45                        // Total trace lines
    }
    ```
    
    Example Usage:
    --------------
    ```python
    # Basic usage
    from helper.otel_collector import get_span_collector
    collector = get_span_collector()
    
    traces = collector.get_formatted_traces()
    summary = collector.get_summary()
    
    file_path, log = store_otel_traces_to_local(traces, summary)
    print(f"Saved to: {file_path}")
    
    # With query and metadata
    metadata = collector.get_metadata()
    file_path, log = store_otel_traces_to_local(
        traces=traces,
        trace_summary=summary,
        query="what is Claude AI",
        metadata=metadata,
        prefix="blast_traces"
    )
    
    # With UI progress updates
    from helper.emitter import create_emitter
    emitter = create_emitter(lambda msg: print(f"[UI] {msg}"))
    file_path, log = store_otel_traces_to_local(
        traces=traces,
        trace_summary=summary,
        emitter=emitter.emit
    )
    ```
    
    Error Handling:
    ---------------
    - Directory creation failure: Returns (None, error_log)
    - File write failure: Returns (None, error_log)
    - Permission errors: Returns (None, error_log)
    - All errors logged in returned log string
    
    Performance:
    ------------
    - Small traces (<100 lines): <10ms
    - Large traces (1000+ lines): ~50-100ms
    - Disk I/O dependent
    
    Storage Considerations:
    -----------------------
    - No automatic cleanup (files accumulate)
    - Consider periodic manual cleanup
    - Typical file size: 10-100 KB per trace session
    - JSON pretty-print (indent=2) for readability
    """
    # STEP 1: Initialize emitter for progress logging
    # create_emitter wraps callback or creates console emitter
    emit_util = create_emitter(emitter)
    
    def emit(msg: str):
        """Helper function to emit log messages."""
        emit_util.emit(msg)
    
    # STEP 2: Determine target directory
    # OTEL_LOCAL_FOLDER: Configurable directory path
    # Default: 'opentele_local' (relative to current working directory)
    # Why configurable? Different projects may have different conventions
    local_folder = os.getenv('OTEL_LOCAL_FOLDER', 'opentele_local')
    emit(f'[OTEL-STORE] Storing traces to local folder: {local_folder}')
    
    # STEP 3: Create directory if doesn't exist
    if not os.path.exists(local_folder):
        try:
            # os.makedirs: Creates intermediate directories if needed
            # Why not os.mkdir? makedirs handles nested paths
            os.makedirs(local_folder)
            emit(f'[INFO] Created local folder {local_folder}.')
        except Exception as e:
            # Directory creation failure (permission, path invalid, etc.)
            # Return None to signal failure, log contains error details
            emit(f'[ERROR] Failed to create local folder: {e}')
            return None, emit_util.get_log()
    
    # STEP 4: Generate timestamped filename
    # Get local time with UTC offset (for user-friendly filenames)
    # UTC_OFFSET: Hours to add to UTC (e.g., 8 for UTC+8, -5 for UTC-5)
    utc_offset_hours = int(os.getenv('UTC_OFFSET', '0'))
    local_time = datetime.utcnow() + timedelta(hours=utc_offset_hours)
    
    # Format timestamp: YYYYMMDD-HHMMSS
    # Why this format? Sortable, no spaces, filesystem-safe
    ts = local_time.strftime('%Y%m%d-%H%M%S')
    
    # Build filename: {prefix}_{timestamp}.json
    # Example: traces_20251110-143052.json
    file_name = f"{prefix}_{ts}.json"
    
    # Build full file path
    # os.path.join: Platform-independent path joining
    file_path = os.path.join(local_folder, file_name)
    emit(f'[OTEL-STORE] Writing to file: {file_path}')
    
    # STEP 5: Prepare JSON payload with all trace data
    payload = {
        # Timestamp (same as filename, for reference)
        "timestamp": ts,
        
        # ISO 8601 timestamp (machine-readable, timezone-aware)
        # Why ISO 8601? Standard format for timestamp exchange
        "timestamp_iso": local_time.isoformat() + 'Z',
        
        # Query or operation name (for context)
        # Helps identify what operation produced these traces
        "query": query,
        
        # Summary statistics from get_summary()
        # Includes: total_spans, total_duration_ms, category_breakdown
        "trace_summary": trace_summary,
        
        # Formatted trace lines from get_formatted_traces()
        # Each line is emoji-prefixed, indented string
        "traces": traces,
        
        # Additional metadata from get_metadata() or custom
        # Can include: executor_counts, workflow_name, etc.
        # Default to empty dict if not provided
        "metadata": metadata or {},
        
        # Total trace line count (for quick reference)
        # Redundant with len(traces) but convenient
        "trace_count": len(traces)
    }
    
    # STEP 6: Write to file with pretty formatting
    try:
        # 'w': Write mode (overwrite if exists, but shouldn't with timestamps)
        # encoding='utf-8': Handle Unicode characters (emoji in traces)
        # Why UTF-8? Standard for JSON, supports all languages and emoji
        with open(file_path, 'w', encoding='utf-8') as f:
            # indent=2: Pretty-print for readability
            # ensure_ascii=False: Preserve Unicode characters (emoji)
            # Why not minified? File size difference minimal, readability valuable
            json.dump(payload, f, indent=2, ensure_ascii=False)
        
        # STEP 7: Log success and return
        emit(f'[SUCCESS] Saved {len(traces)} trace lines to {file_path}.')
        return file_path, emit_util.get_log()
    
    except Exception as e:
        # File write failure (permission, disk full, etc.)
        # Return None to signal failure, log contains error details
        emit(f'[ERROR] Failed to write trace file: {e}')
        return None, emit_util.get_log()


def load_otel_traces_from_local(
    file_path: str,
    emitter: Optional[Callable[[str], None]] = None
) -> Tuple[Optional[Dict], str]:
    """Load OpenTelemetry traces from a local JSON file.
    
    Reads and parses a previously saved trace file.
    Useful for offline analysis, debugging, and historical review.
    
    Execution Flow:
    1. Initialize emitter for logging
    2. Check if file exists
    3. Read file contents
    4. Parse JSON
    5. Extract trace count
    6. Return parsed data and log
    
    Args:
        file_path: Path to the JSON trace file (absolute or relative)
                   Example: 'opentele_local/traces_20251110-143052.json'
                   Should be a file created by store_otel_traces_to_local()
        
        emitter: Optional callback for progress updates
                 Signature: (str) -> None
                 If None, prints to console
                 Used for UI updates (e.g., Streamlit)
    
    Returns:
        Tuple[Optional[Dict], str]: (trace_data, log)
            trace_data: Parsed JSON dictionary (None if failed)
                        Contains keys:
                        - 'timestamp': str (YYYYMMDD-HHMMSS)
                        - 'timestamp_iso': str (ISO 8601)
                        - 'query': str (operation name)
                        - 'trace_summary': dict (statistics)
                        - 'traces': list (formatted trace lines)
                        - 'metadata': dict (additional context)
                        - 'trace_count': int (total lines)
            log: Complete log of operation (success or error messages)
    
    Example Usage:
    --------------
    ```python
    # Basic load
    from helper.storeotel import load_otel_traces_from_local
    
    data, log = load_otel_traces_from_local('opentele_local/traces_20251110-143052.json')
    if data:
        print(f"Query: {data['query']}")
        print(f"Total spans: {data['trace_summary']['total_spans']}")
        print(f"Duration: {data['trace_summary']['total_duration_ms']}ms")
        
        # Display traces
        for trace_line in data['traces']:
            print(trace_line)
    else:
        print(f"Load failed: {log}")
    
    # Access metadata
    data, log = load_otel_traces_from_local('opentele_local/traces_20251110-143052.json')
    if data:
        workflow_name = data['metadata'].get('workflow_name')
        executor_counts = data['metadata'].get('executor_counts')
        print(f"Workflow: {workflow_name}")
        print(f"Executors: {executor_counts}")
    
    # With UI progress updates
    from helper.emitter import create_emitter
    emitter = create_emitter(lambda msg: print(f"[UI] {msg}"))
    data, log = load_otel_traces_from_local(
        'opentele_local/traces_20251110-143052.json',
        emitter=emitter.emit
    )
    ```
    
    Use Cases:
    ----------
    1. Offline Analysis: Review traces without running application
    2. Historical Comparison: Compare traces from different time periods
    3. Performance Debugging: Identify patterns in slow operations
    4. Testing Validation: Verify expected trace patterns
    5. Compliance/Audit: Review historical operational data
    
    Error Handling:
    ---------------
    - File not found: Returns (None, error_log)
    - Invalid JSON: Returns (None, error_log)
    - Permission errors: Returns (None, error_log)
    - All errors logged in returned log string
    
    Performance:
    ------------
    - Small files (<100 KB): <10ms
    - Large files (1+ MB): ~50-100ms
    - Disk I/O dependent
    - JSON parsing overhead minimal
    
    Data Validation:
    ----------------
    No schema validation performed.
    Assumes file created by store_otel_traces_to_local().
    Gracefully handles missing keys (returns None for .get() calls).
    """
    # STEP 1: Initialize emitter for progress logging
    # create_emitter wraps callback or creates console emitter
    emit_util = create_emitter(emitter)
    
    def emit(msg: str):
        """Helper function to emit log messages."""
        emit_util.emit(msg)
    
    emit(f'[OTEL-LOAD] Loading traces from: {file_path}')
    
    # STEP 2: Check if file exists
    if not os.path.exists(file_path):
        # File not found - cannot proceed
        emit(f'[ERROR] File not found: {file_path}')
        return None, emit_util.get_log()
    
    # STEP 3: Read and parse JSON file
    try:
        # 'r': Read mode
        # encoding='utf-8': Handle Unicode characters (emoji in traces)
        with open(file_path, 'r', encoding='utf-8') as f:
            # json.load: Parse JSON from file object
            data = json.load(f)
        
        # STEP 4: Extract trace count for logging
        # Try 'trace_count' field first (explicit count)
        # Fall back to len(traces) if not present (backward compatibility)
        trace_count = data.get('trace_count', len(data.get('traces', [])))
        
        # STEP 5: Log success and return
        emit(f'[SUCCESS] Loaded {trace_count} trace lines from {file_path}.')
        return data, emit_util.get_log()
    
    except Exception as e:
        # File read or JSON parsing failure
        # Possible errors:
        # - JSONDecodeError: Invalid JSON format
        # - PermissionError: Insufficient file permissions
        # - IOError: File read failure
        emit(f'[ERROR] Failed to read trace file: {e}')
        return None, emit_util.get_log()
