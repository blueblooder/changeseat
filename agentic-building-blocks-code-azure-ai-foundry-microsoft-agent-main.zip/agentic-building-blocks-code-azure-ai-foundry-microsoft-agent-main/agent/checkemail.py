"""Email checking agent tool sample.

This module can be imported as `agent.checkemail` or executed directly:

	python -m agent.checkemail
or (from repo root):
	python .\\agent\\checkemail.py

Agent Behavior:
	The agent retrieves Outlook emails via Microsoft Graph API for a specified date range,
	analyzes email content including subject, body, recipients, and attachments,
	and provides structured summaries or insights about the emails retrieved.
"""

from __future__ import annotations

import os
import sys
import json
from datetime import datetime, timedelta
from typing import Optional, Callable, Dict, Any, List
from dotenv import load_dotenv
from azure.ai.projects import AIProjectClient
from azure.identity import AzureCliCredential
from azure.ai.agents.models import (
	ListSortOrder,
	MessageRole,
)

DEFAULT_QUESTION = "Please analyze my recent emails"

if __name__ == "__main__":
	repo_root = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
	if repo_root not in sys.path:
		sys.path.insert(0, repo_root)

from helper.tokenmanager import get_cached_or_new_token
from helper.graphapi import get_outlook_emails
from helper.storeemail import store_emails_to_local
from helper.agent_config_loader import load_agent_config, AgentConfigError
from helper.emitter import create_emitter

load_dotenv()

project_endpoint = os.getenv("PROJECT_ENDPOINT")
model_deployment_name = os.getenv("MODEL_DEPLOYMENT_NAME")
MAX_WORDS_PER_EMAILBODY = 100

def load_stored_emails(file_path: str | None = None) -> tuple[List[Dict[str, Any]], str]:
	"""Load emails from a stored JSON file.
	
	Parameters
	----------
	file_path: Optional specific file path. If None, loads the most recent email file.
	
	Returns
	-------
	tuple: (emails_list, file_path_used)
	"""
	if file_path is None:
		# Find the most recent email file
		emails_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "emails_local")
		if not os.path.exists(emails_dir):
			return [], ""
		
		email_files = [f for f in os.listdir(emails_dir) if f.startswith("emails_") and f.endswith(".json")]
		if not email_files:
			return [], ""
		
		# Sort by filename (which includes timestamp) to get the most recent
		email_files.sort(reverse=True)
		file_path = os.path.join(emails_dir, email_files[0])
	
	try:
		with open(file_path, 'r', encoding='utf-8') as f:
			emails = json.load(f)
		return emails, file_path
	except Exception:
		return [], file_path


def run_email_agent_analysis(
	emails_content: List[Dict[str, Any]] | str,
	emitter: Optional[Callable[[str], None]] = None,
	return_mode: str = "log",
	tracing_mode: str = "both",
) -> str | dict:
	"""Process email content through Azure AI agent for analysis.
	
	The agent analyzes email content and generates structured summaries or insights.
	
	Execution Flow:
	1. Initialize answer storage
	2. Setup emitter for progress tracking
	3. Convert emails to JSON string format
	4. Auto-detect tracing mode if set to 'auto'
	5. Configure OpenTelemetry tracing manager
	6. Truncate email content if exceeds token limit (250K chars)
	7. Validate Azure project configuration (endpoint, model)
	8. Connect to Azure AI Project and agents client
	9. Load agent configuration from YAML file
	10. Format agent instructions with MAX_WORDS_PER_EMAILBODY
	11. Validate email JSON structure
	12. Create agent for email analysis
	13. Create thread and submit email content
	14. Execute agent and gather responses
	15. Clean up agent resources
	16. Collect OpenTelemetry traces and generate summary report
	17. Format return payload based on return_mode
	
	Parameters
	----------
	emails_content: Either a list of email dictionaries or JSON string containing email data.
	emitter: Optional callback(string) for incremental UI updates.
	return_mode: Controls return payload:
		'answer' -> answer text (fallback to log if empty)
		'log'    -> full log only (default for backward compatibility)
		'both'   -> dict { 'output_text': str, 'answer': str, 'log': str }
	tracing_mode: Controls OpenTelemetry tracing destination:
		'auto' (default) -> Azure Monitor if APPLICATIONINSIGHTS_CONNECTION_STRING is set, else none
		'azure_monitor'  -> Send traces to Azure AI Foundry Portal
		'console'        -> Print traces to console (with gen_ai agent traces)
		'none'           -> Disable tracing
	
	Returns
	-------
	str | dict depending on `return_mode`.
	"""
	
	# STEP 1: Initialize answer storage
	# Why? Collect multiple response fragments from agent's email analysis
	answer_fragments: List[str] = []

	# STEP 2: Setup emitter for progress tracking
	# Why? Provides real-time feedback during email analysis and debugging visibility
	emit_util = create_emitter(emitter)
	emit = emit_util.emit

	# STEP 3: Convert emails to JSON string format
	# Why? Agent requires structured JSON input regardless of input format (list or string)
	# STEP 3: Convert emails to JSON string format
	# Why? Agent requires structured JSON input regardless of input format (list or string)
	if isinstance(emails_content, list):
		email_json_str = json.dumps(emails_content, indent=2, ensure_ascii=False)
	else:
		email_json_str = str(emails_content)
	
	# STEP 4: Auto-detect tracing mode if set to 'auto'
	# Why? Automatically enable Azure Monitor tracing if Application Insights configured
	if tracing_mode == "auto":
		application_insights_connection_string = os.environ.get("APPLICATIONINSIGHTS_CONNECTION_STRING")
		if application_insights_connection_string and application_insights_connection_string.strip():
			tracing_mode = "both"
			emit("[TRACING] Auto-detected APPLICATIONINSIGHTS_CONNECTION_STRING - using dual tracing mode")
		else:
			tracing_mode = "console"
			emit("[TRACING] No APPLICATIONINSIGHTS_CONNECTION_STRING found - using console tracing")

	# STEP 5: Configure OpenTelemetry tracing manager
	# Why? Enables distributed tracing for debugging email analysis workflow and performance analysis
	from helper.unified_trace_manager import UnifiedTraceManager
	trace_mgr = UnifiedTraceManager(tracing_mode=tracing_mode, trace_type="agent", emitter=emit)
	trace_mgr.setup()
	
	# STEP 6: Truncate email content if exceeds token limit (250K chars)
	# Why? GPT-4o Global Standard limits: 450K tokens/min, 7500 tokens/sec - prevent context overflow
	MAX_CONTENT_LENGTH = 250000
	if len(email_json_str) > MAX_CONTENT_LENGTH:
		emit(f"[AGENT] Email content too long ({len(email_json_str)} chars), truncating to {MAX_CONTENT_LENGTH} chars...")
		if isinstance(emails_content, list) and len(emails_content) > 1:
			reduced_emails = emails_content[:max(1, len(emails_content) // 2)]
			try:
				email_json_str = json.dumps(reduced_emails, indent=2, ensure_ascii=False)
				emit(f"[AGENT] Reduced to {len(reduced_emails)} emails ({len(email_json_str)} chars)")
				
				if len(email_json_str) > MAX_CONTENT_LENGTH:
					# Try to truncate at a safe point (end of complete email object)
					truncated = email_json_str[:MAX_CONTENT_LENGTH]
					# Find the last complete email object by looking for "},\n"
					last_complete_email = truncated.rfind('},\n')
					if last_complete_email > 0:
						truncated = truncated[:last_complete_email+1] + '\n]'
					else:
						last_brace = truncated.rfind('}')
						if last_brace > 0:
							truncated = truncated[:last_brace+1] + '\n]'
						else:
							truncated = '[]'
					email_json_str = truncated
					emit(f"[AGENT] Further truncated to {len(email_json_str)} chars")
					
					try:
						json.loads(email_json_str)
					except json.JSONDecodeError:
						emit("[AGENT] Truncated JSON invalid, using fallback")
						email_json_str = json.dumps(reduced_emails[:1], indent=2, ensure_ascii=False)
						
			except Exception as json_error:
				emit(f"[AGENT] JSON processing error during truncation: {json_error}")
				email_json_str = f"Email processing error. Content summary: {len(emails_content)} emails retrieved."
		else:
			try:
				if isinstance(emails_content, list) and len(emails_content) == 1:
					email_json_str = json.dumps(emails_content[0], indent=2, ensure_ascii=False)[:MAX_CONTENT_LENGTH]
					open_braces = email_json_str.count('{')
					close_braces = email_json_str.count('}')
					if open_braces > close_braces:
						email_json_str += '}' * (open_braces - close_braces)
				else:
					email_json_str = str(emails_content)[:MAX_CONTENT_LENGTH]
				emit(f"[AGENT] Truncated to {len(email_json_str)} chars")
			except Exception:
				email_json_str = f"Email content too large to process. Summary: {type(emails_content)} with {len(emails_content) if isinstance(emails_content, list) else len(str(emails_content))} items/chars."

	# STEP 7: Validate Azure project configuration (endpoint, model)
	# Why? Fail fast if environment variables missing - prevents confusing downstream errors
	if not project_endpoint or not model_deployment_name:
		emit("[ERROR] Please set PROJECT_ENDPOINT and MODEL_DEPLOYMENT_NAME in your environment/.env")
		log_joined = emit_util.get_log()
		return log_joined if return_mode != "both" else {"output_text": log_joined, "answer": log_joined, "log": log_joined}

	# STEP 8: Start parent tracing span with email count metadata
	# Why? Captures end-to-end latency for email analysis including email count for diagnostics
	email_count = len(emails_content) if isinstance(emails_content, list) else 1
	trace_mgr.start_parent_span(
		span_name=f"run_email_agent_analysis: {email_count} emails",
		attributes={
			"email_count": email_count,
			"tracing_mode": tracing_mode
		}
	)

	# STEP 9: Connect to Azure AI Project and agents client
	# Why? All agent operations require AIProjectClient connection with proper credentials
	emit("[AGENT] Azure AI Project Client initializing...")
	try:
		with AIProjectClient(endpoint=project_endpoint, credential=AzureCliCredential()) as project_client:
			agents_client = project_client.agents
			
			# STEP 10: Load agent configuration from YAML file with error handling
			# Why? Dynamic config loading allows separation of prompts from code, validate before agent creation
			try:
				emit("[AGENT] Loading agent configuration...")
				pyfile_name = os.path.splitext(os.path.basename(__file__))[0]
				agent_name, agent_instructions, agent_description = load_agent_config(pyfile_name)
				# Agent will: (1) Parse email JSON containing subject, body, recipients, and attachments
				#             (2) Analyze patterns, urgency, topics, and relationships across emails
				#             (3) Generate structured summaries highlighting key insights and actions
				emit(f"[AGENT] Loaded agent configuration: {agent_name}")
			except AgentConfigError as cfg_err:
				emit(f"[ERROR] {cfg_err}")
				log_joined = emit_util.get_log()
				return log_joined if return_mode != "both" else {"output_text": log_joined, "answer": log_joined, "log": log_joined}

			# STEP 11: Format agent instructions with MAX_WORDS_PER_EMAILBODY
			# Why? Inject word limit into agent instructions for controlled summarization length
			emit("[AGENT CONFIG] Loaded configuration for checkemail agent")
			agent_instructions = agent_instructions.format(MAX_WORDS_PER_EMAILBODY=MAX_WORDS_PER_EMAILBODY)
			
			# STEP 12: Create agent for email analysis
			# Why? Configured agent with specific instructions for email pattern analysis
			agent = agents_client.create_agent(
				model=model_deployment_name,
				name=agent_name,
				instructions=agent_instructions,
				description=agent_description,
			)
			emit(f"[AGENT] Created agent ID: {agent.id}")
			
			# STEP 13: Create thread for agent conversation
			# Why? Provides isolated conversation context for this email analysis request
			thread = agents_client.threads.create()
			emit(f"[AGENT] Created thread ID: {thread.id}")
			
			# STEP 14: Validate email JSON structure before sending to agent
			# Why? Prevent agent execution with malformed JSON - saves tokens and time
			try:
				if email_json_str.strip():
					json.loads(email_json_str)
					emit("[AGENT] Email JSON validated successfully")
				else:
					emit("[ERROR] Email JSON is empty")
					log_joined = emit_util.get_log()
					return log_joined if return_mode != "both" else {"output_text": log_joined, "answer": log_joined, "log": log_joined}
			except json.JSONDecodeError as json_err:
				emit(f"[ERROR] Invalid JSON detected before sending to agent: {json_err}")
				emit(f"[ERROR] JSON content preview: {email_json_str[:500]}...")
				email_json_str = json.dumps({
					"error": "Original email JSON was malformed",
					"email_count": len(emails_content) if isinstance(emails_content, list) else 1,
					"message": "Please check email retrieval process"
				}, indent=2)
				emit("[AGENT] Using fallback JSON structure")
			
			# STEP 15: Submit email content to agent for processing
			# Why? Provide email JSON to agent for analysis
			emit("[AGENT] Sending email content to agent for processing...")
			user_message = agents_client.messages.create(
				thread_id=thread.id,
				role="user",
				content=email_json_str,
			)
			emit(f"[AGENT] Posted user message ID: {user_message.id}")
			
			# STEP 16: Execute agent and check run status
			# Why? Blocks until email analysis completes, handles failure scenarios
			run = agents_client.runs.create_and_process(thread_id=thread.id, agent_id=agent.id)
			emit(f"[AGENT] Run status: {run.status}")
			if run.status == "failed":
				emit(f"[AGENT] Run failed: {run.last_error}")

			# STEP 17: Gather agent responses for output
			# Why? Extract analysis results from agent messages
			messages = agents_client.messages.list(thread_id=thread.id, order=ListSortOrder.ASCENDING)
			for m in messages:
				if m.role == MessageRole.AGENT:
					for txt in m.text_messages:
						val = txt.text.value
						answer_fragments.append(val)
						emit("[AGENT OUTPUT]\n" + val)
				elif m.role != MessageRole.USER:
					for txt in m.text_messages:
						emit(f"[{m.role}] {txt.text.value}")

			# STEP 18: Clean up agent resources
			# Why? Free Azure resources immediately after use
			agents_client.delete_agent(agent.id)
			emit("[AGENT] Deleted agent")
			
			# STEP 19: Emit Azure Monitor tracing notification if enabled
			# Why? Inform user where to find distributed traces for debugging
			if tracing_mode == "azure_monitor":
				emit("")
				emit("AZURE MONITOR TRACING")
				emit("✅ Agent traces have been sent to Azure Monitor / Application Insights")
				emit("📊 View traces in Azure AI Foundry Portal: https://ai.azure.com")
				emit("")

	# STEP 20: Handle unexpected exceptions with detailed error reporting
	# Why? Email JSON parsing issues are common - provide detailed diagnostics for debugging
	except Exception as exc:
		import traceback
		error_details = traceback.format_exc()
		emit(f"[ERROR] Unexpected exception: {exc}")
		emit(f"[ERROR] Exception type: {type(exc).__name__}")
		if "receivedDateTime" in str(exc):
			emit("[ERROR] This appears to be a JSON parsing issue with email data")
			emit(f"[ERROR] Email JSON length: {len(email_json_str)} chars")
			emit(f"[ERROR] Email JSON preview: {email_json_str[:200]}...")
		emit(f"[DEBUG] Full traceback:\n{error_details}")
		trace_mgr.record_exception(exc, f"Fatal exception: {exc}")
	finally:
		# STEP 21: End parent tracing span
		# Why? Ensures span is closed even if exception occurred
		trace_mgr.end_parent_span()

	# STEP 22: Collect OpenTelemetry traces and generate summary
	# Why? Provides detailed performance metrics and distributed trace visualization
	# STEP 22: Collect OpenTelemetry traces and generate summary
	# Why? Provides detailed performance metrics and distributed trace visualization
	trace_lines, trace_summary = trace_mgr.get_traces()
	
	# STEP 23: Emit trace summary report if traces collected
	# Why? Console visibility into span hierarchy, latency, and HTTP calls
	if trace_lines:
		emit("")
		emit("=" * 50)
		emit("OPENTELEMETRY TRACE SUMMARY")
		emit("=" * 50)
		emit(f"Total Spans: {trace_summary.get('total_spans', 0)}")
		emit(f"Agent Spans: {trace_summary.get('agent_spans', 0)}")
		emit(f"Thread Spans: {trace_summary.get('thread_spans', 0)}")
		emit(f"Message Spans: {trace_summary.get('message_spans', 0)}")
		emit(f"Run Spans: {trace_summary.get('run_spans', 0)}")
		emit(f"HTTP Spans: {trace_summary.get('http_spans', 0)}")
		emit(f"Main Elapsed: {trace_summary.get('main_elapsed_ms', 0):.2f}ms")
		emit("")
		for line in trace_lines:
			emit(line)
		emit("=" * 50)

	# STEP 24: Format answer and build return payload
	# Why? Join analysis fragments and format based on return_mode
	answer_joined = "\n\n".join(answer_fragments)
	log_joined = emit_util.get_log()

	# STEP 25: Build return payload based on return_mode
	# Why? Flexible output format - answer only, logs only, or both with traces
	if return_mode == "both":
		payload = {
			"output_text": answer_joined or log_joined,
			"answer": answer_joined,
			"log": log_joined,
			"traces": trace_lines,
			"trace_summary": trace_summary,
		}
	elif return_mode == "answer":
		payload = answer_joined if answer_joined else log_joined
	else:
		payload = log_joined

	return payload


def run_check_emails(
	start_datetime: str,
	end_datetime: str,
	max_items: int = 25,
	from_addresses: Optional[List[str]] = None,
	emitter: Optional[Callable[[str], None]] = None,
	return_mode: str = "log",
	store_local: bool = True,
	analyze_with_agent: bool = False,
	stored_email_file: str | None = None,
	tracing_mode: str = "both",
) -> str | dict:
	"""Check and retrieve Outlook emails for the specified date range.

	Retrieves emails via Microsoft Graph API, optionally stores them locally,
	and can analyze them with an AI agent.
	
	Execution Flow:
	1. Initialize answer storage and emails list
	2. Setup emitter for progress tracking
	3. If stored_email_file provided: load and analyze stored emails (bypass retrieval)
	4. Acquire Microsoft Graph API access token
	5. Retrieve emails from Outlook via Microsoft Graph API
	6. Display email summary (first 10 emails)
	7. Store emails to local JSON file if store_local=True
	8. Optionally analyze emails with AI agent if analyze_with_agent=True
	9. Format return payload based on return_mode

	Parameters
	----------
	start_datetime: Start date/time for email filtering (ISO 8601 format).
	end_datetime: End date/time for email filtering (ISO 8601 format).
	max_items: Maximum number of emails to retrieve.
	emitter: Optional callback(string) for incremental UI updates.
	return_mode: Controls return payload:
		'answer' -> output_text as described above (fallback to log if empty)
		'log'    -> full log only (default for backward compatibility)
		'both'   -> dict { 'output_text': str, 'answer': str, 'log': str }
	store_local: Whether to store emails to local file. If True, output_text is file path. If False, output_text is full email content.
	analyze_with_agent: Whether to process emails through Azure AI agent for analysis.
	stored_email_file: Optional path to existing email file for agent analysis (bypasses email retrieval).
	tracing_mode: Controls OpenTelemetry tracing destination:
		'auto' (default) -> Azure Monitor if APPLICATIONINSIGHTS_CONNECTION_STRING is set, else none
		'azure_monitor'  -> Send traces to Azure AI Foundry Portal
		'console'        -> Print traces to console (with gen_ai agent traces)
		'none'           -> Disable tracing

	Returns
	-------
	str | dict depending on `return_mode`.
	"""

	# STEP 1: Initialize answer storage and emails list
	# Why? Track both output fragments (file paths/analysis) and retrieved emails for processing
	answer_fragments: List[str] = []
	emails_retrieved: List[Dict[str, Any]] = []

	# STEP 2: Setup emitter for progress tracking
	# Why? Provides real-time feedback during email retrieval and debugging visibility
	emit_util = create_emitter(emitter)
	emit = emit_util.emit

	emit("[EMAIL CHECK] Starting email retrieval process...")

	# STEP 3: If stored_email_file provided, load and analyze stored emails (bypass retrieval)
	# Why? Allows analysis of previously retrieved emails without re-fetching from Graph API
	if analyze_with_agent and stored_email_file:
		emit(f"[EMAIL ANALYSIS] Loading stored email file: {stored_email_file}")
		emails_retrieved, _ = load_stored_emails(stored_email_file)
		if not emails_retrieved:
			emit(f"[ERROR] Failed to load stored email file: {stored_email_file}")
			log_joined = emit_util.get_log()
			return log_joined if return_mode != "both" else {"output_text": log_joined, "answer": log_joined, "log": log_joined}
		
		agent_result = run_email_agent_analysis(emails_retrieved, emitter=emitter, return_mode="both", tracing_mode=tracing_mode)
		if isinstance(agent_result, dict):
			answer_fragments.append(agent_result["answer"])
			for line in agent_result["log"].splitlines():
				if line not in emit_util.get_messages():
					emit_util.messages.append(line)
		else:
			answer_fragments.append(agent_result)
			
		answer_joined = "\n\n".join(answer_fragments)
		log_joined = emit_util.get_log()

		if return_mode == "both":
			payload = {"output_text": answer_joined or log_joined, "answer": answer_joined, "log": log_joined}
		elif return_mode == "answer":
			payload = answer_joined if answer_joined else log_joined
		else:
			payload = log_joined
		
		return payload

	# STEP 4: Acquire Microsoft Graph API access token
	# Why? Token required for all Microsoft Graph API calls to Outlook
	emit("[TOKEN] Acquiring access token...")
	try:
		token_result = get_cached_or_new_token(interactive=True, emitter=emitter, return_mode="both")
		
		if isinstance(token_result, dict):
			token = token_result.get("token")
			token_log = token_result.get("log", "")
		else:
			token = None
			token_log = str(token_result) if token_result else ""

		if token_log:
			for line in token_log.splitlines():
				if line not in emit_util.get_messages():
					emit_util.messages.append(line)
	except Exception as exc:
		emit(f"[ERROR] Token acquisition failed: {exc}")
		log_joined = emit_util.get_log()
		return log_joined if return_mode != "both" else {"output_text": log_joined, "answer": log_joined, "log": log_joined}

	if not token:
		emit("[ERROR] No access token available")
		log_joined = emit_util.get_log()
		return log_joined if return_mode != "both" else {"output_text": log_joined, "answer": log_joined, "log": log_joined}

	# STEP 5: Retrieve emails from Outlook via Microsoft Graph API
	# Why? Fetch emails within date range using specified select fields for complete email data
	emit(f"[EMAIL] Retrieving emails from {start_datetime} to {end_datetime}...")
	try:
		select_fields = [
			'subject', 'receivedDateTime', 'from', 'toRecipients', 'ccRecipients', 'bccRecipients',
			'body', 'bodyPreview', 'attachments', 'isRead', 'sentDateTime', 'hasAttachments'
		]
		
		emails, fetch_log = get_outlook_emails(
			token, 
			start_datetime, 
			end_datetime, 
			top=max_items, 
			select=select_fields,
			from_addresses=from_addresses,
			emitter=emitter
		)
		
		if fetch_log:
			for line in fetch_log.splitlines():
				if line not in emit_util.get_messages():
					emit_util.messages.append(line)
		
		emails_retrieved = emails
		
		if emails:
			emit(f"[SUCCESS] Retrieved {len(emails)} emails")
			
			# STEP 6: Display email summary (first 10 emails)
			# Why? Provide quick overview of retrieved emails without overwhelming console output
			summary_lines = [f"Email Retrieval Summary - {len(emails)} emails found:"]
			for i, email in enumerate(emails[:10], 1):  # Show first 10 in summary
				subject = email.get('subject', 'No Subject')
				received = email.get('receivedDateTime', 'Unknown')
				from_addr = email.get('from', {}).get('emailAddress', {}).get('address', 'Unknown')
				summary_lines.append(f"{i}. {subject} (From: {from_addr}, Received: {received})")
			
			if len(emails) > 10:
				summary_lines.append(f"... and {len(emails) - 10} more emails")
			
			summary_text = "\n".join(summary_lines)
			emit("[EMAIL SUMMARY]\n" + summary_text)
			
			# STEP 7: Store emails to local JSON file if store_local=True
			# Why? Persist email data for future analysis without re-fetching from Graph API
			if store_local:
				emit("[STORAGE] Storing emails to local file...")
				try:
					file_path, store_log = store_emails_to_local(emails, prefix="emails", emitter=emitter)
					
					if store_log:
						for line in store_log.splitlines():
							if line not in emit_util.get_messages():
								emit_util.messages.append(line)
					
					if file_path:
						answer_fragments.append(file_path)
					else:
						answer_fragments.append("Failed to store emails locally")
				except Exception as exc:
					emit(f"[STORAGE ERROR] Failed to store emails: {exc}")
					answer_fragments.append(f"Storage failed: {exc}")
			else:
				import json
				email_content = json.dumps(emails, indent=2, ensure_ascii=False)
				answer_fragments.append(email_content)
			
			# STEP 8: Optionally analyze emails with AI agent if analyze_with_agent=True
			# Why? Provides intelligent email analysis and insights beyond raw email data
			if analyze_with_agent:
				emit("[AGENT ANALYSIS] Processing emails through Azure AI agent...")
				try:
					agent_result = run_email_agent_analysis(emails_retrieved, emitter=emitter, return_mode="both", tracing_mode=tracing_mode)
					if isinstance(agent_result, dict):
						if agent_result.get("answer"):
							if store_local:
								answer_fragments.append(f"\n\nAgent Analysis:\n{agent_result['answer']}")
							else:
								answer_fragments[-1] = agent_result["answer"]
						for line in agent_result.get("log", "").splitlines():
							if line not in emit_util.get_messages():
								emit_util.messages.append(line)
					else:
						if store_local:
							answer_fragments.append(f"\n\nAgent Analysis:\n{agent_result}")
						else:
							answer_fragments[-1] = str(agent_result)
				except Exception as exc:
					emit(f"[AGENT ERROR] Agent analysis failed: {exc}")
					answer_fragments.append(f"Agent analysis failed: {exc}")
			
		else:
			emit("[INFO] No emails found for the specified date range")
			answer_fragments.append("No emails found for the specified date range")
			
	except Exception as exc:
		emit(f"[ERROR] Email retrieval failed: {exc}")

	# STEP 9: Format return payload based on return_mode
	# Why? Flexible output format - answer only, logs only, or both
	answer_joined = "\n\n".join(answer_fragments)
	log_joined = emit_util.get_log()

	if return_mode == "both":
		payload = {"output_text": answer_joined or log_joined, "answer": answer_joined, "log": log_joined}
	elif return_mode == "answer":
		payload = answer_joined if answer_joined else log_joined
	else:
		payload = log_joined
	
	return payload


if __name__ == "__main__":
	
    utc_offset = int(os.getenv("UTC_OFFSET", "8"))
    email_start = os.getenv("EMAIL_STARTTIME", "2025-09-01T00:00:00")
    email_end = os.getenv("EMAIL_ENDTIME", "2025-09-30T23:59:59")
    
    # Parse and apply offset
    def offset_to_utc(dtstr, offset):
        try:
            dt0 = datetime.fromisoformat(dtstr)
            dt_utc = dt0 - timedelta(hours=offset)
            return dt_utc.strftime("%Y-%m-%dT%H:%M:%SZ")
        except Exception:
            return dtstr + "Z" if not dtstr.endswith("Z") else dtstr
    
    start_default = offset_to_utc(email_start, utc_offset)
    end_default = offset_to_utc(email_end, utc_offset)
    
    run_check_emails(start_default, end_default, analyze_with_agent=False, store_local=True, return_mode="both")