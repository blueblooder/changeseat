"""URL content extraction utility with multi-format support.

This module provides robust web content fetching capabilities with support
for HTML, PDF, and image content types, including JavaScript-rendered pages.

===== Purpose =====

1. Multi-Format Content Extraction:
   - HTML: Parse and extract text from web pages
   - PDF: Extract text from PDF documents
   - Images: Download and save image files

2. JavaScript Rendering:
   - Detect placeholder content (e.g., "Just a moment...")
   - Fall back to Selenium for JavaScript-rendered pages
   - Handle cookie consent banners automatically

3. SSL/TLS Compatibility:
   - Custom SSL adapter for legacy server support
   - Handles SSL renegotiation issues
   - Compatible with older web servers

===== Architecture =====

Components:
- SSLAdapter: Custom HTTPAdapter for legacy SSL support
- extract_content_from_url(): Main extraction function
- handle_cookie_banner(): Selenium helper for cookie consent

Content Type Handling:
- text/html → BeautifulSoup parsing (or Selenium if JS-rendered)
- application/pdf → PyMuPDF extraction
- image/* → Download to imgoutput directory

===== Usage Examples =====

```python
# Extract text from HTML page
text, content_type, status_code = extract_content_from_url("https://example.com/article")
print(text)  # Extracted text content

# Extract text from PDF
pdf_text, content_type, status = extract_content_from_url("https://example.com/doc.pdf")

# Download image
img_path, content_type, status = extract_content_from_url("https://example.com/image.jpg")
# Image saved to imgoutput/image.jpg
```

===== Dependencies =====

Required:
- requests: HTTP requests
- beautifulsoup4: HTML parsing
- selenium: JavaScript rendering
- webdriver-manager: Chrome driver management

Optional:
- PyMuPDF (fitz): PDF text extraction
  If not available: Returns error message for PDF URLs

===== Error Handling =====

SSL Errors:
- Returns: "SSL error: <details>", None, None
- Common causes: Certificate issues, legacy servers

PDF Errors:
- Returns: "PDF parse error: <details>", content_type, status_code
- Common causes: Corrupted PDF, unsupported PDF features

Unsupported Content:
- Returns: "Unsupported content type: <type>", content_type, status_code
- For content types other than HTML, PDF, or image

===== Performance Considerations =====

HTML Parsing:
- Fast: BeautifulSoup in-memory parsing (~100ms)
- Slow: Selenium for JS pages (~3-5 seconds)

PDF Extraction:
- Depends on PDF size (1-2 seconds per MB)
- Memory intensive for large PDFs

Image Download:
- Network speed dependent
- Files saved to disk (imgoutput directory)

===== SSL/TLS Configuration =====

Why Custom SSL Adapter?
- Some servers require legacy TLS renegotiation
- Standard requests library doesn't support this
- OP_LEGACY_SERVER_CONNECT flag enables compatibility

Security Note:
- Legacy SSL support reduces security
- Only use for trusted sources
- Consider updating servers instead of enabling legacy support
"""

import requests
import sys
from dotenv import load_dotenv
from bs4 import BeautifulSoup

# Try to import PyMuPDF for PDF extraction
# Graceful degradation: If not available, PDF extraction returns error message
try:
    import fitz  # PyMuPDF
    _FITZ_AVAILABLE = True
except Exception as e:  # noqa: BLE001
    # Module not available - PDF URLs will return error message
    fitz = None  # type: ignore
    _FITZ_AVAILABLE = False
    _FITZ_ERROR = e

from io import BytesIO
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from selenium.common.exceptions import NoSuchElementException
import ssl
from requests.adapters import HTTPAdapter
from urllib3.poolmanager import PoolManager
from urllib3.util.ssl_ import create_urllib3_context

# Default URL for CLI testing
# BBC News article used as representative test case
DEFAULT_URL = "https://www.bbc.com/news/world-us-canada-66231820"

class SSLAdapter(HTTPAdapter):
    """Custom HTTP adapter with legacy SSL/TLS support.
    
    Purpose:
    - Enable connections to servers requiring legacy TLS renegotiation
    - Work around SSL compatibility issues with older servers
    - Provide custom SSL context to requests library
    
    Why Needed?
    - Some servers don't support modern TLS negotiation
    - Standard requests library fails with these servers
    - Custom adapter injects SSL context into connection pool
    
    Security Implications:
    - Reduces security by enabling legacy protocols
    - Should only be used for trusted sources
    - Consider server upgrades instead when possible
    
    Architecture:
    - Extends requests.adapters.HTTPAdapter
    - Overrides init_poolmanager to inject SSL context
    - Used via session.mount('https://', SSLAdapter(...))
    
    Usage:
    ```python
    ssl_context = ssl.create_default_context()
    ssl_context.options |= ssl.OP_LEGACY_SERVER_CONNECT
    session = requests.Session()
    session.mount('https://', SSLAdapter(ssl_context=ssl_context))
    response = session.get('https://legacy-server.com')
    ```
    """
    
    def __init__(self, ssl_context=None, **kwargs):
        """Initialize SSL adapter with custom context.
        
        Args:
            ssl_context: Custom SSL context for TLS configuration.
                         If None, creates default urllib3 context.
            **kwargs: Additional arguments passed to HTTPAdapter.__init__
        
        Why Store SSL Context?
        - Used in init_poolmanager to configure connection pool
        - Persists across multiple requests
        - Allows reuse without recreating context
        """
        # Store SSL context or create default
        self.ssl_context = ssl_context or create_urllib3_context()
        # Initialize parent HTTPAdapter
        super().__init__(**kwargs)

    def init_poolmanager(self, *args, **kwargs):
        """Initialize connection pool with custom SSL context.
        
        Called by requests when creating connection pool.
        Injects our custom SSL context into pool configuration.
        
        Args:
            *args: Positional arguments for pool manager
            **kwargs: Keyword arguments for pool manager
        
        Returns:
            Configured pool manager with custom SSL context
        
        Why Override This Method?
        - PoolManager initialization is where SSL context is set
        - This is the hook point for custom SSL configuration
        - Parent method creates default context, we inject ours
        """
        # Inject our SSL context
        kwargs['ssl_context'] = self.ssl_context
        # Call parent to create pool with our context
        return super().init_poolmanager(*args, **kwargs)

# Create a custom SSL context that allows legacy renegotiation
# Why? Some servers (especially older ones) require this for TLS handshake
ssl_context = ssl.create_default_context()

# Enable legacy server connection support
# OP_LEGACY_SERVER_CONNECT: Allows unsafe legacy renegotiation
# Needed for servers that don't support RFC 5746 secure renegotiation
ssl_context.options |= ssl.OP_LEGACY_SERVER_CONNECT

# Create persistent session with custom SSL adapter
# Why session? Reuses connections, improves performance
# Why mount to https://? Applies adapter to all HTTPS requests
session = requests.Session()
session.mount('https://', SSLAdapter(ssl_context=ssl_context))

def extract_content_from_url(url):
    """Extract text content from URL with multi-format support.
    
    Main content extraction function supporting HTML, PDF, and image formats.
    Automatically detects content type and applies appropriate extraction method.
    
    Content Type Handling:
    1. text/html:
       - Parse with BeautifulSoup for static content
       - Fall back to Selenium for JavaScript-rendered pages
       - Automatically handle cookie consent banners
    
    2. application/pdf:
       - Extract text using PyMuPDF (if available)
       - Return error message if PyMuPDF not installed
    
    3. image/*:
       - Download and save to imgoutput directory
       - Return local file path as content
    
    Args:
        url (str): The URL to extract content from.
                   Supports: HTTP/HTTPS protocols
                   Formats: HTML, PDF, image files
    
    Returns:
        tuple: (content, content_type, status_code)
            content (str): Extracted text, error message, or file path
            content_type (str): MIME type from response headers
            status_code (int): HTTP response code
    
    Return Values by Content Type:
    - HTML: (extracted_text, "text/html", 200)
    - PDF: (pdf_text, "application/pdf", 200)
    - Image: (local_file_path, "image/jpeg", 200)
    - SSL Error: ("SSL error: <details>", None, None)
    - Unsupported: ("Unsupported content type: <type>", content_type, code)
    
    Example Usage:
    ```python
    # Extract HTML article
    text, content_type, status = extract_content_from_url("https://news.com/article")
    if status == 200:
        print(f"Article text: {text}")
    
    # Extract PDF document
    pdf_text, _, _ = extract_content_from_url("https://example.com/report.pdf")
    
    # Download image
    img_path, _, _ = extract_content_from_url("https://example.com/photo.jpg")
    # Image saved to imgoutput/photo.jpg
    ```
    
    Error Handling:
    - SSL errors: Returns error message tuple, logs exception
    - PDF parse errors: Returns error message with exception details
    - Unsupported types: Returns descriptive error message
    
    Performance Notes:
    - HTML (static): ~100-500ms
    - HTML (JavaScript): ~3-5 seconds (Selenium overhead)
    - PDF: ~1-2 seconds per MB
    - Images: Network speed dependent
    
    Dependencies:
    - Required: requests, beautifulsoup4, selenium
    - Optional: PyMuPDF (for PDF extraction)
    
    Thread Safety:
    - NOT thread-safe (uses global session object)
    - For multi-threading: Create separate sessions per thread
    """
    # Set User-Agent to mimic browser
    # Why? Some sites block requests without proper User-Agent
    # This string identifies as Edge browser on Windows
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36 Edg/117.0.2045.43'}
    
    # Make HTTP GET request
    try:
        response = session.get(url, headers=headers)
    except requests.exceptions.SSLError as e:
        # SSL/TLS handshake failed
        # Common causes: Certificate issues, protocol mismatch, legacy server
        return f"SSL error: {str(e)}", None, None

    # Extract response metadata
    # Content-Type header tells us what format the response is
    # .lower() ensures case-insensitive comparison
    content_type = response.headers.get('Content-Type', '').lower()
    response_code = response.status_code

    # Function to handle cookie banners dynamically
    def handle_cookie_banner(driver):
        """Automatically accept cookie consent banners.
        
        Uses XPath to find and click cookie acceptance buttons.
        Common button text patterns: "accept", "allow", "cookie"
        
        Why Needed?
        - Cookie banners block content access
        - Required for GDPR-compliant EU websites
        - Prevents Selenium from seeing actual page content
        
        Detection Strategy:
        - Search for buttons with case-insensitive text matching
        - Patterns: "accept", "allow", "cookie"
        - Uses XPath translate() for case-insensitive search
        
        Args:
            driver: Selenium WebDriver instance
        
        Side Effects:
            - Clicks accept button if found
            - Prints status message to console
            - Modifies page state (banner dismissed)
        
        Error Handling:
            - NoSuchElementException: No banner found (normal case)
            - Prints message and continues without error
        
        XPath Explanation:
        //button[contains(translate(text(), 'UPPER', 'lower'), 'accept')]
        - //button: Find all button elements
        - contains(...): Check if text contains pattern
        - translate(...): Convert text to lowercase for case-insensitive match
        - Multiple patterns with 'or': Accept any matching pattern
        """
        try:
            # Use XPath to find buttons with text containing "accept", "allow", or "cookie" (case-insensitive)
            # translate() function converts uppercase to lowercase for case-insensitive matching
            # Why this approach? Cookie banners use various languages and capitalizations
            accept_button = driver.find_element(
                By.XPATH,
                "//button[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), 'accept') or contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), 'allow') or contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), 'cookie')]"
            )
            accept_button.click()
            print("Cookie banner accepted.")
        except NoSuchElementException:
            # No cookie banner found - this is normal for many sites
            # Not an error, just means site doesn't have cookie consent
            print("No cookie banner found.")

    if 'text/html' in content_type:
        # ===== HTML CONTENT EXTRACTION =====
        
        # STEP 1: Parse HTML content with BeautifulSoup
        # Why BeautifulSoup? Robust HTML parser, handles malformed HTML
        # 'html.parser': Built-in parser, no external dependencies
        soup = BeautifulSoup(response.content, 'html.parser')
        
        # Extract text from parsed HTML
        # separator=' ': Join text blocks with spaces (preserve word boundaries)
        # strip=True: Remove leading/trailing whitespace from each text block
        text = soup.get_text(separator=' ', strip=True)

        # STEP 2: Check for JavaScript-rendered content placeholder
        # Some sites (e.g., Cloudflare protected) show placeholder until JS loads
        # Detection: Look for specific placeholder text in extracted content
        # Why "Just a moment..."? Common Cloudflare waiting page message
        if "Just a moment... Enable JavaScript and cookies to continue" in text:
            # Fall back to Selenium for JavaScript rendering
            # Selenium: Automated browser, executes JavaScript, waits for content
            
            # Configure Chrome options for headless operation
            # Why headless? No GUI needed, faster, works on servers without display
            options = Options()
            options.add_argument('--headless')        # Run without browser window
            options.add_argument('--disable-gpu')     # Disable GPU acceleration (not needed headless)
            options.add_argument('--no-sandbox')      # Required for Docker/containerized environments

            # Create Chrome WebDriver with auto-managed driver
            # ChromeDriverManager().install(): Automatically downloads correct Chrome driver version
            # Why? Avoids manual driver version management
            # 'with' statement: Ensures driver cleanup (quit) even if exception occurs
            with webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options) as driver:
                # Navigate to URL
                # driver.get(): Blocks until page load event fires
                driver.get(url)

                # Handle cookie consent banner
                # Must do before extracting content (banner blocks page)
                handle_cookie_banner(driver)

                # Extract the page content after handling cookies
                # By.TAG_NAME: Find element by HTML tag name
                # "body": Main content container
                # .text: Extract visible text (JavaScript-rendered content now available)
                text = driver.find_element(By.TAG_NAME, "body").text

        # Return extracted text with metadata
        return text, content_type, response_code

    elif 'application/pdf' in content_type:
        # ===== PDF CONTENT EXTRACTION =====
        
        # Check if PyMuPDF available
        # Why check? PDF extraction is optional dependency
        if not _FITZ_AVAILABLE:
            # Return error message with exception details
            # Helps user understand what's missing
            return f"PyMuPDF not available for PDF extraction: {_FITZ_ERROR}", content_type, response_code
        
        # Load PDF from response content into memory stream
        # Why BytesIO? Avoids writing PDF to disk (faster, cleaner)
        # response.content: Raw binary PDF data
        pdf_stream = BytesIO(response.content)
        
        try:
            # Open PDF document from memory stream
            # fitz.open(): PyMuPDF document loader
            # stream=...: Read from BytesIO instead of file path
            # filetype="pdf": Explicit format (could auto-detect, but explicit is clearer)
            doc = fitz.open(stream=pdf_stream, filetype="pdf")
            
            # Extract text from all pages
            # Generator expression: page.get_text() for each page
            # "".join(): Concatenate all page texts
            # Why join? Single string easier to work with than list
            text = "".join(page.get_text() for page in doc)
        except Exception as e:  # noqa: BLE001
            # PDF parsing failed
            # Common causes: Corrupted PDF, unsupported PDF features, encrypted PDF
            return f"PDF parse error: {e}", content_type, response_code
        
        # Return extracted PDF text
        return text, content_type, response_code

    elif 'image/' in content_type:
        # ===== IMAGE DOWNLOAD AND SAVE =====
        
        import os
        from urllib.parse import urlparse
        
        # Create output directory for images
        # Why separate directory? Organize downloads, avoid cluttering workspace
        img_dir = os.path.join(os.getcwd(), 'imgoutput')
        os.makedirs(img_dir, exist_ok=True)  # exist_ok=True: Don't error if exists
        
        # Create a filename from the URL or fallback to a generic name
        # Why extract from URL? Preserves original filename if available
        parsed_url = urlparse(url)
        filename = os.path.basename(parsed_url.path)
        
        if not filename:
            # URL has no filename (e.g., https://example.com/api/image)
            # Generate filename from status code and content type
            # Why include status? Helps debug download issues
            # content_type.split("/")[-1]: Extract file extension (e.g., "jpeg" from "image/jpeg")
            filename = f'image_{response_code}.{content_type.split("/")[-1]}'
        
        # Build full path to save image
        img_path = os.path.join(img_dir, filename)
        
        # Write image binary data to file
        # 'wb': Write binary mode (required for image data)
        # response.content: Raw image bytes
        with open(img_path, 'wb') as f:
            f.write(response.content)
        
        # Image saved to disk; OCR removed per request.
        # Return the local image path as the content so callers can access the saved file.
        # Why return path? Caller knows where to find downloaded image
        return img_path, content_type, response_code

    else:
        # ===== UNSUPPORTED CONTENT TYPE =====
        # Content type not HTML, PDF, or image
        # Examples: application/json, video/mp4, application/zip
        # Return error message with content type for debugging
        return f"Unsupported content type: {content_type}", content_type, response_code


# If run as a script, keep old CLI behavior
# Enables command-line testing: python fetchurl.py <url>
if __name__ == "__main__":
    # Get URL from command-line argument or use default
    # sys.argv[1]: First command-line argument (script name is argv[0])
    # .strip(): Remove whitespace from argument
    # Fallback: Use DEFAULT_URL if no argument or empty argument
    targeturl = sys.argv[1] if len(sys.argv) > 1 and sys.argv[1].strip() else DEFAULT_URL
    
    # Extract and print content
    # Returns tuple: (content, content_type, status_code)
    # print() displays all three values
    print(extract_content_from_url(targeturl))