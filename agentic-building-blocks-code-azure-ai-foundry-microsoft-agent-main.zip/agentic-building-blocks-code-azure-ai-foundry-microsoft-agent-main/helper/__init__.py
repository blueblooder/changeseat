"""Helper package for utility functions and external service integrations.

This package contains helper modules that provide foundational services
and utilities used by agents, workflows, and the main application.

Module Categories:

1. Configuration & Tracing:
   - agent_config_loader.py: Loads agent configurations from YAML files
   - agent_trace_configurator.py: Configures tracing for Agent SDK
   - unified_trace_manager.py: Unified tracing setup for both Agent SDK and agent_framework
   - trace_exporters.py: Custom OpenTelemetry exporters (console, file, custom processors)
   - otel_collector.py: Collects and formats traces for UI display

2. External Service Integrations:
   - graphapi.py: Microsoft Graph API client (email, calendar, users)
   - gettoken.py: Azure AD token acquisition and management
   - logicappemail.py: Email sending via Azure Logic App
   - text2speech.py: Text-to-speech conversion using Azure Cognitive Services

3. Search & Web Tools:
   - bingsearch.py: Bing Web Search API integration (tool function)
   - yahoosearch.py: Yahoo Search scraping (alternative to Bing)
   - headlesssearch.py: Headless browser-based Google search (Selenium)
   - gcptxtsearch.py: Google Programmable Search Engine API
   - fetchurl.py: URL content fetching and processing

4. Data Persistence:
   - storeemail.py: Local storage of email data (JSON files)
   - storeotel.py: Local storage of OpenTelemetry traces (JSON files)

5. Utilities:
   - emitter.py: Progress/status message emission for UI feedback
   - tokenmanager.py: Token counting and management for LLM contexts

Design Principles:
- Single Responsibility: Each module has one clear purpose
- External Dependencies: Encapsulates third-party API interactions
- Error Handling: Graceful degradation when services unavailable
- Observability: Consistent logging and tracing across all helpers
- Reusability: Functions designed for use across agents and workflows

Why "Helper" Package?
These modules are "helpers" in that they support the main functionality
(agents, workflows) but don't implement core business logic themselves.
They handle infrastructure concerns: API calls, file I/O, configuration,
tracing, etc.
"""
