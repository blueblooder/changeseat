# PowerShell script to recursively remove all __pycache__ folders

Write-Host "Searching for __pycache__ folders..." -ForegroundColor Cyan

# Get all __pycache__ directories recursively
$pycacheFolders = Get-ChildItem -Path . -Directory -Recurse -Force -Filter "__pycache__" -ErrorAction SilentlyContinue

if ($pycacheFolders.Count -eq 0) {
    Write-Host "No __pycache__ folders found." -ForegroundColor Green
    exit 0
}

Write-Host "Found $($pycacheFolders.Count) __pycache__ folder(s):" -ForegroundColor Yellow
$pycacheFolders | ForEach-Object { Write-Host "  - $($_.FullName)" -ForegroundColor Gray }

# Remove each __pycache__ folder
$removedCount = 0
foreach ($folder in $pycacheFolders) {
    try {
        Remove-Item -Path $folder.FullName -Recurse -Force
        Write-Host "Removed: $($folder.FullName)" -ForegroundColor Green
        $removedCount++
    }
    catch {
        Write-Host "Failed to remove: $($folder.FullName) - $($_.Exception.Message)" -ForegroundColor Red
    }
}

Write-Host "`nCleanup complete! Removed $removedCount folder(s)." -ForegroundColor Cyan
