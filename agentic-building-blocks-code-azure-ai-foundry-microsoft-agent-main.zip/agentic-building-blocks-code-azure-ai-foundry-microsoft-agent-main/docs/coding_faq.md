# Coding FAQ for Developers

This FAQ covers common questions and patterns you'll encounter when working with this Python project. Each answer includes the "why" behind the concept, visual examples, and practical guidance.

---

## Table of Contents
- [Python Module Imports and Path Management](#python-module-imports-and-path-management)
- [More FAQs Coming Soon](#more-faqs-coming-soon)

---

## Python Module Imports and Path Management

### Q: Why do some Python files have `sys.path.insert(0, repo_root)` at the top, but `main.py` doesn't?

**Short Answer:**  
Files in subdirectories (like `agent/`, `helper/`, `workflow/`) need to add the repo root to Python's module search path so they can import from other packages when run directly. Root-level files like `main.py` don't need this because they're already at the repo root.

---

### The Problem This Solves

When you run a Python file directly, Python automatically adds **the directory containing that file** to `sys.path[0]` (the module search path). This creates a problem for files in subdirectories:

```
repo_root/
├── main.py          ← sys.path[0] = repo_root ✅
├── helper/
│   ├── __init__.py
│   └── emitter.py
└── agent/
    └── summariseURL.py  ← sys.path[0] = agent/ ❌
```

**What happens when you run:**
- `python main.py` → Python sees `helper/` as a sibling directory → `from helper.emitter import ...` works ✅
- `python agent/summariseURL.py` → Python's working context is inside `agent/` → Cannot find `helper/` → ImportError ❌

---

### The Solution Pattern

**Files in subdirectories** use this pattern at the top:

```python
# agent/summariseURL.py
import os
import sys

if __name__ == "__main__":
    repo_root = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
    if repo_root not in sys.path:
        sys.path.insert(0, repo_root)

# Now local imports work!
from helper.emitter import create_emitter
from helper.fetchurl import extract_content_from_url
```

**Root-level files** don't need this:

```python
# main.py (at repo root)
import streamlit as st
from dotenv import load_dotenv

# These imports work directly - no path setup needed
from helper.emitter import create_streamlit_emitter
from apps.config import AppConfig
```

---

### Breaking Down the Path Setup Code

Let's examine each line and understand **why** it's needed:

```python
if __name__ == "__main__":
```
**Why?** Only runs when the file is executed directly (not when imported as a module). This prevents the path manipulation from running when another file imports this module.

```python
repo_root = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
```
**What it does:**
1. `os.path.dirname(__file__)` → Gets the directory containing the current file (e.g., `agent/`)
2. `os.path.join(..., os.pardir)` → Navigates up one level using `os.pardir` (parent directory)
3. `os.path.abspath(...)` → Converts to absolute path (e.g., `C:/Github_Repo/project/`)

**Why?** We need the absolute path to the repo root to add it to Python's search path.

```python
if repo_root not in sys.path:
    sys.path.insert(0, repo_root)
```
**Why?** 
- Checks if repo root is already in the path (prevents duplicates)
- `insert(0, ...)` adds it to the **front** of the search path so our modules are found first
- This allows `from helper.emitter import ...` to work correctly

---

### Why is Placement Critical?

The path setup **must run before any local imports**:

❌ **WRONG - This will fail:**
```python
# agent/summariseURL.py
import os
import sys
from helper.emitter import create_emitter  # ❌ ImportError! helper not found yet

if __name__ == "__main__":
    repo_root = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
    if repo_root not in sys.path:
        sys.path.insert(0, repo_root)  # Too late!
```

✅ **CORRECT - Path setup happens first:**
```python
# agent/summariseURL.py
import os
import sys

if __name__ == "__main__":
    repo_root = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
    if repo_root not in sys.path:
        sys.path.insert(0, repo_root)

from helper.emitter import create_emitter  # ✅ Now this works!
```

---

### Visual Example: How Python Finds Modules

```
repo_root/
├── main.py
├── helper/
│   ├── __init__.py
│   └── emitter.py
├── agent/
│   ├── __init__.py
│   └── summariseURL.py
└── workflow/
    ├── __init__.py
    └── blastwebsearch.py
```

**When you run `python main.py`:**
```
sys.path[0] = "C:/Github_Repo/project/"

Python looks for modules in:
  → C:/Github_Repo/project/helper/ ✅ Found!
  → C:/Github_Repo/project/agent/ ✅ Found!
  → C:/Github_Repo/project/workflow/ ✅ Found!
```

**When you run `python agent/summariseURL.py` WITHOUT path setup:**
```
sys.path[0] = "C:/Github_Repo/project/agent/"

Python looks for modules in:
  → C:/Github_Repo/project/agent/helper/ ❌ Not found!
  → Looks in other sys.path locations... ❌ Still not found!
  → ImportError!
```

**When you run `python agent/summariseURL.py` WITH path setup:**
```
# After path setup runs:
sys.path[0] = "C:/Github_Repo/project/"  # <-- We inserted this!
sys.path[1] = "C:/Github_Repo/project/agent/"  # <-- Original path moved down

Python looks for modules in:
  → C:/Github_Repo/project/helper/ ✅ Found!
  → C:/Github_Repo/project/agent/ ✅ Found!
  → C:/Github_Repo/project/workflow/ ✅ Found!
```

---

### When Do You Need This Pattern?

**✅ Use this pattern when:**
- Your file is in a subdirectory (`agent/`, `helper/`, `workflow/`, etc.)
- The file can be run directly as a script
- The file imports modules from other packages in your project

**❌ Don't use this pattern when:**
- Your file is at the repo root level
- Your file only uses standard library imports (no local project imports)
- Your file is only ever imported, never run directly

---

### Quick Reference: Files in This Project

| File Location | Needs Path Setup? | Why? |
|---------------|-------------------|------|
| `main.py` | ❌ No | Already at repo root |
| `agent/summariseURL.py` | ✅ Yes | In subdirectory, runs directly |
| `agent/emailwriter.py` | ✅ Yes | In subdirectory, runs directly |
| `workflow/blastwebsearch.py` | ✅ Yes | In subdirectory, runs directly |
| `helper/emitter.py` | ❌ Usually No | Typically only imported, not run directly |

---

### Best Practices Summary

1. **Position Matters:** Place path setup **after standard imports** but **before local imports**
2. **Only When Needed:** Only use `if __name__ == "__main__":` guard for path manipulation
3. **Consistency:** Use the same pattern across all subdirectory files for maintainability
4. **Documentation:** Comment why you're doing this for future developers

**Example with good commenting:**

```python
import os
import sys

# Path setup for direct execution from subdirectory
# This allows imports like 'from helper.emitter import ...' to work
if __name__ == "__main__":
    repo_root = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
    if repo_root not in sys.path:
        sys.path.insert(0, repo_root)

from helper.emitter import create_emitter
```

---

## More FAQs Coming Soon

Have a question? Add it to this FAQ! This document will grow as we encounter more common patterns and questions.

---

**Last Updated:** November 12, 2025
