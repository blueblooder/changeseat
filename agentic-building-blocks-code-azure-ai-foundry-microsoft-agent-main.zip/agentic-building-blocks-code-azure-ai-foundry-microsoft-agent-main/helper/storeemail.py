"""Email storage utility for Azure Blob Storage and local filesystem.

This module provides functions to store email data in JSON format to either
Azure Blob Storage or local filesystem, with automatic timestamp-based naming.

===== Purpose =====

1. Azure Blob Storage:
   - Upload email JSON arrays to cloud storage
   - Support connection string or managed identity authentication
   - Automatic container creation if needed
   
2. Local Filesystem:
   - Save emails to local directory (fallback/development)
   - Configurable output directory via environment variable
   - Creates directory structure automatically

3. Common Features:
   - Timestamp-based filenames (sortable, unique)
   - UTC offset support for local time
   - Detailed logging via emitter pattern
   - Graceful error handling with log preservation

===== Architecture =====

Storage Functions:
- store_emails_to_blob(): Upload to Azure Blob Storage
- store_emails_to_local(): Save to local filesystem

Both functions return: (url/path, log)
- Success: (blob_url or file_path, complete_log)
- Failure: (None, error_log)

Authentication Methods (Azure Blob):
1. Connection String (BLOB_CONNECTION_STRING):
   - Direct connection with account key
   - Simple, good for development
   
2. Managed Identity (BLOB_ACCOUNT_URL + AzureCliCredential):
   - Uses Azure CLI credentials or managed identity
   - Secure, no secrets in code
   - Requires az login or managed identity setup

===== Filename Pattern =====

Format: {prefix}_YYYYMMDD-HHMMSS.json

Examples:
- outlook_20251110-143052.json
- gmail_20251110-143052.json

Why This Pattern?
- Sortable: Lexicographic sort = chronological sort
- Unique: Timestamp ensures no conflicts (unless <1 second apart)
- Prefix: Distinguishes email sources (outlook, gmail, etc.)
- Filesystem-safe: No spaces or special characters

===== UTC Offset Support =====

Environment Variable: UTC_OFFSET
- Default: 0 (UTC)
- Examples: 8 (UTC+8), -5 (UTC-5)

Why?
- Filenames reflect local time (easier to identify)
- Blob storage uses UTC internally
- Display time matches user's timezone

Example:
```python
# User in UTC+8, current UTC time: 2025-11-10 06:30:52
# With UTC_OFFSET=8:
# Filename: outlook_20251110-143052.json (local time 14:30:52)
```

===== Environment Variables =====

Azure Blob Storage:
- BLOB_CONNECTION_STRING: Full connection string (optional)
- BLOB_ACCOUNT_URL: Storage account URL (required if no connection string)
- BLOB_CONTAINER: Container name (default: "emails")

Local Storage:
- EMAIL_LOCAL_FOLDER: Output directory (default: "emails_local")

Timezone:
- UTC_OFFSET: Hours offset from UTC (default: 0)

===== Usage Examples =====

```python
# Azure Blob Storage
emails = [{"id": "1", "subject": "Test"}]
blob_url, log = store_emails_to_blob(emails, prefix='outlook')
if blob_url:
    print(f"Uploaded to: {blob_url}")
else:
    print(f"Failed: {log}")

# Local filesystem
file_path, log = store_emails_to_local(emails, prefix='gmail')
if file_path:
    print(f"Saved to: {file_path}")

# With custom emitter (Streamlit)
import streamlit as st
placeholder = st.empty()
from helper.emitter import create_streamlit_emitter
emitter = create_streamlit_emitter(placeholder)

url, log = store_emails_to_blob(emails, emitter=emitter.emit)
# Progress shown in Streamlit UI in real-time
```

===== Error Handling =====

Azure Blob Errors:
- Missing credentials: Returns (None, error_log)
- Network failures: Returns (None, error_log)
- Authentication failures: Returns (None, error_log)

Local File Errors:
- Directory creation failure: Returns (None, error_log)
- File write failure: Returns (None, error_log)
- Permission issues: Returns (None, error_log)

All errors logged via emitter for UI display.

===== Performance Considerations =====

Azure Blob:
- Network dependent (~100-500ms for small files)
- Parallel uploads not implemented (sequential)
- Consider batching for large email sets

Local File:
- Fast (~10-50ms for typical email sets)
- Disk I/O bound
- No size limits (besides disk space)

===== Dependencies =====

Required:
- azure.storage.blob: Azure Blob Storage SDK
- azure.identity: Authentication (for managed identity)
- python-dotenv: Environment variable loading

Optional:
- helper.emitter: Logging and UI updates (uses console if not available)
"""

import os
import json
from datetime import datetime, timedelta
from typing import List, Dict, Tuple, Optional, Callable
from azure.storage.blob import BlobServiceClient
from dotenv import load_dotenv
from helper.emitter import create_emitter

# Load environment variables from .env file
# Must call before accessing os.getenv()
# Why at module level? Ensures vars loaded before function calls
load_dotenv()

# Environment variables for Azure Blob Storage
# ACCOUNT_URL: Storage account endpoint (e.g., https://mystorageaccount.blob.core.windows.net)
# CONTAINER: Target container name (default: "emails")
# CONNECTION_STRING: Full connection string (alternative to ACCOUNT_URL + credential)
ACCOUNT_URL = os.getenv('BLOB_ACCOUNT_URL')
CONTAINER = os.getenv('BLOB_CONTAINER', 'emails')
CONNECTION_STRING = os.getenv('BLOB_CONNECTION_STRING')


def store_emails_to_blob(
    emails: List[Dict], 
    prefix: str = 'outlook',
    emitter: Optional[Callable[[str], None]] = None
) -> Tuple[str, str]:
    """Store list of email JSON objects into Azure Blob Storage as a single JSON file.

    Uploads email data to Azure Blob Storage with automatic timestamp-based naming.
    Supports both connection string and managed identity authentication.
    
    Execution Flow:
    1. Initialize emitter for logging
    2. Authenticate with Azure (connection string or managed identity)
    3. Get/create container
    4. Generate timestamped blob name
    5. Upload JSON payload
    6. Return blob URL and log
    
    Args:
        emails: List of email dictionaries to store.
                Each email should be JSON-serializable dict.
                Example: [{"id": "1", "subject": "Test", "body": "..."}]
                Can be empty list (creates empty JSON array file).
        
        prefix: Filename prefix for blob name (default: 'outlook').
                Used to distinguish email sources.
                Examples: 'outlook', 'gmail', 'exchange'
        
        emitter: Optional callback function for progress messages.
                 Signature: (str) -> None
                 If None, prints to console.
                 Used for UI updates (e.g., Streamlit).
    
    Returns:
        Tuple[str, str]: (blob_url, log)
            blob_url: Full URL to uploaded blob (None if failed)
                      Example: "https://account.blob.core.windows.net/emails/outlook_20251110-143052.json"
            log: Complete log of operation (success or error messages)
                 Useful for displaying operation details to user
    
    Authentication Methods:
    
    1. Connection String (Priority 1):
       - Environment: BLOB_CONNECTION_STRING
       - Format: "DefaultEndpointsProtocol=https;AccountName=...;AccountKey=...;EndpointSuffix=core.windows.net"
       - Use case: Development, testing
       - Security: Contains account key, store securely
    
    2. Managed Identity (Priority 2):
       - Environment: BLOB_ACCOUNT_URL
       - Requires: Azure CLI login (az login) or managed identity
       - Use case: Production, secure environments
       - Security: No secrets in code/config
    
    Error Handling:
    - Missing credentials: Returns (None, error_log)
    - Network failure: Exception propagated (caller handles)
    - Container creation failure: Ignored (likely already exists)
    - Upload failure: Exception propagated
    
    Blob Naming:
    - Pattern: {prefix}_YYYYMMDD-HHMMSS.json
    - Timezone: Uses UTC + UTC_OFFSET environment variable
    - Example: outlook_20251110-143052.json
    
    Example Usage:
    ```python
    # Simple usage with defaults
    emails = get_outlook_emails()
    blob_url, log = store_emails_to_blob(emails)
    print(f"Uploaded to: {blob_url}")
    
    # With custom prefix and emitter
    from helper.emitter import create_emitter
    emitter = create_emitter(lambda msg: print(f"[CUSTOM] {msg}"))
    url, log = store_emails_to_blob(emails, prefix='gmail', emitter=emitter.emit)
    
    # Error handling
    url, log = store_emails_to_blob(emails)
    if url is None:
        print(f"Upload failed: {log}")
    else:
        print(f"Success: {url}")
    ```
    
    Performance:
    - Small files (<100 emails): ~100-300ms
    - Large files (1000+ emails): ~500ms-2s
    - Network dependent (Azure datacenter latency)
    
    Storage Costs:
    - Blob Storage: ~$0.02 per GB per month
    - Transaction costs: ~$0.05 per 10,000 operations
    - Typical email JSON: 1-10 KB per email
    """
    # Initialize emitter utility for logging
    # create_emitter wraps callback or creates console emitter
    emit_util = create_emitter(emitter)
    
    def emit(msg: str):
        """Helper function to emit log messages."""
        emit_util.emit(msg)
    
    # Handle empty email list
    # Still create file (empty JSON array) for consistency
    if not emails:
        emit('[WARN] No emails to store, creating empty file.')
    
    emit(f'[BLOB] Starting blob storage operation for {len(emails)} emails')
    
    # STEP 1: Authenticate with Azure Blob Storage
    # Try connection string first (simpler, for dev/test)
    if CONNECTION_STRING:
        service = BlobServiceClient.from_connection_string(CONNECTION_STRING)
        emit('[INFO] Using connection string authentication.')
    
    # Fall back to managed identity (secure, for production)
    elif ACCOUNT_URL:
        # Rely on AzureCliCredential chain automatically
        # Tries: Environment vars → Managed Identity → Azure CLI login
        # Local import to keep base import minimal (only import if needed)
        from azure.identity import AzureCliCredential
        cred = AzureCliCredential()
        service = BlobServiceClient(account_url=ACCOUNT_URL, credential=cred)
        emit('[INFO] Using ACCOUNT_URL with AzureCliCredential.')
    
    # No credentials available - cannot proceed
    else:
        emit('[ERROR] Set either BLOB_CONNECTION_STRING or BLOB_ACCOUNT_URL env vars.')
        # Return None URL to indicate failure
        return None, emit_util.get_log()

    # STEP 2: Get container client (may not exist yet)
    container_client = service.get_container_client(CONTAINER)
    
    # STEP 3: Create container if doesn't exist
    try:
        container_client.create_container()
        emit(f'[INFO] Created container {CONTAINER}.')
    except Exception:  # likely ResourceExistsError - container already exists
        # Not an error, just means container was already created
        emit(f'[INFO] Container {CONTAINER} exists.')

    # STEP 4: Generate timestamped blob name
    # Get local time with UTC offset (for user-friendly filenames)
    # UTC_OFFSET: Hours to add to UTC (e.g., 8 for UTC+8, -5 for UTC-5)
    utc_offset_hours = int(os.getenv('UTC_OFFSET', '0'))
    local_time = datetime.utcnow() + timedelta(hours=utc_offset_hours)
    
    # Format timestamp: YYYYMMDD-HHMMSS
    # Why this format? Sortable, no spaces, filesystem-safe
    ts = local_time.strftime('%Y%m%d-%H%M%S')
    blob_name = f"{prefix}_{ts}.json"
    emit(f'[BLOB] Creating blob: {blob_name}')
    
    # STEP 5: Get blob client for upload
    blob_client = container_client.get_blob_client(blob_name)
    
    # STEP 6: Serialize emails to JSON
    # indent=2: Pretty-print for readability
    # Why not minified? File size difference minimal, readability valuable
    payload = json.dumps(emails, indent=2)
    
    # STEP 7: Upload to blob storage
    # overwrite=True: Replace if blob already exists (shouldn't happen with timestamps)
    # content_type='application/json': Set correct MIME type for HTTP access
    blob_client.upload_blob(payload, overwrite=True, content_type='application/json')
    
    # STEP 8: Get blob URL and return success
    # blob_client.url: Full HTTP URL to access blob
    # Format: https://<account>.blob.core.windows.net/<container>/<blob_name>
    blob_url = blob_client.url
    emit(f'[SUCCESS] Uploaded {len(emails)} emails to {blob_url}.')
    
    return blob_url, emit_util.get_log()


def store_emails_to_local(
    emails: List[Dict], 
    prefix: str = 'outlook',
    emitter: Optional[Callable[[str], None]] = None
) -> Tuple[str, str]:
    """Store list of email JSON objects into local filesystem as a single JSON file.

    Writes email data to local directory with automatic timestamp-based naming.
    Creates directory if doesn't exist. Useful for offline development and debugging.
    
    Execution Flow:
    1. Initialize emitter for logging
    2. Determine target directory (env var or default)
    3. Create directory if needed
    4. Generate timestamped filename
    5. Write JSON to file
    6. Return file path and log
    
    Args:
        emails: List of email dictionaries to store.
                Each email should be JSON-serializable dict.
                Example: [{"id": "1", "subject": "Test", "body": "..."}]
                Can be empty list (creates empty JSON array file).
        
        prefix: Filename prefix (default: 'outlook').
                Used to distinguish email sources.
                Examples: 'outlook', 'gmail', 'exchange'
        
        emitter: Optional callback function for progress messages.
                 Signature: (str) -> None
                 If None, prints to console.
                 Used for UI updates (e.g., Streamlit).
    
    Returns:
        Tuple[str, str]: (file_path, log)
            file_path: Absolute path to written file (None if failed)
                       Example: "c:\Github_Repo\...\emails_local\outlook_20251110-143052.json"
            log: Complete log of operation (success or error messages)
                 Useful for displaying operation details to user
    
    Directory Configuration:
    - Environment: EMAIL_LOCAL_FOLDER (optional)
    - Default: 'emails_local' (relative to current working directory)
    - Created automatically if doesn't exist
    - Why configurable? Different projects may need different paths
    
    File Naming:
    - Pattern: {prefix}_YYYYMMDD-HHMMSS.json
    - Timezone: Uses UTC + UTC_OFFSET environment variable
    - Example: outlook_20251110-143052.json
    - Why timestamp? Prevents overwrites, sortable chronologically
    
    UTC Offset Behavior:
    - Environment: UTC_OFFSET (integer hours)
    - Examples: 8 (UTC+8), -5 (UTC-5), 0 (UTC)
    - Purpose: User-friendly filenames in local timezone
    - Why needed? UTC timestamps confusing for local files
    
    Example Usage:
    ```python
    # Simple usage with defaults
    emails = get_outlook_emails()
    file_path, log = store_emails_to_local(emails)
    if file_path:
        print(f"Saved to: {file_path}")
    else:
        print(f"Error: {log}")
    
    # With custom directory
    os.environ['EMAIL_LOCAL_FOLDER'] = 'my_emails'
    path, log = store_emails_to_local(emails, prefix='gmail')
    
    # Reading back the file
    file_path, log = store_emails_to_local(emails)
    if file_path:
        with open(file_path, 'r') as f:
            loaded_emails = json.load(f)
    ```
    
    Error Handling:
    - Directory creation failure: Returns (None, error_log)
    - File write failure: Returns (None, error_log)
    - Permission errors: Returns (None, error_log)
    - All errors logged in returned log string
    
    Performance:
    - Small files (<100 emails): <10ms
    - Large files (1000+ emails): ~50-100ms
    - Disk I/O dependent
    
    Storage Considerations:
    - No automatic cleanup (files accumulate)
    - Consider periodic manual cleanup for testing
    - Typical email JSON: 1-10 KB per email
    """
    # Initialize emitter utility for logging
    # create_emitter wraps callback or creates console emitter
    emit_util = create_emitter(emitter)
    
    def emit(msg: str):
        """Helper function to emit log messages."""
        emit_util.emit(msg)
    
    # STEP 1: Determine target directory
    # EMAIL_LOCAL_FOLDER: Configurable directory path
    # Default: 'emails_local' (relative to current working directory)
    # Why configurable? Different projects may have different conventions
    local_folder = os.getenv('EMAIL_LOCAL_FOLDER', 'emails_local')
    emit(f'[LOCAL] Storing emails to local folder: {local_folder}')
    
    # STEP 2: Create directory if doesn't exist
    if not os.path.exists(local_folder):
        try:
            # os.makedirs: Creates intermediate directories if needed
            # Why not os.mkdir? makedirs handles nested paths
            os.makedirs(local_folder)
            emit(f'[INFO] Created local folder {local_folder}.')
        except Exception as e:
            # Directory creation failure (permission, path invalid, etc.)
            # Return None to signal failure, log contains error details
            emit(f'[ERROR] Failed to create local folder: {e}')
            return None, emit_util.get_log()
    
    # STEP 3: Generate timestamped filename
    # Get local time with UTC offset (for user-friendly filenames)
    # UTC_OFFSET: Hours to add to UTC (e.g., 8 for UTC+8, -5 for UTC-5)
    utc_offset_hours = int(os.getenv('UTC_OFFSET', '0'))
    local_time = datetime.utcnow() + timedelta(hours=utc_offset_hours)
    
    # Format timestamp: YYYYMMDD-HHMMSS
    # Why this format? Sortable, no spaces, filesystem-safe
    ts = local_time.strftime('%Y%m%d-%H%M%S')
    file_name = f"{prefix}_{ts}.json"
    
    # STEP 4: Build full file path
    # os.path.join: Platform-independent path joining
    # Handles Windows backslashes and Unix forward slashes automatically
    file_path = os.path.join(local_folder, file_name)
    emit(f'[LOCAL] Writing to file: {file_path}')
    
    # STEP 5: Write JSON to file
    try:
        # 'w': Write mode (overwrite if exists, but shouldn't with timestamps)
        # encoding='utf-8': Handle international characters in emails
        # Why UTF-8? Standard for JSON, supports all languages
        with open(file_path, 'w', encoding='utf-8') as f:
            # indent=2: Pretty-print for readability
            # ensure_ascii=False: Preserve Unicode characters (e.g., Chinese, emoji)
            # Why not minified? File size difference minimal, readability valuable
            json.dump(emails, f, indent=2, ensure_ascii=False)
        
        # STEP 6: Return success
        emit(f'[SUCCESS] Saved {len(emails)} emails to {file_path}.')
        return file_path, emit_util.get_log()
    
    except Exception as e:
        # File write failure (permission, disk full, etc.)
        # Return None to signal failure, log contains error details
        emit(f'[ERROR] Failed to write file: {e}')
        return None, emit_util.get_log()


if __name__ == '__main__':
    """Simple manual test for blob storage functionality.
    
    Usage:
    1. Set environment variables (BLOB_CONNECTION_STRING or BLOB_ACCOUNT_URL)
    2. Run: python storeemail.py
    3. Check console output for blob URL
    
    Example Output:
    [BLOB] Starting blob storage operation for 1 emails
    [INFO] Using connection string authentication.
    [INFO] Container emails exists.
    [BLOB] Creating blob: outlook_20251110-143052.json
    [SUCCESS] Uploaded 1 emails to https://account.blob.core.windows.net/emails/outlook_20251110-143052.json.
    
    Purpose:
    - Quick validation that Azure credentials work
    - Test blob naming and upload process
    - Verify container creation/access
    
    Why dummy data?
    - Minimal payload for fast testing
    - Avoids dependency on Graph API token
    - Focuses on storage functionality only
    """
    # Dummy email data for testing
    # Minimal structure to validate JSON serialization
    dummy = [{"id":"1","subject":"Test"}]
    
    # Test blob storage (requires Azure credentials)
    url, log = store_emails_to_blob(dummy)
    print(log)
    print('URL:', url)
