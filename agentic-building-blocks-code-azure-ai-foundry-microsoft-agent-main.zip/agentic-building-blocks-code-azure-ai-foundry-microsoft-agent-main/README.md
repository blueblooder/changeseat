# Agentic Building Blocks with Azure AI Foundry SDK and Microsoft Agent Framework

> **TL;DR:** A catalog of runnable Python samples demonstrating Azure AI Foundry SDK and Azure AI Agent Framework patterns (single agents, connected agents, workflows). Copy and adapt these building blocks into your own multi-agent solutions—they're not a turnkey deployment, but show production-style techniques you can reuse.

## 📑 Table of Contents
- [Real-World Business Scenario](#-real-world-business-scenario)
- [What This Repository Provides](#-what-this-repository-provides)
- [Implementation Catalog](#-implementation-catalog)
- [Agent Architecture Patterns](#-agent-architecture-patterns)
- [Technology Stack](#-technology-stack)
- [Quick Start](#-quick-start)
- [Project Structure](#-project-structure)
- [Documentation & Learning Path](#-documentation--learning-path)
- [Observability](#-observability)
- [Contributing & License](#-contributing--license)

---

## 💼 Real-World Business Scenario

![cover](./docs/cover.png)

**Automated Market Intelligence Aggregator** addresses a critical business requirement in the financial services industry. Business managers in securities trade operations face the challenge of processing large volumes of time-sensitive data from both trusted sources (Bloomberg, Reuters) and untrusted sources (social media platforms). The samples in this repository demonstrate the building blocks needed to create such systems: parallel web search aggregation, content summarization, email reporting, and multi-tier triage workflows.

**Note:** This is one example domain. The same patterns apply to customer support automation, compliance document routing, email processing pipelines, and other multi-agent scenarios.

---

## 🎯 What This Repository Provides

Built to address real-world requirements from the **Automated Market Intelligence Aggregator** scenario, these samples provide production-proven building blocks using Azure AI Foundry SDK and Azure AI Agent Framework. While not a turnkey deployment, they demonstrate patterns that solve actual business challenges: parallel data aggregation, content summarization, intelligent routing, and automated reporting.

**Think of these samples like LEGO blocks** — individual components you can mix and match to create your own custom solutions. Each implementation demonstrates a specific pattern or capability, helping you understand different architectural approaches and adapt them for your specific business requirements.

**For production architecture** (frontend/backend separation, async processing, Azure deployment), see the [**Solution Accelerator for Multi-AI Agents**](https://github.com/denlai-mshk/Solution-Accelerator-for-building-Multi-AI-Agents-by-AI-Foundry-Agent-SDK-Streamlit-FastAPI).

### 🧱 What's Inside

This repository demonstrates Azure AI capabilities and design patterns:

- 🤖 **Single Agent Patterns** - Individual agents with specialized tools (search, email, content analysis)
- 🔗 **Connected Agents** - Sequential collaboration where agents delegate to specialists  
- 🔄 **Workflow Orchestration** - Parallel (fan-out/fan-in) and sequential execution patterns
- 🤝 **Handoff Patterns** - Multi-tier agent delegation with triage and routing
- 🛠️ **Tool Integration** - Azure AI Search, Bing Search, Microsoft Graph API, text-to-speech, web scraping

**Use cases span multiple domains:** market intelligence aggregation, customer support automation, email processing pipelines, compliance triage, document routing, and more.

## 📚 Implementation Catalog

Explore reference implementations organized by complexity and pattern type. Pattern types: **Single Agent** (one agent with tools), **Agent + Integration** (agent plus external services), **Connected Agents** (LLM-coordinated delegation), **Workflow** (Agent Framework orchestration).

### 🤖 Single Agent Patterns

Standalone agents with integrated tools and capabilities:

| Use Case | Description | Pattern | File Reference |
|----------|-------------|---------|----------------|
| **AI Search** | Query Azure AI Search indexes with RAG capabilities | Single Agent | `agent/aisearch.py` |
| **Web Search** | Web search using Bing/Yahoo/Google Search grounding | Single Agent | `agent/bingsearch.py`, `agent/yahoosearch.py` |
| **Web Search + Email** | Web search with automated email delivery via Logic Apps | Agent + Integration | `agent/bingsearch.py` (with email) |
| **Summarize URL** | Extract and summarize web page content | Single Agent | `agent/summariseURL.py` |
| **Summarize URL + Email + Audio** | URL summarization with email reporting and text-to-speech MP3 output | Agent + Integration | `agent/summariseURL.py` (full pipeline) |
| **Email Analysis** | Analyze Microsoft 365 emails with AI summarization | Agent + Integration | `agent/checkemail.py` |
| **Email Analysis + Reporting** | Email analysis with automated reporting via email | Agent + Integration | `agent/checkemail.py` (with send) |

### 🔧 Tool-Based Operations

Direct tool integrations without agent orchestration:

| Use Case | Description | Pattern | File Reference |
|----------|-------------|---------|----------------|
| **Headless Google Search** | Programmatic Google search using headless browser | Tool Integration | `helper/headlesssearch.py` |
| **Yahoo Search** | Programmatic Yahoo search using headless browser | Tool Integration | `helper/yahoosearch.py` |
| **Google Custom Search** | Google Custom Search API integration | Tool Integration | `helper/gcptxtsearch.py` |
| **Check Email** | Fetch and display Microsoft 365 emails | Tool + Graph API | `agent/checkemail.py` |

### 🌐 Connected Agentic Patterns

Multi-agent collaboration using LLM-driven coordination:

| Use Case | Description | Pattern | File Reference |
|----------|-------------|---------|----------------|
| **Summarize URL (Connected)** | Multi-agent collaboration: coordinator delegates URL fetching to specialist, then summarizes | Connected Agents | `agentic/summariseURL.py` |

**Compare:** See `agent/summariseURL.py` (rule-based orchestration) vs `agentic/summariseURL.py` (LLM-coordinated delegation) to understand the paradigm shift.

### 🔄 Workflow Orchestration

Agent Framework patterns for parallel and sequential execution:

| Use Case | Description | Pattern | File Reference |
|----------|-------------|---------|----------------|
| **Blast Web Search** | Parallel multi-source web search (Fan-out/Fan-in) | Workflow (Parallel) | `workflow/blastwebsearch.py` |
| **Blast Web Search + Email** | Parallel search with aggregated email reporting | Workflow + Integration | `workflow/blastwebsearch.py` |
| **Email Pipeline** | Sequential: fetch emails → AI summarization → send report | Workflow (Sequential) | `workflow/checkSumSendEmail.py` |
| **Multi-Tier Handoff** | Triage agent routes to specialist coordinators, who delegate to domain experts | Workflow (Handoff) | `workflow/handoff_bidirectional.py` |

## 🏗️ Agent Architecture Patterns

This repository demonstrates three core patterns for building intelligent agentic systems. Each pattern represents a different level of sophistication in how agents collaborate and make decisions.

> 💡 **New to agentic design?** Read [**From Rule-Based to Agentic**](docs/from_rule_based_to_agentic.md) to understand the fundamental shift from traditional programming to AI-driven orchestration. This guide explains why we can't just use LLMs for input parsing while keeping rule-based logic - and shows how truly agentic applications delegate workflow decisions to LLM intelligence.

### Single Agent with Tools
Individual agents enhanced with specific capabilities (search, email, speech synthesis). Best for straightforward tasks where a single AI decision-maker can handle the entire workflow with access to the right tools.

### Connected Agents
Sequential agent collaboration where one agent delegates specialized tasks to another agent. The coordinator agent uses natural language to route work to specialist agents, eliminating the need for hardcoded orchestration logic. See the comparison between `agent/summariseURL.py` (rule-based) and `agentic/summariseURL.py` (connected agents) for a concrete example.

### Workflow Orchestration
- **Parallel (Concurrent) Execution**: Fan-out/fan-in pattern using the Agent Framework for concurrent processing of independent tasks (e.g., multi-source web search)
- **Sequential Execution**: Pipeline pattern using the Agent Framework for dependent stages where each executor processes output from the previous one (e.g., fetch → analyze → send)
- **Multi-tier Handoff**: Hierarchical agent delegation where a triage agent routes requests to specialized handoff coordinators, which then delegate to domain experts

## 📖 Documentation & Guides

Comprehensive documentation to help you get started:

- [**Setup Guide**](docs/SETUP.md) - Installation, dependencies, environment configuration, and prerequisites
- [**Testing Guide**](docs/TESTING.md) - Run samples via Streamlit GUI or command-line with parameter details
- [**From Rule-Based to Agentic**](docs/from_rule_based_to_agentic.md) - **📘 Conceptual deep-dive:** Understand the paradigm shift from traditional rule-based programming to agentic AI design. Learn why we need to move beyond "first-hop" LLM usage and how to build truly intelligent applications where LLMs orchestrate workflows, not just parse input. Includes concrete examples using URL typo correction and the evolution from GUI to natural language interfaces.
- [**Workflow-Concurrent**](docs/blastwebsearch.md) - Agent Framework workflow architecture with Concurrent process design patterns
- [**Workflow-Sequential**](docs/checkSumSendEmail.md) - Agent Framework workflow architecture with Sequential process design patterns
- [**Workflow-Handoff**](docs/handoff_bidirectional.md) - Agent Framework workflow architecture with Multi-tier Handoff patterns
- [**Observability**](docs/observability.md) - Two approaches for production monitoring:
  - **Option A: OpenTelemetry Only** - For teams with existing tools (Jaeger, Zipkin, Grafana); full control and flexibility
  - **Option B: Azure Monitor + OpenTelemetry** - For Azure AI Foundry users; zero-setup portal visualization
  
  Both provide timing analysis, bottleneck detection, and parallel execution metrics with automatic framework instrumentation. 

## 🛠️ Technology Stack

- **Azure AI Foundry SDK** - Agent creation and tool integration
- **Azure AI Agent Framework** - Workflow orchestration (referred to as "Agent Framework" throughout)
- **Azure AI Search** - Vector search and RAG
- **Microsoft Graph API** - Microsoft 365 email access
- **Azure AI Services** - Text-to-speech synthesis
- **Azure Logic Apps** - Email delivery automation
- **Bing Search API** - Web search grounding
- **Google Custom Search API** - Alternative search provider

## ✨ Key Features

Samples illustrate production-style techniques you can adapt:

- ✅ **Error Handling & Logging** - Structured error reporting and diagnostic output
- ✅ **Modular Design** - Clear separation of concerns; reusable components
- ✅ **YAML Configuration** - Externalized agent definitions
- ✅ **Multiple Output Modes** - Text, JSON, streaming events (see `apps/ui_manager.py`)
- ✅ **Token Caching** - Microsoft Graph authentication persistence
- ✅ **HTML Email Support** - Rich formatting with automatic URL detection
- ✅ **Interactive Testing** - Streamlit GUI for rapid experimentation

## 🎓 Recommended Learning Path

Progress from simple to complex patterns, and understand the underlying philosophy:

1. **Understand the Philosophy** - Read [**From Rule-Based to Agentic**](docs/from_rule_based_to_agentic.md) to grasp the fundamental differences between traditional rule-based programming and agentic AI design. Learn why applications that only use LLMs for input parsing (the "first hop") still fail with natural language interfaces, and how truly agentic systems delegate decision-making to AI intelligence.

2. **Start Simple** - Begin with [Agent] AI Search or [Agent] Bing Search to understand basic single-agent patterns with tool integration

3. **Add Complexity** - Progress to [Agent] Summarise URL to learn how agents use tools to fetch and process external content

4. **Compare Approaches** - Explore both:
   - `agent/summariseURL.py` (rule-based with regex parsing and sequential agents)
   - `agentic/summariseURL.py` (connected agents with LLM-driven URL identification)
   
   Try the same input with typos or incomplete URLs in both to see the practical differences!

5. **Master Orchestration** - Study [Workflow] Blast Web Search for parallel execution patterns using the Agent Framework

6. **Advanced Patterns** - Tackle [Workflow] Handoff Bidirectional for multi-tier agent delegation and routing

## 📂 Project Structure

```
Common-AgentSDK-Samples/
├── agent/              # Single agent implementations (Azure AI Foundry SDK)
├── agentfx/            # Agent Framework single-agent implementations
├── agentic/            # Connected agents (LLM-coordinated delegation)
├── workflow/           # Agent Framework workflow orchestration
├── helper/             # Shared utilities (API clients, token management)
├── apps/               # Streamlit UI components
├── config/             # YAML agent configurations
├── docs/               # Documentation and guides
├── emails_local/       # Local email snapshots (JSON)
├── mp3_local/          # Text-to-speech audio files
├── main.py             # Streamlit GUI entry point
└── requirements.txt    # Python dependencies
```

## 📊 Observability

The Agent Framework provides automatic instrumentation for tracing agent workflows, tool calls, and parallel execution patterns.

### Two Implementation Options

**Option A: OpenTelemetry Only**
- Best for: Teams with existing observability infrastructure (Jaeger, Zipkin, Grafana)
- Benefits: Full control, vendor flexibility, custom exporters
- Setup: Configure OTLP exporter to your preferred backend

**Option B: Azure Monitor + OpenTelemetry**
- Best for: Azure AI Foundry users
- Benefits: Zero-config portal visualization, integrated with AI Studio
- Setup: Automatic integration when using Azure AI Foundry project

### What You Get
- ⏱️ **Timing Analysis** - Execution duration for each agent and tool call
- 🔍 **Bottleneck Detection** - Identify slow operations in workflows
- 🔄 **Parallel Execution Metrics** - Visualize fan-out/fan-in patterns
- 📈 **Automatic Instrumentation** - No manual logging required

📘 **Detailed guide:** See [`docs/observability.md`](docs/observability.md) for configuration examples and best practices.

---

## 🤝 Contributing & License

This is a learning and reference repository. Feel free to fork, modify, and adapt for your own projects.

**License:** MIT - See [LICENSE](LICENSE) for details.

---

**Questions or feedback?** Open an issue or check the [Solution Accelerator](https://github.com/denlai-mshk/Solution-Accelerator-for-building-Multi-AI-Agents-by-AI-Foundry-Agent-SDK-Streamlit-FastAPI) for production deployment examples.

---

## 🚀 Quick Start

**Get started in 5 steps:**

![Streamlit Interface](./docs/streamlit.png)

```powershell
# 1. Clone and navigate
git clone https://github.com/denlai-mshk/agentic-building-blocks-code-azure-ai-foundry-microsoft-agent.git
cd agentic-building-blocks-code-azure-ai-foundry-microsoft-agent

# 2. Create virtual environment
python -m venv .venv
.venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Configure environment variables
copy .env-sample as .env
# See docs/SETUP.md for detailed prerequisites and configuration

# 5. Launch Streamlit interface
streamlit run main.py
```

**Alternative: Run individual samples**
```powershell
python agent/aisearch.py
```

📘 **Next steps:**
- [**Setup Guide**](docs/SETUP.md) - Prerequisites, Azure resources, environment variables, and detailed configuration
- [**Testing Guide**](docs/TESTING.md) - How to test each sample, parameter details, and expected outputs

