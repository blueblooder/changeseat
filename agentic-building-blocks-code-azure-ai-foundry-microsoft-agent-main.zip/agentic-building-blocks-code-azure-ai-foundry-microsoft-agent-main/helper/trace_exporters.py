# ------------------------------------
# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
# ------------------------------------
"""Custom OpenTelemetry Span Exporters for Agent SDK

This module provides specialized span exporters for Agent SDK applications:
1. JSONFileExporter: Persists traces to timestamped JSON files for debugging
2. AgentTraceCollector: Formats traces for Streamlit UI display with emojis

=== Overview ===

OpenTelemetry generates spans (units of work) during agent execution.
These exporters capture and format those spans for different purposes:

- JSONFileExporter: Local file storage for post-execution analysis
- AgentTraceCollector: Real-time UI display in Streamlit

=== OpenTelemetry Exporter Interface ===

Both classes implement the SpanExporter abstract interface:

Required Methods:
- export(spans: List[ReadableSpan]) -> SpanExportResult
  * Called by OpenTelemetry when spans ready for export
  * Receives batch of completed spans
  * Must return SpanExportResult.SUCCESS or FAILURE
  
- shutdown() -> None
  * Called when exporter being shut down
  * Opportunity to flush buffers, close files
  * Should be idempotent (safe to call multiple times)

=== Span Data Structure ===

ReadableSpan contains:
- name: Operation name (e.g., "AgentsClient.create_agent")
- context: Trace context (trace_id, span_id, trace_flags)
- parent: Parent span reference (for hierarchy)
- start_time: Nanoseconds since epoch
- end_time: Nanoseconds since epoch
- status: StatusCode (OK, ERROR, UNSET)
- attributes: Key-value metadata (dict)
- events: Timeline events within span
- links: Links to other spans

Common Agent SDK Span Names:
- "AgentsClient.create_agent" - Agent creation
- "ThreadsClient.create_thread" - Thread creation
- "MessagesClient.create_message" - Message creation
- "process_thread_run" - Run execution with token counts
- "get_thread_run" - Run status polling
- "list_run_steps" - Retrieve run steps
- "list_messages" - Retrieve messages
- "AgentsClient.delete_agent" - Agent cleanup

=== Usage Patterns ===

With UnifiedTraceManager:
```python
from helper.unified_trace_manager import UnifiedTraceManager

# Automatic setup via UnifiedTraceManager
manager = UnifiedTraceManager(tracing_mode="console", trace_type="agent")
tracer, collector = manager.setup()

# collector is AgentTraceCollector instance
# JSONFileExporter automatically added

# After agent execution
traces, summary = manager.get_traces()
# traces = ["🤖 [Agent] Create agent - 123.45ms", ...]
# summary = {"total_spans": 10, "agent_spans": 2, ...}
```

Direct Usage (Advanced):
```python
from opentelemetry.sdk.trace import TracerProvider, SimpleSpanProcessor
from helper.trace_exporters import JSONFileExporter, AgentTraceCollector

# Create tracer provider
provider = TracerProvider()

# Add file exporter
file_exporter = JSONFileExporter(output_dir="traces")
provider.add_span_processor(SimpleSpanProcessor(file_exporter))

# Add UI collector
ui_collector = AgentTraceCollector()
provider.add_span_processor(SimpleSpanProcessor(ui_collector))

# Use provider
trace.set_tracer_provider(provider)
```

=== File Output Format ===

JSONFileExporter produces files like:
opentele_local/traces_20251110-143022.json

Content example:
```json
[
  {
    "name": "AgentsClient.create_agent",
    "trace_id": "a1b2c3d4e5f6...",
    "span_id": "1234567890abcdef",
    "parent_id": null,
    "start_time": 1699999999.123,
    "end_time": 1699999999.456,
    "duration_ms": 333.0,
    "status": "StatusCode.OK",
    "attributes": {
      "gen_ai.agent.id": "asst_abc123",
      "gen_ai.agent.name": "MyAgent"
    }
  },
  ...
]
```

=== UI Display Format ===

AgentTraceCollector formats for console/Streamlit:

```
🤖 [Agent] Create agent - 123.45ms
🧵 [Thread] Create thread - 45.67ms
💬 [Message] Create user message - 12.34ms
⚡ [Run] Process thread run - 5432.10ms
   └─ Status: completed
   └─ Tokens: 150 in, 250 out
🔄 [Poll] Check run status (completed) - 23.45ms
📋 [Steps] List run steps - 34.56ms
📬 [Messages] List messages - 45.67ms
🗑️ [Agent] Delete agent - 56.78ms
```

Emoji Legend:
- 🤖 Agent operations
- 🧵 Thread operations
- 💬 Message operations
- ⚡ Run processing
- 🔄 Status polling
- 📋 Step retrieval
- 📬 Message retrieval
- 🗑️ Cleanup operations
- 🌐 HTTP requests
- 📊 Generic spans

=== Thread Safety ===

Both exporters are designed for single-threaded use by OpenTelemetry SDK.
The SDK handles thread safety at the processor level.

If used outside SDK context:
- Add locking around export() calls
- Protect shared state (spans_data list)

=== Performance Considerations ===

JSONFileExporter:
- File I/O on every export() call
- SimpleSpanProcessor calls synchronously (blocks span end)
- For high-throughput: Use BatchSpanProcessor instead
- Disk write ~1-10ms per batch

AgentTraceCollector:
- In-memory storage only (fast)
- Memory grows with span count
- Typical agent run: 10-50 spans, ~50KB memory
- Long sessions: Consider periodic clearing

=== Error Handling ===

Both exporters use graceful degradation:
- File write failures: Log warning, continue
- No exceptions raised (prevents span loss)
- Returns SUCCESS even on partial failure
- Callers can't rely on return value for error detection
"""

from opentelemetry.sdk.trace.export import SpanExporter, SpanExportResult
from opentelemetry.sdk.trace import ReadableSpan
from typing import List
from datetime import datetime
from pathlib import Path
import json


class JSONFileExporter(SpanExporter):
	"""Export spans to timestamped JSON file in opentele_local directory.
	
	Persists OpenTelemetry spans as JSON for post-execution analysis and debugging.
	Each exporter instance writes to a single timestamped file.
	
	Purpose:
	- Debugging: Examine traces after execution
	- Auditing: Persistent record of operations
	- Offline Analysis: Process traces with external tools
	- Troubleshooting: Share trace files with support
	
	File Naming:
	- Format: traces_YYYYMMDD-HHMMSS.json
	- Example: traces_20251110-143022.json
	- Timestamp: When exporter created (not when spans exported)
	
	Why Timestamped?
	- Multiple runs don't overwrite each other
	- Easy to find traces from specific execution
	- Chronological ordering in directory
	
	Output Directory:
	- Default: opentele_local/ (relative to current working directory)
	- Created automatically if doesn't exist
	- Can be customized via constructor parameter
	
	JSON Structure:
	Array of span objects with:
	- name: Operation name
	- trace_id: Full trace identifier (hex string)
	- span_id: Span identifier (hex string)
	- parent_id: Parent span ID (null for root)
	- start_time: Unix timestamp (seconds with decimals)
	- end_time: Unix timestamp (seconds with decimals)
	- duration_ms: Duration in milliseconds
	- status: Status code (OK, ERROR, UNSET)
	- attributes: Custom metadata dictionary
	
	Thread Safety:
	NOT thread-safe. Relies on OpenTelemetry SDK's processor for synchronization.
	If used directly, caller must synchronize export() calls.
	
	Memory:
	Accumulates all spans in memory (self.spans_data list).
	Writes to file on every export() call (no batching).
	For large trace volumes, file can grow to MB/GB.
	
	Cleanup:
	No automatic file rotation or cleanup.
	Manual cleanup required to prevent disk space issues.
	Consider cron job or retention policy.
	"""
	
	def __init__(self, output_dir: str = "opentele_local"):
		"""Initialize JSON file exporter.
		
		Creates output directory and generates timestamped filename.
		
		Args:
			output_dir: Directory to store trace files
			           Default: "opentele_local"
			           Relative paths: Relative to current working directory
			           Absolute paths: Used as-is
			           
		Side Effects:
			- Creates output_dir if doesn't exist
			- Generates timestamped filename
			- Initializes empty spans list
		
		File Path Example:
		```python
		exporter = JSONFileExporter()
		# Creates: ./opentele_local/traces_20251110-143022.json
		
		exporter = JSONFileExporter(output_dir="/var/log/traces")
		# Creates: /var/log/traces/traces_20251110-143022.json
		```
		"""
		# Convert to Path object for easier manipulation
		self.output_dir = Path(output_dir)
		
		# Create directory if doesn't exist
		# exist_ok=True: Don't error if already exists
		# parents=True: Create parent directories if needed (implicit, default for mkdir)
		self.output_dir.mkdir(exist_ok=True)
		
		# Generate timestamp for filename
		# Format: YYYYMMDD-HHMMSS (sortable, filesystem-safe)
		# Why this format? No spaces or colons (Windows-compatible)
		timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
		
		# Build full file path
		# operator / concatenates Path objects
		self.file_path = self.output_dir / f"traces_{timestamp}.json"
		
		# Initialize spans accumulator
		# All exported spans added to this list
		# Written to file on each export() call
		self.spans_data = []
	
	def export(self, spans: List[ReadableSpan]) -> SpanExportResult:
		"""Export spans to JSON file.
		
		Called by OpenTelemetry SDK when spans are ready for export.
		Converts spans to JSON-serializable dicts and appends to file.
		
		Execution Flow:
		1. Convert each ReadableSpan to dict
		2. Append to self.spans_data list
		3. Write complete list to file (overwrites previous)
		4. Return SUCCESS
		
		Why Overwrite File Each Time?
		- Ensures file always has complete trace
		- If process crashes, have partial trace
		- Simpler than append (no need for JSON array handling)
		
		Performance:
		- O(n) where n = total spans (reads all, writes all)
		- File I/O blocks until complete (~1-10ms per write)
		- For high-throughput: Use BatchSpanProcessor to reduce frequency
		
		Args:
			spans: List of ReadableSpan objects from OpenTelemetry
			       Typically 1-100 spans per call (depends on processor)
			       Spans already completed (have end_time)
			       
		Returns:
			SpanExportResult.SUCCESS: Always (even on file write failure)
			
		Why Always SUCCESS?
		- Prevents OpenTelemetry from dropping spans
		- File write failure shouldn't affect tracing
		- Warning logged for debugging
		- Graceful degradation philosophy
		
		Span Conversion Details:
		- trace_id: 128-bit int → 32-char hex string
		- span_id: 64-bit int → 16-char hex string
		- parent_id: 64-bit int → 16-char hex string (or None)
		- start_time: nanoseconds → seconds (float)
		- end_time: nanoseconds → seconds (float)
		- duration_ms: (end - start) in nanoseconds → milliseconds
		- status: StatusCode enum → string representation
		- attributes: ImmutableAttributes → dict
		
		Example Conversion:
		```python
		ReadableSpan(
		    name="create_agent",
		    context=SpanContext(trace_id=123456..., span_id=78901...),
		    start_time=1699999999123456789,  # ns
		    end_time=1699999999456789012,    # ns
		    status=Status(StatusCode.OK),
		    attributes={"agent.id": "asst_123"}
		)
		
		→
		
		{
		    "name": "create_agent",
		    "trace_id": "000000000000000000000000001e240...",
		    "span_id": "0000000000012d85",
		    "parent_id": null,
		    "start_time": 1699999999.123,  # seconds
		    "end_time": 1699999999.457,
		    "duration_ms": 333.333,
		    "status": "StatusCode.OK",
		    "attributes": {"agent.id": "asst_123"}
		}
		```
		"""
		# STEP 1: Convert spans to JSON-serializable dicts
		for span in spans:
			# Build span dictionary
			span_dict = {
				# Operation name (e.g., "AgentsClient.create_agent")
				"name": span.name,
				
				# Trace ID: Convert 128-bit int to 32-char hex
				# Why format '032x'? 32 hex chars, zero-padded, lowercase
				# Example: "a1b2c3d4e5f6789012345678901234ab"
				"trace_id": format(span.context.trace_id, '032x'),
				
				# Span ID: Convert 64-bit int to 16-char hex
				# Why format '016x'? 16 hex chars, zero-padded, lowercase
				# Example: "1234567890abcdef"
				"span_id": format(span.context.span_id, '016x'),
				
				# Parent Span ID: Only if has parent
				# Root spans: parent is None
				# Child spans: parent references parent span
				"parent_id": format(span.parent.span_id, '016x') if span.parent else None,
				
				# Start time: Convert nanoseconds to seconds
				# Why divide by 1e9? 1 second = 1,000,000,000 nanoseconds
				# Result: Unix timestamp with decimal precision
				# Example: 1699999999.123456789
				"start_time": span.start_time / 1e9,
				
				# End time: Convert nanoseconds to seconds
				# Same conversion as start_time
				"end_time": span.end_time / 1e9,
				
				# Duration: Convert nanoseconds to milliseconds
				# Why divide by 1e6? 1 ms = 1,000,000 nanoseconds
				# Result: Duration in ms (common unit for latency)
				# Example: 333.333 ms
				"duration_ms": (span.end_time - span.start_time) / 1e6,
				
				# Status: Convert enum to string
				# StatusCode.OK → "StatusCode.OK"
				# StatusCode.ERROR → "StatusCode.ERROR"
				# Preserves original enum name for debugging
				"status": str(span.status.status_code),
				
				# Attributes: Convert ImmutableAttributes to dict
				# Handle None attributes (some spans have no attributes)
				# dict() makes copy, prevents reference issues
				"attributes": dict(span.attributes) if span.attributes else {},
			}
			
			# Add to accumulated spans
			self.spans_data.append(span_dict)
		
		# STEP 2: Write to file
		try:
			# Open file in write mode (overwrites existing)
			# encoding='utf-8': Support international characters
			with open(self.file_path, 'w', encoding='utf-8') as f:
				# Write JSON array with formatting
				# indent=2: Pretty-print with 2-space indentation
				# ensure_ascii=False: Allow Unicode characters (not escaped)
				# Why ensure_ascii=False? Preserves readable characters
				json.dump(self.spans_data, f, indent=2, ensure_ascii=False)
		except Exception as e:
			# File write failed - log warning but don't raise
			# Common causes:
			# - Disk full
			# - Permission denied
			# - Invalid characters in path
			# - File locked by another process
			print(f"[WARN] Failed to write traces to {self.file_path}: {e}")
		
		# STEP 3: Return success
		# Always return SUCCESS, even if file write failed
		# Why? Don't want to disrupt tracing due to I/O issues
		return SpanExportResult.SUCCESS
	
	def shutdown(self):
		"""Shutdown exporter.
		
		Called when OpenTelemetry SDK is shutting down.
		Opportunity to flush buffers and close resources.
		
		For file exporter: No-op (file written on every export).
		
		Why No-Op?
		- File already up-to-date (written on each export)
		- No buffers to flush
		- File handle closed after each write (context manager)
		- No persistent resources to clean up
		
		Other exporters might:
		- Flush pending batches
		- Close network connections
		- Write final summary
		- Release locks
		"""
		pass  # No cleanup needed for file exporter


class AgentTraceCollector(SpanExporter):
	"""In-memory span collector for UI display with emoji categorization.
	
	Purpose:
	- Collects spans in memory during application runtime
	- Formats spans for Streamlit UI display with emojis
	- Categorizes Agent SDK operations (agents, threads, messages, runs)
	- Provides human-readable trace summaries
	
	Design Rationale:
	- Separate from file export (different lifecycle)
	- In-memory storage (no persistence needed)
	- UI-focused formatting (human-readable)
	- Real-time updates (export called immediately)
	
	Why Not Use JSONFileExporter for UI?
	- File I/O overhead unnecessary
	- Different format needed (emoji, tree structure)
	- UI needs immediate access (no file reading)
	- Memory efficient for short-lived traces
	
	Span Recognition Patterns:
	🤖 Agent Operations:
	   - Pattern: "create_agent", "AgentsClient.create_agent", "delete_agent"
	   - Examples: Agent creation, deletion, updates
	   
	🧵 Thread Operations:
	   - Pattern: "create_thread", "ThreadsClient.create_thread"
	   - Examples: Thread creation, conversation context
	   
	💬 Message Operations:
	   - Pattern: "create_message", "MessagesClient.create_message"
	   - Examples: User messages, assistant responses
	   
	⚡ Run Operations:
	   - Pattern: "process_thread_run", "create_run", "poll_run"
	   - Examples: Agent execution, status polling
	   - Shows: Status, token counts, response times
	   
	🔄 Status Polling:
	   - Pattern: "poll" in name
	   - Examples: Waiting for run completion
	   
	📋 Step Retrieval:
	   - Pattern: "list_run_steps", "get_run_steps"
	   - Examples: Tool calls, function executions
	   
	📬 Message Retrieval:
	   - Pattern: "list_messages" (not "create_message")
	   - Examples: Fetching conversation history
	   
	🗑️ Cleanup Operations:
	   - Pattern: "delete" in name
	   - Examples: Agent/thread deletion
	   
	🌐 HTTP Requests:
	   - Pattern: "HTTP" in name
	   - Examples: REST API calls to Agent Service
	   
	Usage in Streamlit:
	```python
	# Setup
	collector = AgentTraceCollector()
	trace_provider.add_span_processor(SimpleSpanProcessor(collector))
	
	# After operations
	traces = collector.get_formatted_traces()
	st.write("## Trace Log")
	for trace in traces:
	    st.write(trace)  # Display emoji-formatted trace
	
	# Summary metrics
	summary = collector.get_summary()
	col1, col2, col3 = st.columns(3)
	col1.metric("Total Spans", summary["total_spans"])
	col2.metric("Agent Operations", summary["agent_ops"])
	col3.metric("HTTP Requests", summary["http_requests"])
	```
	
	Memory Considerations:
	- Each span: ~1-2 KB (depends on attributes)
	- 100 spans: ~100-200 KB
	- 1000 spans: ~1-2 MB
	- Recommended: Clear after display or limit retention
	
	Clearing Collected Traces:
	```python
	collector.spans_data.clear()  # Reset for new trace collection
	```
	
	Thread Safety:
	- NOT thread-safe (no locks on self.spans_data)
	- Assumption: Single-threaded Streamlit app
	- If multi-threaded: Add threading.Lock()
	
	Comparison with JSONFileExporter:
	+---------------------------+-------------------+------------------+
	| Feature                   | AgentTrace        | JSONFile         |
	|                           | Collector         | Exporter         |
	+---------------------------+-------------------+------------------+
	| Storage                   | In-memory         | File             |
	| Persistence               | No                | Yes              |
	| Format                    | Emoji + summary   | JSON             |
	| Overhead                  | Low               | Medium (I/O)     |
	| Use Case                  | Real-time UI      | Debugging, audit |
	| Retention                 | Until cleared     | Until deleted    |
	| Threading                 | Single-thread     | Single-thread    |
	+---------------------------+-------------------+------------------+
	"""
	
	def __init__(self):
		"""Initialize in-memory span collector.
		
		Creates empty list for span accumulation.
		No file path needed (all in memory).
		
		Initial State:
		- self.spans_data = []  # Empty list
		
		Why List Not Set?
		- Preserve insertion order (chronological)
		- Allow duplicate spans (re-runs)
		- Support indexing (get span by position)
		"""
		self.spans_data = []
	
	def export(self, spans: List[ReadableSpan]) -> SpanExportResult:
		"""Export spans to in-memory list.
		
		Called by OpenTelemetry SDK when spans are ready for export.
		Simply converts spans to dicts and accumulates in memory.
		
		Execution Flow:
		1. Convert each ReadableSpan to dict
		2. Append to self.spans_data list
		3. Return SUCCESS (no I/O)
		
		Why Simpler Than JSONFileExporter?
		- No file I/O (faster)
		- No error handling needed (memory allocation rarely fails)
		- No formatting (done in get_formatted_traces())
		
		Performance:
		- O(n) where n = number of spans in batch
		- No blocking I/O operations
		- Memory allocation only (microseconds)
		
		Args:
			spans: List of ReadableSpan objects from OpenTelemetry
			       Typically 1-100 spans per call
			       
		Returns:
			SpanExportResult.SUCCESS: Always
		"""
		for span in spans:
			# Build minimal span dictionary
			# Store only what's needed for UI display
			span_dict = {
				"name": span.name,
				"trace_id": format(span.context.trace_id, '032x'),
				"span_id": format(span.context.span_id, '016x'),
				"parent_id": format(span.parent.span_id, '016x') if span.parent else None,
				"start_time": span.start_time / 1e9,
				"end_time": span.end_time / 1e9,
				"duration_ms": (span.end_time - span.start_time) / 1e6,
				"status": str(span.status.status_code),
				"attributes": dict(span.attributes) if span.attributes else {},
			}
			self.spans_data.append(span_dict)
		return SpanExportResult.SUCCESS
	
	def shutdown(self):
		"""Shutdown collector (no-op).
		
		Called when OpenTelemetry SDK is shutting down.
		No cleanup needed for in-memory collector.
		
		Why No-Op?
		- No files to close
		- No network connections
		- Memory freed by garbage collector
		- No persistent resources
		"""
		pass
	
	def get_formatted_traces(self) -> List[str]:
		"""Format collected traces for Agent SDK operations with emoji categorization.
		
		Transforms raw span data into human-readable trace lines for UI display.
		Recognizes Agent SDK operation patterns and adds appropriate emojis.
		
		Pattern Recognition Logic:
		1. Check span name against known patterns (case-insensitive substring match)
		2. Extract relevant attributes (status, token counts, error info)
		3. Format with emoji prefix and duration
		4. Build descriptive message
		
		Why Emoji Categorization?
		- Visual scanning: Quickly identify operation types
		- Pattern recognition: See workflow at a glance
		- User-friendly: More approachable than raw span names
		- Consistent: Same emoji for same operation category
		
		Formatted Output Examples:
		```
		🤖 [Agent] Create agent - 234.56ms
		🧵 [Thread] Create thread - 123.45ms
		💬 [Message] Create user message - 89.12ms
		⚡ [Run] Process thread run - 5678.90ms
		   └─ Status: completed
		   └─ Tokens: 150 in, 250 out
		🔄 [Poll] Check run status (completed) - 45.67ms
		📋 [Steps] List run steps - 234.56ms
		📬 [Messages] List messages - 123.45ms
		🗑️ [Agent] Delete agent - 67.89ms
		🌐 [HTTP] POST /agents/create - 345.67ms
		📊 Generic span - 123.45ms
		```
		
		Token Count Display Logic:
		- Extract from attributes: gen_ai.usage.input_tokens, gen_ai.usage.output_tokens
		- Format: Indented details under main span (tree structure)
		- Only show if values present
		- Helps track API usage and costs
		
		Run Status Values:
		- "requires_action": Agent needs tool outputs
		- "in_progress": Agent processing
		- "completed": Successfully finished
		- "failed": Error occurred
		- "cancelled": User cancelled
		- "expired": Timeout
		
		Tree Structure Format:
		- Main span: No indentation
		- Sub-details: "   └─ " prefix (3 spaces + tree character)
		- Creates visual hierarchy
		- Easy to scan for status/metrics
		
		Performance:
		- O(n) where n = number of collected spans
		- String operations only (no I/O)
		- Typically <1ms for 100 spans
		
		Returns:
			List of formatted trace strings (may have multiple lines per span)
			Empty list if no spans collected
			
		Example Usage:
		```python
		# Display in Streamlit
		traces = collector.get_formatted_traces()
		st.write("## Execution Trace")
		for trace in traces:
		    st.write(trace)
		    
		# Or filter specific types
		agent_ops = [t for t in traces if "🤖" in t]
		st.write(f"Agent operations: {len(agent_ops)}")
		```
		"""
		lines = []
		for span in self.spans_data:
			# Extract span metadata
			name = span['name']
			duration = span['duration_ms']
			attributes = span.get('attributes', {})
			
			# Pattern matching and formatting
			# Check each pattern in order of specificity
			
			# 🤖 Agent creation - Most specific first
			if 'create_agent' in name or 'AgentsClient.create_agent' in name:
				lines.append(f"🤖 [Agent] Create agent - {duration:.2f}ms")
			
			# 🧵 Thread creation
			elif 'create_thread' in name or 'ThreadsClient.create_thread' in name:
				lines.append(f"🧵 [Thread] Create thread - {duration:.2f}ms")
			
			# 💬 User message creation (not list_messages)
			elif 'create_message' in name or 'MessagesClient.create_message' in name:
				lines.append(f"💬 [Message] Create user message - {duration:.2f}ms")
			
			# ⚡ Run processing - Show status and tokens in tree format
			elif 'process_thread_run' in name:
				# Get run status from attributes
				# Common values: requires_action, in_progress, completed, failed
				status = attributes.get('gen_ai.thread.run.status', 'unknown')
				
				# Get token counts if available
				# input_tokens: Input tokens (user message + system prompt)
				# output_tokens: Output tokens (agent response)
				input_tokens = attributes.get('gen_ai.usage.input_tokens', 0)
				output_tokens = attributes.get('gen_ai.usage.output_tokens', 0)
				
				# Main span line
				lines.append(f"⚡ [Run] Process thread run - {duration:.2f}ms")
				
				# Sub-details in tree format
				# "   └─ " creates visual hierarchy
				lines.append(f"   └─ Status: {status}")
				lines.append(f"   └─ Tokens: {input_tokens} in, {output_tokens} out")
			
			# 🔄 Status polling - Show current status
			elif 'get_thread_run' in name:
				# Get current run status
				status = attributes.get('gen_ai.thread.run.status', 'unknown')
				lines.append(f"🔄 [Poll] Check run status ({status}) - {duration:.2f}ms")
			
			# 📋 Step retrieval
			elif 'list_run_steps' in name:
				lines.append(f"📋 [Steps] List run steps - {duration:.2f}ms")
			
			# 📬 Message retrieval (not creation)
			elif 'list_messages' in name:
				lines.append(f"📬 [Messages] List messages - {duration:.2f}ms")
			
			# 🗑️ Agent deletion
			elif 'delete_agent' in name or 'AgentsClient.delete_agent' in name:
				lines.append(f"🗑️ [Agent] Delete agent - {duration:.2f}ms")
			
			# 🔍 Main function spans - Top-level workflow execution
			elif 'run_' in name or name.startswith('run_'):
				# Typically the root span wrapping entire operation
				# Example: "run_agent_workflow", "run_batch_job"
				lines.append(f"🔍 [Main] {name} - {duration:.2f}ms")
			
			# 🌐 HTTP requests - Low-level API calls
			# Check for HTTP methods in span name
			elif 'GET' in name or 'POST' in name or 'DELETE' in name:
				lines.append(f"🌐 [HTTP] {name} - {duration:.2f}ms")
			
			# 📊 Generic fallback - Unknown span types
			else:
				lines.append(f"📊 {name} - {duration:.2f}ms")
		
		return lines
	
	def get_summary(self) -> dict:
		"""Get trace summary metrics for Agent SDK operations.
		
		Categorizes and counts spans by operation type.
		Calculates total execution time from main function span.
		
		Purpose:
		- Provide high-level metrics for UI dashboards
		- Track operation counts for debugging
		- Measure end-to-end execution time
		- Identify performance bottlenecks
		
		Categories Tracked:
		
		1. Total Spans (total_spans):
		   - Count of all collected spans
		   - Use Case: Overall trace size, complexity measure
		
		2. Agent Spans (agent_spans):
		   - Pattern: "create_agent" or "delete_agent" in span name
		   - Examples: create_agent, delete_agent
		   - Use Case: Track agent lifecycle operations
		
		3. Thread Spans (thread_spans):
		   - Pattern: "create_thread" in span name
		   - Examples: create_thread, ThreadsClient.create_thread
		   - Use Case: Monitor conversation context creation
		
		4. Message Spans (message_spans):
		   - Pattern: "create_message" or "list_messages" in span name
		   - Examples: create_message, list_messages
		   - Use Case: Count message exchanges (both creation and retrieval)
		
		5. Run Spans (run_spans):
		   - Pattern: "process_thread_run", "get_thread_run", or "list_run_steps"
		   - Examples: process_thread_run, get_thread_run (polling), list_run_steps
		   - Use Case: Track agent execution cycles (processing + polling + steps)
		
		6. HTTP Spans (http_spans):
		   - Pattern: "GET", "POST", or "DELETE" in span name
		   - Examples: HTTP POST /agents/create, HTTP GET /threads/{id}/runs
		   - Use Case: Monitor low-level API call volume
		
		Main Elapsed Time Calculation:
		- Finds spans with "run_" prefix or containing "run_"
		- Takes maximum duration among these spans
		- Represents total end-to-end execution time
		- Why max()? Root span has longest duration (wraps all children)
		- If no main span: returns 0
		
		Why Track These Categories?
		- Performance analysis: Which operations are most frequent?
		- Cost estimation: More runs = more API calls = higher costs
		- Debugging: Unexpected counts indicate logic errors
		- User feedback: Show progress metrics in UI
		
		Example Output:
		```python
		{
		    "total_spans": 23,
		    "agent_spans": 2,        # create_agent + delete_agent
		    "thread_spans": 1,       # create_thread
		    "message_spans": 3,      # create_message (user) + list_messages + create_message (assistant)
		    "run_spans": 6,          # process_thread_run + 4x get_thread_run (polling) + list_run_steps
		    "http_spans": 11,        # All REST API calls
		    "main_elapsed_ms": 8234.56  # Total execution time
		}
		```
		
		Streamlit Dashboard Usage:
		```python
		summary = collector.get_summary()
		
		# Display metrics in columns
		col1, col2, col3, col4 = st.columns(4)
		col1.metric("Total Spans", summary["total_spans"])
		col2.metric("Agent Ops", summary["agent_spans"])
		col3.metric("Run Executions", summary["run_spans"])
		col4.metric("Total Time", f"{summary['main_elapsed_ms']:.2f}ms")
		
		# Calculate derived metrics
		if summary["run_spans"] > 0:
		    avg_run_time = summary["main_elapsed_ms"] / summary["run_spans"]
		    st.metric("Avg Run Time", f"{avg_run_time:.2f}ms")
		
		# Show breakdown
		st.bar_chart({
		    "Agents": summary["agent_spans"],
		    "Threads": summary["thread_spans"],
		    "Messages": summary["message_spans"],
		    "Runs": summary["run_spans"],
		    "HTTP": summary["http_spans"]
		})
		```
		
		Performance:
		- O(n) where n = number of collected spans
		- Single pass through span list
		- No I/O operations
		- Typically <1ms for 100 spans
		
		Thread Safety:
		- Reads self.spans_data (no modifications)
		- Safe to call concurrently with export()
		- Returns new dict (no shared state)
		
		Returns:
			Dictionary with span counts and timing metrics:
			{
			    "total_spans": int,
			    "agent_spans": int,
			    "thread_spans": int,
			    "message_spans": int,
			    "run_spans": int,
			    "http_spans": int,
			    "main_elapsed_ms": float
			}
		"""
		# Initialize counters
		agent_spans = 0
		thread_spans = 0
		message_spans = 0
		run_spans = 0
		http_spans = 0
		main_elapsed_ms = 0
		
		# Scan all collected spans
		for span in self.spans_data:
			name = span['name']
			duration = span['duration_ms']
			
			# Categorize spans by operation type
			# Use specific pattern matching (not overlapping)
			# Each span counted in only one category
			
			# Agent operations: create or delete agent
			if 'create_agent' in name or 'delete_agent' in name:
				agent_spans += 1
			
			# Thread operations: create thread
			elif 'create_thread' in name:
				thread_spans += 1
			
			# Message operations: create or list messages
			elif 'create_message' in name or 'list_messages' in name:
				message_spans += 1
			
			# Run operations: process, poll, or get steps
			# These are the core agent execution operations
			elif 'process_thread_run' in name or 'get_thread_run' in name or 'list_run_steps' in name:
				run_spans += 1
			
			# HTTP operations: REST API calls
			# Check for HTTP methods in span name
			elif 'GET' in name or 'POST' in name or 'DELETE' in name:
				http_spans += 1
			
			# Find main function span (top-level execution)
			# Pattern: starts with "run_" or contains "run_"
			# Use max() because root span has longest duration
			if 'run_' in name or name.startswith('run_'):
				main_elapsed_ms = max(main_elapsed_ms, duration)
		
		# Return summary dictionary
		# Include total_spans for convenience
		return {
			'total_spans': len(self.spans_data),  # Total span count
			'agent_spans': agent_spans,
			'thread_spans': thread_spans,
			'message_spans': message_spans,
			'run_spans': run_spans,
			'http_spans': http_spans,
			'main_elapsed_ms': main_elapsed_ms,
		}
