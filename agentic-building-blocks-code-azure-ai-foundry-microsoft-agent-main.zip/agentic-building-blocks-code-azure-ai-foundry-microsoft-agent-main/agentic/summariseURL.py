"""Connected agents URL summarization tool sample.

This module uses two-agent architecture with connected agents for URL analysis:
1. Main Coordinator Agent - Orchestrates workflow and delegates tasks
2. URL Summarizer Agent (Connected) - Specializes in summarizing URL content

Architecture Pattern:
	The coordinator agent intelligently identifies URLs from user questions,
	fetches content, and delegates summarization to specialized connected agent.
	Final aggregation produces comprehensive multi-URL analysis.
"""

import os
import sys
import math
import json
from typing import List, Dict, Callable
from dotenv import load_dotenv
from azure.ai.projects import AIProjectClient
from azure.identity import AzureCliCredential
from azure.ai.agents.models import ListSortOrder, MessageRole, ConnectedAgentTool, FunctionTool

if __name__ == "__main__": 
	repo_root = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
	if repo_root not in sys.path:
		sys.path.insert(0, repo_root)

import agent
from helper.agent_config_loader import load_agent_config, AgentConfigError
from helper.emitter import create_emitter
from helper.fetchurl import extract_content_from_url

load_dotenv()

project_endpoint = os.getenv("PROJECT_ENDPOINT")
model_deployment_name = os.getenv("MODEL_DEPLOYMENT_NAME")

DEFAULT_QUESTION = "Compare docs.microsoft.com/azure and aws.amazon.com/documentation for cloud services"

MAX_WORDS_PER_URL = 100

def normalize_url(url: str) -> str:
    """Normalize incomplete URLs by adding https:// if missing protocol"""
    url = url.strip()
    if not url.startswith(('http://', 'https://')):
        return f'https://{url}'
    return url

def fetch_url_content_tool_function(url: str) -> str:
    """
    Function tool for agents to fetch URL content.
    Takes a URL and returns the extracted content as JSON string.
    """
    try:
        # Normalize the URL first
        normalized_url = normalize_url(url)
        
        # Extract content using the helper function
        content, content_type, response_code = extract_content_from_url(normalized_url)
       
        # Return as JSON for the agent to parse
        result = {
            "success": True,
            "url": normalized_url,
            "content": content,
            "content_type": content_type,
            "response_code": response_code,
            "content_length": len(str(content))
        }
        
        return json.dumps(result, ensure_ascii=False)
        
    except Exception as e:
        error_result = {
            "success": False,
            "url": url,
            "error": str(e),
            "content": None,
            "content_type": None,
            "response_code": None
        }
        return json.dumps(error_result, ensure_ascii=False)

def safe_truncate_words(text: str, max_words: int) -> str:
    words = text.split()
    if len(words) <= max_words:
        return text
    return " ".join(words[:max_words])


def build_coordinator_instructions(question: str) -> str:
    """Build instructions for the main coordinator agent"""
    import yaml
    config_file = os.getenv("AGENTIC_CONFIG_FILE", "config/agentic_config.yaml")
    with open(config_file, 'r', encoding='utf-8') as f:
        full_cfg = yaml.safe_load(f) or {}
    
    summarise_section = full_cfg.get('summariseURL', {})
    coordinator_cfg = summarise_section.get('coordinator', {})
    instructions_template = coordinator_cfg.get('instructions', '')
    coordinator_instructions = instructions_template.format(
        question=question,
        urls='Agent will identify URLs intelligently',
        MAX_WORDS_PER_URL=MAX_WORDS_PER_URL
    )
    
    return coordinator_instructions

def load_message_template(template_name: str, **kwargs) -> str:
    """Load and format a message template from agentic_config.yaml"""
    import yaml
    config_file = os.getenv("AGENTIC_CONFIG_FILE", "config/agentic_config.yaml")
    with open(config_file, 'r', encoding='utf-8') as f:
        full_cfg = yaml.safe_load(f) or {}
    
    summarise_section = full_cfg.get('summariseURL', {})
    coordinator_cfg = summarise_section.get('coordinator', {})
    messages = coordinator_cfg.get('messages', {})
    
    template = messages.get(template_name, '')
    if not template:
        raise ValueError(f"Message template '{template_name}' not found in agentic_config.yaml")
    
    return template.format(**kwargs)

def build_url_summarizer_instructions(original_question: str = "", content_type: str = "unknown", response_code: str = "unknown") -> str:
    """Build instructions for the URL summarizer connected agent"""
    import yaml
    config_file = os.getenv("AGENTIC_CONFIG_FILE", "config/agentic_config.yaml")
    with open(config_file, 'r', encoding='utf-8') as f:
        full_cfg = yaml.safe_load(f) or {}
    
    summarise_section = full_cfg.get('summariseURL', {})
    summarizer_cfg = summarise_section.get('url_summarizer', {})
    base_instructions_template = summarizer_cfg.get('instructions', '')
    base_instructions = base_instructions_template.format(
        MAX_WORDS_PER_URL=MAX_WORDS_PER_URL,
        original_question=original_question,
        content_type=content_type,
        response_code=response_code
    )
    
    enhanced_template = summarizer_cfg.get('enhanced_instructions', '')
    if enhanced_template:
        enhanced_instructions = enhanced_template.format(
            base_instructions=base_instructions,
            MAX_WORDS_PER_URL=MAX_WORDS_PER_URL,
            original_question=original_question,
            content_type=content_type,
            response_code=response_code
        )
        return enhanced_instructions
    else:
        return base_instructions

def run_summarise_url_agentic(
    question: str | None = None,
    emitter: Callable[[str], None] | None = None,
    return_mode: str = "summary",
    save_json: str | os.PathLike | None = None,
    tracing_mode: str = "both",
) -> str | dict:
    """Connected agents version of URL summarization.
    
    Uses coordinator agent with connected URL summarizer agent for intelligent
    URL identification, content fetching, and comprehensive analysis.
    
    Execution Flow:
        1. Initialize tracking variables and emitter
        2. Validate/default question input
        3. Configure tracing mode (auto/azure_monitor/console/none)
        4. Setup unified trace manager
        5. Validate Azure environment configuration
        6. Initialize Azure AI Project Client
        7. Load and validate agentic YAML configuration
        8. Create URL Summarizer connected agent
        9. Create Coordinator agent with connected tool
        10. Create main conversation thread
        11. Process URL identification request
        12. Extract and clean identified URLs
        13. Process each URL with content fetching
        14. Create URL analysis messages
        15. Execute coordinator runs for each URL
        16. Aggregate final results
        17. Extract final agent response
        18. Cleanup agents
        19. Collect and emit trace summary
        20. Format payload based on return_mode
        21. Save JSON artifact if requested

    Parameters
    ----------
    question: User question containing URLs to analyze
    emitter: Optional callback for progress updates
    return_mode: Output format:
        'summary' -> summary text (fallback to log if empty)
        'log'     -> full log only
        'both'    -> dict { 'summaries': [...], 'output_text': str, 'log': str }
    save_json: Optional path to save results as JSON
    tracing_mode: Controls OpenTelemetry tracing destination:
        'auto' (default) -> Azure Monitor if APPLICATIONINSIGHTS_CONNECTION_STRING is set, else none
        'azure_monitor'  -> Send traces to Azure AI Foundry Portal
        'console'        -> Print traces to console (with gen_ai agent traces)
        'none'           -> Disable tracing

    Returns
    -------
    str | dict depending on `return_mode`.
    """
    # STEP 1: Initialize tracking variables and emitter
    # Why? Track resource creation counts for cleanup auditing and cost visibility
    output_texts: list[str] = []

    agents_created = 0
    threads_created = 0
    messages_created = 0

    # STEP 2: Setup emitter utility for consistent logging
    # Why? Centralize output management and enable flexible emitter injection for UI integration
    # STEP 2: Setup emitter utility for consistent logging
    # Why? Centralize output management and enable flexible emitter injection for UI integration
    emit_util = create_emitter(emitter)
    emit = emit_util.emit

    # STEP 3: Validate and default question input
    # Why? Ensure valid question exists before expensive Azure operations
    if not question or not question.strip():
        question = DEFAULT_QUESTION

    # STEP 4: Configure tracing mode with auto-detection
    # Why? Intelligently enable Azure Monitor tracing when connection string exists, fallback to console
    if tracing_mode == "auto":
        application_insights_connection_string = os.environ.get("APPLICATIONINSIGHTS_CONNECTION_STRING")
        if application_insights_connection_string and application_insights_connection_string.strip():
            tracing_mode = "both"
            emit("[TRACING] Auto-detected APPLICATIONINSIGHTS_CONNECTION_STRING - using dual tracing mode")
        else:
            tracing_mode = "console"
            emit("[TRACING] No APPLICATIONINSIGHTS_CONNECTION_STRING found - using console tracing")

    # STEP 5: Initialize unified trace manager
    # Why? Setup OpenTelemetry instrumentation before any Azure SDK operations to capture all spans
    from helper.unified_trace_manager import UnifiedTraceManager
    trace_mgr = UnifiedTraceManager(tracing_mode=tracing_mode, trace_type="agent", emitter=emit)
    trace_mgr.setup()

    # STEP 6: Validate Azure environment configuration
    # Why? Fail fast if critical Azure credentials are missing, before creating any resources
    if not project_endpoint or not model_deployment_name:
        emit("[ERROR] PROJECT_ENDPOINT and MODEL_DEPLOYMENT_NAME must be set in environment/.env")
        return emit_util.get_log()

    # STEP 7: Start parent tracing span for entire workflow
    # Why? Capture end-to-end telemetry with connected agents architecture metadata
    trace_mgr.start_parent_span(
        span_name=f"run_summarise_url_agentic: {question[:50]}",
        attributes={
            "question": question,
            "architecture": "connected_agents",
            "tracing_mode": tracing_mode
        }
    )

    emit("Azure AI Project Client initializing with Connected Agents architecture...")
    
    try:
        # STEP 8: Initialize Azure AI Project Client and agents client
        # Why? Context manager ensures proper credential cleanup even on exceptions
        with AIProjectClient(endpoint=project_endpoint, credential=AzureCliCredential()) as project_client:
            agents_client = project_client.agents
            
            # STEP 9: Load and validate agentic YAML configuration
            # Why? Fail fast with detailed error if configuration is missing/invalid before creating agents
            try:
                import yaml
                config_file = os.getenv("AGENTIC_CONFIG_FILE", "config/agentic_config.yaml")
                with open(config_file, 'r', encoding='utf-8') as f:
                    full_cfg = yaml.safe_load(f) or {}
                summarise_section = full_cfg.get('summariseURL', {})
                coordinator_cfg = summarise_section.get('coordinator', {})
                url_summarizer_cfg = summarise_section.get('url_summarizer', {})
                for label, cfg in [('coordinator', coordinator_cfg), ('url_summarizer', url_summarizer_cfg)]:
                    if not cfg or 'name' not in cfg or 'instructions' not in cfg:
                        raise AgentConfigError(f"Missing required fields for summariseURL {label} agent in agentic YAML")
            except AgentConfigError as cfg_err:
                emit(f"[ERROR] {cfg_err}")
                return emit_util.get_log()
            except Exception as exc:
                emit(f"[ERROR] Failed to load agentic summariseURL agent config: {exc}")
                return emit_util.get_log()

            emit("[AGENTIC ARCHITECTURE] Creating connected agents setup...")

            # STEP 10: Create URL Summarizer connected agent
            # Why? Specialized agent for summarization tasks - created first to obtain ID for connection
            emit(f"[AGENT CREATE] Creating URL Summarizer agent with name: {url_summarizer_cfg['name']}")
            url_summarizer_agent = agents_client.create_agent(
                model=model_deployment_name,
                name=url_summarizer_cfg['name'],
                description=url_summarizer_cfg.get('description', 'Specialized agent for summarizing URL content with detailed analysis'),
                instructions=build_url_summarizer_instructions()
            )
            agents_created += 1
            emit(f"[CONNECTED AGENT] Created URL Summarizer agent ID: {url_summarizer_agent.id}")

            # STEP 11: Create ConnectedAgentTool wrapper
            # Why? Wrap URL summarizer agent as tool for coordinator agent to delegate tasks
            connected_summarizer = ConnectedAgentTool(
                id=url_summarizer_agent.id,
                name=url_summarizer_cfg['name'],
                description=url_summarizer_cfg.get('description', 'Specialized agent for summarizing URL content with detailed analysis')
            )

            # STEP 12: Create Coordinator agent with connected tool
            # Why? Main orchestrator agent with access to URL summarizer through connected agent tool
            emit(f"[AGENT CREATE] Creating Coordinator agent with name: {coordinator_cfg['name']}")
            coordinator_agent = agents_client.create_agent(
                model=model_deployment_name,
                name=coordinator_cfg['name'],
                description=coordinator_cfg.get('description', 'Main coordinator agent that orchestrates URL analysis and delegates summarization tasks'),
                instructions=build_coordinator_instructions(question),
                tools=connected_summarizer.definitions,
            )
            agents_created += 1
            emit(f"[MAIN AGENT] Created Coordinator agent ID: {coordinator_agent.id}")

            # STEP 13: Create main conversation thread
            # Why? Single thread for all coordinator-user interactions and URL processing workflow
            emit("[THREAD CREATE] Creating main conversation thread")
            main_thread = agents_client.threads.create()
            threads_created += 1
            emit(f"[THREAD] Created main thread ID: {main_thread.id}")

            emit("[WORKFLOW] Processing request through intelligent coordinator with URL content pre-fetching...")
            
            # STEP 14: Load URL identification message template
            # Why? Use YAML-configured template for consistent coordinator prompting strategy
            identification_message = load_message_template('url_identification', question=question)
            
            emit(f"[URL IDENTIFICATION REQUEST]\n{identification_message}")
            
            # STEP 15: Create URL identification message in thread
            # Why? Initial coordinator request to intelligently identify URLs from user question
            emit(f"[MESSAGE CREATE] Creating URL identification message in thread {main_thread.id}")
            agents_client.messages.create(
                thread_id=main_thread.id,
                role="user", 
                content=identification_message,
            )
            messages_created += 1
            emit("[MESSAGE] URL identification message created successfully")

            # STEP 16: Execute coordinator run for URL identification
            # Why? Let coordinator agent process question and identify all relevant URLs
            run_result = agents_client.runs.create_and_process(
                thread_id=main_thread.id, 
                agent_id=coordinator_agent.id
            )
            
            # STEP 17: Check URL identification run status
            # Why? Log failures early but continue to extract any partial results
            if run_result.status == "failed":
                emit(f"[ERROR] URL identification failed: {run_result.last_error}")
            
            # STEP 18: Extract coordinator response from thread messages
            # Why? Retrieve agent's URL identification response for regex parsing
            messages = agents_client.messages.list(thread_id=main_thread.id, order=ListSortOrder.ASCENDING)
            coordinator_response = ""
            for m in messages:
                if m.role == MessageRole.AGENT:
                    for t in m.text_messages:
                        coordinator_response = t.text.value
                        break
            
            emit(f"[COORDINATOR IDENTIFIED URLS]\n{coordinator_response}")
            
            # STEP 19: Extract and clean URLs from coordinator response using regex
            # Why? Parse all https URLs from text, remove trailing punctuation, deduplicate
            import re
            all_urls = re.findall(r'https://[^\s<>"{}|\\^`\[\]*]+', coordinator_response)
            cleaned_urls = []
            for url in all_urls:
                clean_url = url.rstrip('.,;:!?*_~`"\'()[]{}')
                if clean_url:
                    cleaned_urls.append(clean_url)
            identified_urls = list(dict.fromkeys(cleaned_urls))
            
            # STEP 20: Branch workflow based on URL identification results
            # Why? Handle two scenarios: URLs found (multi-URL processing) vs no URLs (general question)
            if not identified_urls:
                # STEP 21: Handle general question scenario (no URLs identified)
                # Why? Fallback path when coordinator determines question doesn't contain URLs
                emit("[INFO] No URLs identified by coordinator - processing as general question")
                
                general_message = load_message_template('general_processing', question=question)
                
                emit(f"[MESSAGE CREATE] Creating general processing message in thread {main_thread.id}")
                agents_client.messages.create(
                    thread_id=main_thread.id,
                    role="user",
                    content=general_message,
                )
                messages_created += 1
                emit("[MESSAGE] General processing message created successfully")
            else:
                # STEP 22: Process identified URLs loop
                # Why? Iterate through all identified URLs to fetch content and create analysis messages
                emit(f"[URL PROCESSING] Found {len(identified_urls)} URLs to process")
                url_summaries = []
                
                for idx, url in enumerate(identified_urls, 1):
                    emit(f"\n===== PROCESSING URL {idx}/{len(identified_urls)}: {url} =====")
                    
                    try:
                        # STEP 23: Fetch URL content using helper function
                        # Why? Extract actual web content with metadata (content-type, status) for analysis
                        content, content_type, response_code = extract_content_from_url(url)
                        
                        emit(f"[URL {idx} METADATA] Content-Type: {content_type}, Status: {response_code}, Length: {len(str(content))}")
                        
                        # STEP 24: Load URL analysis message template with content
                        # Why? Create structured message with URL content, metadata, and context for coordinator
                        url_analysis_message = load_message_template(
                            'url_analysis',
                            url=url,
                            content_type=content_type,
                            response_code=response_code,
                            content=content,
                            original_question=question,
                            url_index=idx,
                            total_urls=len(identified_urls)
                        )
                        
                        # STEP 25: Create URL analysis message in thread
                        # Why? Add fetched content to conversation for coordinator processing
                        emit(f"[MESSAGE CREATE] Creating URL analysis message for URL {idx} in thread {main_thread.id}")
                        agents_client.messages.create(
                            thread_id=main_thread.id,
                            role="user",
                            content=url_analysis_message,
                        )
                        messages_created += 1
                        emit(f"[MESSAGE] URL analysis message {idx} created successfully")
                        
                        # STEP 26: Execute coordinator run for URL analysis
                        # Why? Process current URL content through coordinator (may delegate to summarizer agent)
                        url_run_result = agents_client.runs.create_and_process(
                            thread_id=main_thread.id, 
                            agent_id=coordinator_agent.id
                        )
                        
                        # STEP 27: Check URL processing run status
                        # Why? Log failures for individual URLs but continue processing remaining URLs
                        if url_run_result.status == "failed":
                            emit(f"[ERROR] URL {idx} processing failed: {url_run_result.last_error}")
                        
                    except Exception as url_error:
                        # STEP 28: Handle URL fetch exceptions gracefully
                        # Why? Continue workflow with error message even if individual URL fetch fails
                        emit(f"[ERROR] Failed to fetch URL {idx} ({url}): {url_error}")
                        
                        error_message = load_message_template('url_error', url=url, error=url_error)
                        emit(f"[MESSAGE CREATE] Creating error message for URL {idx} in thread {main_thread.id}")
                        agents_client.messages.create(
                            thread_id=main_thread.id,
                            role="user",
                            content=error_message,
                        )
                        messages_created += 1
                        emit(f"[MESSAGE] Error message for URL {idx} created successfully")
                
                # STEP 29: Create final aggregation message
                # Why? Request coordinator to synthesize all URL analyses into final comparative summary
                aggregation_message = load_message_template(
                    'final_aggregation',
                    total_urls=len(identified_urls),
                    question=question
                )
                
                emit(f"[MESSAGE CREATE] Creating final aggregation message in thread {main_thread.id}")
                agents_client.messages.create(
                    thread_id=main_thread.id,
                    role="user",
                    content=aggregation_message,
                )
                messages_created += 1
                emit("[MESSAGE] Final aggregation message created successfully")

            # STEP 30: Execute final coordinator run for result aggregation
            # Why? Generate final comprehensive response combining all URL analyses
            final_run_result = agents_client.runs.create_and_process(
                thread_id=main_thread.id, 
                agent_id=coordinator_agent.id
            )
            emit(f"[EXECUTION] Final workflow status: {final_run_result.status}")
            
            # STEP 31: Check final run status
            # Why? Log workflow-level failures for debugging and visibility
            if final_run_result.status == "failed":
                emit(f"[ERROR] Final workflow failed: {final_run_result.last_error}")

            # STEP 32: Extract final agent response from thread
            # Why? Retrieve most recent agent message (descending order) as final output
            messages = agents_client.messages.list(thread_id=main_thread.id, order=ListSortOrder.DESCENDING)
            for m in messages:
                if m.role == MessageRole.AGENT:
                    for t in m.text_messages:
                        output_text = t.text.value
                        emit("[FINAL AGGREGATED OUTPUT]\n" + output_text)
                        output_texts.append(output_text)
                        break
                    break

            # STEP 33: Emit execution summary with resource counts
            # Why? Provide cost/resource visibility showing agents/threads/messages created
            emit("\n" )
            emit("[EXECUTION SUMMARY] Resource Creation Report")
            emit(f"[SUMMARY] Total Agents Created: {agents_created}")
            emit(f"[SUMMARY] Total Threads Created: {threads_created}")
            emit(f"[SUMMARY] Total Messages Created: {messages_created}")
            emit("\n" )

            # STEP 34: Cleanup agents to avoid orphaned resources
            # Why? Delete both coordinator and connected summarizer agents to prevent accumulation
            emit("[CLEANUP] Deleting agents...")
            agents_client.delete_agent(coordinator_agent.id)
            agents_client.delete_agent(url_summarizer_agent.id)
            emit("[CLEANUP] Connected agents workflow completed")
            
            # STEP 35: Emit Azure Monitor tracing confirmation
            # Why? Inform user where to view traces when Azure Monitor mode is active
            if tracing_mode == "azure_monitor":
                emit("")
                emit("AZURE MONITOR TRACING")
                emit("✅ Agent traces have been sent to Azure Monitor / Application Insights")
                emit("📊 View traces in Azure AI Foundry Portal: https://ai.azure.com")
                emit("")

    except Exception as outer_exc:
        # STEP 36: Handle unexpected exceptions with trace recording
        # Why? Capture any workflow-level failures in telemetry for debugging
        trace_mgr.record_exception(outer_exc, f"Unexpected exception in connected agents workflow: {outer_exc}")
        emit(f"[ERROR] Unexpected exception in connected agents workflow: {outer_exc}")
    finally:
        # STEP 37: End parent span regardless of success/failure
        # Why? Ensure telemetry span is closed properly for complete trace capture
        trace_mgr.end_parent_span()

    # STEP 38: Retrieve collected traces and summary statistics
    # Why? Extract all telemetry data for console display and JSON artifact inclusion
    trace_lines, trace_summary = trace_mgr.get_traces()
    
    # STEP 39: Emit trace summary to console if traces exist
    # Why? Provide visibility into span counts and performance metrics
    if trace_lines:
        emit("")
        emit("=" * 50)
        emit("OPENTELEMETRY TRACE SUMMARY")
        emit("=" * 50)
        emit(f"Total Spans: {trace_summary.get('total_spans', 0)}")
        emit(f"Agent Spans: {trace_summary.get('agent_spans', 0)}")
        emit(f"Thread Spans: {trace_summary.get('thread_spans', 0)}")
        emit(f"Message Spans: {trace_summary.get('message_spans', 0)}")
        emit(f"Run Spans: {trace_summary.get('run_spans', 0)}")
        emit(f"HTTP Spans: {trace_summary.get('http_spans', 0)}")
        emit(f"Main Elapsed: {trace_summary.get('main_elapsed_ms', 0):.2f}ms")
        emit("")
        for line in trace_lines:
            emit(line)
        emit("=" * 50)

    # STEP 40: Join output texts and log for different return modes
    # Why? Prepare summary and log strings for flexible return format (summary/log/both)
    summary_joined = "\n\n".join(output_texts) if output_texts else ""
    log_joined = emit_util.get_log()

    # STEP 41: Format payload based on return_mode
    # Why? Support three return modes: 'both' (dict), 'log' (str), 'summary' (str with fallback)
    payload = None
    if return_mode == "both":
        payload = {
            "summaries": output_texts,
            "output_text": summary_joined or log_joined,
            "log": log_joined,
            "traces": trace_lines,
            "trace_summary": trace_summary,
        }
    elif return_mode == "log":
        payload = log_joined
    else:
        payload = summary_joined if summary_joined else log_joined

    # STEP 42: Save JSON artifact if path provided
    # Why? Persist complete workflow results with traces for offline analysis and debugging
    if save_json:
        import json, pathlib
        try:
            path_obj = pathlib.Path(save_json)
            path_obj.parent.mkdir(parents=True, exist_ok=True)
            json.dump(
                {
                    "summaries": output_texts,
                    "output_text": summary_joined,
                    "log": log_joined,
                    "architecture": "connected_agents",
                    "traces": trace_lines,
                    "trace_summary": trace_summary,
                },
                path_obj.open('w', encoding='utf-8'),
                ensure_ascii=False,
                indent=2,
            )
        except Exception as exc:
            # STEP 43: Handle JSON save failures gracefully
            # Why? Ensure updated log is returned even if file write fails
            emit(f"[WARN] Failed to save JSON artefact: {exc}")
            if isinstance(payload, dict):
                payload["log"] = emit_util.get_log()
            elif return_mode == "log":
                payload = emit_util.get_log()

    # STEP 44: Return formatted payload
    # Why? Deliver results in requested format (str or dict) with all workflow outputs
    return payload


if __name__ == "__main__":
    user_question = sys.argv[1] if len(sys.argv) > 1 and sys.argv[1].strip() else DEFAULT_QUESTION
    run_summarise_url_agentic(user_question)