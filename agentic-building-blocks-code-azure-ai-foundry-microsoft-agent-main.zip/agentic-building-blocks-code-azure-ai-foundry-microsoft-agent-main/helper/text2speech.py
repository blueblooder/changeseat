"""Azure Cognitive Services Text-to-Speech (TTS) Integration

Converts text to MP3 audio files using Azure Speech Services with Azure RBAC authentication.
Supports neural voices, customizable audio formats, and automatic timestamp-based file naming.

Purpose:
========
1. Text-to-Speech Conversion: Convert text strings to natural-sounding speech
2. MP3 File Generation: Produce high-quality MP3 audio files (24kHz 160kbps)
3. Azure RBAC Authentication: Secure authentication using managed identity or Azure CLI
4. Timestamp Naming: Automatic unique filenames with UTC offset support
5. Progress Logging: Integration with emitter pattern for UI updates

Architecture:
=============
Authentication Flow:
  Azure CLI Login (az login)
       ↓
  AzureCliCredential obtains AAD token
       ↓
  Token formatted with Resource ID
       ↓
  SpeechSynthesizer authenticates
       ↓
  Text synthesized to MP3

File Naming Pattern:
  Default: mp3_local/YYYYMMDD-HHMMSS.mp3
  Custom: User-specified path
  
  Example with UTC+8:
    Input time: 2025-01-10 14:30:52 UTC
    Filename: 20250110-223052.mp3 (14:30 + 8 hours = 22:30)

Authentication Method (RBAC):
=============================
Unlike API key authentication, uses Azure Active Directory (AAD) tokens:

1. Prerequisites:
   - Azure CLI installed and logged in (az login)
   - User/Managed Identity has Cognitive Services User role on Speech resource
   - SPEECH_REGION environment variable set
   - SPEECH_RESOURCE_ID environment variable set

2. Token Format:
   - Standard AAD token: credential.get_token("https://cognitiveservices.azure.com/.default")
   - Special format for SDK: "aad#{resourceId}#{token}"
   - Why special format? SpeechSynthesizer requires resource scoping

3. Security Benefits:
   - No API keys in code or config
   - Automatic token rotation
   - Fine-grained RBAC control
   - Audit trail via Azure AD

Environment Variables:
======================
Required:
- SPEECH_REGION: Azure region (e.g., "eastus", "westeurope")
  Example: "eastus"
  Purpose: Routes request to correct Speech service endpoint

- SPEECH_RESOURCE_ID: Full Azure Resource ID
  Format: "/subscriptions/{sub-id}/resourceGroups/{rg}/providers/Microsoft.CognitiveServices/accounts/{name}"
  Example: "/subscriptions/12345-67890/resourceGroups/my-rg/providers/Microsoft.CognitiveServices/accounts/my-speech"
  How to find: Azure Portal → Speech resource → Properties → Resource ID

Optional:
- SPEECH_VOICE: Neural voice name (default: "en-US-JennyNeural")
  Examples: "en-US-JennyNeural" (female), "en-US-GuyNeural" (male)
  Full list: https://learn.microsoft.com/azure/ai-services/speech-service/language-support
  
- UTC_OFFSET: Hours offset from UTC for timestamps (default: 0)
  Examples: 8 (UTC+8), -5 (UTC-5), 0 (UTC)

Audio Format:
=============
Configured settings:
- Sample rate: 24kHz (high quality, suitable for most applications)
- Bitrate: 160 kbps (good balance between quality and file size)
- Channels: Mono (sufficient for speech, smaller file size)
- Format: MP3 (widely compatible)

Alternative formats available:
- 48kHz 192kbps (highest quality)
- 16kHz 128kbps (lower quality, smaller files)
- WAV, OGG formats (via SpeechSynthesisOutputFormat enum)

Typical file sizes (estimated):
- 100 words: ~200-300 KB
- 500 words: ~1-1.5 MB
- 1000 words: ~2-3 MB

Usage Examples:
===============
Basic usage (auto-generated filename):
```python
from helper.text2speech import convert_text_to_mp3

text = "Hello, this is a test of the Azure Speech service."
mp3_path, log = convert_text_to_mp3(text)
print(f"Generated: {mp3_path}")  # mp3_local/20251110-143052.mp3
```

With custom filename:
```python
mp3_path, log = convert_text_to_mp3(
    text="Welcome to the demo.",
    output_file="custom_output.mp3"
)
```

With emitter for UI updates:
```python
from helper.emitter import create_emitter

def ui_callback(msg: str):
    print(f"[UI] {msg}")

emitter = create_emitter(ui_callback)
mp3_path, log = convert_text_to_mp3(
    text="This will log progress to UI.",
    emitter=emitter.emit
)
```

Legacy wrapper (backward compatibility):
```python
from helper.text2speech import convert_text_to_mp3_legacy

# Returns only path (no log), for old code
mp3_path = convert_text_to_mp3_legacy("Test text")
```

Error Handling:
===============
Common Errors:
1. Missing SPEECH_REGION: RuntimeError raised, clear error message
2. Missing SPEECH_RESOURCE_ID: RuntimeError raised, guidance provided
3. Azure login expired: AzureCliCredential fails, re-run 'az login'
4. Insufficient RBAC permissions: Synthesis canceled with error details
5. Empty text: ValueError raised before synthesis

All errors logged via emitter with actionable guidance.

Performance:
============
- Authentication: ~100-500ms (first call, token cached by SDK)
- Synthesis time: ~500ms-2s per 100 words
- File write: <50ms (local disk)
- Network latency: Depends on Azure region proximity

Best practices:
- Reuse SpeechSynthesizer instances when possible (internal caching)
- Keep text under 10,000 characters for responsive synthesis
- Consider async/batch processing for multiple texts

Integration Points:
===================
Used by:
- Workflow agents for voice output generation
- Email notification systems (audio attachments)
- Accessibility features (text-to-speech for UI)

Dependencies:
- azure-cognitiveservices-speech: Azure Speech SDK
- azure-identity: AAD authentication
- helper.emitter: Progress logging pattern
"""

import sys
import os
from datetime import datetime, timedelta
from typing import Optional, Callable, Tuple
from dotenv import load_dotenv
import azure.cognitiveservices.speech as speechsdk
from azure.identity import AzureCliCredential
from helper.emitter import create_emitter

# Default text for CLI testing and demonstrations
# Provides instructions and describes the authentication method
DEFAULT_TEXT = "Make sure to have your Azure Speech resource region set in environment variable SPEECH_REGION and authenticate using 'az login'. This uses Azure RBAC authentication with the Azure Cognitive Services Speech SDK for Python and saves the synthesized speech as an MP3 file. The voice and audio format can be customized as shown."


# Default directory (absolute) for synthesized MP3 files
# Why absolute path? Ensures consistent location regardless of working directory
# Why '../mp3_local'? Places files at project root for easy access
DEFAULT_OUTPUT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'mp3_local'))


def convert_text_to_mp3(
    text: str, 
    output_file: str = None, 
    emitter: Optional[Callable[[str], None]] = None
) -> Tuple[str, str]:
    """Convert input text to an MP3 file using Azure Cognitive Services Speech.

    Synthesizes natural-sounding speech from text using Azure neural voices.
    Authenticates via Azure RBAC (requires az login or managed identity).
    Writes MP3 directly to disk with configurable filename.
    
    Execution Flow:
    1. Initialize emitter for progress logging
    2. Determine output file path (auto-generated or custom)
    3. Load environment variables
    4. Authenticate with Azure Speech service (RBAC)
    5. Configure speech synthesizer (voice, format)
    6. Synthesize text to speech
    7. Write MP3 to file
    8. Return file path and log
    
    Parameters:
    -----------
    text : str
        The text to synthesize.
        Must be non-empty.
        Supports SSML for advanced control (pitch, speed, pauses).
        Example: "Hello, this is a test of the Azure Speech service."
        
    output_file : str, optional
        Destination MP3 filename.
        Can be absolute or relative path.
        If None, auto-generates: mp3_local/YYYYMMDD-HHMMSS.mp3
        Directory created automatically if doesn't exist.
        Example: "custom_output.mp3" or "audio/speech_20251110.mp3"
        
    emitter : Callable[[str], None], optional
        Optional callback for progress updates and debugging info.
        Signature: (str) -> None
        If None, prints to console.
        Used for UI updates (e.g., Streamlit).
        Example: lambda msg: print(f"[CUSTOM] {msg}")

    Returns:
    --------
    Tuple[str, str]
        (output_file_path, log_string)
        output_file_path: Absolute path to generated MP3 file
                          Example: "c:\\Github_Repo\\...\\mp3_local\\20251110-143052.mp3"
        log_string: Complete log of operation (progress and errors)
                    Useful for displaying operation details to user
    
    Authentication:
    ---------------
    Uses Azure RBAC with AzureCliCredential:
    1. Requires Azure CLI login: az login
    2. Obtains AAD token for Cognitive Services
    3. Formats token with resource ID: "aad#{resourceId}#{token}"
    4. Passes to SpeechSynthesizer for authentication
    
    Environment Requirements:
    - SPEECH_REGION: Azure region (e.g., "eastus")
    - SPEECH_RESOURCE_ID: Full resource ID from Azure portal
    - Optional: SPEECH_VOICE (default: "en-US-JennyNeural")
    - Optional: UTC_OFFSET for timestamp (default: 0)
    
    Raises:
    -------
    RuntimeError: If authentication fails or environment variables missing
    ValueError: If text is empty
    
    Example Usage:
    --------------
    ```python
    # Basic usage with auto-generated filename
    text = "Hello world"
    mp3_path, log = convert_text_to_mp3(text)
    print(f"Generated: {mp3_path}")
    
    # Custom filename
    mp3_path, log = convert_text_to_mp3(text, output_file="greeting.mp3")
    
    # With UI progress updates
    from helper.emitter import create_emitter
    emitter = create_emitter(lambda msg: print(f"[UI] {msg}"))
    mp3_path, log = convert_text_to_mp3(text, emitter=emitter.emit)
    
    # Error handling
    try:
        mp3_path, log = convert_text_to_mp3(text)
        print(f"Success: {mp3_path}")
    except RuntimeError as e:
        print(f"Authentication failed: {e}")
    except ValueError as e:
        print(f"Invalid input: {e}")
    ```
    
    Performance:
    ------------
    - Authentication: ~100-500ms (first call)
    - Synthesis: ~500ms-2s per 100 words
    - File write: <50ms
    - Total: ~1-3s for typical requests
    
    Audio Quality:
    --------------
    - Format: MP3 (24kHz, 160kbps, Mono)
    - Voice: Neural TTS (highly natural)
    - Typical file size: ~2-3 MB per 1000 words
    """
    # STEP 1: Initialize emitter for progress logging
    # create_emitter wraps callback or creates console emitter
    emit_util = create_emitter(emitter)
    
    def emit(msg: str):
        """Helper function to emit log messages."""
        emit_util.emit(msg)
    
    emit(f"[TTS] Starting text-to-speech conversion for {len(text)} characters")
    
    # STEP 2: Determine output file path
    if output_file is None:
        # Auto-generate timestamped filename in default directory
        
        # Create directory if doesn't exist
        # exist_ok=True: Don't error if directory already exists
        os.makedirs(DEFAULT_OUTPUT_DIR, exist_ok=True)
        
        # Generate timestamp with UTC offset (for user-friendly filenames)
        # UTC_OFFSET: Hours to add to UTC (e.g., 8 for UTC+8)
        utc_offset_hours = int(os.getenv('UTC_OFFSET', '0'))
        local_time = datetime.utcnow() + timedelta(hours=utc_offset_hours)
        
        # Format: YYYYMMDD-HHMMSS.mp3
        # Why this format? Sortable, unique, filesystem-safe
        ts = local_time.strftime('%Y%m%d-%H%M%S')
        output_file = os.path.join(DEFAULT_OUTPUT_DIR, f'{ts}.mp3')
        emit(f"[TTS] Using auto-generated filename: {output_file}")
    else:
        # Custom filename provided - ensure directory exists
        out_dir = os.path.dirname(output_file)
        if out_dir and not os.path.isdir(out_dir):
            # Create intermediate directories if needed
            os.makedirs(out_dir, exist_ok=True)
            emit(f"[TTS] Created output directory: {out_dir}")
        emit(f"[TTS] Using specified output file: {output_file}")
    
    # STEP 3: Load environment variables from .env file
    # override=False: Don't override already-set environment variables
    # Why lazy load? Allows import-time definition without .env dependency
    load_dotenv(override=False)

    # STEP 4: Validate required environment variables
    speech_region = os.environ.get('SPEECH_REGION')
    if not speech_region:
        # Missing region - cannot proceed
        emit("[ERROR] Missing SPEECH_REGION environment variable.")
        raise RuntimeError("Missing SPEECH_REGION environment variable.")
    
    emit(f"[TTS] Using Azure Speech service in region: {speech_region}")

    # STEP 5: Authenticate with Azure Speech service using RBAC
    try:
        # AzureCliCredential: Uses Azure CLI login credentials
        # Tries in order: Environment vars → Managed Identity → Azure CLI
        credential = AzureCliCredential()
        
        # Get AAD token for Cognitive Services
        # Scope: Standard Cognitive Services endpoint
        token = credential.get_token("https://cognitiveservices.azure.com/.default")
        emit(f"[TTS] Successfully obtained Azure RBAC authentication token (expires: {token.expires_on})")
        
        # Get Speech resource ID from environment
        # Required for RBAC authentication with SpeechSynthesizer
        # Format: /subscriptions/{sub}/resourceGroups/{rg}/providers/Microsoft.CognitiveServices/accounts/{name}
        speech_resource_id = os.environ.get('SPEECH_RESOURCE_ID')
        if not speech_resource_id:
            emit("[ERROR] Missing SPEECH_RESOURCE_ID environment variable required for RBAC authentication.")
            emit("[ERROR] Get your Speech resource ID from Azure portal -> Speech resource -> Properties -> Resource ID")
            raise RuntimeError("Missing SPEECH_RESOURCE_ID environment variable.")
        
        # Build authorization token with special format required by SpeechSynthesizer
        # Format: "aad#{resourceId}#{token}"
        # Why special format? SDK needs resource scoping for RBAC
        authorization_token = f"aad#{speech_resource_id}#{token.token}"
        emit("[TTS] Built authorization token with AAD format for SpeechSynthesizer")
        
        # Create speech config with RBAC token
        # auth_token: Uses token instead of subscription key
        # region: Routes request to correct Azure datacenter
        speech_config = speechsdk.SpeechConfig(auth_token=authorization_token, region=speech_region)
        emit("[TTS] Created SpeechConfig with AAD authorization token")
            
    except Exception as e:
        # Authentication failed - provide troubleshooting guidance
        emit(f"[ERROR] Failed to authenticate with Azure RBAC: {str(e)}")
        emit("[ERROR] Make sure you are logged in with 'az login' and have the appropriate RBAC permissions for the Speech service.")
        raise RuntimeError(f"Azure RBAC authentication failed: {str(e)}")

    # STEP 6: Configure speech synthesis settings
    
    # Select voice from environment or use default
    # SPEECH_VOICE: Neural voice name (e.g., "en-US-JennyNeural", "en-GB-SoniaNeural")
    # Default: en-US-JennyNeural (female US English, natural-sounding)
    # Full list: https://learn.microsoft.com/azure/ai-services/speech-service/language-support
    voice_name = os.environ.get('SPEECH_VOICE', 'en-US-JennyNeural')
    speech_config.speech_synthesis_voice_name = voice_name
    emit(f"[TTS] Using voice: {voice_name}")

    # Set audio output format to 24kHz 160kbps Mono MP3
    # Why 24kHz? High quality, suitable for most applications
    # Why 160kbps? Good balance between quality and file size
    # Why Mono? Sufficient for speech, smaller file size
    speech_config.set_speech_synthesis_output_format(
        speechsdk.SpeechSynthesisOutputFormat.Audio24Khz160KBitRateMonoMp3
    )
    emit("[TTS] Audio format set to 24kHz 160kbps Mono MP3")

    # Create audio output config that writes directly to file
    # filename: MP3 written here automatically by SDK
    # Why direct file write? More efficient than buffering in memory
    audio_config = speechsdk.audio.AudioOutputConfig(filename=output_file)
    
    # Create speech synthesizer with config
    # speech_config: Voice, format, authentication
    # audio_config: Output destination
    speech_synthesizer = speechsdk.SpeechSynthesizer(speech_config=speech_config, audio_config=audio_config)
    emit("[TTS] Speech synthesizer initialized")

    # STEP 7: Validate input text
    if not text:
        emit("[ERROR] Input text must be non-empty.")
        raise ValueError("Input text must be non-empty.")

    # STEP 8: Synthesize speech
    emit("[TTS] Starting speech synthesis...")
    
    # speak_text_async: Asynchronous synthesis (returns Future)
    # .get(): Block until synthesis complete
    # Audio written directly to file via audio_config
    result = speech_synthesizer.speak_text_async(text).get()

    # STEP 9: Check synthesis result
    if result.reason == speechsdk.ResultReason.SynthesizingAudioCompleted:
        # Synthesis successful
        emit(f"[SUCCESS] Speech synthesis completed successfully. Saved to {output_file}")
        
        # Get file size for additional info
        try:
            file_size = os.path.getsize(output_file)
            emit(f"[INFO] Generated MP3 file size: {file_size:,} bytes")
        except Exception:
            # File size retrieval failed - not critical
            pass
    
    elif result.reason == speechsdk.ResultReason.Canceled:
        # Synthesis canceled - extract error details
        cancellation_details = result.cancellation_details
        emit(f"[ERROR] Speech synthesis canceled: {cancellation_details.reason}")
        
        if cancellation_details.reason == speechsdk.CancellationReason.Error:
            # Error occurred during synthesis
            if cancellation_details.error_details:
                emit(f"[ERROR] Error details: {cancellation_details.error_details}")
            emit("[ERROR] Did you set the speech resource region correctly and authenticate with 'az login'?")
    
    # STEP 10: Return result
    return output_file, emit_util.get_log()


def convert_text_to_mp3_legacy(text: str, output_file: str = None) -> str:
    """Backward-compatible wrapper for convert_text_to_mp3 that returns only the file path.
    
    Maintains compatibility with existing code that expects only the file path.
    Discards the log output from convert_text_to_mp3.
    
    Purpose:
    --------
    Legacy API support - older code may call this function expecting:
    - Single return value (file path only)
    - No log string handling
    
    Migration Path:
    ---------------
    Old code:
    ```python
    mp3_path = convert_text_to_mp3_legacy("Hello world")
    ```
    
    New code (recommended):
    ```python
    mp3_path, log = convert_text_to_mp3("Hello world")
    # Can now access log for debugging/UI updates
    ```
    
    Parameters:
    -----------
    text : str
        The text to synthesize.
    output_file : str, optional
        Destination MP3 filename.
    
    Returns:
    --------
    str
        Absolute path to generated MP3 file.
    
    Note:
    -----
    This function is deprecated. Use convert_text_to_mp3() directly
    for access to detailed logging information.
    """
    # Call new function and extract only the path
    # Underscore (_) convention: Ignore log return value
    result_path, _ = convert_text_to_mp3(text, output_file)
    return result_path


# If run as a script, keep old CLI behavior
if __name__ == "__main__":
    """Command-line interface for text-to-speech conversion.
    
    Usage:
    ------
    Basic usage (default text):
    $ python helper/text2speech.py
    
    Custom text:
    $ python helper/text2speech.py "Your custom text here"
    
    Custom text and output file:
    $ python helper/text2speech.py "Hello world" custom_output.mp3
    
    Prerequisites:
    --------------
    1. Set environment variables:
       - SPEECH_REGION=eastus
       - SPEECH_RESOURCE_ID=/subscriptions/.../accounts/my-speech
    
    2. Authenticate with Azure:
       $ az login
    
    3. Optional environment variables:
       - SPEECH_VOICE=en-US-JennyNeural (default)
       - UTC_OFFSET=8 (for timestamp, default: 0)
    
    Example Output:
    ---------------
    [TTS] Starting text-to-speech conversion for 15 characters
    [TTS] Using auto-generated filename: mp3_local/20251110-143052.mp3
    [TTS] Using Azure Speech service in region: eastus
    [TTS] Successfully obtained Azure RBAC authentication token (expires: ...)
    [TTS] Built authorization token with AAD format for SpeechSynthesizer
    [TTS] Created SpeechConfig with AAD authorization token
    [TTS] Using voice: en-US-JennyNeural
    [TTS] Audio format set to 24kHz 160kbps Mono MP3
    [TTS] Speech synthesizer initialized
    [TTS] Starting speech synthesis...
    [SUCCESS] Speech synthesis completed successfully. Saved to mp3_local/20251110-143052.mp3
    [INFO] Generated MP3 file size: 245,678 bytes
    Final result: Saved MP3 to: mp3_local/20251110-143052.mp3
    
    Error Handling:
    ---------------
    Errors printed to console with exit code 1.
    Common errors:
    - Missing SPEECH_REGION or SPEECH_RESOURCE_ID
    - Azure login expired (run: az login)
    - Insufficient RBAC permissions
    """
    # Parse command-line arguments
    # sys.argv[0]: Script name (helper/text2speech.py)
    # sys.argv[1]: Text to synthesize (optional, defaults to DEFAULT_TEXT)
    # sys.argv[2]: Output filename (optional, auto-generated if not provided)
    try:
        # Get text from argument 1, or use default if not provided or empty
        targettext = sys.argv[1] if len(sys.argv) > 1 and sys.argv[1].strip() else DEFAULT_TEXT
        
        # Get output filename from argument 2, or None for auto-generation
        outfile = sys.argv[2] if len(sys.argv) > 2 and sys.argv[2].strip() else None
        
        # Perform text-to-speech conversion
        result_path, log = convert_text_to_mp3(targettext, outfile)
        
        # Log already printed via emit function (progress messages shown during execution)
        # Just print final result for clarity
        print(f"Final result: Saved MP3 to: {result_path}")
    
    except Exception as e:  # pragma: no cover - CLI error path
        # Catch all exceptions and print error message
        # Exit code 1: Indicates failure to caller (e.g., shell scripts)
        print(f"[ERROR] {e}")
        sys.exit(1)