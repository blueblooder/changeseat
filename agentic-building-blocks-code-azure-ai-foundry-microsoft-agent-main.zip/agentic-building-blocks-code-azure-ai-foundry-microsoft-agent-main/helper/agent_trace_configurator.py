# ------------------------------------
# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
# ------------------------------------

"""Agent Trace Configurator - OpenTelemetry Tracing Setup for Azure AI Agents.

Purpose:
--------
Provides centralized configuration for OpenTelemetry distributed tracing in Azure AI Agents applications.
Supports multiple tracing backends (Azure Monitor, Console) with agent instrumentation options.

This module serves as tracing infrastructure compared to:
- Manual OpenTelemetry setup: Scattered tracing code across application (hard to maintain)
- No tracing: Limited observability into agent operations (debugging nightmare)
- Application Insights only: Misses agent-specific spans and context

Key Capabilities:
-----------------
1. Azure Monitor Integration: Send traces to Application Insights (Azure Monitor)
2. Console Tracing: Print spans to console for development/debugging
3. Agent Instrumentation: Capture agent-specific operations (gen_ai namespace)
4. Interactive Menu: User-friendly CLI selection for tracing mode
5. Programmatic Configuration: setup_tracing(choice) for automated setup
6. Validation: Checks Application Insights connection string before enabling
7. Error Handling: Graceful degradation if instrumentation unavailable

Architecture:
-------------
```
Application
    |
    v
AgentTraceConfigurator(agents_client)
    |
    +---> setup_tracing(choice)
            |
            +---> Choice 1: Azure Monitor
            |       |
            |       +---> Validate APPLICATIONINSIGHTS_CONNECTION_STRING
            |       +---> configure_azure_monitor()
            |       +---> Traces sent to Azure portal
            |
            +---> Choice 2: Console (no agent)
            |       |
            |       +---> ConsoleSpanExporter
            |       +---> TracerProvider
            |       +---> Spans printed to stdout
            |
            +---> Choice 3: Console (with agent)
            |       |
            |       +---> ConsoleSpanExporter
            |       +---> TracerProvider
            |       +---> AIAgentsInstrumentor().instrument()
            |       +---> Agent spans included in output
            |
            +---> Choice 4: No tracing
                    |
                    +---> Skip tracing setup
```

Tracing Modes Explained:
-------------------------

Mode 1: Azure Monitor (Production)
- Endpoint: Application Insights in Azure Portal
- Use Case: Production observability, long-term storage
- Requires: APPLICATIONINSIGHTS_CONNECTION_STRING env var
- Benefits:
  ✓ Persistent trace storage (90 days default)
  ✓ Query interface (KQL)
  ✓ Visualizations (dependency maps, performance charts)
  ✓ Alerts and monitoring
- Drawbacks:
  ✗ Requires Azure subscription
  ✗ Network latency for trace export
  ✗ Cost (free tier: 5GB/month, then paid)

Mode 2: Console Without Agent Traces (Basic)
- Endpoint: stdout (terminal/console)
- Use Case: Development, debugging non-agent code
- Requires: Nothing (works offline)
- Benefits:
  ✓ Instant feedback (no network round-trip)
  ✓ Free (no Azure costs)
  ✓ Works offline
  ✓ Simple setup
- Drawbacks:
  ✗ No agent-specific spans (missing gen_ai operations)
  ✗ Console clutter (verbose output)
  ✗ No persistence (lost after process exit)
  ✗ No query/filter capabilities

Mode 3: Console With Agent Traces (Full)
- Endpoint: stdout with AIAgentsInstrumentor
- Use Case: Development, debugging agent operations
- Requires: azure-ai-agents package with AIAgentsInstrumentor
- Benefits:
  ✓ Full agent operation visibility (gen_ai namespace)
  ✓ See agent decision-making process
  ✓ Free and offline
  ✓ Instant feedback
- Drawbacks:
  ✗ Very verbose (many agent spans)
  ✗ No persistence
  ✗ Requires AIAgentsInstrumentor availability

Mode 4: No Tracing (Minimal Overhead)
- Endpoint: None
- Use Case: Performance testing, minimal dependencies
- Benefits:
  ✓ Zero tracing overhead
  ✓ Fastest execution
  ✓ Clean console output
- Drawbacks:
  ✗ No observability (blind to internal operations)
  ✗ Difficult debugging

Why Agent Instrumentation?
---------------------------
AIAgentsInstrumentor adds OpenTelemetry spans for:
- Agent initialization
- Tool calls
- Message processing
- Agent handoffs
- Error handling

Without instrumentation:
- Only see HTTP requests, database calls (generic spans)
- Missing agent context (which agent, which tool, which message)

With instrumentation:
- Full agent operation trace tree
- Span attributes: agent_id, tool_name, message_content
- Links between agent operations

Application Insights Setup:
----------------------------
Required Environment Variable:
  APPLICATIONINSIGHTS_CONNECTION_STRING

Format:
  InstrumentationKey=<guid>;IngestionEndpoint=https://<region>.in.applicationinsights.azure.com/...

How to Get:
1. Create Application Insights resource in Azure Portal
2. Go to resource → Overview → Copy "Connection String"
3. Set environment variable:
   - Windows: $env:APPLICATIONINSIGHTS_CONNECTION_STRING="..."
   - Linux/Mac: export APPLICATIONINSIGHTS_CONNECTION_STRING="..."
   - .env file: APPLICATIONINSIGHTS_CONNECTION_STRING=...

Why Connection String (not Instrumentation Key)?
- Modern approach (replaces legacy instrumentation key)
- Includes endpoint information (regional routing)
- More flexible (supports multiple regions)

Interactive Menu Flow:
----------------------
```
Select a tracing option:
1. Enable Azure Monitor tracing
2. Enable console tracing without enabling gen_ai agent traces
3. Enable console tracing with gen_ai agent traces
4. Do not enable traces
Enter your choice (1-4): _
```

Why Interactive?
- User-friendly (no command-line args)
- Discoverable (shows available options)
- Safe (validates input)

Programmatic Usage:
-------------------
Skip menu with direct choice parameter:
```python
configurator = AgentTraceConfigurator(agents_client)
configurator.setup_tracing(choice=1)  # Azure Monitor
configurator.setup_tracing(choice=3)  # Console with agents
```

Dependencies:
-------------
- opentelemetry (API and SDK)
  Install: pip install opentelemetry-api opentelemetry-sdk
  
- azure-monitor-opentelemetry
  Install: pip install azure-monitor-opentelemetry
  Required for: Azure Monitor mode (choice 1)
  
- azure-ai-agents (with AIAgentsInstrumentor)
  Install: pip install azure-ai-agents
  Required for: Agent instrumentation (choice 3)

Error Handling:
---------------
- Missing connection string: Prints error, exits (choice 1)
- AIAgentsInstrumentor unavailable: Prints warning, continues (choice 3)
- Invalid menu choice: Prints error, returns without exiting
- Invalid input (non-numeric): Prints error, returns

Why Not Raise Exceptions?
- User-facing tool (friendly errors)
- Tracing setup failure shouldn't crash application
- Allows graceful degradation

Best Practices:
---------------
1. Use Azure Monitor for production (persistent traces)
2. Use Console with agents for local development
3. Set APPLICATIONINSIGHTS_CONNECTION_STRING in .env (not code)
4. Enable tracing early in application lifecycle
5. Test with console mode before deploying to Azure

Security Considerations:
------------------------
- Connection string contains secrets (don't commit to git)
- Use Key Vault for production connection strings
- Rotate connection strings periodically
- Limit access to Application Insights resource

Performance Considerations:
---------------------------
- Azure Monitor: ~1-5ms overhead per span (network export)
- Console: ~0.1-1ms overhead per span (stdout write)
- No tracing: 0ms overhead
- Trade-off: Observability vs. performance

Example Usage:
--------------
```python
# Interactive menu
from helper.agent_trace_configurator import AgentTraceConfigurator
from azure.ai.agents import AgentsClient

client = AgentsClient(...)
configurator = AgentTraceConfigurator(client)
configurator.setup_tracing()  # Shows menu, prompts user

# Programmatic setup
configurator.setup_tracing(choice=1)  # Azure Monitor

# Environment-based choice
import os
trace_choice = int(os.getenv('TRACE_MODE', '4'))  # Default: no tracing
configurator.setup_tracing(choice=trace_choice)
```

Limitations:
------------
- Only supports Azure Monitor (not Jaeger, Zipkin, etc.)
- No custom span processor support
- No sampling configuration
- No dynamic tracing enable/disable (requires restart)
- Console export is synchronous (blocks on write)

Related Modules:
----------------
- helper/unified_trace_manager.py: UnifiedTraceManager for workflow tracing
- helper/trace_exporters.py: Custom trace exporters (JSON, etc.)
- helper/storeotel.py: OpenTelemetry trace persistence

Future Enhancements:
--------------------
- Support for additional exporters (Jaeger, Zipkin)
- Sampling configuration (percentage of traces)
- Batch span export (performance optimization)
- Custom span attributes injection
- Trace filtering by agent ID or operation
"""

import os
import sys
from typing import cast, Optional
from opentelemetry import trace  # OpenTelemetry API
from opentelemetry.sdk.trace import TracerProvider  # SDK implementation
from opentelemetry.sdk.trace.export import SimpleSpanProcessor, ConsoleSpanExporter  # Exporters
from azure.ai.agents import AgentsClient  # Azure AI Agents client
from azure.monitor.opentelemetry import configure_azure_monitor  # Azure Monitor integration


class AgentTraceConfigurator:
    """Configures OpenTelemetry tracing for Azure AI Agents applications.
    
    This class provides centralized tracing setup with multiple backend options (Azure Monitor, Console)
    and agent-specific instrumentation capabilities. Acts as configuration facade for OpenTelemetry SDK.
    
    Why Class-Based?
    ----------------
    - Encapsulation: Groups related tracing methods (Azure Monitor, Console, Agent instrumentation)
    - State Management: Holds agents_client reference for potential future use
    - Extensibility: Easy to add new tracing modes (e.g., Jaeger, Zipkin)
    - Testability: Can mock AgentTraceConfigurator in unit tests
    
    Why Not Singleton?
    ------------------
    - Multiple agents_client instances: Different agents may need different tracing configs
    - Testability: Singleton complicates test isolation
    - Flexibility: Allows per-instance configuration (not currently used, but future-proof)
    
    Attributes:
    -----------
    agents_client : AgentsClient
        Azure AI Agents client instance. Currently stored for future use (e.g., agent-specific filters).
        Not actively used in current methods but prepares for future enhancements like:
        - Filtering traces by agent ID
        - Injecting agent metadata into spans
        - Agent-specific sampling rates
    
    Design Patterns:
    ----------------
    - Facade: Simplifies OpenTelemetry SDK complexity (TracerProvider, Exporters, Processors)
    - Strategy: Encapsulates different tracing strategies (Azure Monitor, Console, None)
    - Command: Each method (enable_*) is a command object for tracing setup
    
    Thread Safety:
    --------------
    Not thread-safe. OpenTelemetry TracerProvider is global singleton, so calling setup methods
    from multiple threads may cause race conditions. Ensure setup_tracing() is called once at
    application startup, before spawning threads.
    
    Example:
    --------
    ```python
    from azure.ai.agents import AgentsClient
    from helper.agent_trace_configurator import AgentTraceConfigurator
    
    # Initialize agents client
    client = AgentsClient(connection_string="...")
    
    # Create configurator
    configurator = AgentTraceConfigurator(client)
    
    # Setup tracing
    configurator.setup_tracing(choice=1)  # Azure Monitor
    
    # Now all OpenTelemetry-instrumented code will export traces to Azure Monitor
    ```
    """
    
    def __init__(self, agents_client: AgentsClient):
        """Initialize the trace configurator with an Azure AI Agents client.
        
        Why Require agents_client?
        --------------------------
        - Future-proofing: Enables agent-specific tracing enhancements (filtering, metadata injection)
        - API consistency: Aligns with Azure AI Agents SDK patterns
        - Type safety: Ensures caller has valid AgentsClient instance
        
        Currently, agents_client is stored but not actively used in tracing setup. This design choice:
        1. Prepares for future features (agent-specific trace filtering)
        2. Maintains API stability (won't need breaking changes later)
        3. Documents intent (this is for agent tracing, not generic tracing)
        
        Parameters:
        -----------
        agents_client : AgentsClient
            Initialized Azure AI Agents client. Must be valid instance (not None).
            
            Initialization example:
            ```python
            from azure.ai.agents import AgentsClient
            client = AgentsClient(
                connection_string=os.getenv("AZURE_AI_AGENTS_CONNECTION_STRING")
            )
            ```
        
        Raises:
        -------
        No exceptions raised. agents_client validation deferred to future use.
        
        Example:
        --------
        ```python
        client = AgentsClient(connection_string="...")
        configurator = AgentTraceConfigurator(client)
        ```
        """
        # STEP 1: Store agents_client for future use
        # Why: Prepares for agent-specific tracing features (filtering, metadata, sampling)
        # Currently unused, but maintains API stability for future enhancements
        self.agents_client = agents_client


    def enable_azure_monitor_tracing(self) -> None:
        """Enable Azure Monitor (Application Insights) tracing for production observability.
        
        Configures OpenTelemetry to export traces to Application Insights in Azure Portal.
        This is the recommended tracing mode for production environments.
        
        Purpose:
        --------
        - Production Observability: Persistent trace storage in Azure (90 days default)
        - Query Interface: KQL query language for trace analysis
        - Visualizations: Dependency maps, performance charts, failure analysis
        - Alerting: Set alerts on trace patterns (high latency, error rates)
        - Correlation: Correlate traces with logs and metrics
        
        Execution Flow:
        ---------------
        1. Read APPLICATIONINSIGHTS_CONNECTION_STRING from environment
        2. Validate connection string exists (not None or empty)
        3. If missing: Print error message and exit (sys.exit(1))
        4. If present: Call configure_azure_monitor() to setup exporter
        
        Environment Variables:
        ----------------------
        APPLICATIONINSIGHTS_CONNECTION_STRING (required)
            Format: "InstrumentationKey=<guid>;IngestionEndpoint=https://<region>.in.applicationinsights.azure.com/..."
            
            How to obtain:
            1. Create Application Insights resource in Azure Portal
            2. Navigate to: Resource → Overview → "Connection String"
            3. Copy full connection string
            
            Setting the variable:
            - Windows PowerShell:
              $env:APPLICATIONINSIGHTS_CONNECTION_STRING="InstrumentationKey=..."
            - Linux/Mac:
              export APPLICATIONINSIGHTS_CONNECTION_STRING="InstrumentationKey=..."
            - .env file:
              APPLICATIONINSIGHTS_CONNECTION_STRING=InstrumentationKey=...
        
        configure_azure_monitor() Behavior:
        ------------------------------------
        Called from azure.monitor.opentelemetry package. This function:
        - Creates AzureMonitorTraceExporter (sends spans to Azure)
        - Registers BatchSpanProcessor (batches spans for efficiency)
        - Sets TracerProvider globally (all traces use this provider)
        - Configures resource attributes (service.name, telemetry.sdk)
        - Sets up auto-instrumentation (HTTP, database, etc.)
        
        Error Handling:
        ---------------
        Missing Connection String:
        - Error: Prints multi-line error message explaining how to fix
        - Action: exit() (terminates process)
        - Rationale: Cannot continue without connection string
        
        Best Practices:
        ---------------
        1. Use Key Vault for connection string (don't hardcode)
        2. Set connection string in deployment pipeline (not code)
        3. Monitor ingestion rate (Azure Portal → Application Insights → Usage)
        4. Set up alerts on ingestion anomalies
        
        Example:
        --------
        ```python
        import os
        os.environ['APPLICATIONINSIGHTS_CONNECTION_STRING'] = "InstrumentationKey=..."
        
        configurator = AgentTraceConfigurator(agents_client)
        configurator.enable_azure_monitor_tracing()
        ```
        """
        # STEP 1: Retrieve Application Insights connection string from environment
        # Why: Secrets should never be hardcoded (security best practice)
        # Why environment variable: Standard approach for cloud configuration (12-factor app)
        # Why this variable name: Microsoft standard for Application Insights connection strings
        application_insights_connection_string = os.environ.get("APPLICATIONINSIGHTS_CONNECTION_STRING")
        
        # STEP 2: Validate connection string exists
        # Why check here: Fail fast with clear error message (better than cryptic Azure Monitor error later)
        # Why not raise exception: CLI tool expectation (users expect exit, not stack trace)
        if not application_insights_connection_string:
            # STEP 2a: Print multi-line error message with instructions
            # Why multi-line: Provides complete context (what's missing, where to get it, how to set it)
            # Why print instead of logging: This is startup configuration (logging may not be setup yet)
            # Why mention AI Foundry: Many users create Application Insights via AI Foundry projects
            print("APPLICATIONINSIGHTS_CONNECTION_STRING environment variable was not set.")
            print("Please create APPLICATIONINSIGHTS_CONNECTION_STRING with the Application Insights,")
            print("connection string. It should be enabled for this project.")
            print("Enable it via the 'Tracing' tab in your AI Foundry project page.")
            
            # STEP 2b: Exit process
            # Why exit(): Terminate process (cannot proceed without connection string)
            # Note: exit() is equivalent to sys.exit(0), but here means fatal config error
            # Alternative: Could use sys.exit(1) for non-zero exit code (better for scripts)
            exit()
        
        # STEP 3: Configure Azure Monitor with connection string
        # Why configure_azure_monitor(): Microsoft-provided convenience function (handles all setup)
        # Why pass connection_string parameter: Explicit configuration (clearer than relying on env var inside SDK)
        # This single call does:
        #   - Creates AzureMonitorTraceExporter (sends spans to Azure)
        #   - Creates BatchSpanProcessor (batches spans for efficiency)
        #   - Sets TracerProvider globally (all traces use this provider)
        #   - Configures resource attributes (service.name, telemetry.sdk)
        #   - Sets up auto-instrumentation for HTTP, database, etc.
        configure_azure_monitor(connection_string=application_insights_connection_string)


    def enable_console_tracing_without_genai(self) -> None:
        """Enable console tracing without agent-specific instrumentation (basic mode).
        
        Configures OpenTelemetry to print spans to console (stdout). This mode captures generic
        OpenTelemetry spans but does NOT include agent-specific operations (no gen_ai namespace).
        
        Purpose:
        --------
        - Development Debugging: See traces locally without Azure account
        - Offline Development: No network connectivity required
        - Quick Testing: Instant feedback (no ingestion delay)
        - Cost Savings: Free (no Azure costs)
        
        What Gets Traced:
        -----------------
        ✓ HTTP requests (requests library, aiohttp)
        ✓ Database queries (psycopg2, pymongo, etc.)
        ✓ Custom spans created via OpenTelemetry API
        ✗ Agent operations (agent initialization, tool calls, handoffs)
        ✗ Gen AI operations (LLM calls, embeddings, completions)
        
        Why No Agent Traces?
        --------------------
        - AIAgentsInstrumentor not called: This method skips agent instrumentation
        - Use Case: When debugging non-agent code (HTTP, database, custom logic)
        - Performance: Fewer spans = less console clutter
        - Simplicity: Minimal dependencies (no agent instrumentation required)
        
        Execution Flow:
        ---------------
        1. Create ConsoleSpanExporter (prints spans to stdout)
        2. Create new TracerProvider (global singleton)
        3. Get tracer instance (for demonstration, not used)
        4. Cast tracer provider to TracerProvider type (type safety)
        5. Add SimpleSpanProcessor with ConsoleSpanExporter
        6. Print confirmation message
        
        OpenTelemetry Components:
        -------------------------
        ConsoleSpanExporter:
        - Purpose: Exports spans to console (stdout)
        - Format: Multi-line JSON-like representation
        - Output: Immediate (synchronous export on span end)
        - Limitation: No batching (one export per span)
        
        TracerProvider:
        - Purpose: Factory for creating Tracer instances
        - Scope: Global singleton (one per process)
        - Registration: trace.set_tracer_provider() makes it global
        
        SimpleSpanProcessor:
        - Purpose: Processes spans one-at-a-time (synchronous)
        - Behavior: Calls exporter.export() immediately on span end
        - Trade-off: Simple but slower than BatchSpanProcessor
        - Why use here: Console export is fast (no network), batching unnecessary
        
        Why Cast TracerProvider?
        ------------------------
        ```python
        provider = cast(TracerProvider, trace.get_tracer_provider())
        ```
        - Type safety: trace.get_tracer_provider() returns generic type
        - IDE support: Enables autocomplete for TracerProvider methods
        - MyPy compliance: Satisfies type checker
        
        Output Format Example:
        ----------------------
        ```
        {
            "name": "HTTP GET",
            "context": {
                "trace_id": "0x5f9c...",
                "span_id": "0x3a2b...",
                "trace_state": "[]"
            },
            "kind": "SpanKind.CLIENT",
            "parent_id": null,
            "start_time": "2025-01-15T10:30:00.123456Z",
            "end_time": "2025-01-15T10:30:00.456789Z",
            "status": {
                "status_code": "OK"
            },
            "attributes": {
                "http.method": "GET",
                "http.url": "https://api.example.com/data",
                "http.status_code": 200
            },
            "events": [],
            "links": [],
            "resource": {
                "telemetry.sdk.language": "python",
                "telemetry.sdk.name": "opentelemetry",
                "telemetry.sdk.version": "1.21.0",
                "service.name": "unknown_service"
            }
        }
        ```
        
        Console Output Characteristics:
        -------------------------------
        - Verbosity: High (many lines per span)
        - Color: None (plain text, could add color with custom exporter)
        - Buffering: Line-buffered (may delay in some terminals)
        - Performance: Synchronous write (blocks span end)
        
        When to Use This Mode:
        ----------------------
        ✓ Local development (laptop, no Azure account)
        ✓ Debugging HTTP requests, database queries
        ✓ Testing custom OpenTelemetry spans
        ✓ CI/CD pipelines (trace tests without Azure setup)
        ✗ Production (use Azure Monitor instead)
        ✗ Debugging agent operations (use enable_console_tracing_with_agent)
        ✗ High-volume tracing (console will scroll too fast)
        
        Comparison to enable_console_tracing_with_agent():
        ---------------------------------------------------
        | Feature                  | without_genai | with_agent |
        |--------------------------|---------------|------------|
        | HTTP requests            | ✓             | ✓          |
        | Database queries         | ✓             | ✓          |
        | Custom spans             | ✓             | ✓          |
        | Agent initialization     | ✗             | ✓          |
        | Tool calls               | ✗             | ✓          |
        | LLM calls                | ✗             | ✓          |
        | Handoffs                 | ✗             | ✓          |
        | Console output volume    | Low           | High       |
        | Dependencies             | Minimal       | AIAgentsInstrumentor |
        
        Best Practices:
        ---------------
        1. Use for debugging non-agent code (HTTP, database, custom logic)
        2. Redirect output to file for post-mortem analysis: `python app.py > traces.log`
        3. Filter spans by name if needed (grep "HTTP GET" traces.log)
        4. Switch to with_agent mode when debugging agent operations
        5. Switch to Azure Monitor for production
        
        Limitations:
        ------------
        - No persistence: Traces lost after process exit
        - No querying: Cannot filter/search after export
        - Console clutter: Verbose output (many lines per span)
        - Synchronous: Blocking export (slight performance impact)
        - No batching: One export per span (inefficient for high volume)
        
        Example:
        --------
        ```python
        configurator = AgentTraceConfigurator(agents_client)
        configurator.enable_console_tracing_without_genai()
        
        # Now trace HTTP requests
        import requests
        requests.get("https://api.example.com")  # Span printed to console
        ```
        
        Troubleshooting:
        ----------------
        - No output:
          1. Check if code is instrumented (auto-instrumentation may be disabled)
          2. Create manual span: `with tracer.start_as_current_span("test"): pass`
          3. Check if output redirected (console may go to /dev/null)
        
        - Too verbose:
          1. Use grep to filter: `python app.py 2>&1 | grep "span_name"`
          2. Switch to Azure Monitor (built-in filtering)
        """
        # STEP 1: Create ConsoleSpanExporter instance
        # Why: This exporter prints spans to stdout (console)
        # Why ConsoleSpanExporter: Built-in OpenTelemetry exporter (no custom implementation needed)
        # Alternative: Could use JSONSpanExporter (custom) for structured logs
        exporter = ConsoleSpanExporter()
        
        # STEP 2: Set global TracerProvider
        # Why TracerProvider: Factory for creating Tracer instances (OpenTelemetry SDK requirement)
        # Why set globally: All code in process will use this provider (centralized configuration)
        # Why new instance: Need fresh provider (previous config may exist)
        # Alternative: Could check if provider already set, but this overwrites cleanly
        trace.set_tracer_provider(TracerProvider())
        
        # STEP 3: Get tracer instance (for demonstration)
        # Why get_tracer: Standard OpenTelemetry pattern (even though not used here)
        # Why __name__: Tracer name (typically module name for attribution)
        # Note: This variable is created but not used (could be removed, but shows pattern)
        tracer = trace.get_tracer(__name__)
        
        # STEP 4: Cast tracer provider to TracerProvider type
        # Why cast: trace.get_tracer_provider() returns generic type (not TracerProvider specifically)
        # Why type safety: Enables access to add_span_processor() method (type checker compliance)
        # Why cast (not assert): Runtime type is correct, just need compile-time type hint
        provider = cast(TracerProvider, trace.get_tracer_provider())
        
        # STEP 5: Add span processor with console exporter
        # Why SimpleSpanProcessor: Synchronous processing (export immediately on span end)
        # Why not BatchSpanProcessor: Console export is fast (no network), batching unnecessary
        # Why add_span_processor: Registers exporter with provider (spans will be exported)
        # Execution: On span end → SimpleSpanProcessor.on_end() → ConsoleSpanExporter.export() → stdout
        provider.add_span_processor(SimpleSpanProcessor(exporter))
        
        # STEP 6: Print confirmation message
        # Why print: User feedback (confirms tracing is enabled)
        # Why "without agent traces": Clarifies limitation (no AIAgentsInstrumentor)
        print("Console tracing enabled without agent traces.")


    def enable_console_tracing_with_agent(self) -> None:
        """Enable console tracing WITH agent-specific instrumentation (full observability mode).
        
        Configures OpenTelemetry to print ALL spans to console, including agent-specific operations
        via AIAgentsInstrumentor. This is the most verbose tracing mode, capturing everything from
        HTTP requests to agent tool calls and LLM interactions.
        
        Purpose:
        --------
        - Agent Development: See every agent decision and tool invocation
        - Debugging Agent Flows: Trace multi-agent handoffs and message routing
        - LLM Observability: Capture gen_ai namespace spans (completions, embeddings)
        - Comprehensive Testing: Verify entire agent execution pipeline
        
        What Gets Traced:
        -----------------
        ✓ HTTP requests (requests library, aiohttp)
        ✓ Database queries (psycopg2, pymongo, etc.)
        ✓ Custom spans created via OpenTelemetry API
        ✓ Agent initialization (agent ID, configuration)
        ✓ Tool calls (tool name, arguments, results)
        ✓ Agent handoffs (source agent → target agent)
        ✓ LLM calls (gen_ai namespace: prompts, completions, tokens)
        ✓ Message processing (user message → agent response)
        
        Why Include Agent Traces?
        --------------------------
        - Full Visibility: See agent decision-making process (which tool, why, with what args)
        - Debugging Handoffs: Trace multi-agent conversations (agent A → agent B → agent C)
        - Performance Analysis: Identify slow tools or LLM calls
        - Error Attribution: See which agent/tool caused error
        
        Execution Flow:
        ---------------
        1. Create ConsoleSpanExporter (prints spans to stdout)
        2. Create new TracerProvider (global singleton)
        3. Add SimpleSpanProcessor to provider (registers exporter)
        4. Set TracerProvider globally (all code uses this provider)
        5. Get tracer instance (for demonstration, not used)
        6. Try to import and enable AIAgentsInstrumentor
        7. If successful: Instrument agent SDK (add gen_ai spans)
        8. If failed: Print warning but continue (graceful degradation)
        9. Print confirmation message
        
        AIAgentsInstrumentor Deep Dive:
        --------------------------------
        What is it?
        - Part of Azure AI Agents SDK (azure.ai.agents.telemetry)
        - Adds OpenTelemetry instrumentation to agent operations
        - Creates spans in gen_ai namespace (semantic conventions for AI)
        
        What does it instrument?
        - Agent initialization: Span for each agent creation
        - Tool execution: Span for each tool call (name, args, result)
        - Message processing: Span for message handling (user input → agent response)
        - Handoffs: Span for agent transitions (source_agent_id, target_agent_id)
        - LLM calls: Span for completions (model, prompt, tokens, latency)
        
        How does it work?
        ```python
        agents_instrumentor = AIAgentsInstrumentor()
        if not agents_instrumentor.is_instrumented():
            agents_instrumentor.instrument()
        ```
        - is_instrumented(): Checks if already instrumented (prevents double instrumentation)
        - instrument(): Monkey-patches agent SDK methods to add span creation
        
        Why check is_instrumented()?
        - Idempotency: Safe to call multiple times (won't double-instrument)
        - Performance: Avoid redundant instrumentation overhead
        - Safety: Prevent conflicts if already instrumented elsewhere
        
        Error Handling (Try/Except):
        ----------------------------
        Why try/except?
        - Graceful degradation: If AIAgentsInstrumentor unavailable, continue with basic tracing
        - Version compatibility: Older azure-ai-agents versions may lack AIAgentsInstrumentor
        - Import errors: If azure.ai.agents.telemetry module missing
        
        Why broad Exception (not specific)?
        - Multiple failure modes: ImportError, AttributeError, RuntimeError all possible
        - User-friendly: Print warning but don't crash (pylint: disable=broad-exception-caught)
        - Logging: Captures exception message for debugging
        
        What happens on failure?
        - Prints warning: "Could not call `AIAgentsInstrumentor().instrument()`. Exception: <error>"
        - Continues execution: Basic console tracing still works (HTTP, database, custom spans)
        - No agent spans: Missing gen_ai namespace (but app doesn't crash)
        
        Console Output Volume:
        ----------------------
        This mode produces VERY verbose output:
        - Each agent operation: 5-20 spans (initialization, tool calls, LLM calls)
        - Each LLM call: 2-5 spans (prompt, completion, token counting)
        - Each handoff: 3-7 spans (source agent end, handoff, target agent start)
        
        Example: Single agent query with one tool call:
        ```
        [50+ lines of span output]
        - agent.initialize (span)
        - agent.process_message (span)
          - llm.completion (span - prompt)
          - llm.completion (span - response)
          - tool.call (span)
            - http.request (span - tool makes API call)
          - llm.completion (span - final response)
        ```
        
        When to Use This Mode:
        ----------------------
        ✓ Debugging agent behavior (why did agent choose this tool?)
        ✓ Tracing multi-agent handoffs (agent A → B → C)
        ✓ Performance profiling (which tool is slow?)
        ✓ Testing agent logic changes (verify tool selection)
        ✗ Production (use Azure Monitor instead)
        ✗ High-volume testing (too verbose)
        ✗ Non-agent code debugging (use enable_console_tracing_without_genai)
        
        Comparison to enable_console_tracing_without_genai():
        ------------------------------------------------------
        | Feature                  | without_genai | with_agent |
        |--------------------------|---------------|------------|
        | HTTP requests            | ✓             | ✓          |
        | Database queries         | ✓             | ✓          |
        | Custom spans             | ✓             | ✓          |
        | Agent initialization     | ✗             | ✓          |
        | Tool calls               | ✗             | ✓          |
        | LLM calls                | ✗             | ✓          |
        | Handoffs                 | ✗             | ✓          |
        | Console output volume    | Low           | High       |
        | Dependencies             | Minimal       | AIAgentsInstrumentor |
        
        Agent Span Attributes Example:
        -------------------------------
        ```
        {
            "name": "agent.tool_call",
            "attributes": {
                "gen_ai.agent.id": "assistant_agent",
                "gen_ai.tool.name": "web_search",
                "gen_ai.tool.arguments": '{"query": "OpenTelemetry"}',
                "gen_ai.tool.result": '{"results": [...]}',
                "gen_ai.operation.name": "tool_call"
            }
        }
        ```
        
        LLM Span Attributes Example:
        -----------------------------
        ```
        {
            "name": "gen_ai.completion",
            "attributes": {
                "gen_ai.system": "azure_openai",
                "gen_ai.request.model": "gpt-4",
                "gen_ai.request.temperature": 0.7,
                "gen_ai.prompt.0.role": "user",
                "gen_ai.prompt.0.content": "Search for OpenTelemetry",
                "gen_ai.response.0.role": "assistant",
                "gen_ai.response.0.content": "I'll search for that...",
                "gen_ai.usage.prompt_tokens": 15,
                "gen_ai.usage.completion_tokens": 8,
                "gen_ai.usage.total_tokens": 23
            }
        }
        ```
        
        Best Practices:
        ---------------
        1. Redirect to file for analysis: `python app.py > agent_traces.log 2>&1`
        2. Use grep to filter specific operations: `grep "tool_call" agent_traces.log`
        3. Analyze token usage from spans: `grep "gen_ai.usage.total_tokens" agent_traces.log`
        4. Switch to Azure Monitor for production (persistent storage + querying)
        5. Combine with logging: Use logging.info() alongside spans for context
        
        Performance Impact:
        -------------------
        - Instrumentation overhead: ~0.5-2ms per agent operation
        - Console write overhead: ~0.1-1ms per span (synchronous stdout)
        - Total: ~1-5% slowdown for agent operations (acceptable for dev)
        - Production: Use Azure Monitor with batching (reduces overhead)
        
        Limitations:
        ------------
        - Very verbose: 50-200 lines per agent query (console clutter)
        - No persistence: Traces lost after process exit
        - No filtering: Cannot query by agent ID or tool name after export
        - Synchronous export: Slight performance impact (blocks on stdout write)
        - Dependency: Requires AIAgentsInstrumentor (graceful degradation if missing)
        
        Example:
        --------
        ```python
        configurator = AgentTraceConfigurator(agents_client)
        configurator.enable_console_tracing_with_agent()
        
        # Now trace agent operations
        agent = agents_client.create_agent(...)
        response = agent.run("Search for OpenTelemetry")
        # All agent spans printed to console (50+ lines)
        ```
        
        Troubleshooting:
        ----------------
        - No agent spans (only HTTP/database):
          1. Check AIAgentsInstrumentor import: `from azure.ai.agents.telemetry import AIAgentsInstrumentor`
          2. Check azure-ai-agents version: `pip show azure-ai-agents` (need recent version)
          3. Look for warning: "Could not call `AIAgentsInstrumentor().instrument()`"
        
        - Too verbose:
          1. Redirect to file: `python app.py > traces.log`
          2. Filter with grep: `grep "agent.tool_call" traces.log`
          3. Switch to Azure Monitor (built-in sampling)
        
        Security Considerations:
        ------------------------
        - Prompts/completions in spans: May contain sensitive data (PII, secrets)
        - Console output: Visible to anyone with terminal access
        - Log files: Secure storage (don't commit to git)
        - Production: Use Azure Monitor with access controls
        """
        # STEP 1: Create ConsoleSpanExporter instance
        # Why: This exporter prints spans to stdout (console)
        # Why variable name span_exporter: Differentiates from provider variable (clearer than "exporter")
        span_exporter = ConsoleSpanExporter()
        
        # STEP 2: Create new TracerProvider
        # Why TracerProvider: Factory for creating Tracer instances (OpenTelemetry SDK requirement)
        # Why new instance: Need fresh provider (clean slate)
        # Why variable name tracer_provider: Matches TracerProvider type (clearer than "provider")
        tracer_provider = TracerProvider()
        
        # STEP 3: Add span processor to provider BEFORE setting globally
        # Why add_span_processor first: Ensures exporter is registered before any spans are created
        # Why SimpleSpanProcessor: Synchronous processing (export immediately on span end)
        # Order matters: add_span_processor → set_tracer_provider (not reversed)
        tracer_provider.add_span_processor(SimpleSpanProcessor(span_exporter))
        
        # STEP 4: Set TracerProvider globally
        # Why set globally: All code in process will use this provider (centralized configuration)
        # Why after add_span_processor: Ensures exporter is registered before any spans are created
        # Alternative: Could set first, then add processor, but this order is clearer
        trace.set_tracer_provider(tracer_provider)
        
        # STEP 5: Get tracer instance (for demonstration)
        # Why get_tracer: Standard OpenTelemetry pattern (even though not used here)
        # Why __name__: Tracer name (typically module name for attribution)
        # Note: This variable is created but not used (could be removed, but shows pattern)
        tracer = trace.get_tracer(__name__)
        
        # STEP 6: Try to enable agent instrumentation (graceful degradation on failure)
        # Why try/except: AIAgentsInstrumentor may not be available (older SDK version, import error)
        # Why broad exception: Multiple failure modes (ImportError, AttributeError, RuntimeError)
        # Why not fail fast: Basic console tracing still works without agent instrumentation
        try:
            # STEP 6a: Import AIAgentsInstrumentor
            # Why import inside try: Defers import error until needed (lazy import)
            # Why from azure.ai.agents.telemetry: SDK-provided instrumentation (not custom)
            # This import may fail if:
            #   - azure-ai-agents not installed
            #   - Older version without telemetry module
            #   - Module renamed in newer versions
            from azure.ai.agents.telemetry import AIAgentsInstrumentor
            
            # STEP 6b: Create AIAgentsInstrumentor instance
            # Why new instance: Standard pattern for instrumentors (one instance per setup)
            # Why not singleton: Instrumentor class manages singleton internally
            agents_instrumentor = AIAgentsInstrumentor()
            
            # STEP 6c: Check if already instrumented (idempotency check)
            # Why check: Prevent double instrumentation (performance overhead, potential conflicts)
            # Why not skip check: Could lead to redundant monkey-patching (subtle bugs)
            # is_instrumented() returns bool: True if already instrumented, False otherwise
            if not agents_instrumentor.is_instrumented():
                # STEP 6d: Instrument agent SDK (add gen_ai spans)
                # Why instrument(): Monkey-patches agent SDK methods to create OpenTelemetry spans
                # What gets instrumented:
                #   - Agent initialization (agent ID, configuration)
                #   - Tool calls (tool name, arguments, results)
                #   - Message processing (user message → agent response)
                #   - Handoffs (source agent → target agent)
                #   - LLM calls (gen_ai namespace: prompts, completions, tokens)
                # Side effects: Modifies agent SDK methods in-place (monkey-patching)
                agents_instrumentor.instrument()
        
        except Exception as exc:  # pylint: disable=broad-exception-caught
            # STEP 6e: Handle instrumentation failure (graceful degradation)
            # Why broad exception: Multiple failure modes (ImportError, AttributeError, RuntimeError)
            # Why not re-raise: Tracing failure shouldn't crash application (graceful degradation)
            # Why pylint disable: Intentional broad exception for user-friendly error handling
            
            # Print warning with exception details
            # Why print (not log): Tracing setup happens early (logging may not be configured)
            # Why f-string: Include exception message for debugging
            # Why "Could not call": Clarifies that instrumentation was attempted but failed
            print(f"Could not call `AIAgentsInstrumentor().instrument()`. Exception: {exc}")
            
            # Continue execution: Basic console tracing still works (HTTP, database, custom spans)
            # Missing: gen_ai namespace spans (agent operations, tool calls, LLM calls)
        
        # STEP 7: Print confirmation message
        # Why print: User feedback (confirms tracing is enabled)
        # Why "with agent traces": Distinguishes from enable_console_tracing_without_genai()
        # Note: Even if instrumentation failed, this prints (basic tracing still enabled)
        print("Console tracing enabled with agent traces.")


    def display_menu(self) -> None:
        """Display interactive tracing configuration menu.
        
        Prints a user-friendly menu of available tracing options to console.
        Used by setup_tracing() when no choice parameter is provided.
        
        Purpose:
        --------
        - User Discoverability: Show all available tracing modes (users may not know options)
        - CLI Interaction: Standard menu-driven interface (familiar UX pattern)
        - Documentation: Menu text serves as inline documentation (explains each mode)
        
        Menu Options Explained:
        -----------------------
        Option 1: "Enable Azure Monitor tracing"
        - Backend: Application Insights (Azure Portal)
        - Use Case: Production observability
        - Requires: APPLICATIONINSIGHTS_CONNECTION_STRING env var
        - Output: Traces sent to Azure (persistent, queryable)
        - Cost: Free tier (5GB/month), then paid
        
        Option 2: "Enable console tracing without enabling gen_ai agent traces"
        - Backend: Console/stdout (local terminal)
        - Use Case: Development, debugging non-agent code
        - Requires: Nothing (works offline)
        - Output: Basic spans (HTTP, database, custom) printed to console
        - Cost: Free
        - Limitation: No agent-specific spans (missing gen_ai operations)
        
        Option 3: "Enable console tracing with gen_ai agent traces"
        - Backend: Console/stdout with AIAgentsInstrumentor
        - Use Case: Development, debugging agent operations
        - Requires: azure-ai-agents with AIAgentsInstrumentor
        - Output: All spans (HTTP, database, custom, agent, LLM) printed to console
        - Cost: Free
        - Limitation: Very verbose (50-200 lines per agent query)
        
        Option 4: "Do not enable traces"
        - Backend: None (no tracing)
        - Use Case: Performance testing, minimal dependencies
        - Output: No traces (clean console)
        - Limitation: No observability (blind to internal operations)
        
        Why Numbered Menu (not letters)?
        ---------------------------------
        - International: Numbers are universal (no language barriers)
        - Typing: Easier to type numbers than letters (less prone to uppercase/lowercase errors)
        - Parsing: int(input()) is simpler than string comparison
        - Convention: Standard CLI menu pattern (most users expect numbers)
        
        Why Four Options (not more)?
        -----------------------------
        - Simplicity: Covers 95% of use cases (production, dev, dev+agents, none)
        - Cognitive Load: More than 5-7 options is overwhelming (Hick's Law)
        - Extensibility: Can add more later (5, 6, 7...) if needed
        
        Output Format:
        --------------
        ```
        Select a tracing option:
        1. Enable Azure Monitor tracing
        2. Enable console tracing without enabling gen_ai agent traces
        3. Enable console tracing with gen_ai agent traces
        4. Do not enable traces
        ```
        
        Why "Select a tracing option:" header?
        - Context: Tells user what the menu is for (clarity)
        - Prompt: Indicates user action required (not just informational)
        
        Why "Enable" prefix for options 1-3?
        - Action-oriented: Verb indicates what happens when selected
        - Consistency: All tracing modes use same verb (parallel structure)
        
        Why "Do not enable traces" (not "Disable tracing")?
        - Positive framing: "Do not enable" is clearer than "Disable" (which implies something is enabled)
        - Consistency: Matches "Enable" pattern (parallel structure)
        
        Why "gen_ai agent traces" wording?
        - Technical accuracy: gen_ai is OpenTelemetry namespace for AI operations
        - Clarity: Distinguishes agent-specific spans from generic HTTP/database spans
        - SDK terminology: Matches Azure AI Agents SDK documentation
        
        Design Considerations:
        ----------------------
        - No blank lines between options: Compact menu (fits in one screen)
        - Simple numbering: 1, 2, 3, 4 (no fancy formatting like "[1]" or "1)")
        - No colors: Plain text (terminal compatibility, accessibility)
        - No icons: ASCII-only (universal terminal support)
        
        Accessibility:
        --------------
        - Screen readers: Numbers read aloud clearly ("1", "2", "3", "4")
        - No visual-only cues: All options have text descriptions
        - Clear prompting: User knows to "Enter your choice (1-4)"
        
        Example Usage:
        --------------
        ```python
        configurator = AgentTraceConfigurator(agents_client)
        configurator.display_menu()
        # Output:
        # Select a tracing option:
        # 1. Enable Azure Monitor tracing
        # 2. Enable console tracing without enabling gen_ai agent traces
        # 3. Enable console tracing with gen_ai agent traces
        # 4. Do not enable traces
        ```
        
        Returns:
        --------
        None (prints to stdout)
        
        Side Effects:
        -------------
        - Prints 5 lines to stdout (header + 4 options)
        - No state changes (purely informational)
        """
        # Print menu header
        # Why "Select a tracing option": Tells user what the menu is for (context + prompt)
        # Why colon: Standard menu header format (signals list follows)
        print("Select a tracing option:")
        
        # Print option 1: Azure Monitor
        # Why "1.": Standard numbered menu format (easy to parse)
        # Why "Enable Azure Monitor tracing": Action verb + backend name + tracing type
        # What it does: Calls enable_azure_monitor_tracing() (sends traces to Azure Portal)
        print("1. Enable Azure Monitor tracing")
        
        # Print option 2: Console without agent traces
        # Why "2.": Sequential numbering (follows option 1)
        # Why "without enabling gen_ai agent traces": Clarifies limitation (no AIAgentsInstrumentor)
        # What it does: Calls enable_console_tracing_without_genai() (basic console tracing)
        print("2. Enable console tracing without enabling gen_ai agent traces")
        
        # Print option 3: Console with agent traces
        # Why "3.": Sequential numbering (follows option 2)
        # Why "with gen_ai agent traces": Clarifies addition of AIAgentsInstrumentor
        # What it does: Calls enable_console_tracing_with_agent() (full console tracing)
        print("3. Enable console tracing with gen_ai agent traces")
        
        # Print option 4: No tracing
        # Why "4.": Sequential numbering (follows option 3)
        # Why "Do not enable traces": Clear opt-out (user explicitly chooses no tracing)
        # What it does: Nothing (setup_tracing() returns without calling tracing methods)
        print("4. Do not enable traces")


    def setup_tracing(self, choice: Optional[int] = None) -> None:
        """Main entry point for tracing configuration with interactive or programmatic mode.
        
        Configures OpenTelemetry tracing based on user selection (interactive menu) or
        programmatic choice parameter. Supports four tracing modes: Azure Monitor, Console
        without agents, Console with agents, or No tracing.
        
        Purpose:
        --------
        - Unified Entry Point: Single method for all tracing setup (simplifies caller code)
        - Dual Mode: Interactive (menu-driven) or programmatic (direct choice parameter)
        - Validation: Input validation with user-friendly error messages
        - Graceful Degradation: Invalid input doesn't crash (returns cleanly)
        
        Execution Flow:
        ---------------
        If choice is None (interactive mode):
        1. Display menu (show 4 tracing options)
        2. Prompt user for input ("Enter your choice (1-4): ")
        3. Parse input as integer (try/except for ValueError)
        4. If invalid (non-numeric): Print error and return
        5. If valid: Continue to choice handling
        
        If choice is provided (programmatic mode):
        1. Skip menu display (caller already knows what they want)
        2. Continue to choice handling
        
        Choice Handling (both modes):
        1. If choice == 1: Call enable_azure_monitor_tracing()
        2. If choice == 2: Call enable_console_tracing_without_genai()
        3. If choice == 3: Call enable_console_tracing_with_agent()
        4. If choice == 4: Print "No tracing enabled." (explicit opt-out)
        5. If choice is other: Print "Invalid choice." (validation)
        
        Parameters:
        -----------
        choice : Optional[int], default=None
            Tracing mode selection (1-4).
            
            Values:
            - None: Interactive mode (display menu, prompt user)
            - 1: Azure Monitor (Application Insights)
            - 2: Console without agent traces (basic)
            - 3: Console with agent traces (full)
            - 4: No tracing (opt-out)
            - Other: Invalid (prints error, returns without setting up tracing)
            
            When to use None (interactive):
            - CLI tools (user interaction expected)
            - Development scripts (quick setup)
            - Demos/workshops (user-friendly)
            
            When to provide value (programmatic):
            - Automated scripts (no user interaction)
            - Environment-based config (TRACE_MODE env var)
            - Testing (predictable setup)
            - Production (explicit configuration)
        
        Interactive Mode Deep Dive:
        ---------------------------
        Why display menu first?
        - User discovery: Shows available options (user may not know choices)
        - Documentation: Menu text explains each mode
        - Consistency: Standard CLI UX pattern
        
        Why input("Enter your choice (1-4): ")?
        - Clear prompt: Tells user exactly what to enter
        - Range hint: "(1-4)" guides valid input
        - Blocking: Waits for user input (synchronous)
        
        Why try/except ValueError?
        - User error: Non-numeric input (e.g., "abc", empty string)
        - Graceful handling: Print error instead of crash (user-friendly)
        - No re-prompt: Returns instead of loop (keeps code simple)
        
        Input Validation Example:
        ```python
        User enters: "2"      → choice = 2 (valid)
        User enters: "abc"    → ValueError, print error, return
        User enters: ""       → ValueError, print error, return
        User enters: "5"      → choice = 5, print "Invalid choice", return
        User enters: "1.5"    → ValueError, print error, return
        ```
        
        Programmatic Mode Deep Dive:
        -----------------------------
        Why allow programmatic choice?
        - Automation: Scripts/tests don't need user interaction
        - Environment-based: Read from config/env vars
        - Predictability: Same choice every run (no user input variance)
        
        Example: Environment-based configuration
        ```python
        import os
        trace_mode = int(os.getenv('TRACE_MODE', '4'))  # Default: no tracing
        configurator.setup_tracing(choice=trace_mode)
        ```
        
        Example: Testing
        ```python
        def test_console_tracing():
            configurator = AgentTraceConfigurator(mock_client)
            configurator.setup_tracing(choice=2)  # Predictable setup
            # Test code...
        ```
        
        Why Optional[int] (not just int)?
        - Dual mode: None enables interactive mode, int enables programmatic mode
        - Default None: Interactive by default (user-friendly for CLI tools)
        - Type safety: Signals to caller that None is valid
        
        Choice Handling Logic:
        ----------------------
        Why if/elif chain (not match/case)?
        - Python 3.9 compatibility: match/case requires Python 3.10+
        - Simplicity: Four choices don't need pattern matching
        - Clarity: if/elif is universally understood
        
        Why separate methods for each choice?
        - Single Responsibility: Each method handles one tracing mode
        - Testability: Can test each mode independently
        - Extensibility: Easy to add new modes (just add method + elif)
        
        Why print for choice 4?
        - User feedback: Confirms no tracing (not silent)
        - Explicit opt-out: User knows they chose no tracing (not a bug)
        
        Why print "Invalid choice" (not raise exception)?
        - User-friendly: Error message instead of stack trace
        - Graceful degradation: App can continue without tracing
        - CLI expectation: Users expect error messages, not crashes
        
        Error Handling:
        ---------------
        Non-numeric input (interactive):
        - Error: "Invalid input. Please enter a number between 1 and 4."
        - Action: Return (no tracing setup, app continues)
        - Rationale: User typo shouldn't crash app
        
        Out-of-range choice (1-4):
        - Error: "Invalid choice. Please select a valid option."
        - Action: Return (no tracing setup, app continues)
        - Rationale: Invalid choice shouldn't crash app
        
        Why return (not sys.exit)?
        - Non-fatal error: Tracing setup failure shouldn't crash app
        - Graceful degradation: App can run without tracing
        - Testability: Easier to test (no process exit)
        
        Side Effects:
        -------------
        - May print menu (if choice is None)
        - May prompt for input (if choice is None)
        - May set global TracerProvider (if choice 1-3)
        - May configure Azure Monitor (if choice 1)
        - May instrument agent SDK (if choice 3)
        - Prints confirmation messages (all choices)
        
        Returns:
        --------
        None (side effects only)
        
        Examples:
        ---------
        Interactive mode (menu-driven):
        ```python
        configurator = AgentTraceConfigurator(agents_client)
        configurator.setup_tracing()  # Shows menu, prompts user
        # User enters "1" → Azure Monitor enabled
        ```
        
        Programmatic mode (direct choice):
        ```python
        configurator = AgentTraceConfigurator(agents_client)
        configurator.setup_tracing(choice=3)  # Console with agents (no menu)
        ```
        
        Environment-based configuration:
        ```python
        import os
        trace_choice = int(os.getenv('TRACE_MODE', '4'))  # Default: no tracing
        configurator.setup_tracing(choice=trace_choice)
        ```
        
        Testing with fixed choice:
        ```python
        def test_azure_monitor_tracing():
            configurator = AgentTraceConfigurator(mock_client)
            configurator.setup_tracing(choice=1)  # Predictable setup
            # Assertions...
        ```
        
        Best Practices:
        ---------------
        1. Use programmatic mode for production (explicit configuration)
        2. Use interactive mode for development (quick setup)
        3. Set choice via environment variable (TRACE_MODE) for deployment flexibility
        4. Validate environment variable before passing to setup_tracing()
        5. Call setup_tracing() early in application lifecycle (before creating spans)
        
        Common Patterns:
        ----------------
        Pattern 1: Environment-based with validation
        ```python
        trace_mode = os.getenv('TRACE_MODE', '4')
        try:
            trace_choice = int(trace_mode)
            if trace_choice not in [1, 2, 3, 4]:
                print(f"Invalid TRACE_MODE: {trace_mode}, using no tracing")
                trace_choice = 4
        except ValueError:
            print(f"Invalid TRACE_MODE: {trace_mode}, using no tracing")
            trace_choice = 4
        configurator.setup_tracing(choice=trace_choice)
        ```
        
        Pattern 2: Conditional tracing (dev vs prod)
        ```python
        if os.getenv('ENVIRONMENT') == 'production':
            configurator.setup_tracing(choice=1)  # Azure Monitor
        elif os.getenv('ENVIRONMENT') == 'development':
            configurator.setup_tracing(choice=3)  # Console with agents
        else:
            configurator.setup_tracing(choice=4)  # No tracing
        ```
        
        Pattern 3: Feature flag
        ```python
        if feature_flags.get('tracing_enabled'):
            configurator.setup_tracing(choice=1)  # Azure Monitor
        else:
            configurator.setup_tracing(choice=4)  # No tracing
        ```
        
        Limitations:
        ------------
        - No re-prompt: Invalid input returns (user must restart)
        - No dynamic switching: Cannot change tracing mode after setup
        - Global state: TracerProvider is global singleton (affects entire process)
        - No validation of Azure Monitor connection string (deferred to enable_azure_monitor_tracing)
        """
        # STEP 1: Check if choice is provided (programmatic mode)
        # Why check None: None means interactive mode (display menu), int means programmatic mode
        # Why is None (not == None): PEP 8 style guide (is for None checks)
        if choice is None:
            # INTERACTIVE MODE: Display menu and prompt for user input
            
            # STEP 1a: Display menu of tracing options
            # Why display_menu(): Separate method for clarity (single responsibility)
            # What it does: Prints 5 lines (header + 4 options) to stdout
            self.display_menu()
            
            # STEP 1b: Prompt user for input and parse as integer
            # Why try/except: input() can return non-numeric string (ValueError on int() conversion)
            # Why not validate before int(): int() itself is the validation (catches all non-numeric input)
            try:
                # STEP 1b-i: Prompt user for choice
                # Why input(): Built-in blocking input function (waits for Enter key)
                # Why "Enter your choice (1-4)": Clear instruction + range hint
                # Why "(1-4)": Guides valid input (reduces user errors)
                # Return type: str (need to convert to int)
                user_input = input("Enter your choice (1-4): ")
                
                # STEP 1b-ii: Convert input to integer
                # Why int(): Parse string as integer (raises ValueError if non-numeric)
                # Examples:
                #   int("2") → 2 (valid)
                #   int("abc") → ValueError (handled in except block)
                #   int("") → ValueError (handled in except block)
                #   int("1.5") → ValueError (int doesn't accept floats as strings)
                choice = int(user_input)
            
            except ValueError:
                # STEP 1c: Handle non-numeric input (user error)
                # Why ValueError: Raised by int() when string is not valid integer
                # Examples: "abc", "", "1.5", "  ", "2a"
                
                # Print user-friendly error message
                # Why print (not raise): CLI tool expectation (error message, not stack trace)
                # Why "Invalid input": Clear problem statement
                # Why "number between 1 and 4": Tells user what's expected
                print("Invalid input. Please enter a number between 1 and 4.")
                
                # STEP 1d: Return without setting up tracing
                # Why return: Graceful degradation (app can continue without tracing)
                # Why not re-prompt: Keeps code simple (user can restart if needed)
                # Why not sys.exit: Tracing setup failure is non-fatal
                return
        
        # STEP 2: Handle choice (both interactive and programmatic modes reach here)
        # Why if/elif chain: Python 3.9 compatibility (match/case requires 3.10+)
        # Why not dict dispatch: Simple logic doesn't benefit from dispatch table
        # Choice values: 1 = Azure Monitor, 2 = Console (basic), 3 = Console (full), 4 = None
        
        if choice == 1:
            # STEP 2a: Enable Azure Monitor tracing (production mode)
            # What it does: Configure OpenTelemetry to send traces to Application Insights
            # Requires: APPLICATIONINSIGHTS_CONNECTION_STRING env var
            # Side effects: Sets global TracerProvider, configures Azure Monitor exporter
            # Output: "Azure Monitor tracing enabled." (or error if connection string missing)
            self.enable_azure_monitor_tracing()
        
        elif choice == 2:
            # STEP 2b: Enable console tracing without agent instrumentation (basic mode)
            # What it does: Configure OpenTelemetry to print spans to console (stdout)
            # Traces: HTTP, database, custom spans (no agent-specific spans)
            # Side effects: Sets global TracerProvider, adds ConsoleSpanExporter
            # Output: "Console tracing enabled without agent traces."
            self.enable_console_tracing_without_genai()
        
        elif choice == 3:
            # STEP 2c: Enable console tracing with agent instrumentation (full mode)
            # What it does: Configure OpenTelemetry to print ALL spans to console (including agent ops)
            # Traces: HTTP, database, custom, agent, LLM spans (very verbose)
            # Side effects: Sets global TracerProvider, adds ConsoleSpanExporter, instruments agent SDK
            # Output: "Console tracing enabled with agent traces." (or warning if instrumentation fails)
            self.enable_console_tracing_with_agent()
        
        elif choice == 4:
            # STEP 2d: No tracing (explicit opt-out)
            # What it does: Nothing (no tracing setup)
            # Why print: User feedback (confirms choice 4 was processed, not ignored)
            # Why "No tracing enabled": Clear confirmation (user chose this, not a bug)
            print("No tracing enabled.")
        
        else:
            # STEP 2e: Invalid choice (out of range 1-4)
            # When: User entered valid integer but not 1-4 (e.g., 0, 5, -1, 100)
            # Why print: User-friendly error message (clear problem statement)
            # Why "Invalid choice": Indicates problem
            # Why "select a valid option": Tells user how to fix (enter 1-4)
            # Why not re-prompt: Keeps code simple (user can restart if needed)
            print("Invalid choice. Please select a valid option.")

