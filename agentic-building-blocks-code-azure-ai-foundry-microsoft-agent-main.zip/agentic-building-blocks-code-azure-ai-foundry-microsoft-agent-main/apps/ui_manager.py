"""UI management for Streamlit application.

This module handles all Streamlit UI rendering logic, separating presentation
concerns from business logic (query handlers) and state management (session manager).

Key Responsibilities:
1. Sidebar Rendering: Mode selection, email parameters, UTC conversion display
2. Question Input: Text input with mode-specific defaults and state sync
3. Mode Change Handling: Detect transitions and trigger context clearing
4. UI State Coordination: Sync between Streamlit widgets and session state

Separation of Concerns:
- ui_manager: Renders widgets, handles user interactions
- session_manager: Manages state persistence across reruns
- query_handlers: Executes business logic based on user input

Why This Matters:
Streamlit reruns the entire script on every interaction. Careful management of:
- Widget keys (prevent duplicate widget errors)
- State synchronization (widgets ↔ session state)
- Rerun triggers (st.rerun() for mode changes)
is critical for stable UI behavior.

Design Patterns:
- Dependency Injection: session_manager and app_config injected via constructor
- Widget Key Strategy: Mode-specific keys prevent widget ID collisions
- State Synchronization: Read from session state → widget → write back to session state
- Controlled Reruns: Only rerun when absolutely necessary (mode changes)
"""

import streamlit as st
from apps.config import AppConfig
from apps.session_manager import SessionStateManager
from apps.time_utils import local_to_utc


class UIManager:
    """Manages UI components and user interactions.
    
    This class orchestrates all Streamlit UI rendering, keeping presentation
    logic separate from business logic and state management.
    
    Architecture:
    - UIManager renders UI and handles interactions
    - SessionStateManager persists state across reruns
    - AppConfig provides configuration and mode information
    - QueryHandlers process user requests (separate module)
    
    State Flow:
    1. UIManager renders widgets with values from SessionStateManager
    2. User interacts with widgets (changes mode, types question, etc.)
    3. Streamlit reruns entire script with new widget values
    4. UIManager detects changes (mode change, question update)
    5. UIManager updates SessionStateManager with new values
    6. If needed, triggers st.rerun() for clean state transition
    """
    
    def __init__(self, session_manager: SessionStateManager, app_config: AppConfig):
        """Initialize UI manager with required dependencies.
        
        Args:
            session_manager: Manages session state persistence
            app_config: Provides configuration and mode information
        
        Dependency Injection Benefits:
        - Testability: Can inject mocks for testing
        - Flexibility: Can swap implementations
        - Clear dependencies: Explicit about what's needed
        """
        self.session_manager = session_manager
        self.app_config = app_config
    
    def render_sidebar(self) -> str:
        """Render sidebar with mode selection and conditional email parameters.
        
        The sidebar contains:
        1. Mode selection radio buttons (always shown)
        2. Email parameters section (only for email modes)
        
        Mode Selection Strategy:
        - Display user-friendly labels with prefixes ([Agent], [Workflow], etc.)
        - Store internal mode identifiers in state (for code consistency)
        - Convert between display and internal using AppConfig.display_to_mode()
        
        Mode Change Handling:
        When user selects different mode:
        1. Detect change via session_manager.mode_changed()
        2. Clear old output via session_manager.clear_context()
        3. Trigger st.rerun() for clean UI reset
        
        Why st.rerun() after mode change?
        - Ensures clean slate for new mode
        - Prevents widget key conflicts
        - Updates default question immediately
        - Clears any stale UI elements
        
        Returns:
            Internal mode identifier string (e.g., "aiSearch", "BingSearch")
        
        Side Effects:
        - May trigger st.rerun() if mode changed
        - Updates session state with email parameters (if email mode)
        - Displays email UTC conversion info (if email mode)
        """
        # STEP 1: Render mode selection radio buttons
        # Shows user-friendly display labels with category prefixes
        # Radio button state managed by Streamlit automatically
        display_mode = st.sidebar.radio("Select Query Mode:", AppConfig.QUERY_MODES_DISPLAY)
        
        # STEP 2: Convert display label to internal mode identifier
        # Why convert? Code uses internal names ("aiSearch"), UI shows display names ("[Agent] AI Search")
        # Mapping defined in AppConfig._DISPLAY_TO_MODE dictionary
        query_mode = AppConfig.display_to_mode(display_mode)
        
        # STEP 3: Handle mode changes
        # Check if selected mode different from previous mode
        if self.session_manager.mode_changed(query_mode):
            # Mode changed - clean up old state
            # Clears output keys, sets question_needs_update flag, updates prev_query_mode
            self.session_manager.clear_context(query_mode)
            
            # Trigger immediate rerun for clean transition
            # Why rerun? Ensures:
            # - New default question loads
            # - Old expanders don't persist
            # - Widget keys update to new mode
            # - UI reflects new mode immediately
            st.rerun()
        
        # STEP 4: Conditionally render email parameters
        # Only show for modes that need email configuration
        # Defined in AppConfig.EMAIL_MODES set
        if query_mode in AppConfig.EMAIL_MODES:
            self._render_email_parameters()
        
        return query_mode
    
    def _render_email_parameters(self):
        """Render email-specific parameters in sidebar.
        
        Displays and manages email filtering parameters:
        - Start datetime (local time)
        - End datetime (local time)
        - Max items (page size)
        - UTC offset (for reference)
        - UTC conversion display (for verification)
        
        Why Local Time Input?
        Users think in their local timezone, not UTC.
        Example: "Show emails from 9am to 5pm today"
        
        UTC Conversion Display:
        Shows what times will be sent to API after conversion.
        Helps users verify correct time range will be queried.
        
        State Synchronization:
        - Read initial values from session state (or defaults)
        - Render widgets with those values
        - Update session state with any changes
        
        This ensures values persist across Streamlit reruns.
        """
        # Visual separation from mode selection
        st.sidebar.markdown("---")
        st.sidebar.markdown("### Email Retrieval Parameters")
        
        # Get email configuration (offset and defaults)
        email_config = AppConfig.get_email_config()
        utc_offset = email_config['utc_offset']
        
        # STEP 1: Render datetime inputs
        # Widget values come from session state (persistent across reruns)
        # Fallback to config defaults if not in session state yet
        
        # Start datetime input
        # Label shows UTC offset for user awareness
        start_dt = st.sidebar.text_input(
            f"Start DateTime (Local UTC+{utc_offset})", 
            value=st.session_state.get('email_start_dt', email_config['default_start']),
            key="start_dt_input"  # Unique key prevents widget ID collision
        )
        
        # End datetime input
        end_dt = st.sidebar.text_input(
            f"End DateTime (Local UTC+{utc_offset})", 
            value=st.session_state.get('email_end_dt', email_config['default_end']),
            key="end_dt_input"
        )
        
        # Max items numeric input
        # Constrained to reasonable range (1-100)
        # Why limit? API performance and practical usage
        max_items = st.sidebar.number_input(
            "Page size (top)", 
            min_value=1, 
            max_value=100, 
            value=st.session_state.get('email_max_items', 25),
            key="max_items_input"
        )
        
        # Sender filter input - allows filtering emails by sender addresses
        sender_filter = st.sidebar.text_input(
            "Filter by Senders (comma-separated)", 
            value=st.session_state.get('email_sender_filter', ''),
            placeholder="e.g., news@example.com, updates@site.com",
            help="Enter email addresses separated by commas. Leave empty to fetch all emails.",
            key="sender_filter_input"
        )
        
        # STEP 2: Update session state with current widget values
        # Why? Persist values across reruns
        # Without this, values would reset to defaults on every rerun
        self.session_manager.update_email_params(start_dt, end_dt, max_items, sender_filter)
        
        # STEP 3: Show UTC offset configuration (read-only info)
        # Displays configured offset for user reference
        # number_input used just for consistent styling (not editable in practice)
        st.sidebar.markdown("UTC Offset (hours):")
        st.sidebar.number_input("UTC Offset", min_value=-12, max_value=14, value=utc_offset)
        
        # STEP 4: Show UTC conversion preview
        # Helps users verify what times will actually be queried
        # Important: Users input local time, but API receives UTC
        st.sidebar.markdown("Email Time Range (converted to UTC for API calls):")
        
        # Convert local times to UTC using time_utils
        # These are the actual values that will be sent to Microsoft Graph API
        start_utc = local_to_utc(start_dt, utc_offset)
        end_utc = local_to_utc(end_dt, utc_offset)
        
        # Display converted times
        # Why show this? Transparency - user can verify conversion is correct
        # Example: Local 9am (UTC+8) → UTC 1am
        st.sidebar.markdown(f"UTC Start: {start_utc}")
        st.sidebar.markdown(f"UTC End: {end_utc}")
        
        # Display parsed sender filter if configured
        if sender_filter and sender_filter.strip():
            sender_list = [s.strip() for s in sender_filter.split(',') if s.strip()]
            st.sidebar.markdown(f"**Filtering {len(sender_list)} sender(s):**")
            for sender in sender_list:
                st.sidebar.markdown(f"  • {sender}")
        
        # Visual separation from rest of sidebar
        st.sidebar.markdown("---")
    
    def render_question_input(self, query_mode: str) -> str:
        """Render question input with mode-appropriate defaults.
        
        Manages the main question text input field with automatic default updates
        when mode changes.
        
        Default Question Behavior:
        - Each mode has a predefined default question (from ImportManager)
        - When mode changes, question updates to new mode's default
        - If user has typed something, that takes precedence
        - Empty question triggers default (helpful first-run behavior)
        
        State Synchronization Challenge:
        Streamlit text_input needs initial value, but also returns current value.
        We must sync: user typing → session state → text_input value
        
        Widget Key Strategy:
        Uses mode-specific key (f"question_input_{query_mode}") to:
        - Force widget recreation on mode change
        - Prevent duplicate widget ID errors
        - Allow Streamlit to track widget independently per mode
        
        Args:
            query_mode: Current internal mode identifier
        
        Returns:
            Current question text (from user input or default)
        
        State Flow:
        1. Check if question should update (mode change or empty)
        2. If yes, set default question in session state
        3. Render text_input with session state value
        4. If user types, detect change and update session state
        5. Return current question for use by query handler
        """
        # STEP 1: Get default question for current mode
        # Each mode has its own default (demonstrates mode's capabilities)
        default_question = self.app_config.get_default_question(query_mode)
        
        # STEP 2: Get current question from session state
        current_question = self.session_manager.get_user_question()
        
        # STEP 3: Check if question needs to be updated to default
        # Returns True if:
        # - Mode just changed (question_needs_update flag set)
        # - Question is empty AND default exists (helpful first-run)
        if self.session_manager.should_update_question(query_mode, default_question):
            # Update session state with default
            # This happens before rendering widget, so widget shows default
            self.session_manager.set_user_question(default_question)
            current_question = default_question
        
        # STEP 4: Render text input widget
        # value= sets initial display value (from session state)
        # key= makes widget unique per mode (prevents conflicts)
        #
        # Why mode-specific key?
        # - Streamlit tracks widgets by key
        # - When mode changes, key changes
        # - Streamlit treats it as new widget (fresh state)
        # - Prevents old widget state from persisting
        user_question = st.text_input(
            "Your question:", 
            value=current_question,
            key=f"question_input_{query_mode}"  # Unique per mode
        )
        
        # STEP 5: Detect and sync changes back to session state
        # If user typed something different from session state value
        # update session state to match (persist the change)
        #
        # Why check before updating?
        # - Avoid unnecessary state writes
        # - Prevent infinite update loops
        # - Only write when value actually changed
        if user_question != self.session_manager.get_user_question():
            self.session_manager.set_user_question(user_question)
        
        # STEP 6: Return current question
        # Used by main app to pass to query handler
        return user_question