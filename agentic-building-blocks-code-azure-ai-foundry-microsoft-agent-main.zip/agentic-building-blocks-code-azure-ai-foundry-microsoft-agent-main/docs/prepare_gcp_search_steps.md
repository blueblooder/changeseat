# Google Custom Search API Setup Guide

This guide provides step-by-step instructions to set up a GCP account and configure Google Custom Search API to obtain the required credentials: `GCS_CX` and `GCS_DEVELOPER_KEY`.

## Table of Contents

- [Prerequisites](#prerequisites)
- [Step-by-Step Setup](#step-by-step-setup)
  - [1. Create a Google Cloud Platform (GCP) Account](#1-create-a-google-cloud-platform-gcp-account)
  - [2. Create a New Project in GCP Console](#2-create-a-new-project-in-gcp-console)
  - [3. Enable the Custom Search API](#3-enable-the-custom-search-api)
  - [4. Create API Key (GCS_DEVELOPER_KEY)](#4-create-api-key-gcs_developer_key)
  - [5. Create a Custom Search Engine (GCS_CX)](#5-create-a-custom-search-engine-gcs_cx)
- [Credit Card Requirement](#credit-card-requirement)
- [Required Credentials](#required-credentials)

## Prerequisites

- A Google account (Gmail or Google Workspace)
- A valid credit or debit card for identity verification
- Basic understanding of GCP Console

## Step-by-Step Setup

### 1. Create a Google Cloud Platform (GCP) Account

1. Visit the [Google Cloud Platform website](https://cloud.google.com/)
2. Sign in using your Google account (Gmail or Google Workspace), or create a new Google account if needed
3. During account creation, you will need to provide billing information, including a valid credit or debit card
   - This is for **identity verification purposes only**
   - **You won't be charged during the free trial unless you explicitly upgrade to a paid plan**

### 2. Create a New Project in GCP Console

1. Go to the [Google Cloud Console](https://console.cloud.google.com/)
2. Click the **project selector** at the top of the page
3. Click **"New Project"**
4. Enter a project name and select or create a billing account
5. Click **"Create"**
   - Your new project will be created in a few moments

### 3. Enable the Custom Search API

1. In the Google Cloud Console, navigate to **"APIs & Services" > "Library"**
2. Search for **"Custom Search API"**
3. Click on the API in the search results
4. Click **"Enable"** to activate the API for your project

### 4. Create API Key (GCS_DEVELOPER_KEY)

1. In the Cloud Console, go to **"APIs & Services" > "Credentials"**
2. Click **"+ CREATE CREDENTIALS"** and select **"API key"**
3. An API key will be generated automatically
4. **Copy and securely store this key** - this is your `GCS_DEVELOPER_KEY`

> **Security Note**: Keep your API key secure and never commit it to public repositories. Consider using environment variables or secret management services.

### 5. Create a Custom Search Engine (GCS_CX)

1. Go to the [Custom Search Engine control panel](https://cse.google.com/cse/all)
2. Click **"Add"** to create a new custom search engine
3. Configure your search engine:
   - Enter websites you want to search, or choose to search the entire web
   - Give your search engine a descriptive name
4. Click **"Create"**
5. After creation, locate the **Search Engine ID** (your `GCS_CX` value)
   - This will be visible on the control panel
   - Or you can find it within the script portion as the value after `cx=`

## Credit Card Requirement

**Yes**, you do need to provide a credit card or valid payment method to sign up for a GCP account and activate the free trial.

Key points:
- **Primary purpose**: Identity verification
- **Free trial benefits**: Google offers **$300 free credits** valid for **90 days** to explore services
- **Charges**: No charges occur unless you explicitly activate a full paid billing account after the free trial

## Required Credentials

After completing this setup, you will have the following credentials:

| Variable | Description | Location |
|----------|-------------|----------|
| `GCS_CX` | Custom Search Engine ID | Custom Search Engine control panel |
| `GCS_DEVELOPER_KEY` | API Key | GCP Console > APIs & Services > Credentials |

These credentials are required to authenticate and make calls to the Google Custom Search API.

### Example Usage

```python
# Example environment variables
GCS_CX = "your-search-engine-id"
GCS_DEVELOPER_KEY = "your-api-key"
```

---

**Next Steps**: Configure these credentials in your application's environment variables or configuration file to start using the Google Custom Search API.