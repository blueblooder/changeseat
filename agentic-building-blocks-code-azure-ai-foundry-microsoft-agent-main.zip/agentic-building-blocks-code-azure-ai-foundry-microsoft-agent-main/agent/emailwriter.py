"""Email body writer agent tool.

This module provides email composition capabilities using Azure AI agents.

Agent Behavior:
	The agent analyzes draft email content and user context/questions,
	generates polished email bodies with proper formatting and tone,
	and returns HTML-formatted email content ready for sending.
"""

from __future__ import annotations

import os
from typing import List, Optional, Callable, Union
from datetime import datetime
from dotenv import load_dotenv
from azure.ai.projects import AIProjectClient
from azure.identity import AzureCliCredential
from azure.ai.agents.models import ListSortOrder, MessageRole

from helper.agent_config_loader import load_agent_config, AgentConfigError
from helper.emitter import create_emitter

load_dotenv()

PROJECT_ENDPOINT = os.getenv("PROJECT_ENDPOINT")
MODEL_DEPLOYMENT_NAME = os.getenv("MODEL_DEPLOYMENT_NAME")


def write_email_body(
    raw_body: str,
    attachments: Optional[List[str]] = None,
    *,
    user_question: Optional[str] = None,
    emitter: Optional[Callable[[str], None]] = None,
    return_mode: str = "answer",
    save_json: Optional[Union[str, os.PathLike]] = None,
    tracing_mode: str = "both",
) -> Union[str, dict]:
    """Write email body using Azure AI agent.
    
    The agent processes draft email content and generates polished HTML-formatted emails.
    
    Execution Flow:
    1. Initialize answer storage
    2. Setup emitter for progress tracking
    3. Validate return_mode parameter
    4. Configure OpenTelemetry tracing (Azure Monitor/console/none)
    5. Validate Azure project configuration (endpoint, model)
    6. Connect to Azure AI Project and agents client
    7. Load agent configuration from YAML file based on module name
    8. Format agent instructions with original_question placeholder
    9. Create agent with formatted instructions
    10. Create thread for agent conversation
    11. Submit email draft to agent
    12. Execute agent and gather HTML-formatted responses
    13. Clean up agent resources
    14. Collect OpenTelemetry traces and generate summary report
    15. Format return payload based on return_mode
    16. Save JSON artifact if requested
    
    Parameters
    ----------
    raw_body: The raw email body content to process.
    attachments: Optional list of attachment names/paths.
    user_question: Optional original user question for context.
    emitter: Optional callback(string) for incremental UI updates.
    return_mode: Controls return payload:
        'answer' -> answer text (fallback to log if empty)
        'log'    -> full log only
        'both'   -> dict { 'output_text': str, 'answer': str, 'log': str }
    save_json: Optional path to persist JSON artefact.
    tracing_mode: Controls OpenTelemetry tracing destination:
        'auto' (default) -> Azure Monitor if APPLICATIONINSIGHTS_CONNECTION_STRING is set, else none
        'azure_monitor'  -> Send traces to Azure AI Foundry Portal
        'console'        -> Print traces to console (with gen_ai agent traces)
        'none'           -> Disable tracing
    
    Returns
    -------
    str | dict depending on `return_mode`.
    """

    # STEP 1: Initialize answer storage
    # Why? Collect multiple HTML fragments from agent (potentially multiple text messages)
    answer_fragments: List[str] = []

    # STEP 2: Setup emitter for progress tracking
    # Why? Provides real-time feedback during email generation and debugging visibility
    emit_util = create_emitter(emitter)
    emit = emit_util.emit

    if attachments:
        emit(f"[INFO] {len(attachments)} attachment(s) provided (names only, not processed by agent).")

    # STEP 3: Validate return_mode parameter
    # Why? Fail early with clear error message if invalid mode specified
    # STEP 3: Validate return_mode parameter
    # Why? Fail early with clear error message if invalid mode specified
    if return_mode not in {"answer", "log", "both"}:
        raise ValueError("return_mode must be one of: 'answer', 'log', 'both'")

    # STEP 4: Configure OpenTelemetry tracing (Azure Monitor/console/none)
    # Why? Enables distributed tracing for debugging email generation workflow and performance analysis
    from helper.unified_trace_manager import UnifiedTraceManager
    
    trace_mgr = UnifiedTraceManager(
        tracing_mode=tracing_mode,
        emitter=emit,
        trace_type="agent"
    )
    tracer, span_collector = trace_mgr.setup()

    # STEP 5: Validate Azure project configuration (endpoint, model)
    # Why? Fail fast if environment variables missing - prevents confusing downstream errors
    if not PROJECT_ENDPOINT or not MODEL_DEPLOYMENT_NAME:
        emit("[ERROR] PROJECT_ENDPOINT and/or MODEL_DEPLOYMENT_NAME not configured in environment")
        joined_log = emit_util.get_log()
        if return_mode == "both":
            return {"output_text": joined_log, "answer": joined_log, "log": joined_log}
        if return_mode == "answer":  
            return joined_log
        
        return joined_log
    
    # STEP 6: Start parent tracing span with email context
    # Why? Captures end-to-end latency for email generation including attachment/question metadata
    body_preview = raw_body[:50] if raw_body else "empty"
    trace_mgr.start_parent_span(
        span_name=f"write_email_body: {body_preview}",
        attributes={
            "has_attachments": bool(attachments),
            "has_user_question": bool(user_question),
            "tracing_mode": tracing_mode
        }
    )
    
    # STEP 7: Connect to Azure AI Project and agents client
    # Why? All agent operations require AIProjectClient connection with proper credentials
    emit("Azure AI Project Client initializing...")
    try:
        with AIProjectClient(endpoint=PROJECT_ENDPOINT, credential=AzureCliCredential()) as project_client:
            agents_client = project_client.agents

            # STEP 8: Load agent configuration from YAML file based on module name
            # Why? Dynamic config loading allows separation of prompts from code
            emit("Loading agent configuration...")
            pyfile_name = os.path.splitext(os.path.basename(__file__))[0]
            agent_name, agent_instructions, agent_description = load_agent_config(pyfile_name)
            # Agent will: (1) Analyze draft email content and user context
            #             (2) Generate polished professional email with proper tone and formatting
            #             (3) Return HTML-formatted email body ready for sending
            emit(f"Loaded agent configuration: {agent_name}")


            # STEP 9: Format agent instructions with original_question placeholder
            # Why? Inject user context (user_question or raw_body) into agent instructions for targeted generation
            formatted_instructions = agent_instructions
            try:
                if "{original_question}" in agent_instructions or "{original_question:" in agent_instructions:
                    max_len = 10000
                    source_text = (user_question if user_question is not None else raw_body).strip()
                    if len(source_text) > max_len:
                        source_text = source_text[:max_len] + "... [TRUNCATED]"
                    formatted_instructions = agent_instructions.format(original_question=source_text)
                    which = "user_question" if user_question is not None else "raw_body"
                    emit(f"[AGENT CONFIG] Injected original_question from {which} into instructions")
            except KeyError as ke:
                emit(f"[WARN] Placeholder formatting issue ({ke}); using simple replacement for original_question")
                formatted_instructions = agent_instructions.replace("{original_question}", raw_body)
            except Exception as fmt_exc:
                emit(f"[WARN] Failed to format instructions with original_question: {fmt_exc}")
                formatted_instructions = agent_instructions.replace("{original_question}", raw_body)

            # STEP 10: Create agent with formatted instructions and no tools
            # Why? Email writing is pure generation task - no grounding or tool calling needed
            agent = agents_client.create_agent(
                model=MODEL_DEPLOYMENT_NAME,
                name=agent_name,
                description=agent_description,
                instructions=formatted_instructions,
                tools=[],
            )
            emit(f"Created agent ID: {agent.id}")

            # STEP 11: Create thread for agent conversation
            # Why? Provides isolated conversation context for this email generation request
            thread = agents_client.threads.create()
            emit(f"Created thread ID: {thread.id}")

            # STEP 12: Submit email draft to agent
            # Why? Provide raw email content for agent to analyze and polish
            user_content = f"Email body draft:\n{raw_body}"
            msg = agents_client.messages.create(thread_id=thread.id, role="user", content=user_content)
            emit("[AGENT PROMPT]\n" + user_content)

            # STEP 13: Execute agent and check run status
            # Why? Blocks until email generation completes, handles failure scenarios
            run = agents_client.runs.create_and_process(thread_id=thread.id, agent_id=agent.id)
            emit(f"Run status: {run.status}")
            if run.status == "failed":
                emit(f"Run failed: {run.last_error}")
                answer_fragments.append(f"[Agent run failed: {run.last_error}]")

            # STEP 14: Gather HTML-formatted email responses from agent
            # Why? Prefer text/html mime type for email bodies, fallback to plain text if unavailable
            messages = agents_client.messages.list(thread_id=thread.id, order=ListSortOrder.ASCENDING)
            for m in messages:
                if m.role == MessageRole.AGENT:
                    preferred_html = [
                        t.text.value
                        for t in getattr(m, "text_messages", [])
                        if getattr(t.text, "mime_type", None) == "text/html"
                    ]
                    if preferred_html:
                        for frag in preferred_html:
                            answer_fragments.append(frag)
                            emit("[AGENT OUTPUT]\n" + frag)
                    else:
                        for t in getattr(m, "text_messages", []):
                            val = t.text.value
                            answer_fragments.append(val)
                            emit("[AGENT OUTPUT]\n" + val)
                elif m.role != MessageRole.USER:
                    for t in getattr(m, "text_messages", []):
                        emit(f"[{m.role}] {t.text.value}")

            # STEP 15: Clean up agent resources with graceful degradation
            # Why? Free Azure resources immediately after use, warn if cleanup fails
            try:
                agents_client.delete_agent(agent.id)
                emit("Deleted agent")
            except Exception:
                emit("[WARN] Failed to delete agent (cleanup)")

    # STEP 16: Handle configuration errors by re-raising
    # Why? AgentConfigError contains specific YAML validation issues that should propagate to caller
    except AgentConfigError:
        raise
    # STEP 17: Handle unexpected exceptions with tracing integration
    # Why? Capture exceptions in OpenTelemetry spans for distributed debugging
    except Exception as exc:
        emit(f"[ERROR] Unexpected exception: {exc}")
        trace_mgr.record_exception(exc)
    
    # STEP 18: End parent tracing span
    # Why? Ensures span is closed even if exception occurred
    trace_mgr.end_parent_span()
    
    # STEP 19: Collect OpenTelemetry traces and generate summary
    # Why? Provides detailed performance metrics and distributed trace visualization
    trace_lines, trace_summary = trace_mgr.get_traces()
    
    # STEP 20: Emit trace summary report if traces collected
    # Why? Console visibility into span hierarchy, latency, and HTTP calls
    if trace_lines:
        emit("")
        emit("=" * 50)
        emit("OPENTELEMETRY TRACE SUMMARY")
        emit("=" * 50)
        emit(f"Total Spans: {trace_summary.get('total_spans', 0)}")
        emit(f"Agent Spans: {trace_summary.get('agent_spans', 0)}")
        emit(f"Thread Spans: {trace_summary.get('thread_spans', 0)}")
        emit(f"Message Spans: {trace_summary.get('message_spans', 0)}")
        emit(f"Run Spans: {trace_summary.get('run_spans', 0)}")
        emit(f"HTTP Spans: {trace_summary.get('http_spans', 0)}")
        emit(f"Main Elapsed: {trace_summary.get('main_elapsed_ms', 0):.2f}ms")
        emit("")
        for line in trace_lines:
            emit(line)
        emit("=" * 50)

    # STEP 21: Format answer fragments with HTML line breaks
    # Why? Join multiple fragments with <br> for HTML email display
    answer_joined = "<br>".join(answer_fragments) if answer_fragments else "[No agent response]"
    log_joined = emit_util.get_log()

    # STEP 22: Build return payload based on return_mode
    # Why? Flexible output format - answer only, logs only, or both with traces
    if return_mode == "both":
        payload: Union[str, dict] = {
            "output_text": answer_joined or log_joined,
            "answer": answer_joined,
            "log": log_joined,
            "traces": trace_lines,
            "trace_summary": trace_summary,
        }
    elif return_mode == "answer":
        payload = answer_joined if answer_joined else log_joined
    else:
        payload = log_joined

    # STEP 23: Save JSON artifact if requested with graceful degradation
    # Why? Persist email generation results for downstream processing, handle save failures gracefully
    if save_json:
        import json, pathlib
        try:
            p = pathlib.Path(save_json)
            p.parent.mkdir(parents=True, exist_ok=True)
            json.dump(
                {
                    "output_text": answer_joined or log_joined,
                    "answer": answer_joined,
                    "log": log_joined,
                    "traces": trace_lines,
                    "trace_summary": trace_summary,
                },
                p.open("w", encoding="utf-8"),
                ensure_ascii=False,
                indent=2,
            )
        except Exception as save_exc:
            emit(f"[WARN] Failed to save JSON artefact: {save_exc}")

    return payload


__all__ = ["write_email_body"]
