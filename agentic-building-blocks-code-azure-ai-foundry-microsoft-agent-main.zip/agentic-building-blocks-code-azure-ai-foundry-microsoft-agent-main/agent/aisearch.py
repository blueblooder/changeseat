"""Azure AI Search agent tool sample.

This module can be imported as `agent.azure_ai_search` or executed directly:

	python -m agent.azure_ai_search "your question"
or (from repo root):
	python .\agent\azure_ai_search.py "your question"

Agent Behavior:
	The agent will search an Azure AI Search index using vector-based semantic queries,
	retrieve the top 3 most relevant documents from the indexed knowledge base,
	and provide answers with inline source citations linking to original documents.
"""

from __future__ import annotations

import os
import sys
from dotenv import load_dotenv
from azure.ai.projects import AIProjectClient
from azure.ai.projects.models import ConnectionType
from azure.identity import AzureCliCredential
from azure.ai.agents.models import (
	AzureAISearchQueryType,
	AzureAISearchTool,
	ListSortOrder,
	MessageRole,
)

if __name__ == "__main__":
	repo_root = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
	if repo_root not in sys.path:
		sys.path.insert(0, repo_root)

from helper.agent_config_loader import load_agent_config, AgentConfigError
from helper.emitter import create_emitter
from helper.agent_trace_configurator import AgentTraceConfigurator

load_dotenv()

project_endpoint = os.getenv("PROJECT_ENDPOINT")
model_deployment_name = os.getenv("MODEL_DEPLOYMENT_NAME")
ai_search_connection_name = os.getenv("AI_SEARCH_CONNECTION_NAME")
ai_search_index_name = os.getenv("AI_SEARCH_INDEX_NAME")

DEFAULT_QUESTION = "tell me the Compliance Hotline"
DEFAULT_QUESTION1 = "tell me some medical benefits"

def run_azure_ai_search(
	question: str | None = None,
	emitter: callable | None = None,
	return_mode: str = "log",
	save_json: str | os.PathLike | None = None,
	tracing_mode: str = "both",
) -> str | dict:
	"""Execute an Azure AI Search query using an agent.

	The agent searches an Azure AI Search index with vector-based queries,
	retrieves top relevant documents, and provides answers with source citations.

	Execution Flow:
	1. Initialize emitter and validate question
	2. Setup OpenTelemetry tracing infrastructure
	3. Validate required environment configuration
	4. Initialize Azure AI Project Client and resolve search connection
	5. Load agent configuration from YAML
	6. Create agent with AI Search tool capabilities
	7. Execute agent conversation (create thread, post message, run agent)
	8. Process tool calls and extract search results
	9. Gather agent responses with citation expansion
	10. Cleanup resources and collect traces
	11. Format and return results based on return_mode

	Parameters
	----------
	question: Optional question text. Uses DEFAULT_QUESTION if blank.
	emitter: Optional callback(string) for incremental UI updates.
	return_mode: Controls return payload:
		'answer' -> answer text (fallback to log if empty)
		'log'    -> full log only (default for backward compatibility)
		'both'   -> dict { 'output_text': str, 'answer': str, 'log': str, 'traces': list, 'trace_summary': dict }
	save_json: Optional path to persist JSON artefact (best when return_mode='both').
	tracing_mode: Controls OpenTelemetry tracing destination:
		'both' (default)  -> Enable both Azure Monitor and Console tracing simultaneously
		'auto'           -> Azure Monitor if APPLICATIONINSIGHTS_CONNECTION_STRING is set, else none
		'azure_monitor'  -> Send traces to Azure AI Foundry Portal
		'console'        -> Print traces to console (with gen_ai agent traces)
		'none'           -> Disable tracing

	Returns
	-------
	str | dict depending on `return_mode`.
	"""

	# STEP 1: Initialize emitter utility and answer collection
	# Why list for answer_fragments? Agent may produce multiple text messages
	# We collect them all and join at the end for complete response
	answer_fragments: list[str] = []

	# Create emitter wrapper that handles None emitter gracefully
	# Why wrap? Provides uniform emit() interface regardless of caller
	emit_util = create_emitter(emitter)
	emit = emit_util.emit

	# STEP 2: Validate and normalize question input
	# Why check both None and empty string? Defensive programming
	# Callers might pass None, "", or whitespace-only strings
	# .strip() catches whitespace-only inputs that look non-empty
	if question is None or not question.strip():
		question = DEFAULT_QUESTION

	# STEP 3: Setup OpenTelemetry tracing infrastructure
	# Why UnifiedTraceManager? Centralizes tracing setup across agent/workflow modes
	# Handles Azure Monitor, console, and local file tracing transparently
	# trace_type="agent" configures agent-specific span collection
	from helper.unified_trace_manager import UnifiedTraceManager
	
	trace_mgr = UnifiedTraceManager(
		tracing_mode=tracing_mode,
		emitter=emit,
		trace_type="agent"
	)
	# Setup returns (tracer, trace_collector) tuple
	# tracer: OpenTelemetry Tracer for creating spans
	# trace_collector: Custom collector for formatting trace output
	tracer, trace_collector = trace_mgr.setup()

	# Extract tracing configuration flags for later logging
	# Why separate flags? Inform user which tracing backends are active
	azure_monitor_configured = trace_mgr.azure_monitor_configured
	console_configured = trace_mgr.console_configured
	local_trace_file = trace_mgr.local_trace_file

	# STEP 4: Validate required environment configuration
	# Why check early? Fail fast principle - no point proceeding without config
	# Better to error immediately than after expensive API calls
	if not project_endpoint or not model_deployment_name or not ai_search_connection_name:
		emit(
			"[ERROR] Please set PROJECT_ENDPOINT, MODEL_DEPLOYMENT_NAME, and AI_SEARCH_CONNECTION_NAME in your environment/.env"
		)
		log_joined = emit_util.get_log()
		# Graceful degradation: Return error log instead of raising exception
		# Why? Caller can handle error and display to user cleanly
		# Ternary handles both simple string and dict return modes
		return log_joined if return_mode != "both" else {"output_text": log_joined, "answer": log_joined, "log": log_joined}
	
	# STEP 5: Start parent trace span (if tracing enabled)
	# Why parent span? Creates root of trace tree for this execution
	# All subsequent operations (agent create, run, etc.) become child spans
	# Attributes capture execution context for debugging/analysis
	if tracer:
		trace_mgr.start_parent_span(
			span_name=f"run_azure_ai_search: {question[:50]}",  # Truncate long questions
			attributes={
				"question": question,
				"tracing_mode": tracing_mode,
			}
		)
	
	# STEP 6: Initialize Azure AI Project Client
	# Why context manager (with statement)? Ensures proper cleanup even on errors
	# Client manages connections to Azure AI services (agents, search, etc.)
	emit("Azure AI Project Client initializing...")
	try:
		with AIProjectClient(endpoint=project_endpoint, credential=AzureCliCredential()) as project_client:
			
			# STEP 7: Resolve Azure AI Search connection
			# Why get_default? Retrieves the default search connection configured in project
			# conn_id needed to link agent's search tool to correct search resource
			conn_id = project_client.connections.get_default(ConnectionType.AZURE_AI_SEARCH).id
			emit(f"Resolved Azure AI Search connection ID: {conn_id}")
			
			# STEP 8: Configure AI Search tool with vector search capabilities
			# Why vector search? Semantic similarity matching vs keyword search
			# top_k=3: Return top 3 most relevant documents (balance quality vs context length)
			# filter="": No additional filtering (could filter by metadata if needed)
			ai_search = AzureAISearchTool(
				index_connection_id=conn_id,
				index_name=ai_search_index_name,
				query_type=AzureAISearchQueryType.VECTOR,  # Semantic vector search
				top_k=3,  # Retrieve top 3 results
				filter="",  # No metadata filtering
			)
			
			# Get agents client for agent lifecycle operations
			agents_client = project_client.agents
			
			try:
				# STEP 9: Load agent configuration from YAML
				# Why YAML config? Separates prompt engineering from code
				# Allows non-developers to modify agent behavior
				# pyfile_name matches YAML filename convention (e.g., aisearch.py -> aisearch.yaml)
				emit("Loading agent configuration...")
				pyfile_name = os.path.splitext(os.path.basename(__file__))[0]
				agent_name, agent_instructions, agent_description = load_agent_config(pyfile_name)
				
				# Document agent capabilities for debugging/logging
				# Agent will: (1) Search Azure AI Search index using vector queries
				#             (2) Retrieve top 3 most relevant documents from knowledge base
				#             (3) Provide answers with inline source citations to original documents
				emit(f"Loaded agent configuration: {agent_name}")
				
			except AgentConfigError as cfg_err:
				# Configuration errors are fatal - can't create agent without config
				# Why early return? No point proceeding if agent setup fails
				emit(f"[ERROR] {cfg_err}")
				log_joined = emit_util.get_log()
				return log_joined if return_mode != "both" else {"output_text": log_joined, "answer": log_joined, "log": log_joined}

			emit("[AGENT CONFIG] Loaded configuration for azure_ai_search agent")
			
			# STEP 10: Create agent with AI Search tool
			# Why create new agent each time? Ensures fresh state, no residual context
			# Alternative: Reuse agent (faster) but risks context contamination
			# tools and tool_resources link agent to search capabilities
			agent = agents_client.create_agent(
				model=os.environ["MODEL_DEPLOYMENT_NAME"],  # LLM to use (e.g., gpt-4)
				name=agent_name,
				instructions=agent_instructions,  # System prompt defining behavior
				description=agent_description,
				tools=ai_search.definitions,  # Tool function signatures
				tool_resources=ai_search.resources,  # Search index resources
			)
			emit(f"Created agent ID: {agent.id}")
			
			# STEP 11: Create conversation thread
			# Why separate thread? Isolates this conversation from others
			# Thread maintains message history and context for agent
			thread = agents_client.threads.create()
			emit(f"Created thread ID: {thread.id}")
			
			# STEP 12: Post user message to thread
			# This is the actual question/prompt the agent will respond to
			emit("[AGENT PROMPT]\n" + question)
			msg = agents_client.messages.create(thread_id=thread.id, role="user", content=question)
			emit(f"Posted user message ID: {msg.id}")
			
			# STEP 13: Execute agent run (agent processes question and uses tools)
			# create_and_process blocks until agent completes
			# Agent will: analyze question → decide to use search tool → call search → synthesize answer
			run = agents_client.runs.create_and_process(thread_id=thread.id, agent_id=agent.id)
			emit(f"Run status: {run.status}")
			
			# STEP 14: Check for run failures
			# Why check? Run might fail due to: API limits, tool errors, timeout, etc.
			# Log error for debugging but continue to cleanup (don't leave orphaned resources)
			if run.status == "failed":
				emit(f"Run failed: {run.last_error}")

			# STEP 15: Extract and log run steps (shows agent's decision-making process)
			# Why log steps? Provides transparency into agent's reasoning and tool usage
			# Each step shows: agent thinking, tool calls, tool results
			# Useful for debugging: "Why did agent choose this search query?"
			run_steps = agents_client.run_steps.list(thread_id=thread.id, run_id=run.id)
			for step in run_steps:
				emit(f"[STEP] {step['id']} status={step['status']}")
				step_details = step.get("step_details", {})
				tool_calls = step_details.get("tool_calls", [])
				
				# STEP 16: Extract tool call details (search queries and results)
				# Why detailed logging? Shows exact search query agent used
				# Helps debug: "Did agent search for right terms?"
				for call in tool_calls:
					emit(f"  [TOOL CALL] id={call.get('id')} type={call.get('type')}")
					azure_ai_search_details = call.get("azure_ai_search", {})
					if azure_ai_search_details:
						emit("    input: " + str(azure_ai_search_details.get('input')))
						emit("    output: " + str(azure_ai_search_details.get('output')))

			# STEP 17: Gather agent responses with inline citation expansion
			# Why expand citations? Agent uses citation markers (e.g., [doc1]) in response
			# We replace markers with readable links: [see Title] (url)
			# Result: User-friendly answer with clickable source references
			messages = agents_client.messages.list(thread_id=thread.id, order=ListSortOrder.ASCENDING)
			for m in messages:
				if m.role == MessageRole.AGENT:
					# Build citation mapping: marker → readable link
					# Why dict? Fast O(1) lookup for replacements
					annotation_map = {}
					if m.url_citation_annotations:
						# Transform: [1] → [see Document Title] (https://...)
						annotation_map = {
							ann.text: f" [see {ann.url_citation.title}] ({ann.url_citation.url})" 
							for ann in m.url_citation_annotations
						}
					
					# Apply citation expansion to each text message
					for txt in m.text_messages:
						val = txt.text.value
						# Replace all citation markers with readable links
						for k, v in annotation_map.items():
							val = val.replace(k, v)
						answer_fragments.append(val)  # Collect for final answer
						emit("[AGENT OUTPUT]\n" + val)
						
				elif m.role != MessageRole.USER:
					# Log any non-agent, non-user messages (system, error, etc.)
					# Why? Helps debug unexpected message types
					for txt in m.text_messages:
						emit(f"[{m.role}] {txt.text.value}")

			# STEP 18: Cleanup agent resource
			# Why delete? Agents are stateful resources that cost money if left running
			# Best practice: Create agent per request, delete when done
			# Alternative: Keep agent alive (faster) but requires lifecycle management
			agents_client.delete_agent(agent.id)
			emit("Deleted agent")
			
			# STEP 19: Log tracing status to inform user
			# Why inform? User needs to know where to find traces for debugging
			# Azure Monitor: View in AI Foundry Portal (cloud-based analysis)
			# Local file: View in IDE or command line (offline debugging)
			if azure_monitor_configured:
				emit("")
				emit("AZURE MONITOR TRACING")
				emit("✅ Agent traces have been sent to Azure Monitor / Application Insights")
				emit("📊 View traces in Azure AI Foundry Portal: https://ai.azure.com")
				emit("")
			
			if local_trace_file:
				emit("")
				emit("LOCAL TRACING")
				emit(f"💾 Traces saved to: {local_trace_file}")
				emit("")
				
	except Exception as exc:
		# STEP 20: Handle unexpected exceptions
		# Why broad exception? Many possible failure points (network, auth, API, etc.)
		# Better to log and degrade gracefully than crash completely
		# record_exception captures exception in trace for debugging
		emit(f"[ERROR] Unexpected exception: {exc}")
		trace_mgr.record_exception(exc)
	finally:
		# STEP 21: End parent trace span (ensures span closed even on errors)
		# Why finally? Guarantees cleanup regardless of success/failure
		# Unclosed spans corrupt trace data and leak resources
		trace_mgr.end_parent_span()

	# STEP 22: Retrieve and format collected traces
	# Why separate step? Trace collection happens after main execution completes
	# trace_lines: List of formatted trace strings (for display)
	# trace_summary: Dict with span counts and timing metrics
	trace_lines, trace_summary = trace_mgr.get_traces()
	
	# STEP 23: Display trace summary in logs (if traces collected)
	# Why conditional? Only show if tracing was enabled and captured data
	# Provides quick diagnostic overview without opening separate trace viewer
	if trace_lines:
			emit("")
			emit("=" * 50)
			emit("OPENTELEMETRY TRACE SUMMARY")
			emit("=" * 50)
			# Display key metrics about agent execution
			# Why these metrics? Show workload distribution across operation types
			emit(f"Total Spans: {trace_summary.get('total_spans', 0)}")
			emit(f"Agent Spans: {trace_summary.get('agent_spans', 0)}")  # Agent lifecycle operations
			emit(f"Thread Spans: {trace_summary.get('thread_spans', 0)}")  # Thread operations
			emit(f"Message Spans: {trace_summary.get('message_spans', 0)}")  # Message create/list
			emit(f"Run Spans: {trace_summary.get('run_spans', 0)}")  # Run execution
			emit(f"HTTP Spans: {trace_summary.get('http_spans', 0)}")  # API calls
			emit(f"Main Elapsed: {trace_summary.get('main_elapsed_ms', 0):.2f}ms")  # Total duration
			emit("")
			# Display detailed trace lines (shows span hierarchy and timing)
			for line in trace_lines:
				emit(line)
			emit("=" * 50)

	# STEP 24: Assemble final answer from collected fragments
	# Why join with double newline? Creates readable separation between messages
	# Alternative: single newline (more compact) or custom delimiter
	answer_joined = "\n\n".join(answer_fragments)
	log_joined = emit_util.get_log()

	# STEP 25: Format return payload based on return_mode
	# Why three modes? Different callers need different data:
	# - "both": Full data for UI display (answer + logs + traces)
	# - "answer": Just answer text for simple use cases
	# - "log": Full execution log for debugging (backward compatible default)
	if return_mode == "both":
		payload = {
			"output_text": answer_joined or log_joined,  # Fallback to log if no answer
			"answer": answer_joined,
			"log": log_joined,
			"traces": trace_lines,  # Formatted trace strings for display
			"trace_summary": trace_summary,  # Metrics dict for summary view
		}
	elif return_mode == "answer":
		# Return answer if available, otherwise full log
		# Why fallback? Ensures caller always gets useful content
		payload = answer_joined if answer_joined else log_joined
	else:
		# Default: backward compatible log-only mode
		payload = log_joined

	# STEP 26: Optionally save execution artefact to JSON file
	# Why save? Enables offline analysis, regression testing, audit trails
	# Best with return_mode="both" (captures complete execution context)
	if save_json:
		import json, pathlib
		try:
			p = pathlib.Path(save_json)
			# Create parent directories if they don't exist
			# Why parents=True? Allows paths like "results/2024/output.json"
			# exist_ok=True prevents errors if directory already exists
			p.parent.mkdir(parents=True, exist_ok=True)
			
			# Save complete execution record
			# Why this structure? Provides both answer and diagnostic data
			json.dump(
				{
					"output_text": answer_joined or log_joined,
					"answer": answer_joined,
					"log": log_joined,
					"traces": trace_lines,
					"trace_summary": trace_summary,
				},
				p.open('w', encoding='utf-8'),
				ensure_ascii=False,  # Preserve Unicode characters
				indent=2,  # Pretty-print for readability
			)
		except Exception as save_exc:
			# STEP 27: Handle JSON save failures gracefully
			# Why not raise? Save is enhancement, shouldn't break main flow
			# Log warning but continue to return results
			emit(f"[WARN] Failed to save JSON artefact: {save_exc}")
			log_joined = emit_util.get_log()  # Refresh log with warning
			
			# Update payload with refreshed log
			# Why refresh? Warning message should be included in returned data
			if return_mode == "both":
				payload = {
					"output_text": answer_joined or log_joined,
					"answer": answer_joined,
					"log": log_joined,
					"traces": trace_lines,
					"trace_summary": trace_summary,
				}
			elif return_mode == "answer" and not answer_joined:
				# If answer mode but no answer, return log (includes save warning)
				payload = log_joined

	return payload


if __name__ == "__main__":
	question_arg = sys.argv[1] if len(sys.argv) > 1 and sys.argv[1].strip() else DEFAULT_QUESTION
	run_azure_ai_search(question_arg)

