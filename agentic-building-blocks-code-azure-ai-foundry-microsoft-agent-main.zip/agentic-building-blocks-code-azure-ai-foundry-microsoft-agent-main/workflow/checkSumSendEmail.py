"""Sequential workflow for email checking, analysis, and sending summary.

This workflow implements a three-stage sequential pipeline for email automation.

Workflow State Machine Flow:
    IDLE → IDLE_WITH_PENDING_REQUESTS (EmailRequest received)
         → PROCESSING (EmailFetcherExecutor retrieves emails via Graph API)
         → PROCESSING (EmailAnalyzerExecutor analyzes with Azure AI agent)
         → PROCESSING (EmailSenderExecutor composes and sends summary)
         → COMPLETED (email sent, workflow ends)

Executor Pipeline:
    1. EmailFetcherExecutor - Retrieves emails from Outlook using Microsoft Graph API
    2. EmailAnalyzerExecutor - Analyzes email content with Azure AI agent for insights
    3. EmailSenderExecutor - Composes HTML email summary and sends via Logic App

Message Flow:
    EmailRequest → EmailFetcherExecutor → EmailData
                → EmailAnalyzerExecutor → EmailAnalysis
                → EmailSenderExecutor → EmailSummary → COMPLETED

Prerequisites:
    - Microsoft Graph API access token for email retrieval
    - Azure AI Project endpoint for agent analysis
    - Logic App configured for email sending
"""

import os
import sys
from datetime import datetime
from typing import Never, TYPE_CHECKING, Callable, Optional, Any, List
from dataclasses import dataclass

if TYPE_CHECKING:
    pass

if __name__ == "__main__":
    repo_root = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
    if repo_root not in sys.path:
        sys.path.insert(0, repo_root)

from agent_framework import (
    Executor,
    WorkflowBuilder,
    WorkflowContext,
    WorkflowOutputEvent,
    handler,
    get_logger,
)
from agent_framework.observability import setup_observability
from opentelemetry import trace
from agent.checkemail import run_check_emails, run_email_agent_analysis
from agent.emailwriter import write_email_body
from helper.logicappemail import send_email
from helper.otel_collector import get_span_collector
from helper.storeotel import store_otel_traces_to_local
from helper.emitter import create_emitter


DEFAULT_QUESTION = "Please analyze my recent emails"

logger = get_logger()

@dataclass
class EmailRequest:
    """Initial request to fetch emails."""
    start_datetime: str
    end_datetime: str
    max_items: int = 25
    from_addresses: Optional[List[str]] = None
    user_question: str = ""


@dataclass
class EmailData:
    """Emails retrieved from Outlook."""
    emails: list
    count: int
    user_question: str


@dataclass
class EmailAnalysis:
    """Analysis results from Azure AI agent."""
    analysis_text: str
    email_count: int
    user_question: str


@dataclass
class EmailSummary:
    """Final email summary with composed email body."""
    subject: str
    body: str
    analysis_text: str


class EmailFetcherExecutor(Executor):
    """Fetches emails from Outlook using Graph API."""
    
    def __init__(self, emitter: Optional[Callable[[str], None]] = None, id: str = "email_fetcher"):
        super().__init__(id=id)
        self.emitter = emitter
    
    @handler
    async def fetch_emails(self, request: EmailRequest, ctx: WorkflowContext[EmailData]) -> None:
        """Retrieve emails from Outlook."""
        emit = create_emitter(self.emitter).emit
        
        emit(f"[EmailFetcher] Starting email retrieval...")
        emit(f"[EmailFetcher] Date range: {request.start_datetime} to {request.end_datetime}")
        emit(f"[EmailFetcher] Max items: {request.max_items}")
        if request.from_addresses:
            emit(f"[EmailFetcher] Filtering by {len(request.from_addresses)} sender(s): {', '.join(request.from_addresses)}")
        
        # Fetch emails using existing agent function
        result = run_check_emails(
            request.start_datetime,
            request.end_datetime,
            max_items=request.max_items,
            from_addresses=request.from_addresses,
            emitter=self.emitter,
            store_local=False,  # Don't store, pass to next executor
            analyze_with_agent=False,  # Analysis happens in next executor
            return_mode="both"
        )
        
        # Extract emails from result
        if isinstance(result, dict):
            output_text = result.get("output_text", "")
            # Parse JSON email content
            import json
            try:
                emails = json.loads(output_text)
                if not isinstance(emails, list):
                    emails = []
            except (json.JSONDecodeError, TypeError):
                emails = []
                emit(f"[EmailFetcher] Warning: Could not parse emails from result")
        else:
            emails = []
        
        email_count = len(emails)
        emit(f"[EmailFetcher] ✓ Retrieved {email_count} emails")
        
        # Send to analyzer
        email_data = EmailData(
            emails=emails,
            count=email_count,
            user_question=request.user_question
        )
        await ctx.send_message(email_data, target_id="email_analyzer")


class EmailAnalyzerExecutor(Executor):
    """Analyzes emails using Azure AI agent."""
    
    def __init__(self, emitter: Optional[Callable[[str], None]] = None, id: str = "email_analyzer"):
        super().__init__(id=id)
        self.emitter = emitter
    
    @handler
    async def analyze_emails(self, email_data: EmailData, ctx: WorkflowContext[EmailAnalysis]) -> None:
        """Process emails through Azure AI agent."""
        emit = create_emitter(self.emitter).emit
        
        emit(f"[EmailAnalyzer] Starting analysis of {email_data.count} emails...")
        
        if not email_data.emails:
            emit(f"[EmailAnalyzer] No emails to analyze")
            analysis_text = "No emails found for the specified date range."
        else:
            # Run agent analysis
            result = run_email_agent_analysis(
                email_data.emails,
                emitter=self.emitter,
                return_mode="both"
            )
            
            if isinstance(result, dict):
                analysis_text = result.get("answer", result.get("output_text", ""))
            else:
                analysis_text = str(result)
            
            emit(f"[EmailAnalyzer] ✓ Analysis complete ({len(analysis_text)} chars)")
        
        # Send to email sender
        email_analysis = EmailAnalysis(
            analysis_text=analysis_text,
            email_count=email_data.count,
            user_question=email_data.user_question
        )
        await ctx.send_message(email_analysis, target_id="email_sender")


class EmailSenderExecutor(Executor):
    """Composes and sends email summary."""
    
    def __init__(self, emitter: Optional[Callable[[str], None]] = None, recipient_email: Optional[str] = None, id: str = "email_sender"):
        super().__init__(id=id)
        self.emitter = emitter
        self.recipient_email = recipient_email
    
    @handler
    async def send_summary(self, analysis: EmailAnalysis, ctx: WorkflowContext[str]) -> None:
        """Compose and send email with analysis results."""
        emit = create_emitter(self.emitter).emit
        
        emit(f"[EmailSender] Composing email summary...")
        
        # Use email writer agent to compose professional email
        result = write_email_body(
            analysis.analysis_text,
            user_question=analysis.user_question,
            emitter=self.emitter,
            return_mode="both"
        )
        
        if isinstance(result, dict):
            email_content = result.get("answer", result.get("output_text", ""))
        else:
            email_content = str(result)
        
        # Parse subject and body (format: subject#####body)
        if "#####" in email_content:
            subject_part, body_part = email_content.split("#####", 1)
            subject = subject_part.strip()
            body = body_part.strip()
        else:
            subject = "Email Analysis Summary"
            body = email_content
        
        emit(f"[EmailSender] Email composed: {subject}")
        
        # Send email if recipient configured
        if self.recipient_email:
            emit(f"[EmailSender] Sending email to {self.recipient_email}...")
            
            send_result = send_email(
                to=self.recipient_email,
                subject=subject,
                body=body,
                emitter=self.emitter,
                return_mode="both"
            )
            
            emit(f"[EmailSender] ✓ Email sent successfully")
        else:
            emit(f"[EmailSender] No recipient configured, skipping email send")
        
        # Yield final output - format as text
        output_text = f"{subject}\n\n{body}"
        await ctx.yield_output(output_text)


# ============================================================================
# Workflow Builder
# ============================================================================

def build_workflow(emitter: Optional[Callable[[str], None]] = None, recipient_email: Optional[str] = None):
    """Build the sequential email workflow with OpenTelemetry tracing.
    
    Workflow flow:
        EmailFetcherExecutor → EmailAnalyzerExecutor → EmailSenderExecutor → Output
    """
    
    # Create executors
    fetcher = EmailFetcherExecutor(emitter=emitter)
    analyzer = EmailAnalyzerExecutor(emitter=emitter)
    sender = EmailSenderExecutor(emitter=emitter, recipient_email=recipient_email)
    
    # Build sequential workflow
    workflow = (
        WorkflowBuilder()
        .set_start_executor(fetcher)
        .add_edge(fetcher, analyzer)
        .add_edge(analyzer, sender)
        .build()
    )
    
    return workflow


# ============================================================================
# Public Interface
# ============================================================================

def run_check_sum_send_email(
    start_datetime: str,
    end_datetime: str,
    max_items: int = 25,
    from_addresses: Optional[List[str]] = None,
    user_question: str = "",
    emitter: Optional[Callable[[str], None]] = None,
    return_mode: str = "both",
    recipient_email: Optional[str] = None,
    tracing_mode: str = "both",  # 'auto' | 'both' | 'azure_monitor' | 'console' | 'none'
) -> str | dict:
    """Run the email check, summarize, and send workflow.
    
    This is a synchronous wrapper around the async workflow execution.
    
    Parameters
    ----------
    start_datetime : str
        Start date/time for email filtering (ISO 8601 format, UTC).
    end_datetime : str
        End date/time for email filtering (ISO 8601 format, UTC).
    max_items : int
        Maximum number of emails to retrieve (default: 25).
    user_question : str
        Optional context/question for the analysis.
    emitter : Callable[[str], None]
        Optional callback for streaming log lines.
    return_mode : str
        'log' | 'answer' | 'both' (default: 'both')
    recipient_email : str
        Email address to send summary to (if None, email not sent).
    tracing_mode : str
        Controls where traces are sent:
        'auto' (default) -> Azure Monitor if APPLICATIONINSIGHTS_CONNECTION_STRING is set, else local
        'local' -> Save to local JSON file only
        'azure_monitor' -> Send to Azure Monitor / Application Insights (viewable in Azure AI Foundry)
        'console' -> Print traces to console
        'none' -> Disable tracing
    
    Returns
    -------
    str | dict
        Depending on return_mode:
        - 'log': Full execution log
        - 'answer': Email summary text
        - 'both': {'output_text': str, 'answer': str, 'log': str, 'traces': list, 'trace_summary': dict, 'trace_file': str}
    """
    # Validate recipient_email if provided
    if recipient_email is not None and recipient_email.strip() == "":
        error_msg = "[ERROR] DEFAULT_EMAIL_RECIPIENT is not configured. Please set it in .env file before using send email functionality."
        if emitter:
            emitter(error_msg)
        
        # Return error based on return_mode
        if return_mode == "log":
            return error_msg
        elif return_mode == "answer":
            return error_msg
        else:  # both
            return {
                "output_text": "",
                "answer": error_msg,
                "log": error_msg,
                "traces": [],
                "trace_summary": {},
                "trace_file": ""
            }
    
    import asyncio
    return asyncio.run(_run_check_sum_send_email_async(
        start_datetime=start_datetime,
        end_datetime=end_datetime,
        max_items=max_items,
        from_addresses=from_addresses,
        user_question=user_question,
        emitter=emitter,
        return_mode=return_mode,
        recipient_email=recipient_email,
        tracing_mode=tracing_mode
    ))


async def _run_check_sum_send_email_async(
    start_datetime: str,
    end_datetime: str,
    max_items: int = 25,
    from_addresses: Optional[List[str]] = None,
    user_question: str = "",
    emitter: Optional[Callable[[str], None]] = None,
    return_mode: str = "both",
    recipient_email: Optional[str] = None,
    tracing_mode: str = "auto"
) -> str | dict:
    """Async implementation of the email check, summarize, and send workflow.
    
    Execution Flow:
        1. Create emitter utility for logging
        2. Auto-detect tracing mode if 'auto'
        3. Setup unified trace manager
        4. Emit workflow header
        5. Build sequential workflow (fetcher -> analyzer -> sender)
        6. Start parent tracing span
        7. Create EmailRequest
        8. Execute workflow stream
        9. Capture final output
        10. End parent span
        11. Collect trace lines and summary
        12. Store traces to local file if enabled
        13. Emit trace summary
        14. Return payload based on return_mode
    """
    
    # STEP 1: Create centralized emitter utility
    # Why? Enable consistent logging with flexible emitter injection for UI integration
    emit_util = create_emitter(emitter)
    emit = emit_util.emit
    
    # STEP 2: Auto-detect tracing mode if set to 'auto'
    # Why? Intelligently enable Azure Monitor tracing when connection string exists, fallback to console
    if tracing_mode == "auto":
        application_insights_connection_string = os.environ.get("APPLICATIONINSIGHTS_CONNECTION_STRING")
        if application_insights_connection_string and application_insights_connection_string.strip():
            tracing_mode = "both"
            emit("[TRACING] Auto-detected APPLICATIONINSIGHTS_CONNECTION_STRING - using dual tracing mode")
        else:
            tracing_mode = "console"
            emit("[TRACING] No APPLICATIONINSIGHTS_CONNECTION_STRING found - using console tracing")
    
    # STEP 3: Setup tracing using UnifiedTraceManager
    # Why? Initialize OpenTelemetry instrumentation for workflow/executor/message span capture
    from helper.unified_trace_manager import UnifiedTraceManager
    trace_mgr = UnifiedTraceManager(tracing_mode=tracing_mode, trace_type="workflow", emitter=emit)
    trace_mgr.setup()
    
    # STEP 4: Enhanced logging for observability
    # Why? Record workflow initiation in both application logger and emitter for debugging
    logger.info(f"Starting email check-summarize-send workflow: {start_datetime} to {end_datetime}")
    emit("[OBSERVABILITY] OpenTelemetry tracing enabled - capturing spans")
    
    # STEP 5: Emit workflow header
    # Why? Provide visibility into workflow configuration for user/debugger
    # STEP 5: Emit workflow header
    # Why? Provide visibility into workflow configuration for user/debugger
    emit("=" * 80)
    emit("EMAIL CHECK -> SUMMARIZE -> SEND WORKFLOW")
    emit("=" * 80)
    emit(f"Date range: {start_datetime} to {end_datetime}")
    emit(f"Max items: {max_items}")
    emit(f"Tracing mode: {tracing_mode}")
    emit("")
    
    # STEP 6: Build sequential workflow
    # Why? Create executor pipeline: EmailFetcher -> EmailAnalyzer -> EmailSender
    emit("[OBSERVABILITY] Building workflow - this will emit workflow.build spans")
    workflow = build_workflow(emitter=emitter, recipient_email=recipient_email)
    logger.info("Workflow graph built successfully")
    emit("[OBSERVABILITY] Workflow built - ready to execute")
    
    # STEP 7: Start parent span for tracing
    # Why? Capture end-to-end telemetry with workflow-level metadata
    query_desc = f"Email {start_datetime} to {end_datetime}"
    trace_mgr.start_parent_span(
        span_name=f"check_sum_send_email: {query_desc[:50]}",
        attributes={
            "start_datetime": start_datetime,
            "end_datetime": end_datetime,
            "max_items": max_items,
            "tracing_mode": tracing_mode,
            "recipient_email": recipient_email if recipient_email else ""
        }
    )
    
    # STEP 8: Create EmailRequest
    # Why? Package workflow parameters into dataclass for executor consumption
    request = EmailRequest(
        start_datetime=start_datetime,
        end_datetime=end_datetime,
        max_items=max_items,
        from_addresses=from_addresses,
        user_question=user_question
    )
    
    # STEP 9: Execute workflow stream
    # Why? Run sequential pipeline with async streaming to capture final output
    emit("\n[WORKFLOW] Starting execution...")
    emit("[OBSERVABILITY] Running workflow - workflow.run, executor.process, and message.send spans will be nested under parent")
    logger.info("Starting workflow execution")
    workflow_start_time = datetime.now()
    
    final_output = None
    success = False
    try:
        async for event in workflow.run_stream(request):
            if isinstance(event, WorkflowOutputEvent):
                final_output = event.data
                emit("")
                emit("=" * 30)
                emit("WORKFLOW COMPLETE")
                emit("=" * 30)
        
        # STEP 10: Calculate workflow elapsed time
        # Why? Provide performance visibility for pipeline execution
        workflow_end_time = datetime.now()
        workflow_elapsed = (workflow_end_time - workflow_start_time).total_seconds() * 1000
        
        output_text = final_output if final_output else "No output from workflow"
        success = final_output is not None
        emit(f"\n[WORKFLOW] ✓ Completed in {workflow_elapsed:.0f}ms")
        emit("=" * 80)
        
        logger.info("Workflow completed successfully")
        
    except Exception as exc:
        # STEP 11: Handle workflow exceptions with telemetry recording
        # Why? Capture unexpected failures in both logs and traces for debugging
        emit(f"\n[WORKFLOW] ✗ Failed: {exc}")
        logger.error(f"Workflow exception: {exc}", exc_info=True)
        import traceback
        emit(f"[DEBUG] Traceback:\n{traceback.format_exc()}")
        output_text = f"[ERROR] Workflow failed: {exc}"
        workflow_elapsed = 0
        
        trace_mgr.record_exception(exc, f"Workflow exception: {exc}")
    finally:
        # STEP 12: End parent span regardless of success/failure
        # Why? Ensure telemetry span is closed properly for complete trace capture
        # STEP 12: End parent span regardless of success/failure
        # Why? Ensure telemetry span is closed properly for complete trace capture
        trace_mgr.end_parent_span()
    
    # STEP 13: Collect complete log from emitter
    # Why? Extract all emitted messages for log-based return modes and JSON artifact
    log_joined = emit_util.get_log()
    
    # STEP 14: Get traces from unified trace manager
    # Why? Retrieve OpenTelemetry spans and summary statistics for observability
    trace_lines = trace_mgr.get_traces()
    trace_summary = {}
    trace_file = None
    
    # STEP 15: Emit Azure Monitor tracing confirmation if applicable
    # Why? Inform user where to view traces when Azure Monitor mode is active
    if tracing_mode == "azure_monitor" or tracing_mode == "both":
        emit("")
        emit("AZURE MONITOR TRACING")
        emit("✅ Workflow traces have been sent to Azure Monitor / Application Insights")
        emit("📊 View traces in Azure AI Foundry Portal: https://ai.azure.com")
        emit("")
    
    # STEP 16: Store traces to local file and emit summary if console/both/local mode
    # Why? Persist telemetry for offline analysis and display span statistics for visibility
    if tracing_mode in ["console", "both", "local"]:
        # Get trace summary if available
        if trace_lines:
            trace_summary = {'total_spans': len(trace_lines), 'workflow_elapsed_ms': workflow_elapsed}
            
            # Store traces to local file if enabled
            if tracing_mode in ["console", "both", "local"]:
                from helper.storeotel import store_otel_traces_to_local
                from helper.otel_collector import get_span_collector
                span_collector = get_span_collector()
                metadata = span_collector.get_metadata() if span_collector else {}
                trace_file, store_log = store_otel_traces_to_local(
                    traces=trace_lines,
                    trace_summary=trace_summary,
                    query=f"Email check {start_datetime} to {end_datetime}",
                    metadata=metadata,
                    prefix='checksumsend',
                    emitter=emit
                )
                if trace_file:
                    emit(f"[OTEL] Traces saved to: {trace_file}")
            
            # Add trace summary to log
            emit("")
            emit("=" * 30)
            emit("OPENTELEMETRY TRACE SUMMARY")
            emit("=" * 30)
            emit(f"Total Spans: {trace_summary['total_spans']}")
            emit(f"Workflow Elapsed Time: {trace_summary['workflow_elapsed_ms']:.2f}ms ({trace_summary['workflow_elapsed_ms']/1000:.2f}s)")
            emit("")

    
    # STEP 17: Return payload based on return_mode
    # Why? Support three return formats: 'both' (dict), 'answer' (str), 'log' (str)
    if return_mode == "both":
        return {
            "output_text": output_text,
            "answer": output_text,
            "log": log_joined,
            "success": success,
            "traces": trace_lines,
            "trace_summary": trace_summary,
            "trace_file": trace_file
        }
    elif return_mode == "answer":
        return output_text
    else:  # 'log'
        return log_joined


# ============================================================================
# CLI Entry Point
# ============================================================================

if __name__ == "__main__":
    from dotenv import load_dotenv
    from datetime import timedelta
    
    load_dotenv()
    
    # Get configuration from environment
    utc_offset = int(os.getenv("UTC_OFFSET", "8"))
    email_start = os.getenv("EMAIL_STARTTIME", "2025-10-01T00:00:00")
    email_end = os.getenv("EMAIL_ENDTIME", "2025-10-23T23:59:59")
    recipient = os.getenv("DEFAULT_EMAIL_RECIPIENT", "your-email@example.com")
    
    # Convert local time to UTC
    def offset_to_utc(dtstr, offset):
        try:
            dt0 = datetime.fromisoformat(dtstr)
            dt_utc = dt0 - timedelta(hours=offset)
            return dt_utc.strftime("%Y-%m-%dT%H:%M:%SZ")
        except Exception:
            return dtstr + "Z" if not dtstr.endswith("Z") else dtstr
    
    start_utc = offset_to_utc(email_start, utc_offset)
    end_utc = offset_to_utc(email_end, utc_offset)
    
    # Get tracing mode from command line or default to 'auto'
    tracing_mode = sys.argv[1] if len(sys.argv) > 1 else "auto"
    
    print(f"\nRunning Email Check -> Summarize -> Send Workflow")
    print(f"Date range: {email_start} to {email_end} (local)")
    print(f"            {start_utc} to {end_utc} (UTC)")
    print(f"Recipient: {recipient}")
    print(f"Tracing mode: {tracing_mode}")
    print("\nAvailable tracing modes:")
    print("  - 'auto': Use Azure Monitor if configured, else local (default)")
    print("  - 'local': Save traces to local JSON file")
    print("  - 'azure_monitor': Send traces to Azure AI Foundry")
    print("  - 'console': Print traces to console")
    print("  - 'none': Disable tracing")
    print()
    
    # Run workflow
    result = run_check_sum_send_email(
        start_datetime=start_utc,
        end_datetime=end_utc,
        max_items=25,
        user_question=DEFAULT_QUESTION,
        recipient_email=recipient,
        return_mode="both",
        tracing_mode=tracing_mode
    )
    
    # Display results
    if isinstance(result, dict):
        print("\n" + "=" * 80)
        print("WORKFLOW RESULT")
        print("=" * 80)
        print(f"\nOutput:\n{result.get('output_text', '')}")
        
        trace_summary = result.get('trace_summary', {})
        if trace_summary:
            print("\n" + "-" * 80)
            print("TRACE SUMMARY")
            print("-" * 80)
            print(f"Total Spans: {trace_summary.get('total_spans', 0)}")
            print(f"Workflow Build: {trace_summary.get('workflow_build_spans', 0)}")
            print(f"Workflow Run: {trace_summary.get('workflow_run_spans', 0)}")
            print(f"Executor Process: {trace_summary.get('executor_spans', 0)}")
            print(f"Message Send: {trace_summary.get('message_spans', 0)}")
            elapsed_ms = trace_summary.get('workflow_elapsed_ms', 0)
            print(f"⏱️  Workflow Elapsed: {elapsed_ms:.0f}ms" if elapsed_ms < 1000 else f"{elapsed_ms/1000:.2f}s")
        
        trace_file = result.get('trace_file')
        if trace_file:
            print(f"\n📁 Traces saved to: {trace_file}")
    else:
        print(f"\nResult: {result}")
