"""Bing Search agent tool sample.

This module can be imported as `agent.bingsearch` or executed directly:

	python -m agent.bingsearch "your question"
or (from repo root):
	python .\agent\bingsearch.py "your question"

Agent Behavior:
	The agent performs web searches using Bing Grounding to find current information,
	retrieves relevant search results with snippets from live web pages,
	and provides answers with inline citations linking to source URLs.
"""

import os
import sys
import json
from typing import Callable
from dotenv import load_dotenv
from azure.ai.projects import AIProjectClient
from azure.identity import AzureCliCredential
from azure.ai.agents.models import BingGroundingTool
from azure.ai.agents.models import ListSortOrder, MessageRole


if __name__ == "__main__":
	repo_root = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
	if repo_root not in sys.path:
		sys.path.insert(0, repo_root)

from helper.agent_config_loader import load_agent_config, AgentConfigError
from helper.emitter import create_emitter

load_dotenv()

project_endpoint = os.getenv("PROJECT_ENDPOINT")
model_deployment_name = os.getenv("MODEL_DEPLOYMENT_NAME")
bingsearch_connection = os.getenv("BING_CONNECTION_NAME")

DEFAULT_QUESTION = "tell me something about agunesmusic"


def run_bing_search(
    question: str | None = None,
    emitter: Callable[[str], None] | None = None,
    return_mode: str = "answer",
    save_json: str | os.PathLike | None = None,
    tracing_mode: str = "both",
):
    """Run a Bing-grounded agent search with structured logging/outputs.

    The agent uses Bing Grounding to search current web information and provide
    answers with citations to source URLs.

    Execution Flow:
    1. Initialize emitter and validate question
    2. Setup OpenTelemetry tracing infrastructure
    3. Validate required environment configuration
    4. Initialize Azure AI Project Client and resolve Bing connection
    5. Load agent configuration from YAML
    6. Create agent with Bing Grounding tool capabilities
    7. Execute agent conversation (create thread, post message, run agent)
    8. Process run steps and extract tool call details
    9. Gather agent responses with citation expansion
    10. Cleanup resources and collect traces
    11. Format and return results based on return_mode

    Parameters:
        question: User query. Defaults to DEFAULT_QUESTION if blank.
        emitter: Optional callback(line: str) for streaming logs.
        return_mode: Controls return value:
            'answer' -> joined agent answers (fallback to log if none)
            'log'    -> full log text only
            'both'   -> dict { 'answers': [...], 'output_text': str, 'log': str, 'success': bool, 'traces': list, 'trace_summary': dict }
        save_json: Optional path to persist artefacts as JSON.
        tracing_mode: Controls OpenTelemetry tracing destination:
            'both' (default)  -> Enable both Azure Monitor and Console tracing simultaneously
            'auto'           -> Azure Monitor if APPLICATIONINSIGHTS_CONNECTION_STRING is set, else none
            'azure_monitor'  -> Send traces to Azure AI Foundry Portal
            'console'        -> Print traces to console (with gen_ai agent traces)
            'none'           -> Disable tracing

    Returns:
        str | dict depending on return_mode. When return_mode='both', includes 'success' boolean.
    """
    # STEP 1: Initialize output collection and success tracking
    # Why list for output_texts? Agent may produce multiple responses
    # success flag tracks whether search completed successfully (used for conditional logic)
    output_texts: list[str] = []
    success = False

    # Create emitter wrapper that handles None emitter gracefully
    # Why wrap? Provides uniform emit() interface regardless of caller
    emit_util = create_emitter(emitter)
    emit = emit_util.emit

    # STEP 2: Validate and normalize question input
    # Why check both None and empty string? Defensive programming
    # Callers might pass None, "", or whitespace-only strings
    if question is None or not question.strip():
        question = DEFAULT_QUESTION

    # STEP 3: Setup OpenTelemetry tracing infrastructure
    # Why UnifiedTraceManager? Centralizes tracing setup across agent/workflow modes
    # trace_type="agent" configures agent-specific span collection
    from helper.unified_trace_manager import UnifiedTraceManager
    
    trace_mgr = UnifiedTraceManager(
        tracing_mode=tracing_mode,
        emitter=emit,
        trace_type="agent"
    )
    tracer, span_collector = trace_mgr.setup()

    # STEP 4: Validate required environment configuration
    # Why check early? Fail fast principle - no point proceeding without config
    # Better to error immediately than after expensive API calls
    if not project_endpoint or not model_deployment_name or not bingsearch_connection:
        emit("[ERROR] PROJECT_ENDPOINT, MODEL_DEPLOYMENT_NAME, and BING_CONNECTION_NAME must be set")
        log_joined = emit_util.get_log()
        # Graceful degradation: Return error log with success=False
        # Why? Caller can check success flag and handle appropriately
        if return_mode == "both":
            return {
                "answers": [],
                "output_text": log_joined,
                "log": log_joined,
                "success": False,
            }
        return log_joined
    
    # STEP 5: Start parent trace span (if tracing enabled)
    # Why parent span? Creates root of trace tree for this execution
    # All subsequent operations become child spans
    trace_mgr.start_parent_span(
        span_name=f"run_bing_search: {question[:50]}",  # Truncate long questions
        attributes={
            "question": question,
            "tracing_mode": tracing_mode
        }
    )
    
    # STEP 6: Initialize Azure AI Project Client
    # Why context manager? Ensures proper cleanup even on errors
    emit("Azure AI Project Client initializing...")
    try:
        with AIProjectClient(endpoint=project_endpoint, credential=AzureCliCredential()) as project_client:
            
            # STEP 7: Resolve Bing Search connection
            # Why try/except? Connection might not exist or be misconfigured
            # Better to give clear error than generic exception
            try:
                connection = project_client.connections.get(name=bingsearch_connection)
            except Exception as conn_exc:
                emit(f"[ERROR] Failed to load Bing connection '{bingsearch_connection}': {conn_exc}")
                log_joined = emit_util.get_log()
                # Early return on connection failure
                # Why? Can't proceed without valid Bing connection
                if return_mode == "both":
                    return {
                        "answers": [],
                        "output_text": log_joined,
                        "log": log_joined,
                        "success": False,
                    }
                return log_joined

            # STEP 8: Configure Bing Grounding tool
            # Why BingGroundingTool? Enables agent to search live web content
            # connection_id links to Bing Search API credentials
            bing = BingGroundingTool(connection_id=connection.id)
            agents_client = project_client.agents
            
            # STEP 9: Load agent configuration from YAML
            # Why YAML config? Separates prompt engineering from code
            # Allows non-developers to modify agent behavior
            try:
                emit("Loading agent configuration...")
                pyfile_name = os.path.splitext(os.path.basename(__file__))[0]
                agent_name, agent_instructions, agent_description = load_agent_config(pyfile_name)
                # Agent will: (1) Perform Bing web searches for current information
                #             (2) Retrieve relevant snippets from live web pages
                #             (3) Provide answers with inline citations to source URLs
                emit(f"Loaded agent configuration: {agent_name}")
            except AgentConfigError as cfg_err:
                # Configuration errors are fatal - can't create agent without config
                emit(f"[ERROR] {cfg_err}")
                log_joined = emit_util.get_log()
                if return_mode == "both":
                    return {
                        "answers": [],
                        "output_text": log_joined,
                        "log": log_joined,
                        "success": False,
                    }
                return log_joined

            # STEP 10: Create agent with Bing Grounding tool
            # Why create new agent each time? Ensures fresh state, no residual context
            # tools parameter links agent to Bing search capabilities
            agent = agents_client.create_agent(
                model=model_deployment_name,
                name=agent_name,
                instructions=agent_instructions,  # System prompt defining behavior
                description=agent_description,
                tools=bing.definitions,  # Bing search tool function signatures
            )
            emit(f"Created agent ID: {agent.id}")

            # STEP 11: Create conversation thread
            # Why separate thread? Isolates this conversation from others
            thread = agents_client.threads.create()
            emit(f"Created thread ID: {thread.id}")
            
            # STEP 12: Post user message to thread
            # This is the actual question/prompt the agent will respond to
            user_message = agents_client.messages.create(
                thread_id=thread.id,
                role="user",
                content=question,
            )
            emit(f"Created user message ID: {user_message['id']}")

            # STEP 13: Execute agent run (agent processes question and uses tools)
            # create_and_process blocks until agent completes
            # Agent will: analyze question → decide to search → call Bing → synthesize answer
            run = agents_client.runs.create_and_process(thread_id=thread.id, agent_id=agent.id)
            emit(f"Run finished with status: {run.status}")
            
            # STEP 14: Check run status and update success flag
            # Why check status? Run might fail due to: API limits, tool errors, timeout
            if run.status == "failed":
                emit(f"Run failed: {run.last_error}")
            else:
                # Mark success only if run completed successfully
                # This flag used later for conditional email sending, etc.
                success = True

            # STEP 15: Extract and log run steps (shows agent's decision-making)
            # Why try/except? Listing steps might fail but shouldn't break main flow
            # Steps are diagnostic - nice to have but not critical
            try:
                run_steps = agents_client.run_steps.list(thread_id=thread.id, run_id=run.id)
                for step in run_steps:
                    emit(f"[STEP] {step['id']} status={step['status']}")
                    # STEP 16: Extract tool call details (Bing queries and results)
                    # Why detailed logging? Shows exact search queries agent used
                    if step.type == "tool_calls":
                        for tool_call in getattr(step.step_details, 'tool_calls', []):
                            try:
                                # Pretty-print tool call as JSON for readability
                                emit("[TOOL CALL]\n" + json.dumps(tool_call.as_dict(), indent=2))
                            except Exception:
                                # Fallback: raw string if JSON serialization fails
                                emit(f"[TOOL CALL RAW] {tool_call}")
                    emit("")
            except Exception as step_exc:
                # Log warning but continue - steps are diagnostic only
                emit(f"[WARN] Failed to list run steps: {step_exc}")

            # STEP 17: Gather agent responses with inline citation expansion
            # Why only if success? Don't process messages if run failed
            # Failed runs might have incomplete/error messages
            if success:
                messages = agents_client.messages.list(thread_id=thread.id, order=ListSortOrder.ASCENDING)
                for message in messages:
                    if message.role == MessageRole.AGENT:
                        # Build citation mapping: marker → readable link
                        # Why dict? Fast O(1) lookup for replacements
                        annotation_map = {}
                        if message.url_citation_annotations:
                            # Transform: [1] → [see Page Title] (https://...)
                            annotation_map = {
                                a.text: f" [see {a.url_citation.title}] ({a.url_citation.url})" 
                                for a in message.url_citation_annotations
                            }
                        # Apply citation expansion to each text message
                        for text_part in message.text_messages:
                            answer_text = text_part.text.value
                            # Replace all citation markers with readable links
                            for k, v in annotation_map.items():
                                answer_text = answer_text.replace(k, v)
                            output_texts.append(answer_text)  # Collect for final answer
                            emit("[ANSWER OUTPUT]\n" + answer_text)

            # STEP 18: Cleanup agent resource
            # Why delete? Agents are stateful resources that cost money if left running
            agents_client.delete_agent(agent.id)
            emit("Deleted agent")


    except Exception as outer_exc:
        # STEP 19: Handle unexpected exceptions
        # Why broad exception? Many possible failure points (network, auth, API, etc.)
        emit(f"[ERROR] Unexpected exception: {outer_exc}")
        success = False  # Ensure success flag reflects failure
        trace_mgr.record_exception(outer_exc)
    
    # STEP 20: End parent trace span (ensures span closed even on errors)
    # Why? Guarantees cleanup regardless of success/failure
    trace_mgr.end_parent_span()
    
    # STEP 21: Retrieve and format collected traces
    # trace_lines: List of formatted trace strings (for display)
    # trace_summary: Dict with span counts and timing metrics
    trace_lines, trace_summary = trace_mgr.get_traces()
    
    # STEP 22: Display trace summary in logs (if traces collected)
    # Why conditional? Only show if tracing was enabled and captured data
    if trace_lines:
        emit("")
        emit("=" * 50)
        emit("OPENTELEMETRY TRACE SUMMARY")
        emit("=" * 50)
        # Display key metrics about agent execution
        emit(f"Total Spans: {trace_summary.get('total_spans', 0)}")
        emit(f"Agent Spans: {trace_summary.get('agent_spans', 0)}")
        emit(f"Thread Spans: {trace_summary.get('thread_spans', 0)}")
        emit(f"Message Spans: {trace_summary.get('message_spans', 0)}")
        emit(f"Run Spans: {trace_summary.get('run_spans', 0)}")
        emit(f"HTTP Spans: {trace_summary.get('http_spans', 0)}")
        emit(f"Main Elapsed: {trace_summary.get('main_elapsed_ms', 0):.2f}ms")
        emit("")
        for line in trace_lines:
            emit(line)
        emit("=" * 50)

    # STEP 23: Assemble final answer from collected fragments
    # Why join with double newline? Creates readable separation between responses
    answers_joined = "\n\n".join(output_texts)
    log_joined = emit_util.get_log()

    # STEP 24: Format return payload based on return_mode
    # Why three modes? Different callers need different data
    # - "both": Full data for UI display (answers + logs + traces + success)
    # - "log": Full execution log for debugging
    # - "answer": Just answer text for simple use cases
    if return_mode == "both":
        payload: dict | str = {
            "answers": output_texts,
            "output_text": answers_joined or log_joined,  # Fallback to log if no answers
            "log": log_joined,
            "success": success,  # Critical: Allows caller to check if search worked
            "traces": trace_lines,
            "trace_summary": trace_summary,
        }
    elif return_mode == "log":
        payload = log_joined
    else:
        # "answer" mode: Return answer if available, otherwise full log
        payload = answers_joined if answers_joined else log_joined

    # STEP 25: Optionally save execution artefact to JSON file
    # Why save? Enables offline analysis, regression testing, audit trails
    if save_json:
        import pathlib
        try:
            path_obj = pathlib.Path(save_json)
            # Create parent directories if they don't exist
            # Why parents=True? Allows paths like "results/2024/output.json"
            path_obj.parent.mkdir(parents=True, exist_ok=True)
            with path_obj.open('w', encoding='utf-8') as f:
                json.dump(
                    {
                        "answers": output_texts,
                        "output_text": answers_joined,
                        "log": log_joined,
                        "success": success,
                        "traces": trace_lines,
                        "trace_summary": trace_summary,
                    },
                    f,
                    ensure_ascii=False,  # Preserve Unicode characters
                    indent=2,  # Pretty-print for readability
                )
        except Exception as exc:
            # STEP 26: Handle JSON save failures gracefully
            # Why not raise? Save is enhancement, shouldn't break main flow
            emit(f"[WARN] Failed to save JSON artefact: {exc}")
            log_joined2 = emit_util.get_log()  # Refresh log with warning
            # Update payload with refreshed log
            if isinstance(payload, dict):
                payload["log"] = log_joined2
            elif return_mode == "log":
                payload = log_joined2

    return payload


if __name__ == "__main__":
    question = sys.argv[1] if len(sys.argv) > 1 and sys.argv[1].strip() else DEFAULT_QUESTION
    run_bing_search(question)