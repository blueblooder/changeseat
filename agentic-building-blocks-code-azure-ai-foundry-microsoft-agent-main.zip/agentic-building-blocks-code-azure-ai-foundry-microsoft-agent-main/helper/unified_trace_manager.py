# ------------------------------------
# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
# ------------------------------------
"""Unified OpenTelemetry Trace Manager

Centralizes tracing setup for both Agent SDK and Workflow (agent_framework) applications.
This module eliminates duplicate tracing configuration code by providing a single,
unified interface that works with both frameworks.

=== Tracing Modes ===
- auto: Auto-detect based on APPLICATIONINSIGHTS_CONNECTION_STRING environment variable
  * If set: Use Azure Monitor
  * If not set: Disable tracing
  * Why auto? Simplifies configuration for different environments (dev vs prod)

- azure_monitor: Azure Monitor / Application Insights only
  * Sends traces to Azure cloud
  * Requires APPLICATIONINSIGHTS_CONNECTION_STRING
  * Best for: Production monitoring, cloud visibility
  
- console: Console output + local file export only
  * Prints spans to terminal for immediate feedback
  * Saves to opentele_local/ for persistence
  * Best for: Local development, debugging

- both: Azure Monitor + Console + local file
  * All of the above combined
  * Best for: Comprehensive debugging in pre-production environments
  * Warning: Double processing overhead
  
- none: No tracing
  * Disables all telemetry
  * Best for: Performance testing, minimal overhead scenarios

=== Key Features ===

1. Single Source of Truth:
   - One class manages tracing for both Agent SDK and agent_framework
   - No duplicate configuration logic
   - Consistent behavior across the application

2. Automatic Parent Span Management:
   - Creates root span for entire operation
   - All child operations automatically nested
   - Enables full distributed tracing across agent calls
   
   Why Important?
   - Groups related operations together in UI
   - Enables trace_id correlation across logs
   - Provides complete execution timeline

3. Trace Collection for Streamlit UI:
   - Captures spans in memory for display
   - Different collectors for Agent SDK vs Workflow
   - Enables real-time trace visualization in web UI
   
4. Local JSON File Export:
   - Saves traces to opentele_local/ directory
   - Timestamped files for debugging sessions
   - Useful when cloud connectivity is unavailable
   
5. Framework-Specific Support:
   - Agent SDK: Uses AIAgentsInstrumentor + AgentTraceCollector
   - agent_framework: Uses setup_observability() + UISpanCollector
   - Handles instrumentation differences transparently

=== Architecture Notes ===

OpenTelemetry Concepts:
- TracerProvider: Factory for creating Tracers
- Tracer: Creates Spans (represents operations)
- Span: Single unit of work with timing, attributes, status
- SpanProcessor: Processes spans before export
- SpanExporter: Exports spans to destination (Azure, console, file)

This Manager:
- Sets up TracerProvider (reuses if already exists)
- Adds multiple SpanProcessors for different outputs
- Creates parent span to group all operations
- Instruments Agent SDK or agent_framework automatically

Why Separate Trace Collectors?
- Agent SDK spans: Use AgentTraceCollector (implements SpanExporter)
- Workflow spans: Use UISpanCollector (implements SpanProcessor)
- Different internal structures require different parsing
- Unified interface abstracts these differences
"""

import os
from typing import Optional, Tuple, Callable
from pathlib import Path
from opentelemetry import trace, context
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import SimpleSpanProcessor, ConsoleSpanExporter


class UnifiedTraceManager:
	"""Manages OpenTelemetry tracing configuration and lifecycle.
	
	This class provides a unified interface for setting up and managing
	OpenTelemetry tracing across both Agent SDK and Workflow applications.
	
	Responsibilities:
	1. Mode Detection: Auto-detect tracing mode or use explicit configuration
	2. Provider Setup: Initialize TracerProvider with appropriate processors
	3. Instrumentation: Configure framework-specific tracing hooks
	4. Parent Span Management: Create root span to group all operations
	5. Trace Collection: Capture spans for UI display and debugging
	
	Lifecycle:
	1. __init__: Configure mode and emitter
	2. setup(): Initialize tracing infrastructure
	3. start_parent_span(): Begin traced operation
	4. ... application code runs, generates child spans ...
	5. end_parent_span(): Finalize trace
	6. get_traces(): Retrieve trace data for display
	
	Why Unified?
	- Agent SDK and agent_framework have different tracing APIs
	- This class abstracts the differences
	- Application code doesn't need to know which framework is used
	- Single configuration point reduces errors and duplication
	"""
	
	def __init__(
		self,
		tracing_mode: str = "auto",
		emitter: Optional[Callable] = None,
		trace_type: str = "agent",
	):
		"""Initialize trace manager.
		
		Sets up configuration but doesn't activate tracing yet.
		Call setup() to actually initialize OpenTelemetry infrastructure.
		
		Why Separate __init__ and setup()?
		- Allows configuration changes before activation
		- Easier testing (can mock dependencies after instantiation)
		- Deferred initialization (setup() can be called when needed)
		
		Args:
			tracing_mode: Tracing mode - 'auto', 'azure_monitor', 'console', 'both', 'none'
			             Default 'auto' detects based on environment variables.
			             
			emitter: Optional callback function for status messages.
			        Signature: (message: str) -> None
			        Default: Uses print() for console output
			        Common: Pass StreamlitEmitterUtil.emit for UI updates
			        
			trace_type: Type of traces - 'agent' for Agent SDK, 'workflow' for agent_framework
			           Determines which instrumentation and collector to use.
			           'agent': AIAgentsInstrumentor + AgentTraceCollector
			           'workflow': setup_observability() + UISpanCollector
		
		Attributes Set:
			Configuration:
			- self.tracing_mode: str
			- self.emitter: Callable
			- self.trace_type: str
			
			State (initialized in setup()):
			- self.azure_monitor_configured: bool (True if Azure Monitor active)
			- self.console_configured: bool (True if Console/File active)
			- self.tracer: Optional[Tracer] (OpenTelemetry Tracer instance)
			- self.trace_collector: Optional[Collector] (For UI display)
			- self.local_trace_file: Optional[Path] (JSON export file path)
			- self.parent_span: Optional[Span] (Root span for operation)
			- self.context_token: Optional[object] (Context attachment token)
		"""
		# Store configuration
		self.tracing_mode = tracing_mode
		# Default to print if no emitter provided
		self.emitter = emitter or print
		self.trace_type = trace_type
		
		# State tracking (initialized in setup())
		# Why initialize here? Allows checking state without setup() call
		self.azure_monitor_configured = False
		self.console_configured = False
		self.tracer = None
		self.trace_collector = None
		self.local_trace_file = None
		self.parent_span = None
		self.context_token = None
	
	def setup(self) -> Tuple[Optional[object], Optional[object]]:
		"""Setup tracing based on configured mode.
		
		This is the main entry point for trace configuration. Call this once
		during application initialization to activate tracing.
		
		Execution Flow:
		1. Mode Auto-Detection (if tracing_mode == "auto"):
		   - Check for APPLICATIONINSIGHTS_CONNECTION_STRING
		   - If present and non-empty: Use "azure_monitor"
		   - If absent or empty: Use "none" (disabled)
		   
		2. Azure Monitor Setup (if mode includes azure_monitor):
		   - Call _setup_azure_monitor()
		   - Sets self.azure_monitor_configured
		   
		3. Console + File Setup (if mode includes console):
		   - Call _setup_console_and_file()
		   - Sets self.console_configured
		   - Configures trace_collector for UI display
		   - Creates local JSON file for persistence
		   
		4. Tracer Creation (if any mode active):
		   - Get tracer via trace.get_tracer(__name__)
		   - Emit summary of configured modes
		
		Why This Order?
		- Auto-detection first: Determines which modes to enable
		- Azure Monitor before Console: Azure SDK may set up base TracerProvider
		- Tracer creation last: After all processors registered
		
		Returns:
			Tuple[Optional[object], Optional[object]]: (tracer, trace_collector)
			
			tracer: OpenTelemetry Tracer instance
			       - Used to create spans: tracer.start_span("operation_name")
			       - None if tracing disabled
			       
			trace_collector: Collector for UI display
			                - AgentTraceCollector for Agent SDK
			                - UISpanCollector for agent_framework
			                - None if tracing disabled or not applicable
			                - Call get_traces() to retrieve formatted traces
		
		Side Effects:
		- Sets global TracerProvider (via trace.set_tracer_provider)
		- Registers span processors for export
		- Instruments Agent SDK or agent_framework
		- Creates local trace file in opentele_local/
		- Emits status messages via self.emitter
		
		Example Usage:
		```python
		# Agent SDK with auto-detection
		manager = UnifiedTraceManager(tracing_mode="auto", trace_type="agent")
		tracer, collector = manager.setup()
		
		# Workflow with explicit console mode
		manager = UnifiedTraceManager(
		    tracing_mode="console",
		    trace_type="workflow",
		    emitter=emitter.emit
		)
		tracer, collector = manager.setup()
		```
		"""
		# STEP 1: Auto-detect mode based on environment
		if self.tracing_mode == "auto":
			# Check for Azure Application Insights connection string
			app_insights_conn = os.environ.get("APPLICATIONINSIGHTS_CONNECTION_STRING")
			
			# Validate it's not just empty whitespace
			if app_insights_conn and app_insights_conn.strip():
				# Found valid connection string, use Azure Monitor
				self.tracing_mode = "azure_monitor"
				self.emit("[TRACING] Auto-detected APPLICATIONINSIGHTS_CONNECTION_STRING - using Azure Monitor")
			else:
				# No connection string, disable tracing
				# Why disable instead of console? Auto mode is for production
				# where you either have monitoring or don't need it
				self.tracing_mode = "none"
				self.emit("[TRACING] No APPLICATIONINSIGHTS_CONNECTION_STRING found - tracing disabled")
		
		# STEP 2: Configure Azure Monitor tracing if requested
		if self.tracing_mode in ["azure_monitor", "both"]:
			self._setup_azure_monitor()
		
		# STEP 3: Configure Console + Local File tracing if requested
		if self.tracing_mode in ["console", "both"]:
			self._setup_console_and_file()
		
		# STEP 4: Get tracer if any tracing mode is active
		if self.azure_monitor_configured or self.console_configured:
			# Get tracer from global TracerProvider
			# __name__ is module name, used to identify tracer source
			self.tracer = trace.get_tracer(__name__)
			
			# Build summary of active modes for user feedback
			modes = []
			if self.azure_monitor_configured:
				modes.append("Azure Monitor")
			if self.console_configured:
				modes.append("Console + Local File")
			
			# Emit success message with active modes
			self.emit(f"[TRACING] ✅ Configured: {' + '.join(modes)}")
		elif self.tracing_mode == "none":
			# Explicit disabled mode
			self.emit("[TRACING] Tracing disabled")
		
		# Return tracer and collector for application use
		return self.tracer, self.trace_collector
	
	def _setup_azure_monitor(self):
		"""Configure Azure Monitor / Application Insights tracing.
		
		Integrates with Azure Application Insights for cloud-based distributed tracing.
		This enables monitoring of agents in production with Azure's monitoring infrastructure.
		
		Prerequisites:
		- APPLICATIONINSIGHTS_CONNECTION_STRING environment variable must be set
		- azure-monitor-opentelemetry package must be installed
		
		What This Does:
		1. Import configure_azure_monitor from Azure SDK
		2. Retrieve connection string from environment
		3. Validate connection string is present and non-empty
		4. Call configure_azure_monitor() to set up tracing
		5. Set self.azure_monitor_configured flag
		
		Why Use Azure Monitor?
		- Cloud-based trace storage and analysis
		- Integration with Azure Application Insights UI
		- Correlation with other Azure services
		- Powerful query capabilities via KQL
		- Automatic metric collection and alerting
		
		Connection String Format:
		InstrumentationKey=<guid>;IngestionEndpoint=https://...;LiveEndpoint=https://...
		
		What configure_azure_monitor() Does:
		- Creates TracerProvider (or reuses existing)
		- Adds AzureMonitorTraceExporter
		- Configures batch processing for efficiency
		- Sets up automatic instrumentation for common libraries
		
		Error Handling:
		- If connection string missing: Emits warning, returns early
		- If import fails: Catches exception, emits warning
		- If configuration fails: Catches exception, emits warning
		- Does NOT raise exceptions (graceful degradation)
		
		Side Effects:
		- May set global TracerProvider
		- Registers Azure Monitor span processor
		- Starts background export thread
		
		Sets:
			self.azure_monitor_configured: bool
			    True if successfully configured, False otherwise
		"""
		self.emit("[TRACING] Configuring Azure Monitor tracing...")
		try:
			# Import Azure Monitor OpenTelemetry integration
			# This is optional dependency, so import may fail
			from azure.monitor.opentelemetry import configure_azure_monitor
			
			# Retrieve connection string from environment
			# Why from environment? Keeps secrets out of code, supports multiple environments
			app_insights_conn = os.environ.get("APPLICATIONINSIGHTS_CONNECTION_STRING")
			
			# Validate connection string exists and is not empty
			if not app_insights_conn or not app_insights_conn.strip():
				self.emit("[TRACING] ⚠️ APPLICATIONINSIGHTS_CONNECTION_STRING not set or empty")
				return  # Early exit, do not set configured flag
			
			# Configure Azure Monitor with connection string
			# This sets up TracerProvider and registers Azure exporter
			configure_azure_monitor(connection_string=app_insights_conn)
			
			# Mark as successfully configured
			self.azure_monitor_configured = True
			self.emit("[TRACING] ✅ Azure Monitor configured")
			
		except Exception as e:
			# Graceful degradation: Log error but continue
			# Why not raise? Tracing is observability, not core functionality
			# Application should work even if tracing fails
			self.emit(f"[TRACING] ⚠️ Azure Monitor setup failed: {e}")
	
	def _setup_console_and_file(self):
		"""Configure Console output and Local File tracing.
		
		Sets up dual-output tracing for local development and debugging:
		1. Console output: Real-time span display in terminal
		2. JSON file export: Persistent trace storage in opentele_local/
		3. UI collector: In-memory trace capture for Streamlit display
		
		This method handles complex initialization with multiple components:
		- TracerProvider management (reuse or create)
		- Multiple span processors for different outputs
		- Framework-specific instrumentation (Agent SDK or agent_framework)
		- Trace collector initialization (different for each framework)
		
		Execution Flow:
		┌─────────────────────────────────────────────────────────────┐
		│ 1. Get or Create TracerProvider                            │
		│    - Reuse existing if available (Azure Monitor may have   │
		│      created one)                                           │
		│    - Create new if none exists                              │
		├─────────────────────────────────────────────────────────────┤
		│ 2. Add ConsoleSpanExporter                                 │
		│    - Prints spans to terminal in human-readable format     │
		│    - Wrapped in SimpleSpanProcessor (synchronous export)   │
		├─────────────────────────────────────────────────────────────┤
		│ 3. Add Trace Collector (framework-specific)                │
		│    Agent SDK:                                               │
		│      - AgentTraceCollector (implements SpanExporter)       │
		│      - Wrapped in SimpleSpanProcessor                      │
		│    agent_framework:                                         │
		│      - UISpanCollector (implements SpanProcessor)          │
		│      - Added directly, enabled explicitly                   │
		├─────────────────────────────────────────────────────────────┤
		│ 4. Add JSONFileExporter                                     │
		│    - Saves spans to timestamped JSON file                  │
		│    - Wrapped in SimpleSpanProcessor                        │
		│    - File path stored in self.local_trace_file             │
		├─────────────────────────────────────────────────────────────┤
		│ 5. Instrument Framework                                     │
		│    Agent SDK:                                               │
		│      - AIAgentsInstrumentor.instrument()                   │
		│      - Hooks into agent execution to create spans          │
		│    agent_framework:                                         │
		│      - setup_observability()                                │
		│      - Configures workflow tracing                          │
		└─────────────────────────────────────────────────────────────┘
		
		Why Multiple Processors?
		Each processor handles a different output destination:
		- Console: Developer feedback during execution
		- File: Persistence for later analysis
		- Collector: UI display in Streamlit
		
		Each processor receives a copy of every span, allowing
		simultaneous export to multiple destinations.
		
		SpanProcessor vs SpanExporter:
		- SpanExporter: Interface for exporting spans (export() method)
		  Examples: ConsoleSpanExporter, JSONFileExporter, AgentTraceCollector
		  Must be wrapped in SimpleSpanProcessor to add to provider
		  
		- SpanProcessor: Interface for processing spans (on_start(), on_end())
		  Examples: SimpleSpanProcessor, BatchSpanProcessor, UISpanCollector
		  Added directly to provider via add_span_processor()
		  
		Why Different Collectors?
		Agent SDK and agent_framework produce different span structures:
		- Agent SDK: Nested spans with specific attributes
		- agent_framework: Workflow-specific span hierarchy
		
		Each collector knows how to parse its framework's span format
		and convert to UI-friendly format.
		
		Error Handling:
		- Graceful degradation: Continues if instrumentation fails
		- Emits warnings for failures
		- Sets console_configured only if core setup succeeds
		
		Sets:
			self.console_configured: bool (True on success)
			self.trace_collector: AgentTraceCollector or UISpanCollector
			self.local_trace_file: Path (JSON export file path)
		"""
		self.emit("[TRACING] Configuring Console + Local File tracing...")
		try:
			# Import OpenTelemetry SDK components
			from opentelemetry.sdk.trace import TracerProvider
			from opentelemetry.sdk.trace.export import SimpleSpanProcessor, ConsoleSpanExporter
			
			# STEP 1: Get existing TracerProvider or create new one
			# Why check existing? Azure Monitor may have already created provider
			current_provider = trace.get_tracer_provider()
			
			# Check if provider supports add_span_processor (indicates it's a real TracerProvider)
			# Default provider is a no-op proxy without this method
			if hasattr(current_provider, 'add_span_processor'):
				# Reuse existing provider (likely from Azure Monitor setup)
				tracer_provider = current_provider
				self.emit("[TRACING] Reusing existing TracerProvider")
			else:
				# Create new TracerProvider
				tracer_provider = TracerProvider()
				# Set as global provider
				# Why global? OpenTelemetry uses global state for instrumentation
				trace.set_tracer_provider(tracer_provider)
				self.emit("[TRACING] Created new TracerProvider")
			
			# STEP 2: Add console exporter for terminal output
			# ConsoleSpanExporter prints spans to stdout in human-readable format
			span_exporter = ConsoleSpanExporter()
			# SimpleSpanProcessor exports each span immediately (synchronous)
			# Why SimpleSpanProcessor? For console output, want immediate feedback
			# BatchSpanProcessor would delay output until batch full
			tracer_provider.add_span_processor(SimpleSpanProcessor(span_exporter))
			
			# STEP 3: Add trace collector based on framework type
			if self.trace_type == "agent":
				# Agent SDK: Use AgentTraceCollector
				from helper.trace_exporters import AgentTraceCollector
				self.trace_collector = AgentTraceCollector()
				self.emit("[TRACING] Using AgentTraceCollector for Agent SDK traces")
				
				# AgentTraceCollector implements SpanExporter, needs SimpleSpanProcessor wrapper
				tracer_provider.add_span_processor(SimpleSpanProcessor(self.trace_collector))
			else:  # workflow
				# agent_framework: Use UISpanCollector
				from helper.otel_collector import get_span_collector
				self.trace_collector = get_span_collector()
				
				# Enable collector (required for UISpanCollector to capture spans)
				self.trace_collector.enable()
				self.emit("[TRACING] Using UISpanCollector for Workflow traces")
				
				# UISpanCollector implements SpanProcessor, add directly
				# No wrapper needed
				tracer_provider.add_span_processor(self.trace_collector)
			
			# STEP 4: Add JSON file exporter for local persistence
			from helper.trace_exporters import JSONFileExporter
			file_exporter = JSONFileExporter()
			
			# Store file path for reference (useful for displaying to user)
			self.local_trace_file = file_exporter.file_path
			
			# Wrap in SimpleSpanProcessor and add to provider
			tracer_provider.add_span_processor(SimpleSpanProcessor(file_exporter))
			
			# Emit file path for user visibility
			# 💾 emoji indicates this is a persistence-related message
			self.emit(f"[TRACING] 💾 Local trace file: {self.local_trace_file}")
			
			# STEP 5: Instrument appropriate SDK
			if self.trace_type == "agent":
				# Instrument Agent SDK
				try:
					from azure.ai.agents.telemetry import AIAgentsInstrumentor
					agents_instrumentor = AIAgentsInstrumentor()
					
					# Check if already instrumented (avoid double instrumentation)
					if not agents_instrumentor.is_instrumented():
						# Instrument: Hooks into agent execution to create spans
						agents_instrumentor.instrument()
						self.emit("[TRACING] ✅ Agent SDK instrumented")
				except Exception as instr_err:
					# Instrumentation failure is not fatal
					# Core tracing still works, just won't auto-create agent spans
					self.emit(f"[TRACING] ⚠️ Agent SDK instrumentation failed: {instr_err}")
			else:  # workflow
				# Configure agent_framework observability
				try:
					from agent_framework.observability import setup_observability
					# This configures workflow-specific tracing hooks
					setup_observability()
					self.emit("[TRACING] ✅ agent_framework observability configured")
				except Exception as obs_err:
					# Non-fatal: Workflows may still work, just without automatic tracing
					self.emit(f"[TRACING] ⚠️ agent_framework observability setup failed: {obs_err}")
			
			# Mark as successfully configured
			# Set this AFTER all critical steps succeed
			self.console_configured = True
			self.emit("[TRACING] ✅ Console + File tracing enabled")
			
		except Exception as e:
			# Catch-all for any unexpected errors
			# Graceful degradation: Don't crash app if tracing fails
			self.emit(f"[TRACING] ⚠️ Console tracing setup failed: {e}")
	
	def start_parent_span(self, span_name: str, attributes: dict = None):
		"""Create and attach parent span to execution context.
		
		This creates a root span that all subsequent operations will be children of,
		allowing the entire execution to be tracked as a single distributed trace.
		
		Purpose:
		- Groups all agent/workflow operations under single trace_id
		- Enables end-to-end visibility in monitoring tools
		- Provides timing for complete operation
		- Allows correlation across multiple services
		
		Execution Flow:
		1. Create span using self.tracer
		2. Set custom attributes if provided
		3. Extract trace_id for logging/correlation
		4. Attach span to OpenTelemetry context
		5. Store context token for later detachment
		
		Why Parent Span?
		Without parent span:
		- Each agent call creates separate trace
		- No connection between operations
		- Hard to debug multi-step workflows
		
		With parent span:
		- All operations nested under one trace_id
		- Clear parent-child relationships
		- Complete execution timeline visible
		- Easy to find all related spans
		
		Context Attachment:
		OpenTelemetry uses context propagation to link spans.
		By attaching parent span to context:
		- Child spans automatically reference it
		- Instrumentation libraries see it
		- Trace_id propagates through all operations
		
		Args:
			span_name: Name for the parent span
			          Examples: "run_azure_ai_search", "execute_workflow", "process_email"
			          Appears as root node in trace visualization
			          Should describe the high-level operation
			          
			attributes: Optional dictionary of attributes to set on the span
			           Examples:
			           - {"query": "search terms", "mode": "azure_ai_search"}
			           - {"workflow_name": "email_processor", "version": "1.0"}
			           - {"user_id": "123", "session_id": "abc"}
			           
			           Why Set Attributes?
			           - Enables filtering in Azure Monitor / trace UI
			           - Provides context for debugging
			           - Allows grouping by attributes (e.g., all errors for user X)
			           - Appears in trace details for correlation
		
		Side Effects:
		- Creates new span in tracer
		- Attaches span to global OpenTelemetry context
		- Stores self.parent_span for later access
		- Stores self.context_token for cleanup
		- Emits status messages via self.emitter
		
		Thread Safety:
		Context is thread-local. If called from multiple threads,
		each thread gets its own parent span context.
		
		Memory:
		Span is kept in memory until end_parent_span() called.
		Must call end_parent_span() to release resources and export.
		
		Example Usage:
		```python
		# Start parent span
		manager.start_parent_span(
		    "run_search",
		    attributes={"query": "AI agents", "mode": "bing"}
		)
		
		# All operations here are children
		result = run_agent(query)
		
		# End parent span
		manager.end_parent_span()
		```
		"""
		# Early exit if tracing not configured
		if not self.tracer:
			return
		
		# STEP 1: Create parent span
		# start_span() creates new span but doesn't attach to context yet
		self.parent_span = self.tracer.start_span(span_name)
		
		# STEP 2: Set attributes if provided
		if attributes:
			for key, value in attributes.items():
				# set_attribute() adds metadata to span
				# Will appear in trace UI and can be used for filtering
				self.parent_span.set_attribute(key, value)
		
		# STEP 3: Log trace ID for correlation
		# get_span_context() retrieves span metadata
		# trace_id is 128-bit integer, format as 32-character hex string
		trace_id = format(self.parent_span.get_span_context().trace_id, '032x')
		self.emit(f"[TRACING] Created parent span '{span_name}' with trace_id: {trace_id}")
		
		# STEP 4: Attach span to context
		# set_span_in_context() creates new context with span
		# This context will propagate to all child operations
		span_context = trace.set_span_in_context(self.parent_span)
		
		# STEP 5: Attach context globally
		# context.attach() makes context active for current thread
		# Returns token for later detachment
		# Why store token? Need it to restore previous context in end_parent_span()
		self.context_token = context.attach(span_context)
		self.emit("[TRACING] Parent span attached to context")
	
	def record_exception(self, exception: Exception):
		"""Record an exception in the parent span.
		
		Marks the span as failed and records exception details for debugging.
		This is critical for error tracking and alerting in production.
		
		What This Does:
		1. Records exception object with full traceback
		2. Sets span status to ERROR
		3. Stores exception message in status description
		4. Emits log message for immediate feedback
		
		Why Record Exceptions in Spans?
		- Exception appears in trace visualization
		- Can trigger alerts in Azure Monitor
		- Searchable by exception type/message
		- Preserves full traceback for debugging
		- Links error to specific operation in trace
		
		OpenTelemetry Status:
		Spans have status field indicating success/failure:
		- UNSET: Default, not explicitly set (treated as OK)
		- OK: Explicit success
		- ERROR: Operation failed
		
		Status includes optional description (error message).
		
		Args:
			exception: The exception to record
			          Can be any Python exception object
			          Full traceback is captured automatically
		
		Example Usage:
		```python
		try:
		    result = run_agent(query)
		except Exception as e:
		    manager.record_exception(e)
		    raise  # Re-raise to propagate error
		finally:
		    manager.end_parent_span()
		```
		
		Side Effects:
		- Modifies self.parent_span status
		- Records exception in span
		- Emits log message
		- Will appear in exported traces
		
		Thread Safety:
		Safe to call from any thread if parent_span exists.
		Each thread should have its own UnifiedTraceManager instance.
		"""
		# Only record if parent span exists
		if self.parent_span:
			# Import OpenTelemetry status types
			from opentelemetry.trace import Status, StatusCode
			
			# Record exception with full traceback
			# OpenTelemetry automatically captures:
			# - Exception type
			# - Exception message
			# - Stack trace
			# - Timestamp
			self.parent_span.record_exception(exception)
			
			# Set span status to ERROR
			# Status() constructor takes:
			# - StatusCode.ERROR: Marks operation as failed
			# - str(exception): Human-readable error description
			self.parent_span.set_status(Status(StatusCode.ERROR, str(exception)))
			
			# Emit log message for immediate visibility
			# Important: Console/logs may be checked before trace export completes
			self.emit(f"[TRACING] Exception recorded in parent span: {exception}")
	
	def end_parent_span(self):
		"""End parent span and detach from context.
		
		This should be called at the end of the traced operation to properly
		close the trace and ensure all data is exported.
		
		Critical for Proper Tracing:
		- Spans are not exported until ended
		- Context remains attached until detached
		- Resources held until cleanup
		
		Execution Order:
		1. Detach context first (restore previous context)
		2. End parent span second (finalize timing and export)
		
		Why This Order?
		- If span ended first, timing would be off
		- Detaching context first prevents new children from attaching
		- Clean separation: context management -> span lifecycle
		
		What end() Does:
		- Records span end time
		- Calculates duration (end_time - start_time)
		- Triggers export via registered span processors
		- Releases span from memory (after processors complete)
		
		What detach() Does:
		- Removes span from OpenTelemetry context
		- Restores previous context (if any)
		- Prevents new child spans from using this parent
		- Releases context token
		
		Error Handling:
		- Graceful handling of detach failures
		- Continues to end span even if detach fails
		- Emits warnings for failures
		
		Why Try-Except for Detach?
		- Context may have been modified elsewhere
		- Token may have been invalidated
		- Don't want detach failure to prevent span ending
		
		Memory Management:
		After this method:
		- self.parent_span is ended but reference remains
		- self.context_token is released
		- Span data in exporters until flushed
		
		Side Effects:
		- Ends self.parent_span
		- Detaches context (restores previous)
		- Triggers span export to all processors
		- Emits status messages
		
		Always Call This:
		Use try/finally to ensure end_parent_span() is called:
		```python
		try:
		    manager.start_parent_span("operation")
		    do_work()
		except Exception as e:
		    manager.record_exception(e)
		    raise
		finally:
		    manager.end_parent_span()  # Always cleanup
		```
		
		Example Usage:
		```python
		manager = UnifiedTraceManager(tracing_mode="console")
		manager.setup()
		
		# Start tracing
		manager.start_parent_span("process_query", {"query": "test"})
		
		try:
		    result = process_query("test")
		except Exception as e:
		    manager.record_exception(e)
		    raise
		finally:
		    # Always end span to ensure export
		    manager.end_parent_span()
		```
		"""
		# STEP 1: Detach context first
		if self.context_token:
			try:
				# Detach context to restore previous context
				# This prevents new operations from using this parent span
				context.detach(self.context_token)
				self.emit("[TRACING] Context detached")
			except Exception as e:
				# Non-fatal: Emit warning but continue to end span
				# Why non-fatal? Span ending is more critical than context cleanup
				# Context will be garbage collected anyway
				self.emit(f"[TRACING] ⚠️ Context detach failed: {e}")
		
		# STEP 2: End parent span
		if self.parent_span:
			# End span: Records end time and triggers export
			# After this, span is finalized and sent to all processors
			self.parent_span.end()
			self.emit("[TRACING] Parent span ended")
	
	def get_traces(self) -> Tuple[list, dict]:
		"""Get formatted traces and summary for UI display.
		
		Retrieves trace data from the collector for display in Streamlit UI.
		The format depends on which collector is configured (Agent SDK or agent_framework).
		
		Purpose:
		- Display traces in web UI after operation completes
		- Show execution timeline and nested operations
		- Provide debugging information to users
		- Visualize agent/workflow behavior
		
		Collector Differences:
		
		AgentTraceCollector (Agent SDK):
		- get_formatted_traces(): Returns list of formatted string lines
		  Format: "[indent]span_name (duration ms) - {attributes}"
		  Example: "  run_azure_ai_search (1234 ms) - {query: 'test'}"
		- get_summary(): Returns dict with span counts, total duration, etc.
		  Example: {"total_spans": 5, "total_duration_ms": 2000}
		
		UISpanCollector (agent_framework):
		- get_formatted_traces(): Returns list of workflow step descriptions
		  Format: "Step: step_name | Duration: Xms | Status: OK"
		  Example: "Step: extract_data | Duration: 500ms | Status: OK"
		- get_summary(): Returns dict with workflow-specific metrics
		  Example: {"steps": 3, "failed_steps": 0}
		
		Why Different Formats?
		- Agent SDK traces: Nested span hierarchy
		- Workflow traces: Linear step sequence
		- Each format optimized for its framework's execution model
		
		Returns:
			Tuple[list, dict]: (trace_lines, trace_summary)
			
			trace_lines: List[str]
			    Human-readable trace lines for display
			    Empty list if no collector or no traces
			    Ready for display in st.text() or similar
			    
			trace_summary: dict
			    Summary metrics about the trace
			    Empty dict if no collector or no traces
			    Can include: span counts, durations, error counts, etc.
			    Format varies by collector type
		
		Use Cases:
		```python
		# After operation completes
		traces, summary = manager.get_traces()
		
		# Display in Streamlit
		if traces:
		    st.text("\n".join(traces))
		    st.json(summary)
		```
		
		Empty Results:
		Returns ([], {}) if:
		- No collector configured (tracing disabled)
		- No traces captured yet
		- Traces were cleared
		
		Thread Safety:
		Safe to call from any thread. Collector handles synchronization.
		
		Performance:
		- O(n) where n = number of spans
		- Formatting done lazily by collector
		- Cached if collector supports caching
		"""
		# Early exit if no collector configured
		if not self.trace_collector:
			# Return empty results (no tracing configured)
			return [], {}
		
		# Get formatted traces from collector
		# Format varies by collector type (see docstring)
		trace_lines = self.trace_collector.get_formatted_traces()
		
		# Get summary metrics from collector
		# Content varies by collector type (see docstring)
		trace_summary = self.trace_collector.get_summary()
		
		# Return tuple for unpacking convenience
		return trace_lines, trace_summary
	
	def emit(self, message: str):
		"""Emit status message via configured emitter.
		
		Wrapper around self.emitter callback for consistent messaging.
		
		Why Wrapper Method?
		- Abstraction: Could add formatting, filtering, levels later
		- Null-safety: Handles None emitter gracefully
		- Consistency: All emits go through same path
		- Testability: Can mock this method instead of callback
		
		Args:
			message: Message to emit
			        Should be human-readable status/progress text
			        Typically starts with "[TRACING]" prefix for categorization
		
		Examples:
		```python
		self.emit("[TRACING] Configuring Azure Monitor...")
		self.emit("[TRACING] ✅ Setup complete")
		self.emit(f"[TRACING] ⚠️ Warning: {error}")
		```
		
		Emoji Usage:
		- ✅ : Success, completion
		- ⚠️ : Warning, non-fatal error
		- 💾 : File/storage related
		- No emoji: Informational status
		
		Side Effects:
		- Calls self.emitter(message)
		- May print to console (default emitter)
		- May update Streamlit UI (if StreamlitEmitterUtil)
		"""
		# Call emitter callback if configured
		# emitter is always set (defaults to print in __init__)
		if self.emitter:
			self.emitter(message)
