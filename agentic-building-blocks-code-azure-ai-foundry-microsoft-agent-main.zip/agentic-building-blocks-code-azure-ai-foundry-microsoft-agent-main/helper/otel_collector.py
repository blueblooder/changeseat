"""OpenTelemetry Span Collector for UI Display

Captures OpenTelemetry spans and formats them for Streamlit UI display with
automatic message routing inference for workflow visualization.

===== Key Features =====

1. Real-Time Trace Collection:
   - Captures span start/end events as they occur
   - Maintains chronological event log
   - Enables live trace display in UI

2. Message Routing Inference:
   - Tracks active executor contexts
   - Infers missing message.from and message.to attributes
   - Supports workflow pattern recognition (BlastWebSearch, Handoff, Email)

3. Workflow Metrics:
   - Counts spans by category (workflow build, run, executor, message)
   - Calculates total execution time
   - Provides summary statistics for UI dashboards

===== Basic Usage =====

```python
from helper.otel_collector import get_span_collector

# Get singleton collector (auto-registered with OTEL)
collector = get_span_collector()

# Enable collection before workflow execution
collector.enable()

# Run workflow (spans automatically collected)
workflow.run()

# Get formatted traces for UI
traces = collector.get_formatted_traces()
for trace in traces:
    st.write(trace)

# Get summary metrics
summary = collector.get_summary()
st.metric("Total Spans", summary["total_spans"])
st.metric("Workflow Time", f"{summary['workflow_elapsed_ms']:.2f}ms")

# Disable collection to save memory
collector.disable()
```

===== Supported Workflow Patterns =====

BlastWebSearch:
  dispatcher → [bing_searcher, headless_searcher, gcptxt_searcher]
  searchers → search_aggregator → email_writer

Handoff:
  input-conversation → handoff-coordinator ↔ handoff-user-input
  handoff-user-input ↔ triage_agent_handoff_requests
  agents ↔ handoff-coordinator

Email:
  email_checker → email_summarizer → email_writer → email_sender

===== Integration Points =====

Used By:
  - apps/ui_manager.py: Displays formatted traces in Streamlit UI
  - helper/storeotel.py: Persists metadata to JSON files
  - workflow/*.py: Automatic trace collection during workflow execution

Depends On:
  - opentelemetry.sdk.trace: Core OpenTelemetry SDK
  - opentelemetry.sdk.trace.export: SpanProcessor interface
"""

from typing import Optional
from opentelemetry.sdk.trace import ReadableSpan
from opentelemetry.sdk.trace.export import SpanProcessor


class UISpanCollector(SpanProcessor):
    """Custom SpanProcessor that captures spans for UI display.
    
    Collects OpenTelemetry span start/end events with timing information
    and attributes, formats them for human-readable display, and infers
    missing message routing attributes based on workflow patterns.
    
    Design Rationale:
    - Uses SpanProcessor interface (not exporter) for real-time collection
    - Maintains executor context stack for message routing inference
    - Tracks both active and completed executors for accurate attribution
    
    State Management:
    - spans: List of all captured span events (start/end)
    - _enabled: Flag to control collection (disable to save memory)
    - _active_executors: Stack of currently executing executors
    - _last_completed_executor: Last executor that finished (for inter-workflow messages)
    
    Memory Usage:
    - Each span event: ~0.5-1 KB
    - 100 spans: ~50-100 KB
    - Enable/disable around specific workflows to manage memory
    """
    
    def __init__(self):
        """Initialize the span collector with empty state.
        
        Creates empty collections for spans and executor tracking.
        Collection is disabled by default (call enable() to start).
        """
        self.spans = []
        self._enabled = False
        self._active_executors = []  # Stack to track active executor contexts
        self._last_completed_executor = None  # Track the last executor that completed
    
    def enable(self):
        """Enable span collection and clear any existing spans.
        
        Why Clear Spans:
        - Prevents mixing traces from different workflow runs
        - Ensures UI displays only current execution
        - Resets executor tracking state for accurate inference
        
        Usage Pattern:
        ```python
        collector.enable()  # Start fresh
        workflow.run()      # Collect this execution only
        traces = collector.get_formatted_traces()
        collector.disable()
        ```
        """
        self._enabled = True
        self.spans = []
        self._active_executors = []
        self._last_completed_executor = None
    
    def disable(self):
        """Disable span collection but preserve existing spans.
        
        Why Preserve Spans:
        - Allows retrieval of traces after workflow completion
        - Enables repeated formatting/display without re-running
        - Supports multiple consumers (UI, storage, logging)
        
        To completely clear: Call enable() which resets all state
        """
        self._enabled = False
    
    def on_start(self, span: ReadableSpan, parent_context=None) -> None:
        """Called by OpenTelemetry SDK when a span starts.
        
        Execution Flow:
        1. Check if collection is enabled
        2. Track executor contexts (for message routing inference)
        3. Record span start event with timestamp and IDs
        
        Args:
            span: The span that started
            parent_context: The parent span context (optional, unused)
        
        Side Effects:
            - Appends executor info to _active_executors (if executor span)
            - Appends start event to self.spans
        
        Executor Tracking:
        - Maintains stack of active executors (push on start, pop on end)
        - Used later to infer message.from attributes
        - Example: {'executor_id': 'bing_searcher', 'span_id': '...', 'start_time': ...}
        """
        if self._enabled:
            # Track active executor contexts for message routing inference
            if 'executor.process' in span.name:
                attributes = dict(span.attributes) if span.attributes else {}
                executor_id = attributes.get('executor.id', 'unknown')
                self._active_executors.append({
                    'executor_id': executor_id,
                    'span_id': format(span.context.span_id, '016x'),
                    'start_time': span.start_time,
                })
            
            self.spans.append({
                'event': 'start',
                'name': span.name,
                'span_id': format(span.context.span_id, '016x'),
                'trace_id': format(span.context.trace_id, '032x'),
                'timestamp': span.start_time / 1_000_000_000,  # Convert nanoseconds to seconds
            })
    
    def on_end(self, span: ReadableSpan) -> None:
        """Called by OpenTelemetry SDK when a span ends.
        
        Execution Flow:
        1. Calculate span duration (nanoseconds → milliseconds)
        2. Extract and normalize attributes
        3. Infer missing message routing attributes (for message.send spans)
        4. Track executor completion state
        5. Record span end event with full details
        
        Args:
            span: The span that ended
        
        Side Effects:
            - Updates _last_completed_executor (if executor span)
            - Removes completed executor from _active_executors stack
            - Modifies span attributes (adds inferred message.from/to)
            - Appends end event to self.spans
        
        Message Routing Inference:
        - Uses _active_executors stack to infer message.from
        - Uses _infer_message_to() to determine message.to
        - Fallback: Uses _last_completed_executor for inter-workflow messages
        
        Example:
        ```
        # Before inference:
        message.send span with no from/to attributes
        
        # After inference:
        attributes['message.from'] = 'dispatcher'
        attributes['message.to'] = 'bing_searcher'
        ```
        """
        if self._enabled:
            duration_ms = (span.end_time - span.start_time) / 1_000_000  # Convert nanoseconds to milliseconds
            attributes = dict(span.attributes) if span.attributes else {}
            
            # MESSAGE ROUTING INFERENCE
            # For message.send spans, infer message.from and message.to if not already set
            if 'message.send' in span.name:
                # Infer message.from from active executor context
                if 'message.from' not in attributes or not attributes.get('message.from'):
                    if self._active_executors:
                        # Use the most recent active executor as the sender
                        attributes['message.from'] = self._active_executors[-1]['executor_id']
                    elif self._last_completed_executor:
                        # Use the last completed executor if no active ones
                        # This handles messages sent between workflow runs
                        attributes['message.from'] = self._last_completed_executor
                    else:
                        attributes['message.from'] = 'unknown'
                
                # Infer message.to based on message.from and message.type
                if 'message.to' not in attributes or not attributes.get('message.to'):
                    from_id = attributes.get('message.from', 'unknown')
                    msg_type = attributes.get('message.type', 'unknown')
                    attributes['message.to'] = self._infer_message_to(from_id, msg_type)
            
            # EXECUTOR COMPLETION TRACKING
            # Track executor completion for inter-workflow message routing
            if 'executor.process' in span.name:
                executor_id = attributes.get('executor.id', 'unknown')
                self._last_completed_executor = executor_id
                
                # Remove completed executor from active stack
                span_id = format(span.context.span_id, '016x')
                self._active_executors = [e for e in self._active_executors if e['span_id'] != span_id]
            
            # Record span end event with all details
            self.spans.append({
                'event': 'end',
                'name': span.name,
                'span_id': format(span.context.span_id, '016x'),
                'trace_id': format(span.context.trace_id, '032x'),
                'start_time': span.start_time / 1_000_000_000,
                'end_time': span.end_time / 1_000_000_000,
                'duration_ms': duration_ms,
                'status': str(span.status.status_code),
                'attributes': attributes,
            })
    
    def _infer_message_to(self, from_id: str, msg_type: str) -> str:
        """Infer message destination based on sender and message type.
        
        Uses workflow pattern matching to determine where messages are routed
        when explicit message.to attribute is missing.
        
        Args:
            from_id: The executor ID that sent the message
            msg_type: The message type (e.g., 'SearchRequest', 'RequestResponse')
        
        Returns:
            The inferred destination executor ID (or 'unknown' if can't infer)
        
        Supported Patterns:
        - BlastWebSearch: dispatcher → searchers → aggregator → email_writer
        - Handoff: coordinator ↔ user-input ↔ triage_agent ↔ agents
        - Email: checker → summarizer → writer → sender
        
        Example:
        ```python
        # BlastWebSearch pattern
        _infer_message_to('dispatcher', 'SearchRequest') → 'searcher'
        _infer_message_to('bing_searcher', 'SearchResponse') → 'search_aggregator'
        
        # Handoff pattern
        _infer_message_to('handoff-coordinator', 'RequestResponse') → 'handoff-user-input'
        _infer_message_to('handoff-user-input', 'UserResponse') → 'handoff-coordinator'
        ```
        """
        # ===== BlastWebSearch Workflow Pattern =====
        if from_id == 'dispatcher':
            # Dispatcher sends SearchRequest to specific searchers
            if 'SearchRequest' in msg_type:
                # We can't determine which searcher without more context
                # But the framework will have set the actual target
                return 'searcher'  # Generic fallback
        
        elif from_id in ['bing_searcher', 'headless_searcher', 'gcptxt_searcher']:
            # All searchers send SearchResponse to aggregator
            if 'SearchResponse' in msg_type:
                return 'search_aggregator'
        
        elif from_id == 'search_aggregator':
            # Aggregator sends to email writer if present
            if 'BlastSearchOutput' in msg_type:
                return 'email_writer'
        
        # ===== Handoff Workflow Pattern =====
        # Handle input-conversation (initial message)
        if 'input-conversation' in from_id:
            # Input conversation sends to the handoff coordinator
            return 'handoff-coordinator'
        
        # Handle handoff-specific message types
        elif 'handoff-coordinator' in from_id:
            # Coordinator sends to triage agent or user input handler
            if 'RequestResponse' in msg_type:
                return 'handoff-user-input'
            elif 'AgentExecutorRequest' in msg_type:
                return 'agent'  # Goes to a specific agent
            elif 'list' in msg_type:
                # List messages from coordinator typically go to user input for handling
                return 'handoff-user-input'
        
        elif 'handoff-user-input' in from_id:
            # User input handler sends back to coordinator
            if 'RequestResponse' in msg_type or 'UserResponse' in msg_type or '_ConversationWithUserInput' in msg_type:
                return 'handoff-coordinator'
            elif 'HandoffUserInputRequest' in msg_type:
                return 'triage_agent_handoff_requests'
        
        elif 'triage_agent_handoff_requests' in from_id:
            # Handoff request handler sends responses back to user input handler
            if 'RequestResponse' in msg_type:
                return 'handoff-user-input'
        
        # Handle agent-to-agent handoffs (triage, replacement, delivery, billing)
        elif '_agent' in from_id:
            # Agent handoff patterns
            if 'HandoffRequest' in msg_type or 'AgentMessage' in msg_type:
                # Generic agent-to-agent handoff
                return 'handoff-coordinator'  # Goes through coordinator
            elif 'RequestResponse' in msg_type or 'AgentExecutorResponse' in msg_type:
                return 'handoff-coordinator'
        
        # ===== Email Workflow Pattern =====
        # Handle email workflow executors
        elif from_id in ['email_checker', 'email_summarizer', 'email_writer', 'email_sender']:
            # Email workflow pattern
            if 'EmailCheckResponse' in msg_type:
                return 'email_summarizer'
            elif 'EmailSummaryResponse' in msg_type:
                return 'email_writer'
            elif 'EmailWriteResponse' in msg_type:
                return 'email_sender'
        
        return 'unknown'
    
    def shutdown(self) -> None:
        """Shutdown the processor (required by SpanProcessor interface).
        
        No cleanup needed - spans remain accessible after shutdown.
        """
        pass
    
    def force_flush(self, timeout_millis: int = 30000) -> bool:
        """Force flush any pending spans (required by SpanProcessor interface).
        
        Args:
            timeout_millis: Timeout in milliseconds (unused - no-op for this processor)
        
        Returns:
            True (always succeeds - no async operations to flush)
        
        Note: This processor writes spans synchronously to memory,
              so there's nothing to flush. Always returns True immediately.
        """
        return True
    
    def get_formatted_traces(self) -> list[str]:
        """Format collected spans for UI display with emojis and timing.
        
        Returns:
            List of formatted trace strings, one per completed span
        
        Output Format Examples:
        ```
        🔨 [workflow.build] workflow.build - 123.45ms
           └─ Event: executors_created
        ▶️  [workflow.run] workflow.run - 5678.90ms
           └─ Event: workflow_completed
        ⚙️  [executor.process] bing_searcher (SearchRequest) - 2345.67ms
        📨 [message.send] dispatcher → bing_searcher (SearchRequest) - 12.34ms
        📊 generic_span - 56.78ms (OK)
        ```
        
        Span Categories:
        - workflow.build: Workflow construction/initialization
        - workflow.run: Workflow execution
        - executor.process: Individual executor processing
        - message.send: Message routing between executors
        - generic: Other spans (with status code)
        """
        lines = []
        for span_data in self.spans:
            if span_data['event'] == 'end':
                name = span_data['name']
                duration = span_data['duration_ms']
                status = span_data['status']
                attributes = span_data.get('attributes', {})
                
                # Format based on span category
                if 'workflow.build' in name:
                    lines.append(f"🔨 [workflow.build] {name} - {duration:.2f}ms")
                    
                    # Show build events
                    if 'event.name' in attributes:
                        event_name = attributes['event.name']
                        lines.append(f"   └─ Event: {event_name}")
                
                elif 'workflow.run' in name:
                    lines.append(f"▶️  [workflow.run] {name} - {duration:.2f}ms")
                    
                    # Show workflow events
                    if 'event.name' in attributes:
                        event_name = attributes['event.name']
                        lines.append(f"   └─ Event: {event_name}")
                
                elif 'executor.process' in name:
                    executor_id = attributes.get('executor.id', 'unknown')
                    message_type = attributes.get('message.type', 'unknown')
                    lines.append(f"⚙️  [executor.process] {executor_id} ({message_type}) - {duration:.2f}ms")
                
                elif 'message.send' in name:
                    from_id = attributes.get('message.from', 'unknown')
                    to_id = attributes.get('message.to', 'unknown')
                    message_type = attributes.get('message.type', 'unknown')
                    lines.append(f"📨 [message.send] {from_id} → {to_id} ({message_type}) - {duration:.2f}ms")
                
                else:
                    # Generic span
                    lines.append(f"📊 {name} - {duration:.2f}ms ({status})")
        
        return lines
    
    def get_summary(self) -> dict:
        """Get summary statistics of collected spans for dashboards.
        
        Returns:
            Dictionary with span counts and timing statistics:
            {
                'total_spans': 42,              # Total completed spans
                'workflow_build_spans': 1,      # Workflow construction spans
                'workflow_run_spans': 1,        # Workflow execution spans
                'executor_spans': 15,           # Executor processing spans
                'message_spans': 25,            # Message routing spans
                'workflow_elapsed_ms': 5678.90, # Wall-clock time (from workflow.run)
                'sum_of_spans_ms': 12345.67,    # Sum of all durations (includes overlaps)
                'avg_duration_ms': 294.42       # Average span duration
            }
        
        Usage:
        ```python
        summary = collector.get_summary()
        st.metric("Total Spans", summary["total_spans"])
        st.metric("Workflow Time", f"{summary['workflow_elapsed_ms']:.2f}ms")
        st.metric("Avg Duration", f"{summary['avg_duration_ms']:.2f}ms")
        ```
        
        Note: sum_of_spans_ms > workflow_elapsed_ms due to parallel execution.
              Use workflow_elapsed_ms for actual wall-clock time.
        """
        ended_spans = [s for s in self.spans if s['event'] == 'end']
        
        if not ended_spans:
            return {
                'total_spans': 0,
                'workflow_build_spans': 0,
                'workflow_run_spans': 0,
                'executor_spans': 0,
                'message_spans': 0,
                'workflow_elapsed_ms': 0,
                'sum_of_spans_ms': 0,
            }
        
        workflow_build = [s for s in ended_spans if 'workflow.build' in s['name']]
        workflow_run = [s for s in ended_spans if 'workflow.run' in s['name']]
        executor_process = [s for s in ended_spans if 'executor.process' in s['name']]
        message_send = [s for s in ended_spans if 'message.send' in s['name']]
        
        # Sum of all span durations (includes overlapping parallel execution)
        sum_of_spans = sum(s['duration_ms'] for s in ended_spans)
        
        # Actual workflow elapsed time (wall-clock time from workflow.run span)
        workflow_elapsed = 0
        if workflow_run:
            # Get the longest workflow.run span (should only be one)
            workflow_elapsed = max(s['duration_ms'] for s in workflow_run)
        
        return {
            'total_spans': len(ended_spans),
            'workflow_build_spans': len(workflow_build),
            'workflow_run_spans': len(workflow_run),
            'executor_spans': len(executor_process),
            'message_spans': len(message_send),
            'workflow_elapsed_ms': workflow_elapsed,
            'sum_of_spans_ms': sum_of_spans,
            'avg_duration_ms': sum_of_spans / len(ended_spans) if ended_spans else 0,
        }
    
    def get_metadata(self) -> dict:
        """Get detailed metadata about collected spans for storage/persistence.
        
        Returns:
            Dictionary with comprehensive span statistics and metadata:
            {
                'total_spans': 42,
                'workflow_build_spans': 1,
                'workflow_run_spans': 1,
                'executor_process_spans': 15,
                'message_send_spans': 25,
                'workflow_elapsed_ms': 5678.90,
                'sum_of_spans_ms': 12345.67,
                'avg_duration_ms': 294.42,
                'executors': ['bing_searcher', 'email_writer', ...]  # Sorted unique IDs
            }
        
        Difference from get_summary():
        - Includes list of unique executor IDs (for workflow analysis)
        - More detailed key names (executor_process_spans vs executor_spans)
        - Designed for JSON storage/logging
        
        Usage:
        ```python
        metadata = collector.get_metadata()
        with open('workflow_trace.json', 'w') as f:
            json.dump(metadata, f, indent=2)
        ```
        """
        ended_spans = [s for s in self.spans if s['event'] == 'end']
        
        if not ended_spans:
            return {
                'total_spans': 0,
                'workflow_build_spans': 0,
                'workflow_run_spans': 0,
                'executor_process_spans': 0,
                'message_send_spans': 0,
                'workflow_elapsed_ms': 0,
                'sum_of_spans_ms': 0,
                'avg_duration_ms': 0,
                'executors': [],
            }
        
        workflow_build = [s for s in ended_spans if 'workflow.build' in s['name']]
        workflow_run = [s for s in ended_spans if 'workflow.run' in s['name']]
        executor_process = [s for s in ended_spans if 'executor.process' in s['name']]
        message_send = [s for s in ended_spans if 'message.send' in s['name']]
        
        # Sum of all span durations (includes overlapping parallel execution)
        sum_of_spans = sum(s['duration_ms'] for s in ended_spans)
        
        # Actual workflow elapsed time (wall-clock time from workflow.run span)
        workflow_elapsed = 0
        if workflow_run:
            # Get the longest workflow.run span (should only be one)
            workflow_elapsed = max(s['duration_ms'] for s in workflow_run)
        
        # Extract unique executor IDs from all executor spans
        executor_ids = set()
        for span in executor_process:
            executor_id = span.get('attributes', {}).get('executor.id', 'unknown')
            executor_ids.add(executor_id)
        
        return {
            'total_spans': len(ended_spans),
            'workflow_build_spans': len(workflow_build),
            'workflow_run_spans': len(workflow_run),
            'executor_process_spans': len(executor_process),
            'message_send_spans': len(message_send),
            'workflow_elapsed_ms': workflow_elapsed,
            'sum_of_spans_ms': sum_of_spans,
            'avg_duration_ms': sum_of_spans / len(ended_spans) if ended_spans else 0,
            'executors': sorted(list(executor_ids)),  # Sorted for consistent output
        }

# ===== GLOBAL SINGLETON INSTANCE =====
# Single collector instance shared across all workflows
# Ensures consistent trace collection and state management
_span_collector: Optional[UISpanCollector] = None


def get_span_collector() -> UISpanCollector:
    """Get or create the global span collector singleton instance.
    
    Ensures only one span collector exists per process and automatically
    registers it with the OpenTelemetry tracer provider.
    
    Returns:
        The global UISpanCollector instance
    
    Usage:
    ```python
    # First call creates and registers collector
    collector = get_span_collector()
    collector.enable()
    
    # Subsequent calls return same instance
    same_collector = get_span_collector()
    assert collector is same_collector  # True
    ```
    
    Thread Safety:
    - NOT thread-safe for initialization (first call)
    - Use lock if multiple threads call simultaneously during startup
    - Once created, the collector itself is thread-safe (OTEL SDK handles it)
    
    Error Handling:
    - Silently fails registration if OTEL not configured yet
    - Normal during app initialization (before setup_observability())
    - Collector still created and returned (registration happens later)
    """
    global _span_collector
    if _span_collector is None:
        _span_collector = UISpanCollector()
        
        # Register with the tracer provider
        try:
            from opentelemetry import trace
            trace.get_tracer_provider().add_span_processor(_span_collector)
        except Exception:
            # Silently fail if OTEL not configured yet
            # This is normal if called before setup_observability()
            pass
    
    return _span_collector


def reset_span_collector():
    """Reset the global span collector to None for testing/reinitialization.
    
    Use Cases:
    - Unit testing: Start each test with fresh collector
    - Configuration changes: Reinitialize after OTEL setup changes
    - Memory cleanup: Force recreation with new settings
    
    Warning:
    - Does NOT unregister old collector from tracer provider
    - May result in multiple collectors if not careful
    - Primarily for testing - avoid in production code
    
    Example:
    ```python
    # In test setup
    reset_span_collector()
    collector = get_span_collector()  # Creates new instance
    collector.enable()
    
    # Run test...
    
    # In test teardown
    collector.disable()
    reset_span_collector()  # Clean slate for next test
    ```
    """
    global _span_collector
    _span_collector = None
