"""Logic App Email Sending Helper - Azure Logic Apps Email Integration.

Purpose:
--------
Provides email sending functionality via Azure Logic Apps HTTP trigger endpoint.
Supports HTML emails, attachments, and OpenTelemetry distributed tracing.

This module serves as a workflow-based email integration compared to:
- helper/graphapi.py: Direct Microsoft Graph API (requires app registration, OAuth)
- SMTP clients: Traditional SMTP servers (requires credentials, port access)
- SendGrid/Twilio: Third-party email services (requires API keys)

Key Capabilities:
-----------------
1. Azure Logic Apps Integration: Sends email via HTTP POST to Logic App endpoint
2. Office 365 Connector Support: Formats attachments for Office 365 (Name, ContentBytes)
3. HTML Email Rendering: Automatic HTML wrapping with optional URL linkification
4. Base64 Attachments: Inline file attachments with automatic encoding
5. OpenTelemetry Tracing: Parent span creation for distributed observability
6. Emitter Pattern: Consistent logging/UI integration
7. Return Mode Flexibility: Supports 'log', 'answer', 'both' return formats
8. JSON Persistence: Optional save_json for email body archival

Architecture:
-------------
```
Application/Agent
    |
    v
send_email()
    |
    +---> Create OpenTelemetry parent span
    |
    +---> Prepare email body
    |       |
    |       +---> HTML wrapping (if needed)
    |       +---> URL linkification (optional)
    |       +---> Newline to <br> conversion
    |
    +---> Process attachments
    |       |
    |       +---> Read file bytes
    |       +---> Base64 encode
    |       +---> Format for Office 365 (Name, ContentBytes)
    |
    +---> Build JSON payload
    |       |
    |       +---> email_to, email_subject, email_body
    |       +---> attachments[] (if any)
    |       +---> email_body_content_type: "html"
    |
    +---> Send HTTP POST to Logic App endpoint
    |
    +---> Parse response (200 = success)
    |
    +---> End OpenTelemetry span
    |
    +---> Return based on mode
```

Azure Logic Apps Workflow:
---------------------------
The Logic App endpoint typically contains:
1. HTTP Request Trigger (receives JSON payload)
2. Office 365 Outlook Connector - "Send an email (V2)" action
3. Map JSON fields to email properties:
   - To: email_to
   - Subject: email_subject
   - Body: email_body
   - Attachments: attachments[] array
4. Response action (200 OK on success)

Why Logic Apps Instead of Direct Graph API?
--------------------------------------------
✓ No Code: Visual workflow designer (low-code solution)
✓ No Auth Flow: Logic App handles authentication to Office 365
✓ Retry Logic: Built-in retry policies for transient failures
✓ Monitoring: Azure Portal monitoring and run history
✓ Scalability: Serverless execution, auto-scaling
✗ Latency: HTTP roundtrip + Logic App execution (~1-3 seconds)
✗ Cost: Pay per execution (free tier: 4,000 runs/month)

Refactoring Notes:
------------------
Previously exposed two functions:
- send_logic_app_email(): Low-level HTTP POST
- send_email(): High-level with email body generation

Current Design (Unified):
- send_email(): Single public function combining preparation + POST
- send_logic_app_email(): Deprecated wrapper for backward compatibility

Why Unified?
- Simplifies API surface (one entry point)
- Removes dependency on agent.emailwriter.write_email_body
- Allows caller to prepare body (more flexible)
- Maintains backward compatibility via deprecated wrapper

Backward Compatibility:
-----------------------
send_logic_app_email() remains for external callers (deprecated):
- Returns list[str] log lines (legacy behavior)
- Delegates to send_email(return_mode='log')
- Emits DeprecationWarning

HTML Email Processing:
----------------------
Automatic HTML wrapping when:
1. html=True (default)
2. Body doesn't contain HTML tags (<html, <div, <p, etc.)

Process:
1. HTML-escape special chars (&, <, >)
2. Optional URL linkification (convert http://... to <a href>)
3. Convert newlines to <br>
4. Wrap in <html><body>...</body></html>

Why Auto-Wrap?
- Email clients expect HTML structure
- Plain text bodies render poorly in HTML mode
- Preserves formatting (line breaks, URLs)

URL Linkification:
------------------
When linkify=True (default):
- Regex matches http:// and https:// URLs
- Converts to clickable <a href="..."> links
- target="_blank": Opens in new tab
- rel="noopener noreferrer": Security (prevent tab-napping)

Why Linkify?
- Improves user experience (clickable links)
- Many email clients don't auto-detect URLs in HTML
- Safe implementation (HTML-escaped before injection)

Attachment Handling:
--------------------
Office 365 Connector expects specific format:
- Name: Filename (string)
- ContentBytes: Base64-encoded file content (string)
- ContentType: MIME type (optional, defaults to application/octet-stream)

Process:
1. Read file bytes from path
2. Base64 encode (binary → ASCII string)
3. Create attachment dict with Office 365 fields
4. Include legacy fields for backward compatibility

Why Base64?
- JSON cannot contain binary data
- Base64 encodes binary as ASCII text
- Office 365 connector expects this format

Tracing Modes:
--------------
'auto' (default):
- Creates parent span "send_email"
- Attaches to OpenTelemetry context
- Allows child spans (HTTP requests) to link
- Use when: Called directly from application

'none':
- Skips parent span creation
- Use when: Already in traced context (workflow)
- Prevents duplicate parent spans

Why Two Modes?
- Standalone calls need parent span for visibility
- Workflow calls inherit existing context
- Avoids nested duplicate spans

Environment Variables:
----------------------
LOGIC_APP_EMAIL_URL: HTTP endpoint of Logic App trigger
- Format: https://<region>.logic.azure.com:443/workflows/<workflow-id>/triggers/manual/paths/invoke?api-version=...&sp=...&sv=...&sig=...
- Obtain from: Logic App → HTTP trigger → "HTTP POST URL"
- Security: Contains SAS token (don't commit to git)

Return Modes:
-------------
'log' (default):
- Returns joined log string
- Use when: Only need diagnostic information
- Legacy behavior for backward compatibility

'answer':
- Returns processed email body (HTML)
- Use when: Need to verify formatted output

'both':
- Returns dict: { 'processed_body', 'output_text', 'log' }
- Use when: Need both formatted body and diagnostics

Pattern Consistency:
--------------------
Mirrors other helper modules (storeemail, text2speech, etc.):
- emit(): Streams log messages to console or UI
- return_mode: Flexible return value formats
- save_json: Optional persistence

Dependencies:
-------------
- requests: HTTP client for Logic App POST
  Install: pip install requests
  
- python-dotenv: Load LOGIC_APP_EMAIL_URL from .env
  Install: pip install python-dotenv
  
- opentelemetry: Distributed tracing instrumentation
  Install: pip install opentelemetry-api opentelemetry-sdk
  
- helper.emitter: Centralized logging utility

Performance Considerations:
---------------------------
- HTTP POST: ~200-500ms (network to Logic App)
- Logic App execution: ~500-2000ms (Office 365 send)
- Total: ~1-3 seconds typical
- Attachment encoding: ~10-50ms per MB

Best Practices:
---------------
1. Store LOGIC_APP_EMAIL_URL in .env file (never commit)
2. Limit attachment sizes (<5MB per file, <10MB total)
3. Use HTML format for rich content (default)
4. Enable tracing for production debugging
5. Cache formatted bodies when sending multiple emails

Security Considerations:
------------------------
- Logic App URL contains SAS token (sensitive)
- Use HTTPS only (enforced by Azure)
- Validate email addresses before sending
- Sanitize user input in email body (prevent injection)
- Don't log full payload (may contain sensitive data)

Example Usage:
--------------
```python
# Basic usage
from helper.logicappemail import send_email

send_email(
    to="user@example.com",
    subject="Test Email",
    body="Hello from Azure Logic Apps!"
)

# HTML with attachments
send_email(
    to="user@example.com",
    subject="Report",
    body="<h1>Monthly Report</h1><p>See attached.</p>",
    attachments=["report.pdf", "chart.png"],
    html=True
)

# Get structured result
result = send_email(
    to="user@example.com",
    subject="Notification",
    body="System alert",
    return_mode="both"
)
if "log" in result:
    print(result['log'])

# Save email body
send_email(
    to="user@example.com",
    subject="Archive",
    body="Important message",
    save_json="sent_emails/email_20250110.json"
)

# Disable tracing (when in workflow context)
send_email(
    to="user@example.com",
    subject="Workflow Step",
    body="Processing complete",
    tracing_mode="none"
)
```

Limitations:
------------
- Requires Azure Logic App setup (not standalone)
- Latency higher than direct SMTP (~1-3s vs ~200ms)
- Attachment size limited by Logic App (typically 100MB)
- Email send failures may not surface immediately
- Requires internet connectivity to Azure

Related Modules:
----------------
- helper/graphapi.py: Direct Microsoft Graph API email sending
- helper/storeemail.py: Email archival to Azure Blob Storage
- agent/emailwriter.py: AI-powered email content generation
- helper/emitter.py: Logging and UI update utility

Public Functions:
-----------------
- send_email(): Primary email sending function
- send_logic_app_email(): Deprecated backward-compatible wrapper
"""

from __future__ import annotations

import os
import requests  # HTTP client for Logic App POST
from typing import List, Optional, Sequence, Union, Callable
from datetime import datetime
import base64  # For attachment encoding
from dotenv import load_dotenv  # Load environment variables from .env
from helper.emitter import create_emitter
from opentelemetry import trace  # Distributed tracing

# Load environment variables from .env file
# Required: LOGIC_APP_EMAIL_URL
load_dotenv()

# Environment variable key for Logic App HTTP endpoint
LOGIC_APP_EMAIL_URL_ENV = "LOGIC_APP_EMAIL_URL"
def send_email(
    to: str,
    subject: str,
    body: str,
    attachments: Optional[Sequence[str]] = None,
    *,
    emitter=None,
    return_mode: str = "log",  # 'log' | 'answer' | 'both'
    save_json: Optional[str] = None,
    logic_app_url: Optional[str] = None,
    html: bool = True,
    linkify: bool = True,
    tracing_mode: str = "auto",  # 'auto' | 'none'
) -> Union[str, dict]:
    """Send an email via Logic App endpoint with flexible return modes.

    Parameters
    ----------
    to : str
        Recipient email address.
    subject : str
        Subject line (timestamp will be appended automatically).
    body : str
        Email body (HTML/text) already prepared by caller. If `html=True` and the
        body does not appear to contain any HTML tags, it will be wrapped in a
        minimal <html><body>...</body></html> scaffold so that downstream Logic
        App / mail sender treats it as HTML.
    attachments : Sequence[str] | None
        Optional list of file paths to attach (base64 inlined).
    emitter : Callable[[str], Any] | None
        Optional callback for streaming log lines (e.g., to UI).
    return_mode : controls this function's return shape (see below)
    save_json : str | None
        If provided, path to write a JSON artefact capturing body + log.
    logic_app_url : str | None
        Override Logic App URL (defaults to env var LOGIC_APP_EMAIL_URL).
    html : bool
        When True (default) mark payload as HTML and ensure basic wrapping.
    linkify : bool
        When True (default) convert raw http(s) URLs in plain text bodies into
        clickable <a href> links before wrapping.
    tracing_mode : str
        Controls OpenTelemetry tracing:
        'auto' (default) -> Create parent span for send_email operation
        'none' -> Skip parent span creation (use when called from workflow with existing context)

    (Email body is sent as-is; previous writer generation removed.)

        Return Modes
        ------------
            'log'   -> joined log string (legacy default)
            'answer'-> processed body only
            'both'  -> { 'processed_body', 'output_text', 'log' }
    """
    # STEP 1: Prepare timestamp for email subject
    # Format: [YYYYMMDD-HHMMSS] for easy sorting and identification
    # Why append timestamp? Makes each email unique, helps with debugging/tracking
    timestamp = datetime.now().strftime("[%Y%m%d-%H%M%S]")
    subject_ts = f"{subject} {timestamp}"
    
    # STEP 2: Initialize emitter for logging
    # create_emitter wraps callback or creates console emitter
    emit_util = create_emitter(emitter)
    
    def emit(line: str):
        emit_util.emit(line)
    
    # STEP 3: OpenTelemetry tracing setup
    # Why tracing? Enables distributed observability across workflow steps
    # Parent span links child operations (HTTP requests, database calls)
    tracer = trace.get_tracer(__name__)
    parent_span = None  # Will hold the parent span if tracing enabled
    span_context = None  # Context for attaching span to current execution
    token = None  # Token for detaching context later (cleanup)
    
    if tracing_mode != "none":
        # Import context here to avoid dependency when tracing disabled
        from opentelemetry import context
        
        # Create parent span for this email send operation
        # Why "send_email"? Top-level operation name in trace visualization
        parent_span = tracer.start_span("send_email")
        
        # Set span attributes for trace analysis and filtering
        # These appear in observability tools (Azure Monitor, Jaeger, etc.)
        parent_span.set_attribute("recipient", to)
        parent_span.set_attribute("subject", subject_ts)
        parent_span.set_attribute("body_length", len(body))
        parent_span.set_attribute("has_attachments", attachments is not None and len(attachments) > 0)
        if attachments:
            parent_span.set_attribute("attachment_count", len(attachments))
        
        # Extract trace ID for logging (32-character hex string)
        # format(..., '032x'): Format as 32-digit hex with leading zeros
        # Why log trace_id? Links logs to traces in observability platform
        trace_id = format(parent_span.get_span_context().trace_id, '032x')
        emit(f"[OBSERVABILITY] Created parent span 'send_email' with trace_id: {trace_id}")
        
        # Attach parent span to current context
        # Why attach? Child operations (HTTP POST) will auto-link to this span
        span_context = trace.set_span_in_context(parent_span)
        token = context.attach(span_context)
    
    try:
        emit(f"Preparing to send email to: {to}")
        emit(f"Subject: {subject_ts}")
        emit(f"Body: {body}")

        # STEP 4: Process email body for HTML rendering
        # Previously, body generation via write_email_body occurred here
        # Now we accept prepared body from caller (more flexible)
        processed_body = body
        
        # Check if body already contains HTML tags
        # Why check? Avoid double-wrapping already-formatted HTML
        # Common tags: <html, <div, <p, <table, <br, <span, <a 
        is_probably_html = any(tag in body.lower() for tag in ("<html", "<div", "<p", "<table", "<br", "<span", "<a "))
        
        if html and not is_probably_html:
            # Body is plain text but HTML mode requested
            # Apply HTML wrapping with escaping and linkification
            sanitized = processed_body
            
            # STEP 4a: HTML escape special characters
            # Why escape? Prevents HTML injection, ensures text displays correctly
            # & → &amp; (must be first to avoid double-escaping)
            # < → &lt; (prevents tag interpretation)
            # > → &gt; (prevents tag interpretation)
            sanitized = sanitized.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            
            if linkify:
                # STEP 4b: Convert plain URLs to clickable links
                import re
                # Regex matches http:// or https:// URLs
                # Character class: [\w\-._~:/%?#@!$&'()*+,;=]+ allows valid URL chars
                # Why specific chars? Follows RFC 3986 URL syntax
                url_re = re.compile(r"(https?://[\w\-._~:/%?#@!$&'()*+,;=]+)")
                
                def _repl(m):
                    url = m.group(1)
                    display = url
                    return f"<a href=\"{url}\" target=\"_blank\" rel=\"noopener noreferrer\">{display}</a>"
                
                # Build linkified version by replacing URLs with <a> tags
                # Why manual replacement? Already escaped, safe to inject HTML
                parts = []
                last = 0
                for match in url_re.finditer(sanitized):
                    # Add text before URL
                    parts.append(sanitized[last:match.start()])
                    
                    raw_url = match.group(1)
                    # raw_url contains no < > because already escaped
                    # target="_blank": Opens in new tab
                    # rel="noopener noreferrer": Security (prevents tab-napping attacks)
                    parts.append(f"<a href=\"{raw_url}\" target=\"_blank\" rel=\"noopener noreferrer\">{raw_url}</a>")
                    last = match.end()
                
                # Add remaining text after last URL
                parts.append(sanitized[last:])
                sanitized = "".join(parts)
            
            # STEP 4c: Convert newlines to HTML line breaks
            # Why? HTML collapses whitespace, need <br> for line breaks
            # Normalize: \r\n → \n, \r → \n (Windows/Mac/Unix)
            # Then: \n → <br>
            sanitized = sanitized.replace("\r\n", "\n").replace("\r", "\n").replace("\n", "<br>")
            
            # STEP 4d: Wrap in HTML document structure
            # Why font-family? Consistent rendering across email clients
            # Segoe UI: Modern Windows font
            # Arial, sans-serif: Fallbacks for other platforms
            processed_body = f"<html><body style=\"font-family:Segoe UI,Arial,sans-serif;\">{sanitized}</body></html>"
        # STEP 5: Get Logic App endpoint URL
        # Priority: logic_app_url parameter > environment variable
        # Why allow override? Testing different endpoints, multi-tenant scenarios
        url = logic_app_url or os.getenv(LOGIC_APP_EMAIL_URL_ENV)
        
        if not url:
            # No Logic App URL configured - cannot send email
            # Log error but don't raise exception (graceful degradation)
            emit("[ERROR] Logic App URL not configured (LOGIC_APP_EMAIL_URL env var).")
            if parent_span:
                parent_span.set_attribute("error", "Logic App URL not configured")
        else:
            # STEP 6: Build JSON payload for Logic App
            # Structure expected by Logic App's Office 365 connector:
            # - email_to: Recipient address
            # - email_subject: Subject line (with timestamp)
            # - email_body: HTML or plain text body
            payload = {
                "email_to": to,
                "email_subject": subject_ts,
                "email_body": processed_body,
            }
            
            if html:
                # Add explicit content type hints for Logic App
                # Why explicit? Some Logic Apps need hints for HTML rendering
                # email_body_content_type: MIME type indicator
                # is_html: Boolean flag for conditional logic in workflow
                payload["email_body_content_type"] = "html"
                payload["is_html"] = True
            
            # STEP 7: Process attachments (if any)
            attachment_entries: List[dict] = []
            if attachments:
                emit(f"[DEBUG] Processing {len(attachments)} attachment(s): {attachments}")
                
                for path in attachments:
                    emit(f"[DEBUG] Processing attachment: {path} (type: {type(path)})")
                    try:
                        # STEP 7a: Validate attachment path
                        # Why check type? Prevents errors from non-string inputs
                        if not isinstance(path, str):
                            emit(f"[ERROR] Attachment path is not a string: {type(path)} - {path}")
                            continue
                            
                        # Check file existence before reading
                        # Why check? Provides clear error instead of file not found exception
                        if not os.path.exists(path):
                            emit(f"[ERROR] Attachment file does not exist: {path}")
                            continue
                            
                        # Get file size for logging and validation
                        # Why log size? Helps debug attachment issues, track email size
                        file_size = os.path.getsize(path)
                        emit(f"[DEBUG] Attachment file size: {file_size:,} bytes")
                        
                        # STEP 7b: Read file and encode as Base64
                        # 'rb' mode: Read binary (required for non-text files)
                        # Why binary? Images, PDFs, audio files are binary data
                        with open(path, 'rb') as f:  # noqa: PTH123
                            file_content = f.read()
                            
                            # Base64 encode binary data to ASCII string
                            # Why Base64? JSON cannot contain binary data
                            # Office 365 connector expects Base64-encoded ContentBytes
                            b64_content = base64.b64encode(file_content).decode('utf-8')
                            
                        filename = os.path.basename(path)
                        
                        # Format attachment for Office 365 connector via Logic App
                        # Office 365 expects: Name and ContentBytes fields
                        attachment_entry = {
                            "Name": filename,  # Office 365 standard field
                            "ContentBytes": b64_content,  # Office 365 standard field  
                            "ContentType": "audio/mpeg" if filename.lower().endswith('.mp3') else "application/octet-stream",
                            # Legacy fields for backward compatibility
                            "filename": filename,
                            "content_base64": b64_content,
                            "size": file_size
                        }
                        attachment_entries.append(attachment_entry)
                        emit(f"[SUCCESS] Prepared attachment: {filename} ({file_size:,} bytes -> {len(b64_content):,} base64 chars)")
                        
                    except Exception as exc:  # pragma: no cover - env specific
                        emit(f"[ERROR] Failed to attach '{path}': {exc}")
                        
                if attachment_entries:
                    # Send attachments in the format expected by Logic App -> Office 365
                    payload["attachments"] = attachment_entries
                    
                    emit(f"[INFO] Added {len(attachment_entries)} attachment(s) to payload.")
                    # Log attachment details (without the base64 content)
                    for i, att in enumerate(attachment_entries):
                        emit(f"[DEBUG] Attachment {i+1}: {att['Name']} ({len(att['ContentBytes'])} base64 chars)")
                    emit("[DEBUG] Attachments formatted for Office 365 connector (Name, ContentBytes, ContentType)")
                else:
                    emit(f"[WARN] No valid attachments processed from {len(attachments) if attachments else 0} provided paths.")
            else:
                emit("[INFO] No attachments specified.")
            # Log payload structure (without sensitive content)
            payload_info = {
                "email_to": payload.get("email_to"),
                "email_subject": payload.get("email_subject"),
                "body_length": len(payload.get("email_body", "")),
                "has_attachments": "attachments" in payload,
                "attachment_count": len(payload.get("attachments", [])),
            }
            if "attachments" in payload and payload["attachments"]:
                # Log attachment structure details
                sample_att = payload["attachments"][0]
                payload_info["attachment_fields"] = list(sample_att.keys())
                payload_info["uses_office365_format"] = all(field in sample_att for field in ["Name", "ContentBytes"])
            emit(f"[DEBUG] Payload info: {payload_info}")
            
            try:
                response = requests.post(url, json=payload, timeout=30)
                emit(f"[DEBUG] Logic App response status: {response.status_code}")
                
                if parent_span:
                    parent_span.set_attribute("http.status_code", response.status_code)
                    parent_span.set_attribute("logic_app_url", url)
                
                if response.status_code == 200:
                    emit(f"Email sent to {to} via Logic App.")
                    if parent_span:
                        parent_span.set_attribute("success", True)
                    # Log response details if available
                    try:
                        response_json = response.json()
                        emit(f"[DEBUG] Logic App response: {response_json}")
                    except:
                        emit(f"[DEBUG] Logic App response text: {response.text}")
                        emit(f"[DEBUG] Logic App response headers: {dict(response.headers)}")
                else:
                    emit(
                        f"Failed to send email. Status: {response.status_code}, Response: {response.text}"  # noqa: E501
                    )
                    if parent_span:
                        parent_span.set_attribute("success", False)
                        parent_span.set_attribute("error_message", response.text)
            except Exception as exc:  # pragma: no cover
                emit(f"Error sending email: {exc}")
                if parent_span:
                    from opentelemetry.trace import Status, StatusCode
                    parent_span.record_exception(exc)
                    parent_span.set_status(Status(StatusCode.ERROR, str(exc)))
                    parent_span.set_attribute("success", False)

        joined_log = emit_util.get_log()

        if save_json:
            import json, pathlib
            try:
                p = pathlib.Path(save_json)
                p.parent.mkdir(parents=True, exist_ok=True)
                json.dump(
                    {"processed_body": processed_body, "output_text": processed_body, "log": joined_log},
                    p.open("w", encoding="utf-8"),
                    ensure_ascii=False,
                    indent=2,
                )
            except Exception as save_exc:  # pragma: no cover
                emit(f"[WARN] Failed to save JSON artefact: {save_exc}")
                joined_log = emit_util.get_log()

        if return_mode == "answer":
            return processed_body
        if return_mode == "both":
            return {"processed_body": processed_body, "output_text": processed_body, "log": joined_log}
        return joined_log
    
    finally:
        # End parent span and detach context
        if token is not None:
            try:
                from opentelemetry import context
                context.detach(token)
            except Exception as detach_err:
                emit(f"[OBSERVABILITY] Warning: Failed to detach context: {detach_err}")
        
        if parent_span:
            parent_span.end()
            emit("[OBSERVABILITY] Parent span 'send_email' ended")


def send_logic_app_email(  # Deprecated wrapper
    to: str,
    subject: str,
    body: str,
    logic_app_url: Optional[str] = None,
    attachments: Optional[Sequence[str]] = None,
) -> List[str]:
    """Deprecated: use `send_email`.

    Maintains backwards compatibility returning list[str] log lines.
    """
    import warnings
    warnings.warn(
        "send_logic_app_email is deprecated; use send_email(return_mode='log'|'answer'|'both') instead.",
        DeprecationWarning,
        stacklevel=2,
    )
    log_text = send_email(
        to=to,
        subject=subject,
        body=body,
        attachments=attachments,
        logic_app_url=logic_app_url,
        return_mode="log",
    )
    if isinstance(log_text, str):
        return log_text.splitlines()
    if isinstance(log_text, dict) and "log" in log_text:
        return str(log_text["log"]).splitlines()
    return [str(log_text)]


__all__ = ["send_email", "send_logic_app_email"]
