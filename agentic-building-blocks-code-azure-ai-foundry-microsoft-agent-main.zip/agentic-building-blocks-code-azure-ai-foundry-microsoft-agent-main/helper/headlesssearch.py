"""Headless Search Helper Module - Google Search via googlesearch-python Library.

Purpose:
--------
Provides programmatic web search functionality using the googlesearch-python library.
Returns structured search results with titles, URLs, and descriptions.

This module serves as an alternative search implementation to:
- helper/yahoosearch.py: Yahoo Search via web scraping (requests + BeautifulSoup)
- agent/bingsearch.py: Bing Search via Azure Cognitive Services API

Key Capabilities:
-----------------
1. Google Search Integration: Uses googlesearch-python library (headless, no browser)
2. Advanced Search Mode: Attempts to retrieve rich metadata (title, URL, description)
3. Simple Search Fallback: Falls back to URL-only results if advanced mode fails
4. Emitter Pattern: Consistent logging/UI update integration with other search modules
5. Return Mode Flexibility: Supports 'answer', 'log', 'both' return formats
6. JSON Persistence: Optional save_json parameter for result caching
7. CLI Interface: Standalone testing via command line

Architecture:
-------------
```
User/Agent
    |
    v
perform_web_search()
    |
    +---> Emitter (log to console/Streamlit)
    |
    +---> googlesearch library
    |       |
    |       +---> Advanced mode (title, URL, description)
    |       |
    |       +---> Simple fallback (URL only)
    |
    +---> Format results
    |
    +---> Return based on mode
    |
    +---> Optional JSON save
```

Search Strategy - Two-Tier Approach:
------------------------------------
1. Advanced Search (Preferred):
   - Uses googlesearch.search(advanced=True)
   - Returns rich result objects with:
     * result.title: Page title
     * result.url: Full URL
     * result.description: Snippet/description
   - More informative but may fail due to anti-bot measures

2. Simple Search (Fallback):
   - Uses googlesearch.search(advanced=False)
   - Returns URL strings only
   - Less informative but more reliable
   - Auto-generates titles ("Result 1", "Result 2", etc.)

Why Two Modes?
--------------
Google employs anti-bot measures (CAPTCHAs, rate limiting, IP blocking).
Advanced mode provides rich metadata but is more likely to trigger protection.
Simple mode is more reliable but provides minimal information.
This two-tier approach maximizes success rate while preferring rich data.

Sleep Interval:
---------------
sleep_interval=1 adds 1-second delay between requests to:
- Reduce detection as automated traffic
- Avoid triggering Google's rate limits
- Improve success rate (at cost of speed)

Pattern Consistency with Other Search Modules:
-----------------------------------------------
Mirrors agent/bingsearch.py and helper/yahoosearch.py patterns:
- emit(): Streams log messages to console or UI (Streamlit)
- output_texts: Collects formatted results for UI display (expander)
- return_mode: 'answer' | 'log' | 'both' for flexible return values
- save_json: Optional persistence of results

Comparison Table - Search Module Selection:
--------------------------------------------
| Module           | Method        | Reliability | Rich Metadata | Auth Required | JavaScript Support |
|------------------|---------------|-------------|---------------|---------------|--------------------|
| headlesssearch   | Library API   | Medium      | Yes (adv mode)| No            | No                 |
| yahoosearch      | Web Scraping  | High        | Yes           | No            | No                 |
| bingsearch       | Azure API     | Very High   | Yes           | Yes (API key) | No                 |

Use This Module When:
----------------------
- Need Google search results (not Bing or Yahoo)
- Don't have Azure Cognitive Services subscription
- Don't want to parse HTML manually
- Acceptable if search occasionally fails (anti-bot)
- Prefer library-based approach over manual scraping

Avoid This Module If:
---------------------
- Need guaranteed high reliability (use bingsearch with Azure)
- Need to scrape JavaScript-heavy content (use Selenium)
- Google blocks your IP/region consistently
- Need commercial/production-grade search (use official APIs)

Dependencies:
-------------
- googlesearch-python: Third-party library for Google search
  Install: pip install googlesearch-python
  Why: Abstracts Google search, handles URL parsing
  Limitations: Subject to Google's anti-bot measures

- helper.emitter: Centralized logging/UI update utility
  Why: Consistent log pattern across modules
  Pattern: create_emitter(callback) -> emit(message)

Error Handling:
---------------
- Advanced search failure: Logs warning, tries simple fallback
- Simple search failure: Logs error, returns empty results
- No results: Warns about anti-bot protection
- Network errors: Logged, operation continues where possible
- All errors use emitter for consistent logging

Performance Considerations:
---------------------------
- sleep_interval=1: Adds 1 second per result (mitigate rate limiting)
- Total time: ~num_results seconds (sequential fetching)
- Example: 5 results = ~5 seconds
- Trade-off: Slower but more reliable

Best Practices:
---------------
1. Use sparingly to avoid triggering Google blocks
2. Consider caching results (save_json parameter)
3. For high-volume use, switch to official Google Custom Search API
4. If facing blocks, use VPN or rotate IPs
5. Prefer yahoosearch or bingsearch for production

Security Considerations:
------------------------
- No authentication required (public search)
- No API keys exposed
- IP address may be logged by Google
- Results are untrusted (validate URLs before use)

Example Usage:
--------------
```python
# Basic usage (console output)
from helper.headlesssearch import perform_web_search

results = perform_web_search("Python tutorials")
print(results)

# Get structured results
result_dict = perform_web_search(
    "machine learning",
    num_results=10,
    return_mode="both"
)
if result_dict['success']:
    print(result_dict['output_text'])
    print(f"Log: {result_dict['log']}")

# With Streamlit UI updates
from helper.emitter import create_emitter
emitter = create_emitter(lambda msg: st.write(msg))
results = perform_web_search(
    "web scraping",
    emitter=emitter.emit,
    return_mode="answer"
)

# Save results to JSON for caching
perform_web_search(
    "Claude AI",
    save_json="search_cache/results.json"
)

# CLI usage
$ python helper/headlesssearch.py "Python tutorials" 10
```

Limitations:
------------
- Subject to Google's anti-bot measures (CAPTCHAs, blocks)
- No control over search parameters (region, language, date)
- Advanced mode may fail unpredictably
- Not suitable for high-volume production use
- Results quality depends on Google's algorithms

Related Modules:
----------------
- agent/bingsearch.py: Bing Search via Azure API (more reliable)
- helper/yahoosearch.py: Yahoo Search via web scraping
- helper/fetchurl.py: URL content extraction after search
"""

import json
import os
import sys
from typing import List, Dict, Tuple, Any, Callable
from googlesearch import search  # Third-party library: googlesearch-python

if __name__ == "__main__":  # pragma: no cover - path adjustment logic
    # Path adjustment for CLI usage
    # Why: When run as script, need to import from parent directory
    # os.path.dirname(__file__): Get directory of this file (helper/)
    # os.pardir: Parent directory marker (..)
    # Result: Add repo root to sys.path for imports
    repo_root = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
    if repo_root not in sys.path:
        sys.path.insert(0, repo_root)

from helper.emitter import create_emitter

# Default configuration
DEFAULT_NUM_RESULTS = 5  # Reasonable default to avoid triggering rate limits
DEFAULT_QUERY = "Python programming tutorials"  # Fallback query for CLI testing

def perform_web_search(
    query: str,
    num_results: int = DEFAULT_NUM_RESULTS,
    emitter: Callable[[str], None] | None = None,
    return_mode: str = "both",  # 'answer' | 'log' | 'both'
    save_json: str | os.PathLike | None = None,
):
    """Perform a web search using Google search via googlesearch-python library.
    
    Executes web search using googlesearch-python library with two-tier approach:
    1. Advanced mode (rich metadata: title, URL, description)
    2. Simple fallback (URL only if advanced fails)
    
    Pattern mirrors agent/bingsearch.py and helper/yahoosearch.py for consistency:
    - emit(): Pushes application log lines (console / Streamlit log area)
    - output_texts: Collects formatted search results suitable for UI expander
    - return_mode: Flexible return format
    - save_json: Optional persistence
    
    Execution Flow:
    ---------------
    1. Initialize emitter and output collection
    2. Try advanced search (title, URL, description)
    3. If advanced fails, fallback to simple search (URL only)
    4. Extract and structure results
    5. Format results for output
    6. Return based on return_mode
    7. Optional JSON save
    
    Args:
        query (str): The search query string
                     Example: "Python programming tutorials"
                     Passed directly to Google search
        
        num_results (int): Number of search results to return (default: 5)
                           Actual results may be fewer if Google blocks request
                           Caution: Large values may trigger anti-bot measures
        
        emitter: Optional callback(line: str) for streaming logs
                 Signature: (str) -> None
                 If None, prints to console
                 Used for UI updates (e.g., Streamlit)
        
        return_mode: Controls return value format:
            'answer' -> formatted results text (fallback to log if none)
                       Use when: Only need search results
            'log'    -> full log text only
                       Use when: Need diagnostic information
            'both'   -> dict { 'answers': [...], 'output_text': str, 'log': str, 'success': bool }
                       Use when: Need both results and diagnostics
        
        save_json: Optional path to persist results as JSON
                   Example: "search_results.json"
                   Directory created automatically if doesn't exist
                   Saves: answers, output_text, log, success
    
    Returns:
        str | dict depending on return_mode:
        
        'answer' mode:
            str: Formatted search results (or log if no results)
        
        'log' mode:
            str: Complete diagnostic log
        
        'both' mode:
            dict: {
                'answers': List[str],      # List of formatted result strings
                'output_text': str,        # Joined answers (or log if none)
                'log': str,                # Complete diagnostic log
                'success': bool            # True if results found
            }
    
    Search Implementation Details:
    ------------------------------
    Uses googlesearch-python library with two modes:
    
    Advanced Mode (Preferred):
    - googlesearch.search(query, advanced=True, sleep_interval=1)
    - Returns rich result objects with attributes:
      * result.title: Page title from HTML <title> tag
      * result.url: Full URL string
      * result.description: Meta description or snippet
    - More informative but prone to anti-bot blocks
    
    Simple Mode (Fallback):
    - googlesearch.search(query, advanced=False, sleep_interval=1)
    - Returns URL strings only (no metadata)
    - Less informative but more reliable
    - Generates placeholder titles: "Result 1", "Result 2", etc.
    
    Sleep Interval:
    - sleep_interval=1: 1-second delay between requests
    - Why: Reduces detection as automated traffic
    - Trade-off: Slower execution but higher success rate
    
    Example Results Structure:
    --------------------------
    Advanced Mode:
    ```python
    [
        {
            "title": "Python Tutorial - Official Documentation",
            "url": "https://docs.python.org/3/tutorial/",
            "description": "This tutorial introduces the reader informally to..."
        }
    ]
    ```
    
    Simple Mode (Fallback):
    ```python
    [
        {
            "title": "Result 1",
            "url": "https://docs.python.org/3/tutorial/",
            "description": "No description available (simple search)"
        }
    ]
    ```
    
    Example Output Text:
    --------------------
    ```
    Search Results for: 'Python tutorials'
    Found: 3 results
    
    1. Python Tutorial - Official Documentation
       URL: https://docs.python.org/3/tutorial/
       Description: This tutorial introduces the reader informally to...
    
    2. Learn Python - W3Schools
       URL: https://www.w3schools.com/python/
       Description: Well organized and easy to understand...
    ```
    
    Error Handling:
    ---------------
    - Advanced search failure: Logged as warning, tries simple fallback
    - Simple search failure: Logged as error, returns empty results
    - No results: Warning about anti-bot protection
    - Network errors: Logged, operation continues where possible
    - Unexpected exceptions: Error logged, success=False
    
    All errors logged via emitter, operation continues where possible.
    
    Anti-Bot Protection:
    --------------------
    Google may block requests due to:
    - High request frequency (rate limiting)
    - Automated access detection
    - IP reputation (VPN, datacenter IPs)
    - Regional restrictions
    
    Mitigation:
    - sleep_interval=1 reduces rate
    - Advanced->Simple fallback increases success
    - Consider using VPN or proxy if consistently blocked
    
    Example Usage:
    --------------
    ```python
    # Simple usage
    results = perform_web_search("Python tutorials")
    print(results)
    
    # Get structured results
    result_dict = perform_web_search(
        "machine learning",
        num_results=10,
        return_mode="both"
    )
    if result_dict['success']:
        print(result_dict['output_text'])
    else:
        print("Search failed:", result_dict['log'])
    
    # With UI updates
    from helper.emitter import create_emitter
    emitter = create_emitter(lambda msg: st.write(msg))
    results = perform_web_search(
        "web scraping",
        emitter=emitter.emit
    )
    
    # Save to file for caching
    perform_web_search(
        "Claude AI",
        save_json="cache/search_results.json"
    )
    ```
    
    Performance:
    ------------
    - sleep_interval: 1 second per result
    - Total time: ~num_results seconds (sequential)
    - Example: 5 results ≈ 5 seconds
    - Network latency adds additional time
    
    Limitations:
    ------------
    - Subject to Google anti-bot measures (may fail unpredictably)
    - No control over search parameters (region, language, date filters)
    - Advanced mode unreliable (depends on Google's response format)
    - Not suitable for high-volume production use
    - Results quality depends on Google's ranking algorithms
    
    Production Alternatives:
    ------------------------
    For reliable production use, consider:
    - Google Custom Search API (official, paid)
    - Bing Search API via Azure (agent/bingsearch.py)
    - Yahoo Search scraping (helper/yahoosearch.py)
    
    Note:
        The googlesearch-python library may return 0 results due to Google's anti-bot measures.
        For production use, consider using official Google Search APIs or other search providers.
        This module is best for prototyping and low-volume testing.
    """
    # Track formatted output and success status
    output_texts: list[str] = []  # captured formatted results
    success = False  # Track operation success
    
    # STEP 1: Initialize emitter for progress logging
    # create_emitter wraps callback or creates console emitter
    emit_util = create_emitter(emitter)
    emit = emit_util.emit
    
    emit(f"[INFO] Performing web search for: '{query}'")
    emit(f"[INFO] Requesting {num_results} results")
    
    try:
        # Initialize results list
        results = []
        
        # STEP 2: Try advanced search first (rich metadata)
        try:
            emit("[INFO] Attempting advanced search...")
            
            # Advanced mode: Returns rich result objects
            # advanced=True: Request title, URL, description
            # sleep_interval=1: 1-second delay between requests (anti-bot mitigation)
            # Why advanced? Provides better user experience with rich metadata
            search_results = search(query, num_results=num_results, advanced=True, sleep_interval=1)
            
            # STEP 3: Extract metadata from advanced results
            for result in search_results:
                # Extract title with fallback
                # hasattr check: Ensure attribute exists (library may change)
                # Why check? Advanced mode format may vary by Google response
                title = result.title if hasattr(result, 'title') and result.title else "No title"
                
                # Extract URL with fallback
                # str(result): Convert object to string if url attribute missing
                url = result.url if hasattr(result, 'url') and result.url else str(result)
                
                # Extract description with fallback
                description = result.description if hasattr(result, 'description') and result.description else "No description available"
                
                results.append({
                    "title": title,
                    "url": url,
                    "description": description
                })
                
        except Exception as advanced_error:
            # Advanced search failed (anti-bot or network error)
            # Log warning but don't fail - try simple fallback
            emit(f"[WARN] Advanced search failed: {advanced_error}")
            emit("[INFO] Trying simple search fallback...")
            
            # STEP 4: Fallback to simple search (URL only)
            try:
                # Simple mode: Returns URL strings only
                # advanced=False: No metadata, just URLs
                # Why fallback? Simple mode more reliable, less likely blocked
                search_results = search(query, num_results=num_results, advanced=False, sleep_interval=1)
                
                # STEP 5: Create results with auto-generated titles
                for i, url in enumerate(search_results):
                    # Generate placeholder title
                    # Why enumerate? Need index for numbering
                    # i+1: Start numbering from 1 (user-friendly)
                    results.append({
                        "title": f"Result {i+1}",
                        "url": str(url),
                        "description": "No description available (simple search)"
                    })
            except Exception as simple_error:
                # Simple search also failed - likely anti-bot block
                emit(f"[ERROR] Simple search also failed: {simple_error}")
        
        # STEP 6: Check if we got any results
        if len(results) == 0:
            # No results from either mode - likely anti-bot protection
            emit("[WARN] No results returned. This may be due to Google's anti-bot protection.")
            emit("[WARN] Consider using official Google Search API, Bing Search API, or other search providers.")
        else:
            # Results found - mark success
            success = True
            emit(f"[INFO] Retrieved {len(results)} results")
            
            # STEP 7: Format results for output
            formatted_results = f"Search Results for: '{query}'\n"
            formatted_results += f"Found: {len(results)} results\n\n"
            
            # Format each result with numbering
            # enumerate(results, 1): Start index from 1 (user-friendly)
            for i, result in enumerate(results, 1):
                formatted_results += f"{i}. {result['title']}\n"
                formatted_results += f"   URL: {result['url']}\n"
                formatted_results += f"   Description: {result['description']}\n\n"
            
            # Add to output collection
            output_texts.append(formatted_results)
            
            # Log as answer output (for UI expander)
            emit("[ANSWER OUTPUT]\n" + formatted_results)
        
    except Exception as e:
        # Unexpected exception (shouldn't normally happen)
        emit(f"[ERROR] Unexpected exception: {e}")
        success = False
    
    # STEP 8: Prepare return payload based on mode
    answers_joined = "\n\n".join(output_texts)
    log_joined = emit_util.get_log()
    
    if return_mode == "both":
        # Comprehensive mode: Return all information
        payload: dict | str = {
            "answers": output_texts,
            "output_text": answers_joined or log_joined,
            "log": log_joined,
            "success": success,
        }
    elif return_mode == "log":
        # Log mode: Return only diagnostic log
        payload = log_joined
    else:  # 'answer'
        # Answer mode: Return formatted results (or log if none)
        payload = answers_joined if answers_joined else log_joined
    
    # STEP 9: Save to JSON if requested
    if save_json:
        import pathlib
        try:
            # Create path object and ensure parent directory exists
            path_obj = pathlib.Path(save_json)
            path_obj.parent.mkdir(parents=True, exist_ok=True)
            
            # Write JSON with pretty formatting
            with path_obj.open('w', encoding='utf-8') as f:
                json.dump(
                    {
                        "answers": output_texts,
                        "output_text": answers_joined,
                        "log": log_joined,
                        "success": success,
                    },
                    f,
                    ensure_ascii=False,  # Preserve Unicode characters
                    indent=2,            # Pretty-print with 2-space indentation
                )
        except Exception as exc:  # pragma: no cover
            # JSON save failed - log warning but don't fail operation
            emit(f"[WARN] Failed to save JSON artefact: {exc}")
            
            # Update log in payload if mode is log or both
            log_joined2 = emit_util.get_log()
            if isinstance(payload, dict):
                payload["log"] = log_joined2
            elif return_mode == "log":
                payload = log_joined2
    
    return payload

if __name__ == "__main__":
    """Command-line interface for Google search testing.
    
    Purpose:
    --------
    Provides direct CLI access for testing Google search functionality.
    Useful for development, debugging, and standalone search operations.
    
    Usage:
    ------
    python headlesssearch.py [query] [num_results]
    
    Arguments:
    ----------
    query: Search query string (optional, default: "Python programming tutorials")
           If contains spaces, wrap in quotes
           Example: "Python web scraping"
    
    num_results: Number of results (optional, default: 5)
                 Must be positive integer
                 Example: 10
                 Caution: Large values may trigger Google anti-bot
    
    Examples:
    ---------
    # Use default query and count
    python headlesssearch.py
    
    # Custom query (5 results)
    python headlesssearch.py "machine learning"
    
    # Custom query and count
    python headlesssearch.py "web scraping" 10
    
    # Single word query
    python headlesssearch.py Python
    
    Output:
    -------
    Prints to console:
    - Formatted search results (title, URL, description)
    - Diagnostic log messages ([INFO], [WARN], [ERROR])
    - Results not saved to JSON in default CLI mode
    
    Error Handling:
    ---------------
    - Advanced search failure: Warns, tries simple fallback
    - Simple search failure: Error logged, returns empty
    - Anti-bot protection: Warning message displayed
    - Network errors: Logged to console
    
    Note:
        All output goes to console (no Streamlit UI dependency).
        Emitter callback is None, so emit() defaults to print().
        May fail due to Google's anti-bot measures (expected behavior).
    """
    # Parse command line arguments
    # sys.argv[0]: script name (headlesssearch.py)
    # sys.argv[1]: query (optional, uses DEFAULT_QUERY if not provided)
    # sys.argv[2]: num_results (optional, uses DEFAULT_NUM_RESULTS if not provided)
    if len(sys.argv) > 1:
        # Query provided via command line
        search_query = sys.argv[1]
        
        # Check for num_results argument
        # int(): Convert string to integer
        # Fallback to DEFAULT_NUM_RESULTS if not provided
        num_results = int(sys.argv[2]) if len(sys.argv) > 2 else DEFAULT_NUM_RESULTS
    else:
        # No arguments provided - use defaults
        # DEFAULT_QUERY: "Python programming tutorials" (defined at top of file)
        # DEFAULT_NUM_RESULTS: 5 (defined at top of file)
        search_query = DEFAULT_QUERY
        num_results = DEFAULT_NUM_RESULTS
    
    # Execute search with console output
    # emitter=None: Uses default console emitter (prints to stdout)
    # All emit() calls will print directly to console
    # No save_json: Results not persisted (CLI mode is for quick testing)
    # Why no save_json? CLI is for interactive testing, not data collection
    perform_web_search(search_query, num_results)
