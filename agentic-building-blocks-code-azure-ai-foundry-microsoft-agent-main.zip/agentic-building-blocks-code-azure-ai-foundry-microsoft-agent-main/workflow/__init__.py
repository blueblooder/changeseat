"""Workflow package for parallel agent execution patterns."""
