"""Configuration management for the Streamlit application.

This module provides centralized configuration for the multi-agent demo application.
It manages:
- Query mode definitions (internal identifiers vs display labels)
- Agent function loading and initialization
- Streamlit page configuration and custom CSS
- Email-related environment variable configuration

Key Design Decisions:
1. Separation of internal mode names from display labels allows:
   - Stable codebase (internal names don't change)
   - User-friendly UI (display labels can include prefixes like [Agent], [Workflow])
   - Easy mapping between the two via _DISPLAY_TO_MODE dictionary

2. Lazy loading via ImportManager ensures:
   - Only required modules are loaded
   - Faster application startup
   - Better error isolation if specific modules fail

3. Static methods for page setup allow:
   - Easy calling without instantiation
   - Consistent page configuration across application lifecycle
"""

import os
import streamlit as st
from apps.imports import ImportManager


class AppConfig:
    """Centralized configuration and state management for the application.
    
    This class serves as the single source of truth for:
    - Available query modes and their display names
    - Agent function loading and access
    - Streamlit page configuration
    - Email configuration from environment variables
    
    Architecture Pattern:
    Uses a combination of class-level constants (for static configuration)
    and instance methods (for dynamic loading) to balance between
    performance and flexibility.
    """
    
    # Internal mode values (unchanged - used throughout codebase)
    # These are the canonical identifiers used in code, state management, and routing
    # Why keep these stable? Changing them would break:
    # - Session state keys
    # - Query handler dispatch tables
    # - Configuration files that reference these modes
    QUERY_MODES = [
        "aiSearch", 
        "BingSearch", 
        "BingSearchSendEmail",
        "YahooSearch",
        "YahooSearchSendEmail",
        "HeadlessSearch",
        "GCPTXTSearch",
        "summariseURL", 
        "summariseURLsendEmailmp3", 
        "agentic_summariseURL",
        "checkEmail", 
        "checkEmailsummarise", 
        "checkEmailsummariseSendEmail",
        "checkEmailsummariseSendEmail_workflow",
        "BlastWebSearch",
        "BlastWebSearchSendEmail",
        "HandoffBidirectional",
        "agenticSumURLsSendEmail"
    ]
    
    # Display labels for GUI (with prefixes for categorization)
    # These are shown in the Streamlit selectbox to help users understand:
    # - [Agent]: Single agent with tool calling
    # - [Agentic]: Multiple connected agents (agent-to-agent communication)
    # - [Workflow]: Orchestrated workflow using agent_framework
    # - [Tool]: Direct tool invocation without agent layer
    # 
    # Why separate display from internal values?
    # 1. User experience: Clear categorization helps users choose the right mode
    # 2. Maintainability: Can change display labels without touching business logic
    # 3. Internationalization-ready: Could swap display labels for different languages
    # 4. Backwards compatibility: Old code/configs use internal names, UI evolves independently
    QUERY_MODES_DISPLAY = [
        "[Agent] AI Search", 
        "[Agent] Bing Search", 
        "[Agent] Bing Search + Send Email",
        "[Agent] Yahoo Search",
        "[Agent] Yahoo Search + Send Email",
        "[Tool] Headless Google Search",
        "[Tool] Google Custom Search",
        "[Agent] Summarise URL", 
        "[Agent] Summarise URL + Send Email + MP3", 
        "[Agentic] Summarise URL (Connected Agents)",
        "[Tool] Check Email", 
        "[Agent] Check Email + Summarise", 
        "[Agent] Check Email + Summarise + Send Email",
        "[Workflow] Check Email + Summarise + Send Email",
        "[Workflow] Blast Web Search",
        "[Workflow] Blast Web Search + Send Email",
        "[Workflow] Multi-Tier Handoff (Bidirectional)",
        "[Workflow] Agentic URL Summary → Email → Send"
    ]
    
    # Mapping from display label to internal mode
    # This dictionary provides O(1) lookup to convert user-selected display text
    # back to the internal mode identifier needed for routing/processing
    # Built using zip() to ensure indices always match between the two lists
    # Why use zip instead of manual dict? Guaranteed consistency and DRY principle
    _DISPLAY_TO_MODE = dict(zip(QUERY_MODES_DISPLAY, QUERY_MODES))
    
    # Email modes that require date range filtering
    # These modes interact with email systems and need temporal filtering
    # Why use set instead of list? O(1) membership testing with 'in' operator
    # Used by query handlers to conditionally show date range UI controls
    EMAIL_MODES = {"checkEmail", "checkEmailsummarise", "checkEmailsummariseSendEmail", "checkEmailsummariseSendEmail_workflow"}
    
    def __init__(self):
        """Initialize configuration and load agent functions.
        
        Initialization Order:
        1. Create ImportManager instance (handles dynamic module loading)
        2. Load agent functions (imports and caches all agent/tool modules)
        
        Why load agent functions in __init__?
        - Eager loading at startup catches import errors early
        - Functions are cached for fast subsequent access
        - ImportManager handles conditional imports (only loads what's needed)
        
        Side Effects:
        - May emit warnings if optional modules are missing
        - Populates ImportManager's internal function cache
        """
        self.import_manager = ImportManager()
        # Load all agent functions eagerly
        # This ensures any import errors are surfaced immediately at startup
        # rather than when user selects a mode (better UX - fail fast)
        self.agent_functions = self.import_manager.load_agent_functions()
    
    @staticmethod
    def display_to_mode(display_label: str) -> str:
        """Convert display label to internal mode value.
        
        Maps user-facing display labels (e.g., "[Agent] AI Search") to
        internal mode identifiers (e.g., "aiSearch") used for routing
        and handler dispatch.
        
        Args:
            display_label: The user-selected label from the UI dropdown
        
        Returns:
            Internal mode string for use in query_handlers and session state.
            If display_label not found in mapping, returns it unchanged
            (defensive programming for edge cases).
        
        Why return display_label as fallback instead of raising exception?
        - Graceful degradation: If mapping is incomplete, system still works
        - Easier debugging: Unmapped value flows through system visibly
        - Forward compatibility: New modes can be added without breaking old code
        """
        return AppConfig._DISPLAY_TO_MODE.get(display_label, display_label)
    
    @staticmethod
    def setup_page():
        """Configure Streamlit page settings and apply custom CSS.
        
        This method must be called BEFORE any Streamlit widgets are rendered.
        Streamlit requirement: st.set_page_config() must be the first Streamlit command.
        
        Configuration Applied:
        1. Page metadata (title, layout)
        2. Custom CSS for text wrapping and overflow handling
        
        Why static method?
        - Called during app initialization before AppConfig instance exists
        - No instance state needed
        - Can be called multiple times safely (Streamlit handles deduplication)
        """
        st.set_page_config(page_title="AI Search & Bing Search Chatbot", layout="wide")
        AppConfig._apply_custom_css()
    
    @staticmethod
    def _apply_custom_css():
        """Apply custom CSS styles for better text wrapping and layout.
        
        Problem Being Solved:
        - Default Streamlit code blocks don't wrap long lines (horizontal scroll)
        - Long text outputs (especially API responses, JSON, traces) break layout
        - Users have to scroll horizontally to see full content (poor UX)
        
        Solution:
        Custom CSS rules force wrapping on:
        1. All code/pre blocks (generic wrapping)
        2. Streamlit's specific code block components
        3. Custom div.wrap-block containers (for manual control)
        4. Root container (prevents page-level horizontal scroll)
        
        CSS Properties Explained:
        - white-space: pre-wrap - Preserves whitespace/newlines but allows wrapping
        - word-break: break-word - Breaks long words at arbitrary points if needed
        - overflow-wrap: anywhere - Most aggressive wrapping (break anywhere)
        - !important flags - Override Streamlit's default styles
        
        Why use unsafe_allow_html=True?
        - Required to inject <style> tags into Streamlit app
        - Safe in this context (we control the CSS content)
        - No user input in the CSS string (no XSS risk)
        """
        st.markdown(
            """
            <style>
            /* Apply wrapping to generic code & pre blocks */
            /* Targets any code/pre elements not caught by more specific rules */
            code, pre {
                white-space: pre-wrap !important; /* preserve newlines but allow wrapping */
                word-break: break-word !important; /* break long words */
                overflow-wrap: anywhere !important; /* allow breaks anywhere if needed */
            }
            /* Streamlit specific code block container */
            /* Targets Streamlit's st.code() rendered output */
            div.stCodeBlock pre, div[data-testid="stCodeBlock"] pre {
                white-space: pre-wrap !important;
            }
            /* Our custom inline <div><code> blocks used below */
            /* For manually wrapped code sections using div class="wrap-block" */
            div.wrap-block > code {
                white-space: pre-wrap !important;
                word-break: break-word !important;
                overflow-wrap: anywhere !important;
                display: block;
            }
            /* Optional: prevent overall app horizontal scroll due to very long tokens */
            /* Last resort: if content is too wide, hide overflow instead of showing scrollbar */
            section.main > div { overflow-x: hidden; }
            </style>
            """,
            unsafe_allow_html=True,
        )
    
    def get_default_question(self, query_mode: str) -> str:
        """Get default question for a given query mode.
        
        Each query mode has a predefined default question that demonstrates
        its capabilities and provides a starting point for users.
        
        Args:
            query_mode: Internal mode identifier (e.g., "aiSearch", "BingSearch")
        
        Returns:
            Default question string appropriate for the mode.
            Returns empty string or generic default if mode not found.
        
        Delegation Pattern:
        This method delegates to ImportManager which maintains the mapping.
        Why delegate instead of storing here?
        - ImportManager already knows about module loading
        - Keeps default questions close to the functions they invoke
        - Allows per-module customization of defaults
        """
        return self.import_manager.get_default_question(query_mode)
    
    def get_function(self, name: str):
        """Get a loaded agent/tool function by name.
        
        Provides access to dynamically loaded agent and tool functions
        without requiring direct imports throughout the codebase.
        
        Args:
            name: Function name to retrieve (e.g., "run_ai_search", "check_email")
        
        Returns:
            Callable function object, or None if function not found/loaded.
        
        Usage Pattern:
        Instead of:
            from agent.aisearch import run_ai_search
            run_ai_search(query)
        
        Use:
            func = config.get_function("run_ai_search")
            if func:
                func(query)
        
        Why this pattern?
        - Centralized function loading (single point of control)
        - Lazy loading (only load what's used)
        - Better error handling (can gracefully handle missing functions)
        - Easier testing (can mock get_function)
        """
        return self.import_manager.get_function(name)
    
    @staticmethod
    def get_email_config():
        """Get email configuration from environment variables.
        
        Loads email-related settings from environment with sensible defaults.
        This configuration is used by email filtering and sending functionality.
        
        Returns:
            Dictionary containing:
            - utc_offset: Hours offset from UTC (default: +8 for Asia/Hong Kong)
            - default_start: Default start datetime for email filtering
            - default_end: Default end datetime for email filtering  
            - default_recipient: Default email address for sending
            - default_sender_filter: Default sender filter (comma-separated email addresses)
        
        Configuration Sources (in order of precedence):
        1. Environment variables (UTC_OFFSET, EMAIL_STARTTIME, etc.)
        2. Hardcoded defaults (used when env vars not set)
        
        Why environment variables instead of config file?
        - Easier deployment (no file edits needed)
        - Better security (credentials not in source code)
        - 12-factor app compliance (config in environment)
        - Container-friendly (easy to override in Docker/K8s)
        
        Default Values Rationale:
        - UTC_OFFSET=8: Hong Kong timezone (common for demo deployments)
        - Date range: Full year 2025 (wide net for testing)
        - Empty recipient: Forces user to specify (prevents accidental sends)
        - Empty sender filter: By default, fetch all emails (no filtering)
        """
        return {
            'utc_offset': int(os.getenv("UTC_OFFSET", "8")),
            'default_start': os.getenv("EMAIL_STARTTIME", "2025-01-01T00:00:00"),
            'default_end': os.getenv("EMAIL_ENDTIME", "2025-12-31T23:59:59"),
            'default_recipient': os.getenv("DEFAULT_EMAIL_RECIPIENT", ""),
            'default_sender_filter': os.getenv("DEFAULT_EMAIL_SENDER_FILTER", "")
        }