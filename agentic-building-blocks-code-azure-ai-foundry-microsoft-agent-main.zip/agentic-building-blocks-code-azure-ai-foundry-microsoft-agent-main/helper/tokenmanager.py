"""Token Management with Persistent Caching and Auto-Refresh

Provides intelligent token lifecycle management with persistent caching, expiry detection,
and automatic refresh. Reduces authentication overhead and improves user experience.

Purpose:
========
1. Token Caching: Persist access tokens to disk to avoid repeated authentication
2. Expiry Detection: Automatically detect and refresh tokens before expiration
3. Grace Period: Refresh tokens early to prevent usage of nearly-expired tokens
4. Thread Safety: Atomic file operations to prevent corruption in concurrent scenarios
5. Emitter Integration: Progress logging for UI updates and debugging

Architecture:
=============
Token Lifecycle:
  Check cache (.sso_token_cache.json)
       ↓
  Valid & not expiring soon? → Return cached token
       ↓
  Expired or missing? → Acquire new token via gettoken
       ↓
  Save to cache (atomic write)
       ↓
  Return new token

Cache File Structure:
```json
{
  "token": "eyJ0eXAi...",               // Access token
  "saved_at_epoch": 1699876543,         // When cached (Unix epoch)
  "expires_on_epoch": 1699880143,       // Token expiration (Unix epoch)
  "grace_seconds": 180                  // Grace period before expiry
}
```

Grace Period Logic:
-------------------
Tokens refreshed GRACE_SECONDS (180s = 3 minutes) before actual expiry.

Example:
- Token expires at: 14:30:00 UTC
- Grace period: 180 seconds
- Token refreshed at: 14:27:00 UTC (3 minutes early)

Why grace period?
- Prevents token expiration during long-running operations
- Accounts for clock skew between client and server
- Provides buffer for network latency

File Locking Strategy:
======================
Atomic Rename Pattern (best-effort thread safety):

1. Write to temporary file: .sso_token_cache.tmp
2. Delete existing cache file (if present)
3. Rename temp file to cache file (atomic on POSIX, best-effort on Windows)

Why this approach?
- Prevents partial writes (corrupted cache)
- Minimizes lock contention
- Works across platforms (Windows requires explicit delete)

Limitations:
- Not fully atomic on Windows (race condition possible)
- Single process recommended (multi-process may have conflicts)
- Errors swallowed to prevent breaking authentication flow

Return Modes:
=============
Flexible return format for different use cases:

1. 'token' mode (simple):
   Returns: "eyJ0eXAi..." (access token string)
   Use case: Caller only needs token

2. 'log' mode (default):
   Returns: "[INFO] Using cached token..." (log string)
   Use case: Caller needs diagnostic information

3. 'both' mode (comprehensive):
   Returns: {"output_text": "...", "token": "...", "log": "..."}
   Use case: Caller needs both token and diagnostics

Environment Integration:
========================
Sets SSO_TOKEN environment variable on success:
- Why? Allows downstream code to access token without passing explicitly
- Pattern: Common in agent workflows
- Example: os.environ['SSO_TOKEN'] = token

Cache File Location:
====================
File: .sso_token_cache.json (current working directory)
- Why current directory? Consistent with .env file pattern
- Why .sso_token_cache? Backward compatible with legacy cache name
- Security: File permissions should restrict access (OS-dependent)

Dependencies:
=============
- helper.gettoken: Token acquisition with device code flow
- helper.emitter: Progress logging pattern
- json, time, pathlib: Standard library utilities

Usage Examples:
===============
Basic usage (returns log only):
```python
from helper.tokenmanager import get_cached_or_new_token

log = get_cached_or_new_token()
print(log)  # "[INFO] Using cached access token."
```

Get token only:
```python
token = get_cached_or_new_token(return_mode="token")
print(f"Token: {token[:20]}...")  # "Token: eyJ0eXAiOiJKV1QiLCJ..."
```

Get both token and log:
```python
result = get_cached_or_new_token(return_mode="both")
print(f"Token: {result['token'][:20]}...")
print(f"Log: {result['log']}")
```

With emitter for UI updates:
```python
from helper.emitter import create_emitter

def ui_callback(msg: str):
    print(f"[UI] {msg}")

emitter = create_emitter(ui_callback)
result = get_cached_or_new_token(emitter=emitter.emit, return_mode="both")
```

Non-interactive mode (fails if device code flow required):
```python
token = get_cached_or_new_token(interactive=False, return_mode="token")
if not token:
    print("Authentication required but non-interactive mode enabled")
```

Error Handling:
===============
Token acquisition failures:
- Returns None (token mode)
- Returns error log (log mode)
- Returns dict with None token (both mode)

Cache corruption:
- Silently ignored, new token acquired
- Error swallowed to prevent breaking auth flow

File write errors:
- Silently ignored, token still returned
- Next call will re-acquire token (performance impact only)

Performance:
============
Cache hit (valid token): <5ms
Cache miss (refresh): ~2-5s (depends on network + device code flow)
Grace period overhead: Negligible (simple timestamp comparison)

Best Practices:
===============
1. Use 'both' mode for comprehensive diagnostics
2. Handle None token gracefully in non-interactive scenarios
3. Set UTC_OFFSET if displaying timestamps to users
4. Secure .sso_token_cache.json file (contains access token)
5. Consider token refresh in long-running applications (>1 hour)

Security Considerations:
========================
1. Cache file contains plaintext access token
2. File permissions should restrict access (chmod 600 on Unix)
3. Token has limited lifetime (typically 1 hour)
4. Token scoped to Microsoft Graph API only
5. Consider clearing cache on application exit
"""
from __future__ import annotations
import os
import json
import time
from pathlib import Path
from typing import Optional, Tuple, Callable, Dict, Any

from helper.gettoken import get_graph_token_with_metadata
from helper.emitter import create_emitter

# Cache file name (same as legacy cache for backward compatibility)
# Stored in current working directory
# Contains: token, saved timestamp, expiry timestamp, grace period
CACHE_FILE = Path('.sso_token_cache.json')

# Grace period: Refresh token this many seconds before actual expiry
# 180 seconds = 3 minutes buffer for:
# - Clock skew between client/server
# - Network latency
# - Long-running operations
GRACE_SECONDS = 180  # refresh 3 minutes before actual expiry


def _return_payload(token: Optional[str], log_joined: str, return_mode: str) -> str | dict:
    """Format return payload based on return_mode.
    
    Helper function to standardize return values across different modes.
    Supports backward compatibility while enabling new use cases.
    
    Args:
        token: Access token (None if acquisition failed)
        log_joined: Complete log string
        return_mode: Output format ('token', 'log', 'both')
    
    Returns:
        str | dict: Formatted payload based on mode
        
        'token' mode: "eyJ0eXAi..." (token string or empty string if None)
        'log' mode: "[INFO] Using cached..." (log string)
        'both' mode: {"output_text": "...", "token": "...", "log": "..."}
    
    Why Three Modes?
    ----------------
    1. 'token': Legacy compatibility, simple token retrieval
    2. 'log': Default for diagnostic/debugging workflows
    3. 'both': Comprehensive output for agent patterns
    
    Example:
    --------
    ```python
    # Token mode
    token = _return_payload("abc123", "logs...", "token")
    # Returns: "abc123"
    
    # Log mode
    log = _return_payload("abc123", "logs...", "log")
    # Returns: "logs..."
    
    # Both mode
    result = _return_payload("abc123", "logs...", "both")
    # Returns: {"output_text": "abc123", "token": "abc123", "log": "logs..."}
    ```
    """
    if return_mode == "both":
        # Comprehensive mode: Return all information
        # output_text: Token for agent pattern consistency
        # token: Explicit token field for clarity
        # log: Complete diagnostic log
        return {"output_text": token or "", "token": token, "log": log_joined}
    elif return_mode == "token":
        # Simple mode: Return only token
        # Empty string if None (for compatibility with string operations)
        return token or ""
    else:  # 'log'
        # Default mode: Return only log
        # Useful for debugging and diagnostic workflows
        return log_joined


def _read_cache() -> Optional[Dict[str, Any]]:
    """Read token cache from disk.
    
    Attempts to load and parse the cache file.
    Returns None if file doesn't exist or is corrupted.
    
    Returns:
        Optional[Dict]: Cache data with keys:
            - 'token': Access token string
            - 'saved_at_epoch': When cached (Unix timestamp)
            - 'expires_on_epoch': When token expires (Unix timestamp)
            - 'grace_seconds': Grace period value
        Returns None if cache doesn't exist or is invalid.
    
    Error Handling:
    ---------------
    All exceptions silently caught and return None.
    Why? Cache corruption shouldn't break authentication flow.
    Caller will simply acquire a new token.
    
    Example Cache:
    --------------
    ```json
    {
      "token": "eyJ0eXAiOiJKV1QiLCJhbGc...",
      "saved_at_epoch": 1699876543,
      "expires_on_epoch": 1699880143,
      "grace_seconds": 180
    }
    ```
    """
    # Check if cache file exists
    # Path.exists(): Returns False if file doesn't exist
    if not CACHE_FILE.exists():
        return None
    
    try:
        # Read file contents
        # encoding='utf-8': Handle Unicode characters in JSON
        data = json.loads(CACHE_FILE.read_text(encoding='utf-8'))
        return data
    except Exception:
        # Catch all exceptions:
        # - JSONDecodeError: Invalid JSON format
        # - PermissionError: Insufficient file permissions
        # - IOError: File read failure
        # Return None to trigger new token acquisition
        return None


def _write_cache(payload: Dict[str, Any]) -> None:
    """Write token cache to disk using atomic rename pattern.
    
    Implements atomic-ish file write to prevent corruption:
    1. Write to temporary file (.sso_token_cache.tmp)
    2. Delete existing cache (Windows requirement)
    3. Rename temp to cache (atomic on POSIX)
    
    Args:
        payload: Cache data to write
            Required keys:
            - 'token': Access token
            - 'saved_at_epoch': Current timestamp
            - 'expires_on_epoch': Expiry timestamp
            - 'grace_seconds': Grace period
    
    Thread Safety:
    --------------
    Best-effort atomicity:
    - POSIX: Rename is atomic (cache corruption impossible)
    - Windows: Delete + rename (small race condition window)
    
    Why not proper locking?
    - File locking complex across platforms
    - Single-process typical use case
    - Cache corruption recoverable (new token acquired)
    
    Error Handling:
    ---------------
    All exceptions silently swallowed.
    Why? Write failure shouldn't break authentication.
    Impact: Next call will re-acquire token (performance only).
    
    Example:
    --------
    ```python
    payload = {
        'token': 'eyJ0eXAi...',
        'saved_at_epoch': 1699876543,
        'expires_on_epoch': 1699880143,
        'grace_seconds': 180
    }
    _write_cache(payload)
    # Creates: .sso_token_cache.json
    ```
    """
    try:
        # STEP 1: Write to temporary file
        # with_suffix('.tmp'): Changes extension to .tmp
        # Why temp file? Prevents partial writes from corrupting cache
        tmp = CACHE_FILE.with_suffix('.tmp')
        tmp.write_text(json.dumps(payload), encoding='utf-8')
        
        # STEP 2: Delete existing cache (Windows requirement)
        # Windows: Cannot rename over existing file
        # unlink(): Deletes file
        # Why check exists()? Avoid error on first cache write
        if CACHE_FILE.exists():
            CACHE_FILE.unlink()  # ensure no permissions issues on Windows
        
        # STEP 3: Atomic rename
        # POSIX: Atomic operation (cache corruption impossible)
        # Windows: Non-atomic (small race condition between unlink and rename)
        tmp.rename(CACHE_FILE)
    except Exception:
        # Swallow any write error:
        # - PermissionError: Insufficient file permissions
        # - OSError: Disk full, path invalid
        # Do not break main authentication flow
        # Next call will re-acquire token (performance impact only)
        pass


def _is_valid(data: Dict[str, Any]) -> bool:
    """Check if cached token is still valid (not expired or expiring soon).
    
    Validates token against expiration time with grace period buffer.
    Grace period prevents usage of nearly-expired tokens.
    
    Args:
        data: Cache data dictionary
            Expected keys:
            - 'token': Access token (required)
            - 'expires_on_epoch': Expiry timestamp (required)
    
    Returns:
        bool: True if token valid and not expiring within grace period
              False if token missing, expired, or expiring soon
    
    Validation Logic:
    -----------------
    1. Check token exists (not None or empty)
    2. Check expires_on_epoch exists
    3. Calculate effective expiry: expires_on - GRACE_SECONDS
    4. Compare effective expiry to current time
    5. Return True if effective expiry > now
    
    Grace Period Example:
    ---------------------
    Current time: 14:25:00
    Token expires: 14:30:00
    Grace period: 180s (3 minutes)
    Effective expiry: 14:27:00 (expires_on - grace)
    Is valid? 14:27:00 > 14:25:00 = True
    
    At 14:27:01:
    Is valid? 14:27:00 > 14:27:01 = False (triggers refresh)
    
    Why Grace Period?
    -----------------
    - Prevents token expiration during long operations
    - Accounts for clock skew between client/server
    - Provides buffer for network latency
    - 3 minutes typical for most scenarios
    
    Example:
    --------
    ```python
    # Valid token
    data = {
        'token': 'eyJ0eXAi...',
        'expires_on_epoch': int(time.time()) + 600  # Expires in 10 minutes
    }
    _is_valid(data)  # True (600s > 180s grace)
    
    # Expiring soon
    data = {
        'token': 'eyJ0eXAi...',
        'expires_on_epoch': int(time.time()) + 60  # Expires in 1 minute
    }
    _is_valid(data)  # False (60s < 180s grace)
    
    # Missing token
    data = {'expires_on_epoch': int(time.time()) + 600}
    _is_valid(data)  # False (no token)
    ```
    """
    # Extract token and expiry from cache data
    token = data.get('token')
    expires_on = data.get('expires_on_epoch')
    
    # Validate presence of required fields
    if not token or not expires_on:
        # Token or expiry missing - cache invalid
        return False
    
    # Get current time (Unix timestamp)
    now = int(time.time())
    
    # Calculate effective expiry with grace period
    # expires_on - GRACE_SECONDS: Token considered expired 3 minutes early
    # Example: If expires at 14:30:00, considered expired at 14:27:00
    # 
    # Why subtract grace? Ensures token has sufficient remaining lifetime
    # for downstream operations
    effective_expiry = expires_on - GRACE_SECONDS
    
    # Check if token still valid
    # effective_expiry > now: Token has at least GRACE_SECONDS remaining
    return effective_expiry > now


def get_cached_or_new_token(
    interactive: bool = True,
    emitter: Optional[Callable[[str], None]] = None,
    return_mode: str = "log",  # 'token' | 'log' | 'both'
    realtime_callback: Optional[Callable[[str], None]] = None  # deprecated, use emitter
) -> str | dict:
    """Returns a valid access token, refreshing if necessary.

    Intelligent token management with caching and automatic refresh.
    Checks cache first, acquires new token if expired or missing.
    
    Pattern aligned with other agent modules for consistency:
    - Application / diagnostic lines are emitted via `emitter` (if provided) and collected in the log.
    - Final token is captured separately as `output_text` (the access token).
    - `return_mode` controls returned data format.
    
    Execution Flow:
    ---------------
    1. Initialize emitter for logging
    2. Check cache (.sso_token_cache.json)
    3. If valid token found → Return cached token
    4. If expired/missing → Acquire new token via gettoken
    5. Save new token to cache
    6. Set SSO_TOKEN environment variable
    7. Return token/log based on mode
    
    Parameters:
    -----------
    interactive : bool, default=True
        Allow interactive authentication if needed.
        True: Device code flow shown to user (browser authentication)
        False: Fail if interactive auth required (automated scenarios)
        
        Example use cases:
        - True: CLI tools, user-facing apps
        - False: Background services, automated testing
    
    emitter : Callable[[str], None], optional
        Optional callback for incremental UI updates.
        Signature: (str) -> None
        Called for each progress message.
        
        Example:
        ```python
        def ui_callback(msg: str):
            print(f"[UI] {msg}")
        get_cached_or_new_token(emitter=ui_callback)
        ```
    
    return_mode : str, default="log"
        Controls return payload format:
        
        'token': Returns access token string (or empty string if failed)
                 Use when: Only need token, ignore diagnostics
                 Example: "eyJ0eXAiOiJKV1Qi..."
        
        'log':   Returns complete log string (default)
                 Use when: Need diagnostic information
                 Example: "[INFO] Using cached token..."
        
        'both':  Returns dict with token and log
                 Use when: Need both token and diagnostics
                 Example: {"output_text": "...", "token": "...", "log": "..."}
    
    realtime_callback : Callable[[str], None], optional
        Deprecated: Use `emitter` instead.
        Maintained for backward compatibility.
        If emitter not provided, uses realtime_callback.
    
    Returns:
    --------
    str | dict: Based on return_mode parameter
        
        'token' mode:
            str: Access token (empty string if failed)
        
        'log' mode:
            str: Complete diagnostic log
        
        'both' mode:
            dict: {
                'output_text': str,  # Access token
                'token': str,        # Access token (duplicate for compatibility)
                'log': str           # Complete diagnostic log
            }
    
    Side Effects:
    -------------
    1. Creates/updates .sso_token_cache.json in current directory
    2. Sets os.environ['SSO_TOKEN'] on success
    3. May trigger browser-based authentication (if interactive=True)
    
    Authentication Flow (if cache miss):
    ------------------------------------
    1. Calls get_graph_token_with_metadata()
    2. Device code flow initiated (if interactive)
    3. User completes browser authentication
    4. AAD returns access token + expiry
    5. Token saved to cache
    6. Token returned to caller
    
    Cache Strategy:
    ---------------
    1. Check cache validity:
       - Token exists?
       - Not expired?
       - Not within grace period (180s)?
    
    2. If valid: Return cached token (fast path)
    
    3. If invalid: Acquire new token (slow path)
       - Call get_graph_token_with_metadata()
       - Save to cache
       - Return new token
    
    Error Handling:
    ---------------
    Token acquisition failures:
    - Returns None/empty string (token mode)
    - Returns error log (log mode)
    - Returns dict with None token (both mode)
    - SSO_TOKEN environment variable not set
    
    Cache read failures:
    - Silently ignored, new token acquired
    
    Cache write failures:
    - Silently ignored, token still returned
    - Next call will re-acquire token
    
    Example Usage:
    --------------
    ```python
    # Simple: Get token only
    token = get_cached_or_new_token(return_mode="token")
    if token:
        print(f"Token: {token[:20]}...")
    
    # Diagnostic: Get log only
    log = get_cached_or_new_token(return_mode="log")
    print(log)
    
    # Comprehensive: Get both
    result = get_cached_or_new_token(return_mode="both")
    print(f"Token: {result['token'][:20]}...")
    print(f"Log: {result['log']}")
    
    # With UI updates
    from helper.emitter import create_emitter
    emitter = create_emitter(lambda msg: print(f"[UI] {msg}"))
    result = get_cached_or_new_token(emitter=emitter.emit, return_mode="both")
    
    # Non-interactive (background service)
    token = get_cached_or_new_token(interactive=False, return_mode="token")
    if not token:
        print("Cached token expired, manual auth required")
    ```
    
    Performance:
    ------------
    Cache hit (valid token): <5ms
    Cache miss (refresh): ~2-5s (network + device code flow)
    
    Typical scenarios:
    - First call: 2-5s (acquire token)
    - Subsequent calls: <5ms (cached)
    - After expiry: 2-5s (refresh)
    
    Security Considerations:
    ------------------------
    1. Token stored in plaintext on disk
    2. File permissions should restrict access (OS-dependent)
    3. Token lifetime typically 1 hour (AAD policy)
    4. Token scoped to Microsoft Graph API only
    5. Consider clearing cache on application exit
    """
    # Track final token result
    # None if acquisition fails
    token_result: Optional[str] = None  # captured access token

    # STEP 1: Initialize emitter for progress logging
    # create_emitter wraps callback or creates console emitter
    emit_util = create_emitter(emitter)
    emit = emit_util.emit
    
    # Backward compatibility: Use realtime_callback if emitter not provided
    # realtime_callback deprecated but maintained for legacy code
    if not emitter and realtime_callback:
        emit_util = create_emitter(realtime_callback)

    # STEP 2: Try to load token from cache
    cached = _read_cache()
    
    # STEP 3: Check if cached token is valid
    if cached and _is_valid(cached):
        # Cache hit: Token valid and not expiring soon
        emit('[INFO] Using cached access token.')
        
        # Extract token from cache
        token = cached['token']
        token_result = token
        
        # Set environment variable for downstream code
        # Why? Allows implicit token access in workflows
        os.environ['SSO_TOKEN'] = token
        
        # Return cached token (fast path)
        log_joined = emit_util.get_log()
        return _return_payload(token_result, log_joined, return_mode)
    
    # STEP 4: Cache miss - determine why
    if cached:
        # Token exists but expired or expiring soon
        emit('[INFO] Cached token expired or invalid; acquiring new one.')
    else:
        # No cache file found
        emit('[INFO] No cached token file found; acquiring new one.')

    # STEP 5: Acquire new token via gettoken module
    # Use emitter for real-time callback if available
    # Otherwise fall back to deprecated realtime_callback
    active_callback = emitter or realtime_callback
    
    # Call get_graph_token_with_metadata for token acquisition
    # Returns: (result_dict, log_string)
    # result_dict: {'access_token': '...', 'expires_on': '1699880143'}
    # log_string: Progress messages from acquisition process
    result, acquire_log = get_graph_token_with_metadata(interactive=interactive, realtime_callback=active_callback)
    
    # STEP 6: Merge acquisition log with our log
    # The acquire_log already contains messages emitted by get_graph_token_with_metadata
    # We need to add them to our messages for the final log
    # But avoid duplicates (messages already emitted via callback)
    if acquire_log:
        for line in acquire_log.splitlines():
            # Only add if not already in our messages
            # Why? Avoid duplicate messages if callback already emitted them
            if line not in emit_util.get_messages():
                emit_util.messages.append(line)
    
    # STEP 7: Check if acquisition succeeded
    if not result or 'access_token' not in result:
        # Token acquisition failed
        # Log error and return failure payload
        emit('[ERROR] Failed to acquire new token.')
        log_joined = emit_util.get_log()
        return _return_payload(None, log_joined, return_mode)

    # STEP 8: Extract token and expiry from result
    token = result['access_token']
    token_result = token
    
    # expires_on: Unix timestamp as string (MSAL convention)
    # Example: "1699880143"
    expires_on = result.get('expires_on')
    
    # STEP 9: Parse expiry timestamp
    try:
        # Convert string to int
        expires_epoch = int(expires_on) if expires_on else int(time.time()) + 300
    except Exception:
        # Parsing failed - use 5 minute default expiry
        # Why 5 minutes? Safe default, forces refresh soon
        expires_epoch = int(time.time()) + 300

    # STEP 10: Build cache payload
    payload = {
        'token': token,                        # Access token string
        'saved_at_epoch': int(time.time()),    # When cached (for diagnostics)
        'expires_on_epoch': expires_epoch,     # When token expires
        'grace_seconds': GRACE_SECONDS         # Grace period (for reference)
    }
    
    # STEP 11: Save token to cache
    # Atomic write pattern (best-effort thread safety)
    # Errors silently ignored (token still returned)
    _write_cache(payload)
    
    # STEP 12: Set environment variable
    # Allows downstream code to access token without passing explicitly
    os.environ['SSO_TOKEN'] = token
    
    # STEP 13: Log success and return
    emit('[INFO] Acquired new token and updated cache.')
    log_joined = emit_util.get_log()
    return _return_payload(token_result, log_joined, return_mode)
