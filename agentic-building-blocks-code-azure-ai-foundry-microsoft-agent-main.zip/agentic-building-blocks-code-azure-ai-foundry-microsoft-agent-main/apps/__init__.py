"""Apps package for the Agent SDK application.

This package contains core application components for the Streamlit-based
multi-agent demonstration application. It orchestrates:

1. Configuration Management (config.py):
   - Loads agent configurations from YAML files
   - Validates required environment variables

2. Query Handling (query_handlers.py):
   - Dispatches user queries to appropriate agent/workflow handlers
   - Manages execution flow for different modes (AI Search, Bing, Email, etc.)

3. Session Management (session_manager.py):
   - Manages Streamlit session state for UI consistency
   - Handles mode switching and context clearing

4. UI Management (ui_manager.py):
   - Renders UI components (sidebars, output sections, trace displays)
   - Manages Streamlit-specific rendering logic

5. Utilities:
   - imports.py: Centralized imports for common dependencies
   - time_utils.py: Date/time handling for email filtering and timestamps

Architecture Notes:
- Separation of concerns: Each module has a single responsibility
- Streamlit state management: Session manager prevents state contamination
- Handler pattern: Query handlers use dispatch tables for extensibility
- UI decoupling: UI manager separates presentation from business logic
"""