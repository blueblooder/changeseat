"""Time conversion utilities for the application.

This module handles timezone conversions between local time (user's timezone)
and UTC (used by Microsoft Graph API for email filtering).

Why Timezone Conversion Matters:
- Users think in local time (e.g., "emails from 9am to 5pm today")
- Microsoft Graph API requires UTC timestamps
- Without conversion, time filters would be off by UTC offset hours
- Example: Hong Kong (UTC+8) user wants 9am, Graph needs 1am UTC

Conversion Strategy:
- User inputs → Local time strings (from datetime-local inputs)
- Before API call → Convert local to UTC (local_to_utc)
- After API response → Convert UTC to local for display (utc_to_local)

Edge Cases Handled:
- Invalid datetime strings (graceful fallback)
- Missing 'Z' suffix (add or remove as needed)
- Parsing failures (return input unchanged)

Design Philosophy:
- Simple, focused functions (single responsibility)
- Defensive programming (try/except for robust handling)
- No external dependencies (uses stdlib datetime only)
"""

from datetime import datetime, timedelta


def local_to_utc(local_dtstr: str, offset: int) -> str:
    """Convert local time string to UTC for API calls.
    
    Takes a datetime string in user's local timezone and converts it to UTC
    by subtracting the timezone offset. Used before calling Microsoft Graph API.
    
    Conversion Logic:
    Local Time = UTC + Offset
    Therefore: UTC = Local Time - Offset
    
    Example:
    Hong Kong local time: 2025-11-10T09:00:00 (UTC+8)
    Offset: 8 hours
    UTC time: 2025-11-10T01:00:00Z
    
    Args:
        local_dtstr: Local datetime string in ISO format (YYYY-MM-DDTHH:MM:SS)
                    From Streamlit datetime-local input widget
        offset: UTC offset in hours (positive for ahead of UTC)
               Example: 8 for Hong Kong (UTC+8), -5 for New York (UTC-5)
        
    Returns:
        UTC datetime string with Z suffix (RFC 3339 format)
        Example: "2025-11-10T01:00:00Z"
        
    Error Handling:
    If parsing fails (invalid format, malformed string):
    - Adds Z suffix if missing (assume already UTC)
    - Returns input unchanged if Z already present
    - Why? Better to attempt API call than fail completely
    - Graph API might accept it or return clearer error
    
    Format Notes:
    - Input: No timezone indicator (assumed local)
    - Output: Z suffix (indicates UTC/Zulu time)
    - ISO format used for consistency and API compatibility
    """
    try:
        # Parse local time string to datetime object
        # fromisoformat handles YYYY-MM-DDTHH:MM:SS format
        dt_local = datetime.fromisoformat(local_dtstr)
        
        # Subtract offset to get UTC time
        # timedelta handles hour arithmetic and date rollover
        # Example: 2025-11-10T01:00 - 8 hours = 2025-11-09T17:00
        dt_utc = dt_local - timedelta(hours=offset)
        
        # Format as ISO string with Z suffix
        # Z indicates UTC (Zulu timezone)
        # Microsoft Graph API requires this format
        return dt_utc.strftime("%Y-%m-%dT%H:%M:%SZ")
        
    except Exception:
        # Parsing failed - likely invalid datetime format
        # Fallback: Add Z if missing, otherwise return as-is
        # Why not raise? Graceful degradation better than crash
        # API call might still work or return clearer error
        return local_dtstr + "Z" if not local_dtstr.endswith("Z") else local_dtstr


def utc_to_local(utc_dtstr: str, offset: int) -> str:
    """Convert UTC time string to local time for display.
    
    Takes a UTC datetime string (from API responses) and converts it to
    user's local timezone by adding the offset. Used for displaying email
    timestamps in user-friendly local time.
    
    Conversion Logic:
    Local Time = UTC + Offset
    
    Example:
    UTC time: 2025-11-10T01:00:00Z
    Offset: 8 hours (Hong Kong)
    Local time: 2025-11-10T09:00:00
    
    Args:
        utc_dtstr: UTC datetime string, typically with Z suffix
                  Example: "2025-11-10T01:00:00Z" or "2025-11-10T01:00:00.000Z"
        offset: UTC offset in hours (same as local_to_utc)
        
    Returns:
        Local datetime string WITHOUT timezone indicator
        Example: "2025-11-10T09:00:00"
        
    Why No Timezone Indicator in Output?
    - Cleaner display in UI (less clutter)
    - User knows it's local (configured offset)
    - Streamlit datetime inputs don't accept timezone indicators
    
    Z Suffix Handling:
    Removes Z from input before parsing (fromisoformat doesn't accept Z).
    Python's fromisoformat requires clean ISO format without timezone.
    
    Error Handling:
    On failure, returns input with Z stripped.
    Same graceful degradation philosophy as local_to_utc.
    """
    try:
        # Remove Z suffix if present
        # fromisoformat can't parse Z (needs naive or offset format)
        clean_dtstr = utc_dtstr.rstrip('Z')
        
        # Parse UTC time string to datetime object
        dt_utc = datetime.fromisoformat(clean_dtstr)
        
        # Add offset to get local time
        # timedelta handles hour arithmetic and date rollover
        dt_local = dt_utc + timedelta(hours=offset)
        
        # Format as ISO string WITHOUT timezone indicator
        # Clean format for UI display
        return dt_local.strftime("%Y-%m-%dT%H:%M:%S")
        
    except Exception:
        # Parsing failed - return input with Z removed
        # Better to show something than crash
        return utc_dtstr.rstrip('Z')