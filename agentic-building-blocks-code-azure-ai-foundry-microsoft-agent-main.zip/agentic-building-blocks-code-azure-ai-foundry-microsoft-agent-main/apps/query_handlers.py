"""Query mode handlers for different application modes.

This module implements the handler pattern for dispatching user queries to
appropriate agent/workflow implementations based on the selected mode.

Key Responsibilities:
1. Request Routing: Maps mode strings to handler methods
2. Pre-execution Validation: Checks email recipients, function availability
3. Result Processing: Extracts and formats output, traces, summaries
4. UI Rendering: Creates expanders, displays metrics, shows traces
5. Post-execution Actions: Sends emails, generates MP3s, saves traces

Architecture Patterns:
- Handler Dispatch Table: execute() method uses dictionary mapping for O(1) lookup
- Lambda Wrappers: Allow parameterized handlers while maintaining uniform signature
- Template Method: Each handle_* method follows common structure:
  * Validate prerequisites (email recipient, function availability)
  * Get/use default question if needed
  * Execute agent/workflow function
  * Extract result components (output_text, traces, trace_summary)
  * Display traces in standardized expander with metrics
  * Display output in mode-specific expander
  * Execute post-actions (email, MP3, etc.)

Why This Design?
- Extensibility: New modes added by creating new handler method + dispatch entry
- Maintainability: Each handler isolated, changes don't affect others
- Consistency: Common trace display logic prevents UI fragmentation
- Testability: Handlers can be tested independently with mocked dependencies
- User Experience: Standardized UI across all modes (predictable, learnable)

Critical Considerations:
- Email Validation: All send_email modes MUST validate DEFAULT_EMAIL_RECIPIENT
  early to prevent user frustration (fail fast before expensive operations)
- Trace Display: Handles both agent-based and workflow-based trace formats
  (different span types, different elapsed time calculations)
- Error Handling: Graceful degradation when functions unavailable (partial installs)
- Streamlit State: Expanders created carefully to avoid state contamination between runs
"""

import os
import streamlit as st
from helper.text2speech import convert_text_to_mp3
from apps.config import AppConfig
from apps.time_utils import local_to_utc


class QueryModeHandlers:
    """Centralized handlers for different query modes.
    
    This class orchestrates execution of various agent and workflow modes,
    managing the complete lifecycle from validation through execution to display.
    
    Design Philosophy:
    - Each mode gets its own handler method (handle_*)
    - Common patterns (trace display, email sending) extracted to helpers
    - Dependencies injected via constructor (emitter_util, app_config)
    - No direct imports of agent/workflow modules (all via app_config)
    
    State Management:
    - Stateless: No instance state modified during execution
    - Streamlit state managed separately by session_manager
    - Each handler call is independent (safe for Streamlit reruns)
    
    Dependency Injection:
    - emitter_util: For real-time logging to UI
    - app_config: For accessing loaded functions and configurations
    """
    
    def __init__(self, emitter_util, app_config: AppConfig):
        """Initialize handler with required dependencies.
        
        Args:
            emitter_util: Utility for emitting progress/status messages to UI
                         Provides emit(message) method for real-time feedback
            app_config: Application configuration object providing:
                       - get_function(): Access to dynamically loaded functions
                       - get_default_question(): Mode-specific defaults
                       - get_email_config(): Email settings from environment
        
        Why dependency injection?
        - Testability: Can inject mocks for testing
        - Flexibility: Can swap implementations without code changes
        - Explicit dependencies: Clear what this class needs to function
        """
        self.emitter_util = emitter_util
        self.app_config = app_config
    
    def execute(self, query_mode: str, user_question: str, email_params: dict):
        """Execute the appropriate handler based on query mode.
        
        This is the main entry point for query execution. It dispatches to
        specialized handlers using a dictionary-based routing table.
        
        Dispatch Pattern:
        Uses dictionary lookup instead of if/elif chains for several reasons:
        1. Performance: O(1) lookup vs O(n) chain
        2. Maintainability: Easy to see all modes at a glance
        3. Extensibility: New modes added by inserting dict entry
        4. Testability: Can verify dispatch table completeness
        
        Lambda Wrapper Pattern:
        Many handlers use lambda wrappers to provide additional parameters
        (send_email, analyze, etc.) while maintaining uniform signature.
        
        Why lambda instead of functools.partial?
        - More readable for simple cases
        - Self-contained (no additional imports)
        - Clear parameter binding at point of definition
        
        Args:
            query_mode: Internal mode identifier (e.g., "aiSearch", "BingSearch")
                       Must match keys in QUERY_MODES from config
            user_question: User's input query/prompt text
                          Empty string triggers use of default question
            email_params: Dictionary with email filtering parameters:
                         - start_dt: Start datetime for email filtering (local time)
                         - end_dt: End datetime for email filtering (local time)
                         - max_items: Maximum number of emails to retrieve
                         Only used by checkEmail* modes, ignored by others
        
        Returns:
            None. Results displayed directly via Streamlit UI components.
        
        Side Effects:
            - Displays output in Streamlit expanders
            - May send emails (if send_email=True variants)
            - May generate MP3 files (summariseURLsendEmailmp3)
            - Emits progress messages via emitter_util
            - May save trace files (workflow modes)
        """
        # Dispatch table: Maps mode string to handler function/lambda
        # Each entry either directly references a handler method or wraps it
        # with additional parameters via lambda
        handlers = {
            # Basic search modes - single agent with tool calling
            "aiSearch": self.handle_ai_search,
            
            # Bing search variants - with/without email sending
            # Lambda wrapper passes send_email flag while keeping uniform signature
            "BingSearch": lambda q: self.handle_bing_search(q, send_email=False),
            "BingSearchSendEmail": lambda q: self.handle_bing_search(q, send_email=True),
            
            # Yahoo search variants - alternative search provider
            "YahooSearch": lambda q: self.handle_yahoo_search(q, send_email=False),
            "YahooSearchSendEmail": lambda q: self.handle_yahoo_search(q, send_email=True),
            
            # Tool-based search modes - direct tool invocation without agent layer
            "HeadlessSearch": self.handle_headless_search,  # Selenium-based Google search
            "GCPTXTSearch": self.handle_gcp_txt_search,     # Google Custom Search API
            
            # URL summarization modes
            "summariseURL": self.handle_summarise_url,
            "summariseURLsendEmailmp3": self.handle_summarise_url_email_mp3,  # Includes TTS + email
            
            # Multi-agent (agentic) mode - demonstrates agent-to-agent communication
            "agentic_summariseURL": self.handle_agentic_summarise_url,
            
            # Email checking modes - different levels of processing
            # Lambda wrappers control analyze and send_email flags
            "checkEmail": lambda q: self.handle_check_email(q, email_params, analyze=False, send_email=False),
            "checkEmailsummarise": lambda q: self.handle_check_email(q, email_params, analyze=True, send_email=False),
            "checkEmailsummariseSendEmail": lambda q: self.handle_check_email(q, email_params, analyze=True, send_email=True),
            
            # Workflow-based modes - using agent_framework orchestration
            "checkEmailsummariseSendEmail_workflow": lambda q: self.handle_check_sum_send_email_workflow(q, email_params),
            "BlastWebSearch": lambda q: self.handle_blast_websearch(q, send_email=False),
            "BlastWebSearchSendEmail": lambda q: self.handle_blast_websearch(q, send_email=True),
            "HandoffBidirectional": self.handle_handoff_bidirectional,
            
            # Agentic URL summary to email workflow - connected agents + email composition + send
            "agenticSumURLsSendEmail": lambda q: self.handle_agentic_sum_urls_email(q, send_email=True),
        }
        
        # Lookup and execute the appropriate handler
        # .get() returns None if key not found (safer than dict[key])
        handler = handlers.get(query_mode)
        if handler:
            # Execute the handler with user's question
            # Handler is responsible for all processing and UI updates
            handler(user_question)
        else:
            # This should never happen if UI and config are in sync
            # But defensive programming prevents silent failures
            # If you see this error, likely mismatch between:
            # - AppConfig.QUERY_MODES (valid internal mode names)
            # - handlers dict keys (dispatch table)
            st.error(f"Unknown query mode: {query_mode}")
    
    def handle_ai_search(self, user_question: str):
        """Handle aiSearch mode - Azure AI Search with agent tool calling.
        
        This mode demonstrates a basic agent pattern where the LLM can call
        a search tool to query an Azure AI Search index for relevant documents.
        
        Execution Flow:
        1. Validate function availability (graceful degradation if not loaded)
        2. Use provided question or fall back to mode's default
        3. Execute search via agent (agent decides when/how to use search tool)
        4. Extract results (answer text, traces, trace summary)
        5. Display traces in metrics expander (if available)
        6. Display final output in dedicated expander
        
        Args:
            user_question: User's search query. Empty string triggers default.
        
        Result Structure:
        Agent functions return dict with:
        - output_text: Final answer/result text
        - traces: List of formatted trace strings (for display)
        - trace_summary: Dict with span counts and timing metrics
        
        Trace Display Pattern:
        Uses st.expander for collapsible trace section with:
        - Summary metrics in 3 columns (total spans, operations, timing)
        - Detailed trace lines (text format, preserves structure)
        - Agent-based spans: agent_spans, thread_spans, run_spans, message_spans
        
        Why separate expanders for traces vs output?
        - Traces are diagnostic (for debugging, learning)
        - Output is the end result (what user cares about)
        - Separating allows users to focus on what matters
        - Collapsed by default (doesn't clutter UI)
        """
        # STEP 1: Validate function availability
        # Why check? ImportManager may have failed to load this module
        # Graceful degradation: Show error instead of crashing
        run_azure_ai_search = self.app_config.get_function('run_azure_ai_search')
        if not run_azure_ai_search:
            st.error("AI Search function not available")
            return
        
        # STEP 2: Use provided question or get default for this mode
        # Why allow empty? UI might not have a question yet (first render)
        # Default questions demonstrate each mode's capabilities
        question = user_question if user_question else self.app_config.get_default_question("aiSearch")
        
        # STEP 3: Execute the agent
        # return_mode="both" requests both output_text and traces in result
        # emitter callback provides real-time progress updates to UI
        result = run_azure_ai_search(question, emitter=self.emitter_util.emit, return_mode="both")
        
        # STEP 4: Extract result components with safe defaults
        # Why isinstance checks? Defensive programming against unexpected result types
        # Some older implementations might return plain string instead of dict
        answer_text = result.get("output_text", "") if isinstance(result, dict) else ""
        trace_lines = result.get("traces", []) if isinstance(result, dict) else []
        trace_summary = result.get("trace_summary", {}) if isinstance(result, dict) else {}
        
        # STEP 5: Display OpenTelemetry traces with metrics
        # Only show if traces actually captured (depends on tracing configuration)
        if trace_lines:
            with st.expander("Show OpenTelemetry Traces", expanded=False):
                # Sub-section: Summary metrics at the top
                # Provides quick overview without reading all trace details
                if trace_summary:
                    st.markdown("**Trace Summary:**")
                    # Three-column layout for better visual organization
                    col1, col2, col3 = st.columns(3)
                    
                    with col1:
                        st.metric("Total Spans", trace_summary.get('total_spans', 0))
                        # Different modes have different span types
                        # Agent-based: agent_spans, thread_spans, run_spans, message_spans
                        # Workflow-based: workflow_build_spans, workflow_run_spans, executor_spans
                        # Check which type we have and display accordingly
                        if 'agent_spans' in trace_summary:
                            st.metric("🤖 Agent Operations", trace_summary.get('agent_spans', 0))
                        else:
                            st.metric("Workflow Build", trace_summary.get('workflow_build_spans', 0))
                    
                    with col2:
                        if 'thread_spans' in trace_summary:
                            st.metric("🧵 Thread Operations", trace_summary.get('thread_spans', 0))
                        else:
                            st.metric("Workflow Run", trace_summary.get('workflow_run_spans', 0))
                        if 'run_spans' in trace_summary:
                            st.metric("⚡ Run Operations", trace_summary.get('run_spans', 0))
                        else:
                            st.metric("Executor Process", trace_summary.get('executor_spans', 0))
                    
                    with col3:
                        st.metric("💬 Message Operations", trace_summary.get('message_spans', 0))
                        # Show elapsed time with appropriate units (ms vs seconds)
                        # Agent traces: main_elapsed_ms
                        # Workflow traces: workflow_elapsed_ms
                        elapsed_ms = trace_summary.get('main_elapsed_ms', 0) or trace_summary.get('workflow_elapsed_ms', 0)
                        # Format based on magnitude for readability
                        st.metric("⏱️ Elapsed", f"{elapsed_ms:.0f}ms" if elapsed_ms < 1000 else f"{elapsed_ms/1000:.2f}s")
                    
                    st.divider()
                
                # Sub-section: Detailed trace lines
                # Raw trace output for deep debugging
                st.markdown("**Detailed Traces:**")
                for trace_line in trace_lines:
                    # Use st.text() to preserve formatting (spans, indentation)
                    # st.markdown() would interpret special characters
                    st.text(trace_line)
        
        # STEP 6: Display final output
        # Separate expander keeps result distinct from traces
        with st.expander("Show Output", expanded=False):
            # Use st.markdown with unsafe_allow_html to support rich formatting
            # Why unsafe_allow_html=True? Agent outputs may include <br>, <b>, etc.
            # Note: st.text() would prevent email addresses from being interpreted
            # as HTML tags, but we want to support intentional HTML in output
            st.markdown(answer_text, unsafe_allow_html=True)
    
    def handle_bing_search(self, user_question: str, send_email: bool = False):
        """Handle BingSearch and BingSearchSendEmail modes.
        
        Performs web search using Bing API via agent tool calling, optionally
        sending results via email after successful search.
        
        Key Differences from AI Search:
        - Uses Bing web search API instead of Azure AI Search index
        - Supports optional email sending (controlled by send_email parameter)
        - Validates email recipient BEFORE expensive search operation
        - Only sends email if search succeeds (prevents empty/error emails)
        
        Email Validation Strategy:
        Why validate early instead of just before sending?
        1. Fail fast: Better UX to error immediately vs after waiting for search
        2. Resource efficiency: Don't waste API calls if email will fail anyway  
        3. Clear feedback: User knows to fix config before trying again
        
        Args:
            user_question: User's search query
            send_email: Whether to email results after successful search
                       Set via lambda wrapper in execute() dispatch table
        
        Conditional Email Sending:
        Email only sent if ALL conditions met:
        - send_email=True (mode requested it)
        - search_success=True (Bing API returned results)
        - output_text not empty/error
        
        Why check search_success separately?
        - Search might fail due to API limits, network issues, etc.
        - Don't want to email errors to users
        - Emitter logs explain why email wasn't sent
        """
        # STEP 1: Early validation of email configuration if sending is requested
        # This happens BEFORE the expensive search operation
        # Why? Fail fast principle - no point searching if email will fail
        if send_email:
            email_config = self.app_config.get_email_config()
            recipient_email = email_config.get('default_recipient', '')
            
            # Validate recipient is configured and non-empty
            # Why check .strip()? Environment variables might be set but empty/whitespace
            if not recipient_email or recipient_email.strip() == "":
                error_msg = "[ERROR] DEFAULT_EMAIL_RECIPIENT is not configured. Please set it in .env file before using send email functionality."
                # Show error in both UI and emitter log for visibility
                st.error(error_msg)
                self.emitter_util.emit(error_msg)
                # Early return prevents search execution
                # User must fix configuration and try again
                return
        
        # STEP 2: Validate function availability
        run_bing_search = self.app_config.get_function('run_bing_search')
        if not run_bing_search:
            st.error("Bing Search function not available")
            return
        
        # STEP 3: Get question (provided or default)
        question = user_question if user_question else self.app_config.get_default_question("BingSearch")
        
        # STEP 4: Execute Bing search via agent
        result = run_bing_search(question, emitter=self.emitter_util.emit, return_mode="both")
        
        # STEP 5: Extract result components
        # Note: search_success flag indicates whether API call succeeded
        # Used later to conditionally send email (only on success)
        output_text = result.get("output_text", "") if isinstance(result, dict) else ""
        search_success = result.get("success", False) if isinstance(result, dict) else False
        trace_lines = result.get("traces", []) if isinstance(result, dict) else []
        trace_summary = result.get("trace_summary", {}) if isinstance(result, dict) else {}
        
        # STEP 6: Display traces (same pattern as handle_ai_search)
        # [Trace display code - same structure, not re-commenting for brevity]
        if send_email:
            email_config = self.app_config.get_email_config()
            recipient_email = email_config.get('default_recipient', '')
            if not recipient_email or recipient_email.strip() == "":
                error_msg = "[ERROR] DEFAULT_EMAIL_RECIPIENT is not configured. Please set it in .env file before using send email functionality."
                st.error(error_msg)
                self.emitter_util.emit(error_msg)
                return
        
        run_bing_search = self.app_config.get_function('run_bing_search')
        if not run_bing_search:
            st.error("Bing Search function not available")
            return
        
        question = user_question if user_question else self.app_config.get_default_question("BingSearch")
        
        result = run_bing_search(question, emitter=self.emitter_util.emit, return_mode="both")
        output_text = result.get("output_text", "") if isinstance(result, dict) else ""
        search_success = result.get("success", False) if isinstance(result, dict) else False
        trace_lines = result.get("traces", []) if isinstance(result, dict) else []
        trace_summary = result.get("trace_summary", {}) if isinstance(result, dict) else {}
        
        # Display OpenTelemetry traces in a separate expander with rich formatting
        if trace_lines:
            with st.expander("Show OpenTelemetry Traces", expanded=False):
                # Show summary at the top
                if trace_summary:
                    st.markdown("**Trace Summary:**")
                    col1, col2, col3 = st.columns(3)
                    with col1:
                        st.metric("Total Spans", trace_summary.get('total_spans', 0))
                        st.metric("🤖 Agent Operations", trace_summary.get('agent_spans', 0))
                    with col2:
                        st.metric("🧵 Thread Operations", trace_summary.get('thread_spans', 0))
                        st.metric("⚡ Run Operations", trace_summary.get('run_spans', 0))
                    with col3:
                        st.metric("💬 Message Operations", trace_summary.get('message_spans', 0))
                        elapsed_ms = trace_summary.get('main_elapsed_ms', 0)
                        st.metric("⏱️ Elapsed", f"{elapsed_ms:.0f}ms" if elapsed_ms < 1000 else f"{elapsed_ms/1000:.2f}s")
                    
                    st.divider()
                
                # Show detailed traces
                st.markdown("**Detailed Traces:**")
                for trace_line in trace_lines:
                    st.text(trace_line)
        
        # STEP 7: Display search results
        # Pre-create expander for consistent layout
        # Why pre-create? Ensures expander exists even if content is empty
        # Provides consistent UI structure across all runs
        bing_expander = st.expander("Show Output BingSearch", expanded=False)
        bing_expander_body = bing_expander.empty()
        
        # Display output with HTML support for rich formatting
        # unsafe_allow_html allows agent to format results with HTML
        bing_expander_body.markdown(output_text, unsafe_allow_html=True)
        
        # STEP 8: Conditional email sending
        # Only send if BOTH conditions are true:
        # 1. send_email=True (mode requested it)
        # 2. search_success=True (search API succeeded)
        #
        # Why check both? Three scenarios:
        # A) send_email=False: User selected BingSearch (no email mode)
        # B) send_email=True AND search_success=False: API failed, don't email errors
        # C) send_email=True AND search_success=True: Success! Send email
        if send_email and search_success:
            # Scenario C: Both conditions met, proceed with email
            self._send_bing_email(output_text, question)
        elif send_email and not search_success:
            # Scenario B: Email requested but search failed
            # Inform user why email wasn't sent (troubleshooting aid)
            self.emitter_util.emit("[INFO] Skipping email send due to Bing search failure.")
    
    def handle_yahoo_search(self, user_question: str, send_email: bool = False):
        """Handle YahooSearch and YahooSearchSendEmail modes"""
        # Validate DEFAULT_EMAIL_RECIPIENT if send_email is requested
        if send_email:
            email_config = self.app_config.get_email_config()
            recipient_email = email_config.get('default_recipient', '')
            if not recipient_email or recipient_email.strip() == "":
                error_msg = "[ERROR] DEFAULT_EMAIL_RECIPIENT is not configured. Please set it in .env file before using send email functionality."
                st.error(error_msg)
                self.emitter_util.emit(error_msg)
                return
        
        run_yahoo_search = self.app_config.get_function('run_yahoo_search')
        if not run_yahoo_search:
            st.error("Yahoo Search function not available")
            return
        
        question = user_question if user_question else self.app_config.get_default_question("YahooSearch")
        
        result = run_yahoo_search(question, emitter=self.emitter_util.emit, return_mode="both")
        output_text = result.get("output_text", "") if isinstance(result, dict) else ""
        search_success = result.get("success", False) if isinstance(result, dict) else False
        trace_lines = result.get("traces", []) if isinstance(result, dict) else []
        trace_summary = result.get("trace_summary", {}) if isinstance(result, dict) else {}
        
        # Display OpenTelemetry traces in a separate expander with rich formatting
        if trace_lines:
            with st.expander("Show OpenTelemetry Traces", expanded=False):
                # Show summary at the top
                if trace_summary:
                    st.markdown("**Trace Summary:**")
                    col1, col2, col3 = st.columns(3)
                    with col1:
                        st.metric("Total Spans", trace_summary.get('total_spans', 0))
                        st.metric("🤖 Agent Operations", trace_summary.get('agent_spans', 0))
                    with col2:
                        st.metric("🧵 Thread Operations", trace_summary.get('thread_spans', 0))
                        st.metric("⚡ Run Operations", trace_summary.get('run_spans', 0))
                    with col3:
                        st.metric("💬 Message Operations", trace_summary.get('message_spans', 0))
                        elapsed_ms = trace_summary.get('main_elapsed_ms', 0)
                        st.metric("⏱️ Elapsed", f"{elapsed_ms:.0f}ms" if elapsed_ms < 1000 else f"{elapsed_ms/1000:.2f}s")
                    
                    st.divider()
                
                # Show detailed traces
                st.markdown("**Detailed Traces:**")
                for trace_line in trace_lines:
                    st.text(trace_line)
        
        # Pre-create expander for consistent layout
        yahoo_expander = st.expander("Show Output YahooSearch", expanded=False)
        yahoo_expander_body = yahoo_expander.empty()
        
        # Use st.text() instead of st.markdown() to prevent email addresses 
        # from being interpreted as HTML tags  
        yahoo_expander_body.markdown(output_text, unsafe_allow_html=True)
        
        # Only send email if search was successful and email is requested
        if send_email and search_success:
            self._send_yahoo_email(output_text, question)
        elif send_email and not search_success:
            self.emitter_util.emit("[INFO] Skipping email send due to Yahoo search failure.")
    
    def handle_headless_search(self, user_question: str):
        """Handle HeadlessSearch mode"""
        run_headless_search = self.app_config.get_function('run_headless_search')
        if not run_headless_search:
            st.error("Headless Search function not available")
            return
        
        question = user_question if user_question else self.app_config.get_default_question("HeadlessSearch")
        result = run_headless_search(question, emitter=self.emitter_util.emit, return_mode="both")
        output_text = result.get("output_text", "") if isinstance(result, dict) else ""
        
        with st.expander("Show Output HeadlessSearch", expanded=False):
            # Use st.text() instead of st.markdown() to prevent email addresses 
            # from being interpreted as HTML tags
            st.markdown(output_text, unsafe_allow_html=True)
    
    def handle_gcp_txt_search(self, user_question: str):
        """Handle GCPTXTSearch mode"""
        run_gcp_txt_search = self.app_config.get_function('run_gcp_txt_search')
        if not run_gcp_txt_search:
            st.error("Google Custom Search function not available")
            return
        
        question = user_question if user_question else self.app_config.get_default_question("GCPTXTSearch")
        result = run_gcp_txt_search(question, emitter=self.emitter_util.emit, return_mode="both")
        output_text = result.get("output_text", "") if isinstance(result, dict) else ""
        
        with st.expander("Show Output GCPTXTSearch", expanded=False):
            # Use st.text() instead of st.markdown() to prevent email addresses 
            # from being interpreted as HTML tags
            st.markdown(output_text, unsafe_allow_html=True)
    
    def _send_bing_email(self, content: str, question: str):
        """Helper to send email for Bing search results.
        
        This method orchestrates the email sending workflow:
        1. Generate professional email body from raw search results
        2. Display the formatted email in UI (for transparency)
        3. Parse subject and body from formatted email
        4. Send email via Logic App endpoint
        
        Why separate method instead of inline?
        - Reusability: Yahoo search uses similar logic (_send_yahoo_email)
        - Testability: Can test email logic independently
        - Readability: Main handler stays focused, delegates details
        
        Args:
            content: Raw search results from Bing agent
            question: Original user question (for email context)
        
        Email Generation Pattern:
        Uses EmailWriter agent to convert raw results into polished email.
        This demonstrates agent composition (search agent → email agent → send).
        
        Why use agent for email formatting?
        - Consistency: Professional tone, proper formatting
        - Context: Agent can reference the original question
        - Flexibility: LLM adapts format based on content
        """
        # STEP 1: Get required functions
        # Both must be available for email workflow to proceed
        write_email_body = self.app_config.get_function('write_email_body')
        send_email = self.app_config.get_function('send_email')
        
        if not write_email_body or not send_email:
            st.error("Email functions not available")
            return
        
        # STEP 2: Create UI section for email generation output
        # Shows user what email will look like before sending
        # Transparency: User can verify email content  
        st.divider()  # Visual separation from search results
        email_writer_expander = st.expander("Show Output EmailWriter", expanded=False)
        email_writer_body = email_writer_expander.empty()
        
        # STEP 3: Generate professional email body
        # EmailWriter agent formats raw search results into polished email
        # user_question provides context for email (e.g., "Re: <question>")
        result = write_email_body(content, user_question=question, 
                                emitter=self.emitter_util.emit, return_mode="both")
        output_text = result.get("output_text", "") if isinstance(result, dict) else ""
        
        # STEP 4: Display generated email in UI
        # Allows user to see exactly what will be sent
        # Why markdown with unsafe_allow_html? Email might use HTML formatting
        email_writer_body.markdown(output_text, unsafe_allow_html=True)
        
        st.divider()  # Visual separation before send action
        
        # STEP 5: Parse email format and send
        # EmailWriter uses ##### delimiter: Subject #####Body
        # _parse_email_content extracts components
        subject, body = self._parse_email_content(output_text)
        self._send_email(subject, body)
    
    def _send_yahoo_email(self, content: str, question: str):
        """Helper to send email for Yahoo search results.
        
        Identical logic to _send_bing_email but kept separate for:
        1. Future customization (Yahoo-specific formatting)
        2. Clear logging (different emitter messages)
        3. Independent modification (changes to one don't affect other)
        
        See _send_bing_email for detailed flow explanation.
        
        Args:
            content: Raw search results from Yahoo agent
            question: Original user question (for email context)
        """
        write_email_body = self.app_config.get_function('write_email_body')
        send_email = self.app_config.get_function('send_email')
        
        if not write_email_body or not send_email:
            st.error("Email functions not available")
            return
        
        st.divider()
        email_writer_expander = st.expander("Show Output EmailWriter", expanded=False)
        email_writer_body = email_writer_expander.empty()
        
        result = write_email_body(content, user_question=question, 
                                emitter=self.emitter_util.emit, return_mode="both")
        output_text = result.get("output_text", "") if isinstance(result, dict) else ""
        email_writer_body.markdown(output_text, unsafe_allow_html=True)
        
        st.divider()
        
        subject, body = self._parse_email_content(output_text)
        self._send_email(subject, body)
    
    def _parse_email_content(self, email_body: str) -> tuple:
        """Parse email content to extract subject and body.
        
        EmailWriter agent uses a convention: "Subject #####Body"
        This delimiter allows simple parsing while supporting multi-line content.
        
        Why ##### delimiter instead of JSON or other format?
        - Simple: No escaping needed for special characters
        - Robust: Works with any content (code, URLs, etc.)
        - Human-readable: Easy to debug in UI
        - LLM-friendly: Agent reliably produces this format
        
        Args:
            email_body: Formatted email text from EmailWriter agent
        
        Returns:
            Tuple of (subject, body) strings.
            If delimiter not found, uses generic subject with full text as body.
        
        Fallback Behavior:
        If ##### not found, assumes entire text is body with generic subject.
        Why? Graceful degradation - better to send with generic subject
        than to fail completely.
        """
        if "#####" in email_body:
            # Standard format: Split on delimiter
            # maxsplit=1 ensures only first ##### is used as delimiter
            # (body might contain ##### for other purposes)
            subject_part, body_part = email_body.split("#####", 1)
            # Strip whitespace from both parts for clean presentation
            return subject_part.strip(), body_part.strip()
        else:
            # Fallback: Delimiter not found (old format or error)
            # Use entire text as body with generic subject
            # Why this fallback? Better UX than failing - email still useful
            return "Response to your query", email_body
    
    def _send_email(self, subject: str, body: str, attachments=None):
        """Send email using configured recipient.
        
        Central email sending method used by all modes that send email.
        Handles configuration retrieval and invocation of send_email function.
        
        Args:
            subject: Email subject line
            body: Email body (may contain HTML)
            attachments: Optional list of file paths to attach
                        Used by summariseURLsendEmailmp3 for MP3 files
        
        Configuration:
        Recipient loaded from environment variable (DEFAULT_EMAIL_RECIPIENT).
        This is validated early in handlers, but we re-fetch here for safety.
        
        Tracing Consideration:
        tracing_mode="none" prevents creating new parent span.
        Why? send_email is called within existing trace context,
        we want it to be a child span, not a new root span.
        This maintains proper trace hierarchy for debugging.
        
        Return Value:
        Result ignored by callers - success/failure indicated via emitter logs.
        UI shows email generation and send progress in real-time via emitter.
        """
        send_email = self.app_config.get_function('send_email')
        if not send_email:
            st.error("Send email function not available")
            return
        
        # Get recipient from environment configuration
        # Should always be valid here (validated early in handlers)
        # But defensive programming: get fresh value in case config changed
        email_config = AppConfig.get_email_config()
        default_recipient = email_config['default_recipient']
        
        # Send email via Logic App endpoint
        # tracing_mode="none" important: Don't create new parent span
        # We're inside existing trace context from main handler
        # Want send_email to be child span for proper hierarchy
        result = send_email(
            default_recipient, 
            subject, 
            body, 
            attachments=attachments or [],  # Empty list if None
            emitter=self.emitter_util.emit, 
            return_mode="both",
            tracing_mode="none"  # Don't create new parent span - use existing context
        )
    
    def handle_summarise_url(self, user_question: str):
        """Handle summariseURL mode"""
        run_summarise_url = self.app_config.get_function('run_summarise_url')
        if not run_summarise_url:
            st.error("URL Summarize function not available")
            return
        
        question = user_question if user_question else self.app_config.get_default_question("summariseURL")
        
        result = run_summarise_url(question, emitter=self.emitter_util.emit, return_mode="both")
        output_text = result.get("output_text", "") if isinstance(result, dict) else ""
        trace_lines = result.get("traces", []) if isinstance(result, dict) else []
        trace_summary = result.get("trace_summary", {}) if isinstance(result, dict) else {}
        
        # Display OpenTelemetry traces in a separate expander with rich formatting
        if trace_lines:
            with st.expander("Show OpenTelemetry Traces", expanded=False):
                # Show summary at the top
                if trace_summary:
                    st.markdown("**Trace Summary:**")
                    col1, col2, col3 = st.columns(3)
                    with col1:
                        st.metric("Total Spans", trace_summary.get('total_spans', 0))
                        st.metric("🤖 Agent Operations", trace_summary.get('agent_spans', 0))
                    with col2:
                        st.metric("🧵 Thread Operations", trace_summary.get('thread_spans', 0))
                        st.metric("⚡ Run Operations", trace_summary.get('run_spans', 0))
                    with col3:
                        st.metric("💬 Message Operations", trace_summary.get('message_spans', 0))
                        elapsed_ms = trace_summary.get('main_elapsed_ms', 0)
                        st.metric("⏱️ Elapsed", f"{elapsed_ms:.0f}ms" if elapsed_ms < 1000 else f"{elapsed_ms/1000:.2f}s")
                    
                    st.divider()
                
                # Show detailed traces
                st.markdown("**Detailed Traces:**")
                for trace_line in trace_lines:
                    st.text(trace_line)
        
        with st.expander("Show Output", expanded=False):
            # Use st.text() instead of st.markdown() to prevent email addresses 
            # from being interpreted as HTML tags
            st.html(output_text)
                
    def handle_agentic_summarise_url(self, user_question: str):
        """Handle agentic_summariseURL mode using connected agents architecture"""
        run_summarise_url_agentic = self.app_config.get_function('run_summarise_url_agentic')
        if not run_summarise_url_agentic:
            st.error("Agentic URL Summarize function not available")
            return
        
        question = user_question if user_question else self.app_config.get_default_question("agentic_summariseURL")
        
        result = run_summarise_url_agentic(question, emitter=self.emitter_util.emit, return_mode="both")
        output_text = result.get("output_text", "") if isinstance(result, dict) else ""
        trace_lines = result.get("traces", []) if isinstance(result, dict) else []
        trace_summary = result.get("trace_summary", {}) if isinstance(result, dict) else {}
        
        # Display OpenTelemetry traces in a separate expander with rich formatting
        if trace_lines:
            with st.expander("Show OpenTelemetry Traces", expanded=False):
                # Show summary at the top
                if trace_summary:
                    st.markdown("**Trace Summary:**")
                    col1, col2, col3 = st.columns(3)
                    with col1:
                        st.metric("Total Spans", trace_summary.get('total_spans', 0))
                        st.metric("🤖 Agent Operations", trace_summary.get('agent_spans', 0))
                    with col2:
                        st.metric("🧵 Thread Operations", trace_summary.get('thread_spans', 0))
                        st.metric("⚡ Run Operations", trace_summary.get('run_spans', 0))
                    with col3:
                        st.metric("💬 Message Operations", trace_summary.get('message_spans', 0))
                        elapsed_ms = trace_summary.get('main_elapsed_ms', 0)
                        st.metric("⏱️ Elapsed", f"{elapsed_ms:.0f}ms" if elapsed_ms < 1000 else f"{elapsed_ms/1000:.2f}s")
                    
                    st.divider()
                
                # Show detailed traces
                st.markdown("**Detailed Traces:**")
                for trace_line in trace_lines:
                    st.text(trace_line)
        
        with st.expander("Show Output (Connected Agents)", expanded=False):
            # Use st.text() instead of st.markdown() to prevent email addresses 
            # from being interpreted as HTML tags
            st.markdown(output_text, unsafe_allow_html=True)
    
    def handle_summarise_url_email_mp3(self, user_question: str):
        """Handle summariseURLsendEmailmp3 mode"""
        # Validate DEFAULT_EMAIL_RECIPIENT
        email_config = self.app_config.get_email_config()
        recipient_email = email_config.get('default_recipient', '')
        if not recipient_email or recipient_email.strip() == "":
            error_msg = "[ERROR] DEFAULT_EMAIL_RECIPIENT is not configured. Please set it in .env file before using send email functionality."
            st.error(error_msg)
            self.emitter_util.emit(error_msg)
            return
        
        run_summarise_url = self.app_config.get_function('run_summarise_url')
        if not run_summarise_url:
            self.emitter_util.emit("[ERROR] summariseURL function not available.")
            return
        
        question = user_question if user_question else self.app_config.get_default_question("summariseURLsendEmailmp3")
        
        try:
            # Generate summary
            self.emitter_util.emit("[INFO] Starting URL summarisation...")
            result = run_summarise_url(question, emitter=self.emitter_util.emit, return_mode="both")
            summary_output = result.get("output_text", "") if isinstance(result, dict) else result
            
            self.emitter_util.emit("Summary generation complete.")
            
            # Convert to MP3
            mp3_path = self._convert_to_mp3(summary_output)
            
            # Send email with MP3 attachment
            if mp3_path:
                self._send_email("URL Summary with Audio", summary_output, [mp3_path])
            
            # Show final output
            with st.expander("Show Output", expanded=False):
                # Use st.text() instead of st.markdown() to prevent email addresses 
                # from being interpreted as HTML tags
                st.html(summary_output)
                
        except Exception as exc:
            self.emitter_util.emit(f"[ERROR] summariseURL failed: {exc}")
    
    def _convert_to_mp3(self, text: str) -> str:
        """Convert text to MP3 audio file and return file path.
        
        Uses Azure Text-to-Speech service to generate MP3 from text.
        This enables accessibility (audio version) and multi-modal delivery
        (email with both text and audio).
        
        Error Handling Strategy:
        - Returns None on any failure (graceful degradation)
        - Logs warnings instead of raising exceptions
        - Calling code checks for None and continues without MP3
        
        Why graceful degradation?
        - TTS is enhancement, not critical functionality
        - Better to send email without audio than fail completely
        - User still gets value (text summary) even if TTS fails
        
        Args:
            text: Text content to convert to speech
        
        Returns:
            String path to generated MP3 file, or None if conversion failed.
        
        Common Failure Scenarios:
        - Azure Speech API key not configured
        - Text too long for TTS service limits
        - Network issues calling Azure service
        - Insufficient disk space for MP3 file
        
        Result Format:
        convert_text_to_mp3 returns tuple: (mp3_path, tts_log)
        - mp3_path: Local file path to generated MP3
        - tts_log: Diagnostic log from TTS process
        """
        # STEP 1: Validate input text
        # Skip TTS if text is empty or indicates prior error
        # Why? Don't waste API calls on invalid input
        if not text or text.startswith('[ERROR]'):
            self.emitter_util.emit("[INFO] Skipping TTS due to earlier error.")
            return None
        
        try:
            # STEP 2: Convert text to speech
            self.emitter_util.emit("[INFO] Converting summary to MP3...")
            tts_result = convert_text_to_mp3(text, emitter=self.emitter_util.emit)
            
            # STEP 3: Validate result format
            # Expected: tuple of (mp3_path, tts_log)
            # Why check? Defensive programming against API changes
            if isinstance(tts_result, tuple) and len(tts_result) == 2:
                mp3_path, tts_log = tts_result
                self.emitter_util.emit(f"MP3 generated at: {mp3_path}")
                # Additional type check: ensure path is string
                # Why? tuple unpacking succeeded but value might be None
                return mp3_path if isinstance(mp3_path, str) else None
            else:
                # Unexpected result format
                # Log warning but don't crash - degrade gracefully
                self.emitter_util.emit(f"[WARN] Unexpected TTS result format: {type(tts_result)}")
                return None
                
        except Exception as exc:
            # Catch all TTS exceptions
            # Why broad exception? Many possible failure modes (network, API, etc.)
            # Better to log and continue than crash entire flow
            self.emitter_util.emit(f"[WARN] Text-to-speech failed: {exc}")
            return None
    
    def handle_check_email(self, user_question: str, email_params: dict, analyze: bool = False, send_email: bool = False):
        """Handle checkEmail modes"""
        # Validate DEFAULT_EMAIL_RECIPIENT if send_email is requested
        if send_email:
            email_config = self.app_config.get_email_config()
            recipient_email = email_config.get('default_recipient', '')
            if not recipient_email or recipient_email.strip() == "":
                error_msg = "[ERROR] DEFAULT_EMAIL_RECIPIENT is not configured. Please set it in .env file before using send email functionality."
                st.error(error_msg)
                self.emitter_util.emit(error_msg)
                return
        
        run_check_emails = self.app_config.get_function('run_check_emails')
        if not run_check_emails:
            st.error("Check Email function not available")
            return
        
        # Convert local times to UTC
        email_config = AppConfig.get_email_config()
        utc_offset = email_config['utc_offset']
        
        start_dt = local_to_utc(email_params['start_dt'], utc_offset)
        end_dt = local_to_utc(email_params['end_dt'], utc_offset)
        max_items = email_params['max_items']
        
        # Parse sender filter from comma-separated string to list
        sender_filter_str = email_params.get('sender_filter', '')
        from_addresses = None
        if sender_filter_str and sender_filter_str.strip():
            from_addresses = [s.strip() for s in sender_filter_str.split(',') if s.strip()]
            self.emitter_util.emit(f"[INFO] Filtering emails by {len(from_addresses)} sender(s)")
        
        # Create expander for check email results if sending email
        if send_email:
            email_check_expander = st.expander("Show Output CheckEmail", expanded=False)
            email_check_body = email_check_expander.empty()
        
        try:
            result = run_check_emails(
                start_dt, 
                end_dt, 
                max_items=max_items,
                from_addresses=from_addresses,
                emitter=self.emitter_util.emit,
                store_local=True,
                analyze_with_agent=analyze,
                return_mode="both"
            )
            
            if isinstance(result, dict):
                output_text = result.get("output_text", "")
                trace_lines = result.get("traces", [])
                trace_summary = result.get("trace_summary", {})
            else:
                output_text = result
                trace_lines = []
                trace_summary = {}
            
            # Display OpenTelemetry traces in a separate expander with rich formatting
            if trace_lines:
                with st.expander("Show OpenTelemetry Traces", expanded=False):
                    # Show summary at the top
                    if trace_summary:
                        st.markdown("**Trace Summary:**")
                        col1, col2, col3 = st.columns(3)
                        with col1:
                            st.metric("Total Spans", trace_summary.get('total_spans', 0))
                            st.metric("🤖 Agent Operations", trace_summary.get('agent_spans', 0))
                        with col2:
                            st.metric("🧵 Thread Operations", trace_summary.get('thread_spans', 0))
                            st.metric("⚡ Run Operations", trace_summary.get('run_spans', 0))
                        with col3:
                            st.metric("💬 Message Operations", trace_summary.get('message_spans', 0))
                            elapsed_ms = trace_summary.get('main_elapsed_ms', 0)
                            st.metric("⏱️ Elapsed", f"{elapsed_ms:.0f}ms" if elapsed_ms < 1000 else f"{elapsed_ms/1000:.2f}s")
                        
                        st.divider()
                    
                    # Show detailed traces
                    st.markdown("**Detailed Traces:**")
                    for trace_line in trace_lines:
                        st.text(trace_line)
            
            # Display results
            if send_email:
                # Use st.text() instead of st.markdown() to prevent email addresses 
                # from being interpreted as HTML tags
                email_check_body.html(output_text)
                
                st.divider()
                
                # Send email with analysis results
                if output_text and not output_text.startswith('[ERROR]'):
                    self._send_email("Email Analysis Summary", output_text)
                else:
                    self.emitter_util.emit("[INFO] No valid output to send via email.")
            else:
                # Show in expander for non-email modes
                with st.expander("Show Output CheckEmail", expanded=False):
                    # Use st.text() instead of st.markdown() to prevent email addresses 
                    # from being interpreted as HTML tags
                    st.html(output_text)
                    
        except Exception as e:
            st.error(f"[ERROR] Email check failed: {e}")
    
    def handle_blast_websearch(self, user_question: str, send_email: bool = False):
        """Handle BlastWebSearch and BlastWebSearchSendEmail modes"""
        # Validate DEFAULT_EMAIL_RECIPIENT if send_email is requested
        if send_email:
            email_config = self.app_config.get_email_config()
            recipient_email = email_config.get('default_recipient', '')
            if not recipient_email or recipient_email.strip() == "":
                error_msg = "[ERROR] DEFAULT_EMAIL_RECIPIENT is not configured. Please set it in .env file before using send email functionality."
                st.error(error_msg)
                self.emitter_util.emit(error_msg)
                return
        
        run_blast_websearch = self.app_config.get_function('run_blast_websearch')
        if not run_blast_websearch:
            st.error("Blast Web Search function not available")
            return
        
        question = user_question if user_question else self.app_config.get_default_question("BlastWebSearch")
        
        # Get recipient email if sending email
        email_config = AppConfig.get_email_config() if send_email else {}
        recipient_email = email_config.get('default_recipient') if send_email else None
        
        # Run workflow with email sending integrated
        result = run_blast_websearch(
            question, 
            emitter=self.emitter_util.emit, 
            return_mode="both",
            send_email=send_email,
            recipient_email=recipient_email
        )
        
        output_text = result.get("output_text", "") if isinstance(result, dict) else ""
        trace_lines = result.get("traces", []) if isinstance(result, dict) else []
        trace_summary = result.get("trace_summary", {}) if isinstance(result, dict) else {}
        trace_file = result.get("trace_file") if isinstance(result, dict) else None
        
        # Display saved trace file info
        if trace_file:
            st.success(f"📁 Traces saved to: `{trace_file}`")
        
        # Display OpenTelemetry traces in a separate expander with rich formatting
        if trace_lines:
            with st.expander("Show OpenTelemetry Traces", expanded=False):
                # Show summary at the top
                if trace_summary:
                    st.markdown("**Trace Summary:**")
                    col1, col2, col3 = st.columns(3)
                    with col1:
                        st.metric("Total Spans", trace_summary.get('total_spans', 0))
                        # For agent-based traces, show agent/thread/message spans
                        if 'agent_spans' in trace_summary:
                            st.metric("🤖 Agent Operations", trace_summary.get('agent_spans', 0))
                        else:
                            st.metric("Workflow Build", trace_summary.get('workflow_build_spans', 0))
                    with col2:
                        if 'thread_spans' in trace_summary:
                            st.metric("🧵 Thread Operations", trace_summary.get('thread_spans', 0))
                        else:
                            st.metric("Workflow Run", trace_summary.get('workflow_run_spans', 0))
                        if 'run_spans' in trace_summary:
                            st.metric("⚡ Run Operations", trace_summary.get('run_spans', 0))
                        else:
                            st.metric("Executor Process", trace_summary.get('executor_spans', 0))
                    with col3:
                        st.metric("💬 Message Operations", trace_summary.get('message_spans', 0))
                        # Show elapsed time (works for both agent and workflow)
                        elapsed_ms = trace_summary.get('main_elapsed_ms', 0) or trace_summary.get('workflow_elapsed_ms', 0)
                        st.metric("⏱️ Elapsed", f"{elapsed_ms:.0f}ms" if elapsed_ms < 1000 else f"{elapsed_ms/1000:.2f}s")
                    
                    st.divider()
                
                # Show detailed traces
                st.markdown("**Detailed Traces:**")
                for trace_line in trace_lines:
                    st.text(trace_line)
        
        # Display output in expander (emitter already captured all formatted results in the log display above)
        with st.expander("Show Output BlastWebSearch", expanded=False):
            st.text(output_text)
        
        # Email sending is now handled by the workflow itself
        # No need for _send_blast_email here anymore
    
    def handle_check_sum_send_email_workflow(self, user_question: str, email_params: dict):
        """Handle checkEmailsummariseSendEmail_workflow mode using workflow approach"""
        # Validate DEFAULT_EMAIL_RECIPIENT
        email_config = AppConfig.get_email_config()
        recipient_email = email_config.get('default_recipient', '')
        if not recipient_email or recipient_email.strip() == "":
            error_msg = "[ERROR] DEFAULT_EMAIL_RECIPIENT is not configured. Please set it in .env file before using send email functionality."
            st.error(error_msg)
            self.emitter_util.emit(error_msg)
            return
        
        run_check_sum_send_email = self.app_config.get_function('run_check_sum_send_email')
        if not run_check_sum_send_email:
            st.error("Check Sum Send Email Workflow function not available")
            return
        
        question = user_question if user_question else self.app_config.get_default_question("checkEmailsummariseSendEmail_workflow")
        
        # Convert local times to UTC
        utc_offset = email_config['utc_offset']
        
        start_dt = local_to_utc(email_params['start_dt'], utc_offset)
        end_dt = local_to_utc(email_params['end_dt'], utc_offset)
        max_items = email_params['max_items']
        
        # Parse sender filter from comma-separated string to list
        sender_filter_str = email_params.get('sender_filter', '')
        from_addresses = None
        if sender_filter_str and sender_filter_str.strip():
            from_addresses = [s.strip() for s in sender_filter_str.split(',') if s.strip()]
            self.emitter_util.emit(f"[INFO] Filtering emails by {len(from_addresses)} sender(s)")
        
        # Run workflow with email sending integrated
        result = run_check_sum_send_email(
            start_datetime=start_dt,
            end_datetime=end_dt,
            max_items=max_items,
            from_addresses=from_addresses,
            user_question=question,
            emitter=self.emitter_util.emit,
            return_mode="both",
            recipient_email=recipient_email
        )
        
        output_text = result.get("output_text", "") if isinstance(result, dict) else ""
        trace_lines = result.get("traces", []) if isinstance(result, dict) else []
        trace_summary = result.get("trace_summary", {}) if isinstance(result, dict) else {}
        trace_file = result.get("trace_file") if isinstance(result, dict) else None
        
        # Display saved trace file info
        if trace_file:
            st.success(f"📁 Traces saved to: `{trace_file}`")
        
        # Display OpenTelemetry traces in a separate expander with rich formatting
        if trace_lines:
            with st.expander("Show OpenTelemetry Traces", expanded=False):
                # Show summary at the top
                if trace_summary:
                    st.markdown("**Trace Summary:**")
                    col1, col2, col3 = st.columns(3)
                    with col1:
                        st.metric("Total Spans", trace_summary.get('total_spans', 0))
                        st.metric("Workflow Build", trace_summary.get('workflow_build_spans', 0))
                    with col2:
                        st.metric("Workflow Run", trace_summary.get('workflow_run_spans', 0))
                        st.metric("Executor Process", trace_summary.get('executor_spans', 0))
                    with col3:
                        st.metric("Message Send", trace_summary.get('message_spans', 0))
                        # Show workflow elapsed time (actual wall-clock time)
                        elapsed_ms = trace_summary.get('workflow_elapsed_ms', 0)
                        st.metric("⏱️ Workflow Elapsed", f"{elapsed_ms:.0f}ms" if elapsed_ms < 1000 else f"{elapsed_ms/1000:.2f}s")
                    
                    st.divider()
                
                # Show detailed traces
                st.markdown("**Detailed Traces:**")
                for trace_line in trace_lines:
                    st.text(trace_line)
        
        # Display output in expander
        with st.expander("Show Output CheckSumSendEmail", expanded=False):
            st.html(output_text)
    
    def handle_handoff_bidirectional(self, user_question: str):
        """Handle HandoffBidirectional mode using multi-tier handoff workflow"""
        run_handoff_bidirect = self.app_config.get_function('run_handoff_bidirect')
        if not run_handoff_bidirect:
            st.error("Handoff Bidirectional Workflow function not available")
            return
        
        question = user_question if user_question else self.app_config.get_default_question("HandoffBidirectional")
        
        # Run workflow
        result = run_handoff_bidirect(
            question, 
            emitter=self.emitter_util.emit, 
            return_mode="both"
        )
        
        output_text = result.get("output_text", "") if isinstance(result, dict) else ""
        trace_lines = result.get("traces", []) if isinstance(result, dict) else []
        trace_summary = result.get("trace_summary", {}) if isinstance(result, dict) else {}
        trace_file = result.get("trace_file") if isinstance(result, dict) else None
        
        # Display saved trace file info
        if trace_file:
            st.success(f"📁 Traces saved to: `{trace_file}`")
        
        # Display OpenTelemetry traces in a separate expander with rich formatting
        if trace_lines:
            with st.expander("Show OpenTelemetry Traces", expanded=False):
                # Show summary at the top
                if trace_summary:
                    st.markdown("**Trace Summary:**")
                    col1, col2, col3 = st.columns(3)
                    with col1:
                        st.metric("Total Spans", trace_summary.get('total_spans', 0))
                        st.metric("Workflow Build", trace_summary.get('workflow_build_spans', 0))
                    with col2:
                        st.metric("Workflow Run", trace_summary.get('workflow_run_spans', 0))
                        st.metric("Agent Process", trace_summary.get('agent_spans', trace_summary.get('executor_spans', 0)))
                    with col3:
                        st.metric("Handoff", trace_summary.get('handoff_spans', trace_summary.get('message_spans', 0)))
                        # Show workflow elapsed time (actual wall-clock time)
                        elapsed_ms = trace_summary.get('workflow_elapsed_ms', 0)
                        st.metric("⏱️ Workflow Elapsed", f"{elapsed_ms:.0f}ms" if elapsed_ms < 1000 else f"{elapsed_ms/1000:.2f}s")
                    
                    st.divider()
                
                # Show detailed traces
                st.markdown("**Detailed Traces:**")
                for trace_line in trace_lines:
                    st.text(trace_line)
        
        # Display output in expander
        with st.expander("Show Conversation Output", expanded=False):
            st.text(output_text)
    
    def handle_agentic_sum_urls_email(self, user_question: str, send_email: bool = False):
        """Handle agenticSumURLsSendEmail mode
        
        Sequential workflow combining:
        1. URL Summarization (connected agents: coordinator + url_summarizer)
        2. Email Composition (email writer agent)
        3. Email Sending (via Logic App)
        """
        # Validate DEFAULT_EMAIL_RECIPIENT if send_email is requested
        if send_email:
            email_config = self.app_config.get_email_config()
            recipient_email = email_config.get('default_recipient', '')
            if not recipient_email or recipient_email.strip() == "":
                error_msg = "[ERROR] DEFAULT_EMAIL_RECIPIENT is not configured. Please set it in .env file before using send email functionality."
                st.error(error_msg)
                self.emitter_util.emit(error_msg)
                return
        
        run_agentic_sum_urls_email = self.app_config.get_function('run_agentic_sum_urls_email')
        if not run_agentic_sum_urls_email:
            st.error("Agentic Sum URLs Email Workflow function not available")
            return
        
        question = user_question if user_question else self.app_config.get_default_question("agenticSumURLsSendEmail")
        
        # Get recipient email if sending email
        email_config = AppConfig.get_email_config() if send_email else {}
        recipient_email = email_config.get('default_recipient') if send_email else None
        
        # Run workflow with email sending integrated
        result = run_agentic_sum_urls_email(
            question, 
            emitter=self.emitter_util.emit, 
            return_mode="both",
            recipient_email=recipient_email
        )
        
        output_text = result.get("output_text", "") if isinstance(result, dict) else ""
        trace_lines = result.get("traces", []) if isinstance(result, dict) else []
        trace_summary = result.get("trace_summary", {}) if isinstance(result, dict) else {}
        trace_file = result.get("trace_file") if isinstance(result, dict) else None
        
        # Display saved trace file info
        if trace_file:
            st.success(f"📁 Traces saved to: `{trace_file}`")
        
        # Display OpenTelemetry traces in a separate expander with rich formatting
        if trace_lines:
            with st.expander("Show OpenTelemetry Traces", expanded=False):
                # Show summary at the top
                if trace_summary:
                    st.markdown("**Trace Summary:**")
                    col1, col2, col3 = st.columns(3)
                    with col1:
                        st.metric("Total Spans", trace_summary.get('total_spans', 0))
                        # For workflow-based traces
                        st.metric("Workflow Build", trace_summary.get('workflow_build_spans', 0))
                    with col2:
                        st.metric("Workflow Run", trace_summary.get('workflow_run_spans', 0))
                        st.metric("Executor Process", trace_summary.get('executor_spans', 0))
                    with col3:
                        st.metric("💬 Message Operations", trace_summary.get('message_spans', 0))
                        # Show elapsed time
                        elapsed_ms = trace_summary.get('workflow_elapsed_ms', 0)
                        st.metric("⏱️ Elapsed", f"{elapsed_ms:.0f}ms" if elapsed_ms < 1000 else f"{elapsed_ms/1000:.2f}s")
                    
                    st.divider()
                
                # Show detailed traces
                st.markdown("**Detailed Traces:**")
                for trace_line in trace_lines:
                    st.text(trace_line)
        
        # Display output in expander
        with st.expander("Show Output Agentic URL Summary → Email", expanded=False):
            st.markdown(output_text, unsafe_allow_html=True)
    
