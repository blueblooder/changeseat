import os
import time
from typing import Optional, Tuple, Callable, Dict, Any
from msal import PublicClientApplication, SerializableTokenCache
from dotenv import load_dotenv
from helper.emitter import create_emitter

load_dotenv()

"""Microsoft OAuth2 Token Acquisition Module

Handles OAuth2 authentication for Microsoft Graph API using MSAL (Microsoft Authentication Library).
This module provides token acquisition with automatic caching, silent refresh, and device code flow.

=== Overview ===

This module implements the OAuth2 device code flow for public client applications
(desktop/CLI apps) to obtain delegated tokens for Microsoft Graph API access.

Key Features:
1. Token Caching: Persistent cache to avoid repeated authentication
2. Silent Refresh: Automatic token refresh using cached credentials
3. Device Code Flow: User-friendly browser-based authentication
4. Multi-Tenant Support: Works with personal and work/school accounts

=== Authentication Flow ===

┌─────────────────────────────────────────────────────────────┐
│ 1. Check Token Cache                                       │
│    - Load .msal_token_cache.json if exists                │
│    - Check for cached accounts                             │
├─────────────────────────────────────────────────────────────┤
│ 2. Silent Token Acquisition (if cached account exists)    │
│    - Try to get token without user interaction            │
│    - Uses refresh token automatically                      │
│    - Returns immediately if successful                     │
├─────────────────────────────────────────────────────────────┤
│ 3. Device Code Flow (if no cache or silent failed)        │
│    - Generate device code and user code                    │
│    - Display URL and code to user                          │
│    - User opens browser and enters code                    │
│    - Poll until user completes authentication              │
│    - Save tokens to cache                                   │
└─────────────────────────────────────────────────────────────┘

=== Device Code Flow Explained ===

The device code flow is designed for devices without web browsers or
with limited input capabilities (TVs, IoT devices, CLI apps).

Process:
1. Application requests device code from Azure AD
2. Azure AD returns:
   - device_code: Secret code for polling
   - user_code: Short code for user to enter (e.g., "A1B2C3D4")
   - verification_uri: URL to visit (e.g., https://microsoft.com/devicelogin)
   - expires_in: Time limit (typically 15 minutes)
3. Application displays instructions to user:
   "Visit https://microsoft.com/devicelogin and enter code: A1B2C3D4"
4. User opens browser, navigates to URL, enters code
5. User authenticates with Microsoft account (username/password, MFA, etc.)
6. User grants consent for requested permissions (Mail.Read)
7. Application polls Azure AD in background
8. Once user completes: Azure AD returns tokens to application

Why Device Code Flow?
- No embedded browser needed (works in terminals, SSH sessions)
- Secure: Tokens never exposed in UI
- User-friendly: Familiar Microsoft login experience
- MFA-compatible: Supports all authentication methods
- Cross-platform: Works on Linux, Mac, Windows

=== Token Caching ===

MSAL automatically handles token caching to minimize authentication prompts.

Cache File: .msal_token_cache.json
Location: Current working directory
Format: JSON with encrypted tokens

Cache Contains:
- Access tokens (short-lived, ~1 hour)
- Refresh tokens (long-lived, ~90 days)
- ID tokens (user identity information)
- Account metadata (username, tenant, etc.)

Cache Benefits:
- Silent token refresh (no user interaction)
- Faster token acquisition (~100ms vs 30+ seconds for device flow)
- Better user experience (less authentication friction)
- Offline support (can refresh while offline if not expired)

Security:
- Cache stored on local filesystem
- NOT encrypted by default (file permissions protect it)
- Do NOT commit cache to version control (.gitignore it)
- Consider encrypting cache for sensitive environments

=== Token Lifecycle ===

Access Token:
- Expires: ~60 minutes (Azure AD default)
- Use: Authorization header for Graph API calls
- Refresh: Automatically via MSAL silent acquisition

Refresh Token:
- Expires: ~90 days (or after idle time)
- Use: Obtain new access tokens without re-authentication
- Storage: In MSAL token cache

Token Expiration Handling:
- MSAL automatically refreshes before expiration
- If refresh fails: Falls back to interactive flow
- Expired refresh token: Requires re-authentication

=== Environment Variables ===

M365_CLIENT_ID (required):
    Azure AD Application (client) ID
    Format: GUID (e.g., "12345678-1234-1234-1234-123456789012")
    
    Obtain From:
    1. Azure Portal → Azure Active Directory → App registrations
    2. Create new registration or use existing
    3. Copy "Application (client) ID"
    
    App Registration Requirements:
    - Platform: Public client (Mobile and desktop applications)
    - Redirect URI: Not required for device code flow
    - API Permissions: Microsoft Graph → Mail.Read (Delegated)
    - Admin consent: May be required for some organizations

M365_TENANT_ID (optional):
    Azure AD Tenant ID
    Format: GUID or special value
    Default: "organizations" (multi-tenant)
    
    Values:
    - "organizations": Any work/school account (multi-tenant)
    - "consumers": Personal Microsoft accounts only
    - "common": Both work/school and personal accounts
    - <tenant_guid>: Specific tenant only (single-tenant)
    
    When to Use:
    - Single-tenant apps: Use specific tenant GUID
    - Multi-tenant apps: Use "organizations" or "common"
    - Personal accounts: Use "consumers"

=== Required Permissions ===

Microsoft Graph API:
- Mail.Read (Delegated): Read user's email
  * Allows reading emails from user's mailbox
  * Requires user consent
  * Does NOT allow sending email (use Mail.Send for that)

Additional Scopes:
Can request multiple scopes by adding to SCOPES list:
- Mail.Send: Send email as user
- Mail.ReadWrite: Read and modify email
- Calendars.Read: Read calendar events
- User.Read: Read user profile

=== Usage Examples ===

Basic Usage (Simple Token):
```python
from helper.gettoken import get_graph_token

# Get token (interactive if needed)
token, log = get_graph_token()

if token:
    # Use token with Microsoft Graph
    headers = {'Authorization': f'Bearer {token}'}
    response = requests.get('https://graph.microsoft.com/v1.0/me', headers=headers)
else:
    print("Authentication failed")
    print(log)
```

Advanced Usage (Token with Metadata):
```python
from helper.gettoken import get_graph_token_with_metadata

# Get full token result with expiration info
result, log = get_graph_token_with_metadata()

if result:
    token = result['access_token']
    expires_in = result['expires_in']  # Seconds until expiration
    expires_on = result['expires_on']  # Epoch timestamp
    
    print(f"Token expires in {expires_in} seconds")
else:
    print("Authentication failed")
```

Non-Interactive Mode (Server/Automation):
```python
# Only use cached token, don't prompt user
token, log = get_graph_token(interactive=False)

if token:
    # Cached token available
    use_token(token)
else:
    # No cached token, need interactive authentication
    print("Please run in interactive mode first to cache credentials")
```

With Streamlit Real-Time Updates:
```python
import streamlit as st
from helper.emitter import create_streamlit_emitter

status_area = st.empty()
emitter = create_streamlit_emitter(status_area)

token, log = get_graph_token(realtime_callback=emitter.emit)

if token:
    st.success("Authenticated successfully!")
else:
    st.error("Authentication failed")
    st.text(log)
```

=== CLI Testing ===

Run as standalone script for testing:

```bash
# Set environment variables
$env:M365_CLIENT_ID = "your-client-id-here"
$env:M365_TENANT_ID = "organizations"  # Optional

# Run authentication test
python gettoken.py

# Expected output:
# [INFO] No cached accounts, starting device code flow.
# === Device Code Flow ===
# To sign in, use a web browser to open the page https://microsoft.com/devicelogin and enter the code A1B2C3D4 to authenticate.
# [INFO] Device code authentication successful.
# [SUCCESS] Retrieved access token (truncated): eyJ0eXAiOiJKV1QiLCJhbGc... ...
```

=== Troubleshooting ===

Common Issues:

1. "M365_CLIENT_ID not set in environment"
   Solution: Set environment variable with your Azure AD app client ID

2. "AADSTS700016: Application not found in directory"
   Solution: Verify CLIENT_ID is correct, app exists in tenant

3. "AADSTS65001: User or administrator has not consented"
   Solution: Grant admin consent for Mail.Read permission

4. Token cache corrupted
   Solution: Delete .msal_token_cache.json and re-authenticate

5. Silent acquisition fails repeatedly
   Solution: Refresh token expired, delete cache and re-authenticate

6. "invalid_client" error
   Solution: Verify app configured as public client (not confidential)

=== Security Best Practices ===

1. Token Storage:
   - Never log full tokens (log only first 40 chars for debugging)
   - Don't commit tokens to version control
   - Use environment variables for client secrets (not needed for public clients)

2. Cache Security:
   - Add .msal_token_cache.json to .gitignore
   - Set restrictive file permissions (read/write for user only)
   - Consider encrypting cache in shared environments

3. Scope Minimization:
   - Request only required scopes
   - Use least-privilege principle
   - Separate apps for different permission sets

4. App Registration:
   - Use different apps for dev/test/prod
   - Enable sign-in audience restrictions
   - Monitor app usage in Azure Portal

=== References ===

MSAL Python Documentation:
https://msal-python.readthedocs.io/

Device Code Flow:
https://learn.microsoft.com/en-us/azure/active-directory/develop/v2-oauth2-device-code

Microsoft Graph Permissions:
https://learn.microsoft.com/en-us/graph/permissions-reference
"""

# === Configuration Constants ===

# Azure AD Application (Client) ID
# Obtain from Azure Portal → App registrations → Your app → Overview
# Format: GUID (e.g., "12345678-1234-1234-1234-123456789012")
# Why from environment? Keeps secrets out of code, supports multiple environments
CLIENT_ID = os.getenv("M365_CLIENT_ID")

# Azure AD Tenant ID
# Controls which accounts can authenticate
# Default: "organizations" allows any work/school account (multi-tenant)
# Alternatives:
# - Specific GUID: Single-tenant, only that directory
# - "common": Both work/school and personal Microsoft accounts
# - "consumers": Personal Microsoft accounts only
TENANT_ID = os.getenv("M365_TENANT_ID", "organizations")

# OAuth2 Scopes for Microsoft Graph API
# Scopes define what permissions the token will have
# Mail.Read: Read user's email messages
# Why list? Can request multiple scopes: ["Mail.Read", "Mail.Send", "Calendars.Read"]
# Delegated permissions: Act on behalf of signed-in user
SCOPES = ["Mail.Read"]

# MSAL token cache file path
# Stores access tokens, refresh tokens, and account metadata
# Persists between sessions to enable silent token acquisition
# Location: Current working directory
# Security: Add to .gitignore, protect with file permissions
# Format: JSON with encrypted tokens
MSAL_CACHE_FILE = ".msal_token_cache.json"


def get_graph_token_with_metadata(
    interactive: bool = True,
    realtime_callback: Optional[Callable[[str], None]] = None
) -> Tuple[Optional[Dict[str, Any]], str]:
    """Acquire a Microsoft Graph delegated token with full MSAL result metadata.
    
    This is the main authentication function that handles both silent (cached)
    and interactive (device code flow) token acquisition.
    
    Authentication Strategy:
    1. Try silent acquisition from cache (fast, no user interaction)
    2. If no cache or silent fails: Fall back to device code flow
    3. Save successful results to cache for future use
    
    Why Return Full Metadata?
    - Access token: For API authorization
    - Expiration info: For token lifetime management
    - Account details: For user identification
    - Token type: For proper Authorization header formatting
    
    Parameters
    ----------
    interactive : bool, default=True
        Whether to allow interactive device code flow.
        
        True: Prompt user if no cached token available
              Suitable for: Development, first-time setup, user-facing apps
              
        False: Return None if no cached token available
               Suitable for: Automated scripts, server processes, CI/CD
               
        Use Case for False:
        ```python
        # Server process that shouldn't block
        result, log = get_graph_token_with_metadata(interactive=False)
        if not result:
            alert_admin("Token cache expired, manual re-auth needed")
        ```
        
    realtime_callback : Optional[Callable[[str], None]], default=None
        Optional callback for real-time progress updates.
        
        Signature: (message: str) -> None
        
        Common Uses:
        - Streamlit UI updates: emitter.emit
        - Logger integration: logger.info
        - Progress bars: update_progress
        
        Example Messages:
        - "[INFO] Silent token acquisition succeeded for user@example.com."
        - "=== Device Code Flow ==="
        - "Visit https://microsoft.com/devicelogin and enter code: A1B2C3D4"
        - "[INFO] Device code authentication successful."
        - "[ERROR] Authentication failed: AADSTS50058: Silent sign-in request failed"
    
    Returns
    -------
    Tuple[Optional[Dict[str, Any]], str]: (result_dict, log)
    
    result_dict: Optional[Dict[str, Any]]
        MSAL authentication result dictionary on success, None on failure.
        
        Success Structure:
        ```python
        {
            'access_token': 'eyJ0eXAi...',  # JWT token for Graph API
            'token_type': 'Bearer',          # Authorization header type
            'expires_in': 3599,              # Seconds until expiration
            'expires_on': 1699999999,        # Epoch timestamp of expiration
            'ext_expires_in': 3599,          # Extended expiration (fallback)
            'refresh_token': '0.AX0A...',    # For silent refresh (not always returned)
            'id_token': 'eyJ0eXAi...',       # User identity claims
            'client_info': '...',            # Client metadata
            'id_token_claims': {             # Decoded ID token
                'aud': 'client_id',
                'iss': 'https://login.microsoftonline.com/...',
                'iat': 1699999999,
                'nbf': 1699999999,
                'exp': 1699999999,
                'name': 'John Doe',
                'preferred_username': 'john@example.com',
                'oid': 'user_object_id',
                'tid': 'tenant_id',
                'sub': 'subject_id'
            }
        }
        ```
        
        Failure: None
        
    log: str
        Multi-line log of all operations performed.
        Includes status messages, errors, warnings.
        
        Example Log:
        ```
        [INFO] Silent token acquisition succeeded for john@example.com.
        ```
        
        Or on failure:
        ```
        [INFO] No cached accounts, starting device code flow.
        === Device Code Flow ===
        To sign in, use a web browser to open the page https://microsoft.com/devicelogin and enter the code A1B2C3D4 to authenticate.
        [INFO] Device code authentication successful.
        ```
    
    Token Usage Example:
    ```python
    result, log = get_graph_token_with_metadata()
    
    if result:
        token = result['access_token']
        expires_in = result['expires_in']
        
        # Use with Microsoft Graph
        headers = {'Authorization': f'Bearer {token}'}
        response = requests.get('https://graph.microsoft.com/v1.0/me', headers=headers)
        
        # Schedule refresh before expiration
        refresh_at = time.time() + expires_in - 300  # 5 min buffer
    ```
    
    Error Handling:
    ```python
    result, log = get_graph_token_with_metadata()
    
    if not result:
        if '[ERROR] M365_CLIENT_ID not set' in log:
            # Environment not configured
            setup_environment()
        elif 'AADSTS' in log:
            # Azure AD error
            parse_aad_error(log)
        else:
            # Other error
            log_error(log)
    ```
    
    Common Azure AD Error Codes in Log:
    - AADSTS50058: Silent sign-in request failed (no cached token)
    - AADSTS700016: Application not found in directory
    - AADSTS65001: User/admin has not consented to permissions
    - AADSTS50059: Tenant identifier not found (invalid tenant)
    - AADSTS7000215: Invalid client secret (for confidential clients)
    """
    # STEP 1: Initialize emitter utility for progress reporting
    # create_emitter wraps callback or defaults to print
    emit_util = create_emitter(realtime_callback)
    emit = emit_util.emit

    # STEP 2: Validate required configuration
    # CLIENT_ID is required for all authentication flows
    if not CLIENT_ID:
        # Early exit with error message
        # Don't raise exception - caller may want to handle gracefully
        return None, "[ERROR] M365_CLIENT_ID not set in environment."

    # STEP 3: Create or load MSAL token cache
    # SerializableTokenCache: In-memory cache that can be persisted to disk
    # Why cache? Enables silent token refresh without user interaction
    cache = SerializableTokenCache()
    
    # Load existing cache file if available
    # Cache contains: access tokens, refresh tokens, account metadata
    if os.path.exists(MSAL_CACHE_FILE):
        try:
            with open(MSAL_CACHE_FILE, 'r', encoding='utf-8') as cache_file:
                # Deserialize JSON cache into MSAL cache object
                cache.deserialize(cache_file.read())
        except Exception as e:
            # Non-fatal: Can still authenticate, just without cache
            # Common causes: File corrupted, permissions issue, invalid JSON
            emit(f"[WARN] Could not load MSAL cache: {e}")

    # STEP 4: Initialize MSAL PublicClientApplication
    # Authority: Azure AD endpoint for authentication
    # Format: https://login.microsoftonline.com/{tenant_id}
    # Examples:
    # - "organizations": https://login.microsoftonline.com/organizations
    # - "common": https://login.microsoftonline.com/common
    # - specific tenant: https://login.microsoftonline.com/12345678-...
    authority = f"https://login.microsoftonline.com/{TENANT_ID}"
    
    # PublicClientApplication: For apps that can't securely store secrets
    # Used for: Desktop apps, mobile apps, CLI tools
    # Not for: Web servers (use ConfidentialClientApplication instead)
    # token_cache: Enables persistent caching across sessions
    app = PublicClientApplication(client_id=CLIENT_ID, authority=authority, token_cache=cache)

    # STEP 5: Try silent token acquisition from cache
    # Silent acquisition uses cached refresh tokens to get new access tokens
    # No user interaction required if cache is valid
    # Benefits: Fast (~100ms), seamless, no interruption
    accounts = app.get_accounts()
    
    if accounts:
        # Found cached accounts, try silent acquisition for each
        # Why loop? Multiple accounts may be cached
        # Try each until one succeeds
        for acct in accounts:
            # acquire_token_silent: Try to get token without user interaction
            # Uses cached refresh token internally
            # Returns: Result dict with access_token on success, None on failure
            result = app.acquire_token_silent(scopes=SCOPES, account=acct)
            
            # Check if successful
            # 'access_token' key present = success
            # Common failures: Refresh token expired, network error, revoked consent
            if result and 'access_token' in result:
                # Silent acquisition succeeded!
                username = acct.get('username', 'unknown user')
                emit(f"[INFO] Silent token acquisition succeeded for {username}.")
                
                # Save updated cache if changed
                # Why check has_state_changed? Avoid unnecessary disk writes
                # Cache changes when: New tokens acquired, tokens refreshed
                if cache.has_state_changed:
                    try:
                        with open(MSAL_CACHE_FILE, 'w', encoding='utf-8') as cache_file:
                            # Serialize cache to JSON string and save
                            cache_file.write(cache.serialize())
                    except Exception as e:
                        # Non-fatal: Token still valid, just won't be cached for next time
                        emit(f"[WARN] Could not save MSAL cache: {e}")
                
                # Return successful result
                return result, emit_util.get_log()
        
        # All cached accounts failed silent acquisition
        # Common causes: All refresh tokens expired, consent revoked, network issue
        emit("[INFO] Silent token acquisition failed, proceeding with interactive device code flow.")
    else:
        # No cached accounts found
        # This is normal for first-time authentication
        emit("[INFO] No cached accounts, starting device code flow.")

    # STEP 6: Check if interactive flow allowed
    # If interactive=False and we reached here, no cached token available
    if not interactive:
        emit("[ERROR] Interactive flow disabled and no cached token available.")
        return None, emit_util.get_log()

    # STEP 7: Device Code Flow (Interactive Authentication)
    # This is the fallback when no cached token available
    # Requires user to open browser and authenticate
    try:
        # Initiate device code flow
        # This generates:
        # - device_code: Secret code for polling (hidden from user)
        # - user_code: Short code for user to enter (e.g., "A1B2C3D4")
        # - verification_uri: URL to visit (e.g., https://microsoft.com/devicelogin)
        # - message: Pre-formatted instruction message for user
        # - expires_in: Time limit (typically 900 seconds = 15 minutes)
        # - interval: Polling interval in seconds (typically 5)
        flow = app.initiate_device_flow(scopes=SCOPES)
        
        # Check if flow creation succeeded
        # 'user_code' key missing = flow creation failed
        # Common causes: Network error, invalid client ID, service outage
        if 'user_code' not in flow:
            emit(f"[ERROR] Failed to create device flow: {flow}")
            return None, emit_util.get_log()
        
        # Display device code instructions to user
        # flow['message'] contains pre-formatted message like:
        # "To sign in, use a web browser to open the page https://microsoft.com/devicelogin 
        #  and enter the code A1B2C3D4 to authenticate."
        emit("=== Device Code Flow ===")
        emit(flow['message'])
        
        # Wait for user to complete authentication
        # This is a BLOCKING call that polls Azure AD until:
        # - User completes authentication (success)
        # - Flow expires (timeout, typically 15 minutes)
        # - User cancels/denies (failure)
        # - Network error (failure)
        # 
        # Polling Behavior:
        # - Polls every 'interval' seconds (typically 5)
        # - Continues until 'expires_in' seconds elapsed
        # - Returns immediately on user completion
        # 
        # Why blocking? Simplifies flow, most clients can wait
        # For non-blocking: Use threading or async version
        result = app.acquire_token_by_device_flow(flow)
        
        # Check if authentication succeeded
        # 'access_token' key present = success
        if 'access_token' in result:
            emit("[INFO] Device code authentication successful.")
            
            # Save tokens to cache for future use
            # This enables silent token refresh next time
            if cache.has_state_changed:
                try:
                    with open(MSAL_CACHE_FILE, 'w', encoding='utf-8') as cache_file:
                        # Serialize and save cache
                        # Cache now contains:
                        # - Access token (for immediate use)
                        # - Refresh token (for future silent refresh)
                        # - Account metadata (for account selection)
                        cache_file.write(cache.serialize())
                except Exception as e:
                    # Non-fatal: Tokens still valid for current session
                    # Just won't be cached for next session
                    emit(f"[WARN] Could not save MSAL cache: {e}")
            
            # Return successful result with tokens
            return result, emit_util.get_log()
        else:
            # Authentication failed
            # result dict contains error information:
            # - error: Error code (e.g., "authorization_pending", "expired_token")
            # - error_description: Human-readable description
            # - error_codes: List of Azure AD error codes
            # - timestamp: When error occurred
            # - trace_id: For correlation with Azure AD logs
            # - correlation_id: For troubleshooting
            error_msg = result.get('error_description', result)
            emit(f"[ERROR] Authentication failed: {error_msg}")
            return None, emit_util.get_log()
            
    except Exception as e:  # pylint: disable=broad-except
        # Catch-all for unexpected errors
        # Common causes:
        # - Network connectivity issues
        # - MSAL library bugs
        # - System errors (out of memory, etc.)
        # 
        # Why broad except? Want to return error log, not crash
        # Caller can decide how to handle based on log content
        emit(f"[ERROR] Exception during device flow: {e}")
        return None, emit_util.get_log()

def get_graph_token(
    interactive: bool = True,
    realtime_callback: Optional[Callable[[str], None]] = None
) -> Tuple[Optional[str], str]:
    """Acquire Microsoft Graph token (simplified interface).
    
    Backward-compatible wrapper that returns only the access token string
    instead of the full MSAL result dictionary.
    
    This is the simpler, more convenient interface for most use cases where
    you just need the token to make API calls.
    
    Why Two Functions?
    - get_graph_token(): Simple interface for common case (just need token)
    - get_graph_token_with_metadata(): Advanced interface for token lifetime management
    
    Internally calls get_graph_token_with_metadata() and extracts access_token.
    
    Parameters
    ----------
    interactive : bool, default=True
        Whether to allow interactive device code flow.
        Same as get_graph_token_with_metadata().
        
    realtime_callback : Optional[Callable[[str], None]], default=None
        Optional callback for real-time progress updates.
        Same as get_graph_token_with_metadata().
    
    Returns
    -------
    Tuple[Optional[str], str]: (access_token, log)
    
    access_token: Optional[str]
        JWT access token for Microsoft Graph API authorization.
        None if authentication failed.
        
        Format: Long base64-encoded JWT string (1000-2000 characters)
        Example: "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIs..."
        
        Use in Authorization header:
        ```python
        headers = {'Authorization': f'Bearer {access_token}'}
        ```
        
    log: str
        Multi-line log of all operations performed.
        Same as get_graph_token_with_metadata().
    
    Usage Example:
    ```python
    from helper.gettoken import get_graph_token
    
    # Get token
    token, log = get_graph_token()
    
    if token:
        # Use with Microsoft Graph API
        import requests
        
        headers = {'Authorization': f'Bearer {token}'}
        
        # Get user profile
        response = requests.get(
            'https://graph.microsoft.com/v1.0/me',
            headers=headers
        )
        
        if response.status_code == 200:
            user = response.json()
            print(f"Authenticated as: {user['displayName']}")
    else:
        print("Authentication failed:")
        print(log)
    ```
    
    When to Use This vs get_graph_token_with_metadata():
    
    Use get_graph_token() when:
    - You just need the token for API calls
    - Token expiration handled by periodic re-authentication
    - Simple scripts and tools
    - Following examples from documentation
    
    Use get_graph_token_with_metadata() when:
    - Need to check token expiration time
    - Implementing token refresh logic
    - Need user identity claims from ID token
    - Building token management system
    - Need correlation IDs for troubleshooting
    """
    # Call full metadata version
    result, log = get_graph_token_with_metadata(
        interactive=interactive, 
        realtime_callback=realtime_callback
    )
    
    # Extract access token if present
    # result is dict on success, None on failure
    if result and 'access_token' in result:
        # Return token string
        return result['access_token'], log
    
    # Authentication failed, return None
    return None, log


if __name__ == "__main__":
    """CLI testing and manual authentication.
    
    Run this script directly to test authentication configuration.
    
    Usage:
    ```bash
    # Set environment variables
    $env:M365_CLIENT_ID = "your-client-id-guid"
    $env:M365_TENANT_ID = "organizations"  # Optional
    
    # Run authentication test
    python gettoken.py
    ```
    
    Expected Workflow:
    1. Script checks for cached token
    2. If no cache: Displays device code instructions
    3. User opens browser and authenticates
    4. Script displays success message with token preview
    5. Token cached for future use
    
    Next Run:
    1. Script loads token from cache
    2. Silent token refresh (no user interaction)
    3. Displays success message immediately
    
    Troubleshooting:
    - "M365_CLIENT_ID not set": Set environment variable
    - "Application not found": Check CLIENT_ID is correct
    - "Silent acquisition failed": Normal for first run, will prompt for device code
    - Token cached but expired: Will automatically refresh or prompt for re-auth
    
    Output Example (First Run):
    ```
    [INFO] No cached accounts, starting device code flow.
    === Device Code Flow ===
    To sign in, use a web browser to open the page https://microsoft.com/devicelogin and enter the code A1B2C3D4 to authenticate.
    [INFO] Device code authentication successful.
    [SUCCESS] Retrieved access token (truncated): eyJ0eXAiOiJKV1QiLCJhbGc... ...
    ```
    
    Output Example (Subsequent Runs):
    ```
    [INFO] Silent token acquisition succeeded for john@example.com.
    [SUCCESS] Retrieved access token (truncated): eyJ0eXAiOiJKV1QiLCJhbGc... ...
    ```
    """
    # Acquire token (will use cache if available, otherwise device code flow)
    token, log = get_graph_token()
    
    # Display operation log
    print(log)
    
    # Display result
    if token:
        # Success: Show token preview (first 40 chars only)
        # Why truncate? Full token is 1000+ chars, overwhelming in console
        # Why show at all? Confirms token was obtained (useful for debugging)
        # Never log full tokens in production!
        print("[SUCCESS] Retrieved access token (truncated):", token[:40], "...")
        print("\nToken ready for use with Microsoft Graph API")
        print("Example: https://graph.microsoft.com/v1.0/me")
    else:
        # Failure: Log already displayed above, just add error status
        print("\n[FAILED] Could not obtain access token")
        print("Check the log above for error details")
