# Copyright (c) Microsoft. All rights reserved.

"""Multi-tier handoff workflow with specialist-to-specialist routing.

This workflow demonstrates advanced handoff routing where specialist agents delegate
to other specialists, enabling complex multi-tier workflows without returning control
to the user until the specialist chain completes.

Workflow State Machine Flow:
    IDLE → IDLE_WITH_PENDING_REQUESTS (user input)
         → PROCESSING (triage agent routes to specialist)
         → PROCESSING (specialist may handoff to another specialist)
         → WAITING_FOR_USER_INPUT (specialist requests user confirmation/info)
         → IDLE_WITH_PENDING_REQUESTS (user responds)
         → COMPLETED (final specialist returns to user)

Routing Pattern:
    User → Triage Agent → Specialist A → Specialist B → Back to User

Agent Handoff Graph:
    - Triage can handoff to: Replacement, Delivery, Billing
    - Replacement can handoff to: Delivery (for tracking info)
    - Delivery can handoff to: Billing (for payment issues)
    - All specialists return control to User when complete

Example Use Cases:
    - Replacement agent needs shipping info → hands off to delivery agent
    - Technical support needs billing info → hands off to billing agent
    - Level 1 support escalates to Level 2 → hands off to escalation agent

Prerequisites:
    - `az login` (Azure CLI authentication)
    - Environment variables configured for AzureOpenAIChatClient

Usage:
    From command line:
        python workflow/handoff_bidirectional.py
        python workflow/handoff_bidirectional.py "I need help with order 12345"
    
    From another module:
        from workflow.handoff_bidirectional import run_handoff_bidirectional
        result = await run_handoff_bidirectional("customer support question")
"""

import asyncio
import json
import os
import sys
from typing import Callable

if __name__ == "__main__":
    repo_root = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
    if repo_root not in sys.path:
        sys.path.insert(0, repo_root)

from collections.abc import AsyncIterable
from typing import cast

from agent_framework import (
    ChatMessage,
    HandoffBuilder,
    HandoffUserInputRequest,
    RequestInfoEvent,
    WorkflowEvent,
    WorkflowOutputEvent,
    WorkflowRunState,
    WorkflowStatusEvent,
    get_logger,
)
from agent_framework.azure import AzureOpenAIChatClient
from agent_framework.observability import setup_observability
from azure.identity import AzureCliCredential
from opentelemetry import trace

# Import helper utilities
from helper.emitter import create_emitter
from helper.otel_collector import get_span_collector
from helper.storeotel import store_otel_traces_to_local

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

# Default question constant (pattern aligned with other agents)
DEFAULT_QUESTION = "I need help with order 12345. I want a replacement and need to know when it will arrive."

# Get logger for observability
logger = get_logger()


def create_agents(chat_client: AzureOpenAIChatClient, emitter: Callable[[str], None] | None = None):
    """Create triage and specialist agents with multi-tier handoff capabilities.

    Args:
        chat_client: Azure OpenAI chat client instance
        emitter: Optional callback for emitting status updates

    Returns:
        Tuple of (triage_agent, replacement_agent, delivery_agent, billing_agent)
    """
    emit = emitter or print
    
    emit("[AGENTS] Creating triage and specialist agents...")
    
    triage = chat_client.create_agent(
        instructions=(
            "You are a customer support triage agent. Assess the user's issue and route appropriately:\n"
            "- For product replacement issues: call handoff_to_replacement_agent\n"
            "- For delivery/shipping inquiries: call handoff_to_delivery_agent\n"
            "- For billing/payment issues: call handoff_to_billing_agent\n"
            "Be concise and friendly."
        ),
        name="triage_agent",
    )

    replacement = chat_client.create_agent(
        instructions=(
            "You handle product replacement requests. Ask for order number and reason for replacement.\n"
            "If the user also needs shipping/delivery information, call handoff_to_delivery_agent to "
            "get tracking details. Otherwise, process the replacement and confirm with the user.\n"
            "Be concise and helpful."
        ),
        name="replacement_agent",
    )

    delivery = chat_client.create_agent(
        instructions=(
            "You handle shipping and delivery inquiries. Provide tracking information, estimated "
            "delivery dates, and address any delivery concerns.\n"
            "If billing issues come up, call handoff_to_billing_agent.\n"
            "Be concise and clear."
        ),
        name="delivery_agent",
    )

    billing = chat_client.create_agent(
        instructions=(
            "You handle billing and payment questions. Help with refunds, payment methods, "
            "and invoice inquiries. Be concise."
        ),
        name="billing_agent",
    )
    
    emit("[AGENTS] Created 4 agents: triage, replacement, delivery, billing")

    return triage, replacement, delivery, billing


async def _drain(stream: AsyncIterable[WorkflowEvent]) -> list[WorkflowEvent]:
    """Collect all events from an async stream into a list."""
    return [event async for event in stream]


def _handle_events(events: list[WorkflowEvent], emitter: Callable[[str], None] | None = None) -> list[RequestInfoEvent]:
    """Process workflow events and extract pending user input requests.
    
    Args:
        events: List of workflow events to process
        emitter: Optional callback for emitting status updates
        
    Returns:
        List of pending user input request events
    """
    emit = emitter or print
    requests: list[RequestInfoEvent] = []

    for event in events:
        if isinstance(event, WorkflowStatusEvent) and event.state in {
            WorkflowRunState.IDLE,
            WorkflowRunState.IDLE_WITH_PENDING_REQUESTS,
        }:
            emit(f"[STATUS] Workflow state: {event.state.name}")

        elif isinstance(event, WorkflowOutputEvent):
            conversation = cast(list[ChatMessage], event.data)
            if isinstance(conversation, list):
                emit("")
                emit("=" * 30)
                emit("FINAL CONVERSATION")
                emit("=" * 30)
                for message in conversation:
                    # Filter out messages with no text (tool calls)
                    if not message.text.strip():
                        continue
                    speaker = message.author_name or message.role.value
                    emit(f"- {speaker}: {message.text}")
                emit("=" * 30)

        elif isinstance(event, RequestInfoEvent):
            if isinstance(event.data, HandoffUserInputRequest):
                _print_handoff_request(event.data, emitter=emit)
            requests.append(event)

    return requests


def _print_handoff_request(request: HandoffUserInputRequest, emitter: Callable[[str], None] | None = None) -> None:
    """Display a user input request with conversation context.
    
    Args:
        request: The handoff user input request to display
        emitter: Optional callback for emitting status updates
    """
    emit = emitter or print
    emit("")
    emit("=" * 30)
    emit("USER INPUT REQUESTED")
    emit("=" * 30)
    # Filter out messages with no text for cleaner display
    messages_with_text = [msg for msg in request.conversation if msg.text.strip()]
    emit(f"Last {len(messages_with_text)} messages in conversation:")
    for message in messages_with_text[-5:]:  # Show last 5 for brevity
        speaker = message.author_name or message.role.value
        text = message.text[:100] + "..." if len(message.text) > 100 else message.text
        emit(f"  {speaker}: {text}")
    emit("=" * 30)


async def run_handoff_bidirectional(
    query: str,
    emitter: Callable[[str], None] | None = None,
    return_mode: str = "both",  # 'output' | 'log' | 'both'
    save_json: str | os.PathLike | None = None,
    num_responses: int = 4,
    scripted_responses: list[str] | None = None,
    tracing_mode: str = "both",  # 'auto' | 'both' | 'azure_monitor' | 'console' | 'none'
) -> dict | str:
    """Execute multi-tier handoff workflow with specialist-to-specialist routing.
    
    Pattern aligned with agent modules (aisearch.py, bingsearch.py):
    - Application/diagnostic lines are emitted via emitter (if provided) and collected in the log
    - Final conversation output is captured separately as output_text
    - return_mode controls returned data:
        'output' -> output text only
        'log'    -> full log only
        'both'   -> dict { 'output_text': str, 'log': str, 'success': bool, 'conversation': list[ChatMessage] }
    
    Execution Flow:
        1. Create emitter utility for logging
        2. Auto-detect tracing mode if 'auto'
        3. Setup unified trace manager
        4. Default query if empty
        5. Emit workflow header
        6. Use default scripted responses if not provided
        7. Create Azure OpenAI chat client
        8. Create triage and specialist agents
        9. Build multi-tier handoff workflow with termination condition
        10. Start parent tracing span
        11. Start workflow with initial message
        12. Process scripted responses loop
        13. Extract final conversation from events
        14. End parent span
        15. Format output_text from conversation
        16. Collect traces and save locally
        17. Save JSON artifact if requested
        18. Return payload based on return_mode
    
    This sample shows:
    1. Triage agent routes to replacement specialist
    2. Replacement specialist hands off to delivery specialist
    3. Delivery specialist can hand off to billing if needed
    4. All transitions are seamless without returning to user until complete

    Args:
        query: Initial customer support question/message
        emitter: Optional callback(string) for incremental UI updates
        return_mode: Controls return payload as described above
        save_json: Optional path to save results as JSON
        num_responses: Number of scripted responses (default: 4, triggers termination after 5th user message)
        scripted_responses: Optional custom scripted responses (default: None, uses predefined responses)
        tracing_mode: Controls where traces are sent:
            'auto' (default) -> Azure Monitor if APPLICATIONINSIGHTS_CONNECTION_STRING is set, else local
            'local' -> Save to local JSON file only
            'azure_monitor' -> Send to Azure Monitor / Application Insights (viewable in Azure AI Foundry)
            'console' -> Print traces to console
            'none' -> Disable tracing
    
    Returns:
        dict | str depending on return_mode
    """
    # STEP 1: Create centralized emitter utility
    # Why? Enable consistent logging with flexible emitter injection for UI integration
    emit_util = create_emitter(emitter)
    emit = emit_util.emit
    
    # STEP 2: Auto-detect tracing mode if set to 'auto'
    # Why? Intelligently enable Azure Monitor tracing when connection string exists, fallback to console
    if tracing_mode == "auto":
        application_insights_connection_string = os.environ.get("APPLICATIONINSIGHTS_CONNECTION_STRING")
        if application_insights_connection_string and application_insights_connection_string.strip():
            tracing_mode = "azure_monitor"
            emit("[OBSERVABILITY] Auto-detected APPLICATIONINSIGHTS_CONNECTION_STRING - using Azure Monitor tracing")
        else:
            tracing_mode = "console"
            emit("[TRACING] No APPLICATIONINSIGHTS_CONNECTION_STRING found - using console tracing")
    
    # STEP 3: Setup tracing using UnifiedTraceManager
    # Why? Initialize OpenTelemetry instrumentation for workflow/agent/handoff span capture
    from helper.unified_trace_manager import UnifiedTraceManager
    trace_mgr = UnifiedTraceManager(tracing_mode=tracing_mode, trace_type="workflow", emitter=emit)
    trace_mgr.setup()
    
    # STEP 4: Enhanced logging for observability
    # Why? Record workflow initiation in both application logger and emitter for debugging
    logger.info(f"Starting multi-tier handoff workflow: query='{query}'")
    emit("[OBSERVABILITY] OpenTelemetry tracing enabled - capturing spans")
    
    # STEP 5: Default query if empty
    # Why? Ensure valid query exists before creating workflow agents
    if not query or not query.strip():
        query = DEFAULT_QUESTION
    
    # STEP 6: Emit workflow header
    # Why? Provide visibility into workflow configuration and expected agent flow
    emit("=" * 30)
    emit("SPECIALIST-TO-SPECIALIST HANDOFF DEMONSTRATION")
    emit("=" * 30)
    emit(f"Query: {query}")
    emit("Scenario: Customer needs replacement + shipping info + billing confirmation")
    emit("Expected flow: User -> Triage -> Replacement -> Delivery -> Billing -> User")
    emit("=" * 30)
    emit("")
    
    # STEP 7: Use default scripted responses if not provided
    # Why? Provide predefined conversation flow for demonstration, or allow custom scripting
    if scripted_responses is None:
        scripted_responses = [
            query,  # Initial message
            "The item arrived damaged. I'd like a replacement shipped to the same address.",
            "Great! Can you confirm the shipping cost won't be charged again?",
            "Thank you!",  # Final response to trigger termination after billing agent answers
        ]
    
    # STEP 8: Trim scripted responses to num_responses
    # Why? Allow customization of conversation length through num_responses parameter
    scripted_responses = scripted_responses[:num_responses]
    
    # STEP 9: Create Azure OpenAI chat client
    # Why? Initialize Azure credential-based client for AI agent creation
    chat_client = AzureOpenAIChatClient(credential=AzureCliCredential())
    triage, replacement, delivery, billing = create_agents(chat_client, emitter=emit)

    # STEP 10: Configure multi-tier handoffs using fluent add_handoff() API
    # Why? Define specialist-to-specialist routing: triage->any, replacement->delivery/billing, delivery->billing
    emit("[OBSERVABILITY] Building workflow - this will emit workflow.build spans")
    workflow = (
        HandoffBuilder(
            name="multi_tier_support",
            participants=[triage, replacement, delivery, billing],
        )
        .set_coordinator(triage)
        .add_handoff(triage, [replacement, delivery, billing])  # Triage can route to any specialist
        .add_handoff(replacement, [delivery, billing])  # Replacement can delegate to delivery or billing
        .add_handoff(delivery, billing)  # Delivery can escalate to billing
        # Termination condition: Stop when more than num_responses user messages exist.
        # This allows agents to respond to the nth user message before the (n+1)th triggers termination.
        .with_termination_condition(lambda conv: sum(1 for msg in conv if msg.role.value == "user") > num_responses)
        .build()
    )
    
    logger.info("Workflow graph built successfully")
    emit("[OBSERVABILITY] Workflow built - ready to execute")

    # STEP 11: Start parent span for tracing
    # Why? Capture end-to-end telemetry with workflow-level metadata
    trace_mgr.start_parent_span(
        span_name=f"handoff_bidirectional: {query[:50]}",
        attributes={
            "query": query,
            "num_responses": num_responses,
            "tracing_mode": tracing_mode
        }
    )
    
    # STEP 12: Start workflow with initial message
    # Why? Begin conversation flow with first user message
    emit(f"[User]: {scripted_responses[0]}")
    emit("")
    
    logger.info("Starting workflow execution")
    emit("[OBSERVABILITY] Running workflow - workflow.run, agent.process, and handoff spans will be nested under parent")
    
    final_conversation = None
    success = False
    try:
        # STEP 13: Process initial message and drain events
        # Why? Execute first workflow run and collect all events for request processing
        events = await _drain(
            workflow.run_stream(scripted_responses[0])
        )
        pending_requests = _handle_events(events, emitter=emit)

        # STEP 14: Process scripted responses loop
        # Why? Iterate through scripted user responses to advance workflow conversation
        response_index = 1
        final_events = events  # Keep track of the latest events
        while pending_requests and response_index < len(scripted_responses):
            user_response = scripted_responses[response_index]
            emit("")
            emit(f"[User]: {user_response}")
            emit("")

            responses = {req.request_id: user_response for req in pending_requests}
            events = await _drain(workflow.send_responses_streaming(responses))
            final_events = events  # Update latest events
            pending_requests = _handle_events(events, emitter=emit)

            response_index += 1
        
        logger.info("Workflow completed successfully")
        
        # STEP 15: Extract final conversation from the last WorkflowOutputEvent
        # Why? Retrieve complete conversation history from workflow output events
        for event in reversed(final_events):
            if isinstance(event, WorkflowOutputEvent):
                final_conversation = cast(list[ChatMessage], event.data)
                break
        
        # STEP 16: Fallback to RequestInfoEvent if no final output event
        # Why? Try to extract conversation from pending requests if workflow didn't yield output event
        if not final_conversation and pending_requests:
            for req in pending_requests:
                if isinstance(req.data, HandoffUserInputRequest):
                    final_conversation = req.data.conversation
                    break
        
        # STEP 17: Determine success based on conversation existence
        # Why? Set success flag if conversation was captured from workflow execution
        success = final_conversation is not None and len(final_conversation) > 0
        
    except Exception as exc:
        # STEP 18: Handle workflow exceptions with telemetry recording
        # Why? Capture unexpected failures in both logs and traces for debugging
        trace_mgr.record_exception(exc, f"Workflow exception: {exc}")
        logger.error(f"Workflow exception: {exc}", exc_info=True)
        emit(f"[ERROR] Workflow exception: {exc}")
    finally:
        # STEP 19: End parent span regardless of success/failure
        # Why? Ensure telemetry span is closed properly for complete trace capture
        trace_mgr.end_parent_span()
    
    # STEP 20: Format output_text from conversation history
    # Why? Convert ChatMessage objects to human-readable text with speaker labels
    if final_conversation:
        output_lines = []
        for message in final_conversation:
            if not message.text.strip():
                continue
            speaker = message.author_name or message.role.value
            output_lines.append(f"{speaker}: {message.text}")
        output_text = "\n".join(output_lines)
    else:
        output_text = "[ERROR] No conversation output received from workflow"
    
    # STEP 21: Collect accumulated logs from emitter
    # Why? Preserve execution log for "both" or "log" return modes
    log_joined = emit_util.get_log()
    
    # STEP 22: Retrieve traces from UnifiedTraceManager
    # Why? Collect OpenTelemetry trace spans and summary statistics for observability
    trace_lines, trace_summary = trace_mgr.get_traces()
    trace_file_path = None
    
    # STEP 23: Handle Azure Monitor tracing confirmation
    # Why? Inform user that traces were exported to Azure Monitor if configured
    if tracing_mode == "azure_monitor" or tracing_mode == "both":
        emit("")
        emit("AZURE MONITOR TRACING")
        emit("✅ Workflow traces have been sent to Azure Monitor / Application Insights")
        emit("📊 View traces in Azure AI Foundry Portal: https://ai.azure.com")
        emit("")
    
    # STEP 24: Save traces to local file if local/console/both mode enabled
    # Why? Persist OpenTelemetry spans locally for offline inspection and debugging
    if tracing_mode in ["console", "both", "local"] and trace_lines:
        from helper.storeotel import store_otel_traces_to_local
        from helper.otel_collector import get_span_collector
        span_collector = get_span_collector()
        metadata = span_collector.get_metadata() if span_collector else {}
        trace_file_path, store_log = store_otel_traces_to_local(
            traces=trace_lines,
            trace_summary=trace_summary,
            query=query,
            metadata=metadata,
            prefix='handoff_bidirect',
            emitter=emit
        )
        if trace_file_path:
            emit(f"[OTEL] Traces saved to: {trace_file_path}")
    
        # STEP 25: Emit trace summary statistics
        # Why? Provide workflow execution breakdown (spans, timing) to console for transparency
        emit("")
        emit("=" * 30)
        emit("OPENTELEMETRY TRACE SUMMARY")
        emit("=" * 30)
        emit(f"Total Spans: {trace_summary.get('total_spans', 0)}")
        emit(f"Workflow Build: {trace_summary.get('workflow_build_spans', 0)} spans")
        emit(f"Workflow Run: {trace_summary.get('workflow_run_spans', 0)} spans")
        emit(f"Agent Process: {trace_summary.get('agent_spans', trace_summary.get('executor_spans', 0))} spans")
        emit(f"Handoff: {trace_summary.get('handoff_spans', trace_summary.get('message_spans', 0))} spans")
        if 'workflow_elapsed_ms' in trace_summary:
            emit(f"Workflow Elapsed Time: {trace_summary['workflow_elapsed_ms']:.2f}ms ({trace_summary['workflow_elapsed_ms']/1000:.2f}s)")
        emit("")

    
    # STEP 26: Save conversation to JSON file if requested
    # Why? Persist conversation history and execution details to file for analysis/replay
    if save_json and final_conversation:
        import pathlib
        try:
            path_obj = pathlib.Path(save_json)
            path_obj.parent.mkdir(parents=True, exist_ok=True)
            with path_obj.open('w', encoding='utf-8') as f:
                # STEP 26a: Convert ChatMessage objects to dictionaries
                # Why? JSON serialization requires plain dicts, not custom objects
                conversation_dicts = []
                for msg in final_conversation:
                    conversation_dicts.append({
                        "role": msg.role.value,
                        "author_name": msg.author_name,
                        "text": msg.text,
                    })
                
                # STEP 26b: Write JSON payload with output, log, and conversation
                # Why? Include all key execution artifacts in single JSON file
                json.dump(
                    {
                        "output_text": output_text,
                        "log": log_joined,
                        "success": success,
                        "conversation": conversation_dicts,
                    },
                    f,
                    ensure_ascii=False,
                    indent=2,
                )
            emit(f"Results saved to: {save_json}")
        except Exception as exc:
            emit(f"[WARN] Failed to save JSON: {exc}")
    
    # STEP 27: Return payload based on return_mode
    # Why? Provide flexible response format: "both" for full details, "log" for logs only, "output" for answer only
    if return_mode == "both":
        return {
            "output_text": output_text,
            "log": log_joined,
            "success": success,
            "conversation": final_conversation,
            "traces": trace_lines,  # Include trace lines for UI display
            "trace_summary": trace_summary,  # Include span statistics
            "trace_file": trace_file_path,  # Include saved file path
        }
    elif return_mode == "log":
        return log_joined
    else:  # 'output'
        return output_text


async def main() -> None:
    """Demonstrate specialist-to-specialist handoffs in a multi-tier support scenario.
    
    CLI entry point that supports:
    - No arguments: uses DEFAULT_QUESTION
    - One argument: custom query
    - Two arguments: custom query and tracing_mode
    """
    if len(sys.argv) > 1:
        query = sys.argv[1]
        tracing_mode = sys.argv[2] if len(sys.argv) > 2 else "auto"
    else:
        query = DEFAULT_QUESTION
        tracing_mode = "auto"
    
    print(f"\n💬 Query: {query}")
    print(f"📝 Tracing mode: {tracing_mode}")
    print("\nAvailable tracing modes:")
    print("  - 'auto': Use Azure Monitor if configured, else local (default)")
    print("  - 'local': Save traces to local JSON file")
    print("  - 'azure_monitor': Send traces to Azure AI Foundry")
    print("  - 'console': Print traces to console")
    print("  - 'none': Disable tracing")
    print()
    
    result = await run_handoff_bidirectional(query, return_mode="both", tracing_mode=tracing_mode)
    
    if isinstance(result, dict):
        print("\n" + "=" * 70)
        print("WORKFLOW EXECUTION SUMMARY")
        print("=" * 70)
        print(f"Success: {result.get('success', False)}")
        print(f"Conversation messages: {len(result.get('conversation', [])) if result.get('conversation') else 0}")
        print("=" * 70)
    else:
        print("\n[ERROR] Unexpected result format")

    """
    Sample Output:

    ================================================================================
    SPECIALIST-TO-SPECIALIST HANDOFF DEMONSTRATION
    ================================================================================

    Scenario: Customer needs replacement + shipping info + billing confirmation
    Expected flow: User → Triage → Replacement → Delivery → Billing → User
    ================================================================================

    [User]: I need help with order 12345. I want a replacement and need to know when it will arrive.


    === User Input Requested ===
    Last 5 messages in conversation:
    user: I need help with order 12345. I want a replacement and need to know when it will arrive.
    triage_agent: I'm connecting you to our replacement team to assist with your request, and to our delivery team for...
    replacement_agent: To assist with your replacement for order 12345 and provide tracking details for delivery, I've reac...
    delivery_agent: I'm handing over your request for a replacement of order 12345, as well as your inquiry about estima...
    billing_agent: I handle billing and payment questions. For replacement and delivery details for order 12345, please...
    ============================
    [status] IDLE_WITH_PENDING_REQUESTS

    [User]: I need help with order 12345. I want a replacement and need to know when it will arrive.


    === User Input Requested ===
    Last 7 messages in conversation:
    replacement_agent: To assist with your replacement for order 12345 and provide tracking details for delivery, I've reac...
    delivery_agent: I'm handing over your request for a replacement of order 12345, as well as your inquiry about estima...
    billing_agent: I handle billing and payment questions. For replacement and delivery details for order 12345, please...
    user: I need help with order 12345. I want a replacement and need to know when it will arrive.
    triage_agent: I'm connecting you with our replacement team to help with your request, and our delivery team for in...
    ============================
    [status] IDLE_WITH_PENDING_REQUESTS

    [User]: The item arrived damaged. I'd like a replacement shipped to the same address.


    === User Input Requested ===
    Last 12 messages in conversation:
    user: The item arrived damaged. I'd like a replacement shipped to the same address.
    triage_agent: Thank you for letting us know your item from order 12345 arrived damaged. Im connecting you to our ...
    replacement_agent: Your replacement request for order 12345 (damaged item) will be processed, and shipped to your curre...
    delivery_agent: I've forwarded your request for a replacement of the damaged item from order 12345 to our team and a...
    billing_agent: Thank you for the information. I've forwarded your request to our support team to arrange a replacem...
    ============================
    [status] IDLE_WITH_PENDING_REQUESTS

    [User]: Great! Can you confirm the shipping cost won't be charged again?


    === Final Conversation ===
    - user: I need help with order 12345. I want a replacement and need to know when it will arrive.
    - triage_agent: I'm connecting you to our replacement team to assist with your request, and to our delivery team for updates on when your replacement will arrive. They'll help you shortly!
    - replacement_agent: To assist with your replacement for order 12345 and provide tracking details for delivery, I've reached out to our teams. Can you please provide the reason for your replacement request? This will help to process things faster.
    - delivery_agent: I'm handing over your request for a replacement of order 12345, as well as your inquiry about estimated delivery timing, to the appropriate team. They'll assist you further with the replacement and delivery details very soon.
    - billing_agent: I handle billing and payment questions. For replacement and delivery details for order 12345, please contact our support team or the order department. Is there a billing or payment issue I can help you with?
    - user: I need help with order 12345. I want a replacement and need to know when it will arrive.
    - triage_agent: I'm connecting you with our replacement team to help with your request, and our delivery team for information about when your replacement will arrive. They'll assist you shortly!
    - user: The item arrived damaged. I'd like a replacement shipped to the same address.
    - triage_agent: Thank you for letting us know your item from order 12345 arrived damaged. I'm connecting you to our replacement team to arrange a replacement shipped to your address, and to our delivery team to update you on the arrival date of your replacement. They'll assist you shortly!
    - replacement_agent: Your replacement request for order 12345 (damaged item) will be processed, and shipped to your current address. The delivery team will also provide tracking and estimated arrival details for your new item soon.
    - delivery_agent: I've forwarded your request for a replacement of the damaged item from order 12345 to our team and asked them to ship it to your current address. You'll also receive tracking information and an estimated delivery date for the replacement soon.
    - billing_agent: Thank you for the information. I've forwarded your request to our support team to arrange a replacement for the damaged item from order 12345. Your replacement will be shipped to the same address, and you'll receive delivery updates soon. If you need a refund instead or have any billing questions, please let me know.
    - user: Great! Can you confirm the shipping cost won't be charged again?
    ==========================
    [status] IDLE
    """  # noqa: E501


if __name__ == "__main__":
    asyncio.run(main())
