"""Azure AI Search agent tool sample using Agent Framework.

This module can be imported as `agentfx.aisearch` or executed directly:

	python -m agentfx.aisearch "your question"
or (from repo root):
	python .\agentfx\aisearch.py "your question"

Agent Behavior:
	The agent searches Azure AI Search index using vector queries, retrieves top 3 documents,
	and provides answers with citations from the indexed content.
"""

from __future__ import annotations

import os
import sys
import asyncio
from dotenv import load_dotenv
from azure.identity.aio import AzureCliCredential
from azure.ai.agents.models import AzureAISearchQueryType
from agent_framework import ChatAgent, HostedFileSearchTool
from agent_framework.azure import AzureAIAgentClient

if __name__ == "__main__":
	repo_root = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
	if repo_root not in sys.path:
		sys.path.insert(0, repo_root)

from helper.agent_config_loader import load_agent_config, AgentConfigError
from helper.emitter import create_emitter

load_dotenv()

project_endpoint = os.getenv("AZURE_AI_PROJECT_ENDPOINT")
model_deployment_name = os.getenv("AZURE_AI_MODEL_DEPLOYMENT_NAME")
ai_search_index_name = os.getenv("AZURE_AI_SEARCH_INDEX_NAME")

DEFAULT_QUESTION = "tell me the Compliance Hotline"
DEFAULT_QUESTION1 = "tell me some medical benefits"


async def run_azure_ai_search(
	question: str | None = None,
	emitter: callable | None = None,
	return_mode: str = "log",
	save_json: str | os.PathLike | None = None,
) -> str | dict:
	"""Execute an Azure AI Search query using an agent with Agent Framework.

	The agent queries Azure AI Search index using vector search and returns answers with citations.
	
	Execution Flow:
	1. Initialize answer storage
	2. Setup emitter for progress tracking
	3. Validate and default question input
	4. Validate Azure project configuration (endpoint, model, search index)
	5. Create Azure AI Search tool with vector query configuration
	6. Load agent configuration from YAML file
	7. Initialize AzureAIAgentClient with async credential
	8. Create ChatAgent with search tool
	9. Execute agent with question
	10. Collect agent response
	11. Clean up credentials
	12. Format return payload based on return_mode
	13. Save JSON artifact if requested

	Parameters
	----------
	question: Optional question text. Uses DEFAULT_QUESTION if blank.
	emitter: Optional callback(string) for incremental UI updates.
	return_mode: Controls return payload:
		'answer' -> answer text (fallback to log if empty)
		'log'    -> full log only (default for backward compatibility)
		'both'   -> dict { 'output_text': str, 'answer': str, 'log': str }
	save_json: Optional path to persist JSON artefact (best when return_mode='both').

	Returns
	-------
	str | dict depending on `return_mode`.
	"""

	# STEP 1: Initialize answer storage
	# Why? Collect response fragments from Agent Framework ChatAgent
	answer_fragments: list[str] = []

	# STEP 2: Setup emitter for progress tracking
	# Why? Provides real-time feedback during Agent Framework async operations
	emit_util = create_emitter(emitter)
	emit = emit_util.emit

	# STEP 3: Validate and default question input
	# Why? Defensive programming - handle empty/None input gracefully
	# STEP 3: Validate and default question input
	# Why? Defensive programming - handle empty/None input gracefully
	if question is None or not question.strip():
		question = DEFAULT_QUESTION

	# STEP 4: Validate Azure project configuration (endpoint, model, search index)
	# Why? Fail fast if environment variables missing - prevents confusing downstream errors
	if not project_endpoint or not model_deployment_name or not ai_search_index_name:
		emit(
			"[ERROR] Please set PROJECT_ENDPOINT, MODEL_DEPLOYMENT_NAME, and AZURE_AI_SEARCH_INDEX_NAME in your environment/.env"
		)
		log_joined = emit_util.get_log()
		return log_joined if return_mode != "both" else {"output_text": log_joined, "answer": log_joined, "log": log_joined}

	# STEP 5: Initialize Agent Framework client
	# Why? Entry point for Agent Framework async operations
	emit("Azure AI Agent Client initializing...")
	
	try:
		# STEP 6: Create Azure AI Search tool with vector query configuration
		# Why? HostedFileSearchTool with vector search and top_k=3 for relevant document retrieval
		azure_ai_search_tool = HostedFileSearchTool(
			additional_properties1={
				"index_name": ai_search_index_name,
				"query_type": AzureAISearchQueryType.VECTOR, 
				"top_k": 3,
			},
		)
		emit(f"Created Azure AI Search tool for index: {ai_search_index_name}")

		# STEP 7: Load agent configuration from YAML file with error handling
		# Why? Dynamic config loading allows separation of prompts from code, validate before agent creation
		try:
			emit("Loading agent configuration...")
			pyfile_name = os.path.splitext(os.path.basename(__file__))[0]
			agent_name, agent_instructions, agent_description = load_agent_config(pyfile_name)
			# Agent will: (1) Search Azure AI index using vector queries for top 3 documents
			#             (2) Analyze retrieved content and extract citations from search results
			#             (3) Generate answers with proper citations and references to source documents
			emit(f"Loaded agent configuration: {agent_name}")
		except AgentConfigError as cfg_err:
			emit(f"[ERROR] {cfg_err}")
			log_joined = emit_util.get_log()
			return log_joined if return_mode != "both" else {"output_text": log_joined, "answer": log_joined, "log": log_joined}

		emit("[AGENT CONFIG] Loaded configuration for aisearch agent")

		# STEP 8: Initialize AzureAIAgentClient with async credential as context manager
		# Why? Agent Framework requires async credential, context manager ensures proper cleanup
		credential = AzureCliCredential()
		try:
			async with (
				AzureAIAgentClient(
					endpoint=project_endpoint,
					async_credential=credential
				) as client,
				# STEP 9: Create ChatAgent with search tool as nested context manager
				# Why? ChatAgent manages agent lifecycle and tool integration within Agent Framework
				ChatAgent(
					chat_client=client,
					name=agent_name,
					instructions=agent_instructions,
					description=agent_description,
					model=model_deployment_name,
					tools=azure_ai_search_tool,
				) as agent,
			):
				emit(f"Created agent: {agent_name}")
				emit("[AGENT PROMPT]\n" + question)

				# STEP 10: Execute agent with question
				# Why? Async agent.run() triggers search tool execution and answer generation
				response = await agent.run(question)
				
				# STEP 11: Extract and collect agent response text
				# Why? Agent Framework response object may have .text attribute or require str conversion
				answer_text = response.text if hasattr(response, 'text') else str(response)
				if answer_text:
					answer_fragments.append(answer_text)
					emit("[AGENT OUTPUT]\n" + answer_text)

				emit("Agent execution completed")
		finally:
			# STEP 12: Clean up async credentials
			# Why? Ensure credential resources released even if exception occurred
			await credential.close()

	# STEP 13: Handle unexpected exceptions
	# Why? Capture any Agent Framework or async-related errors for debugging
	# STEP 13: Handle unexpected exceptions
	# Why? Capture any Agent Framework or async-related errors for debugging
	except Exception as exc:
		emit(f"[ERROR] Unexpected exception: {exc}")

	# STEP 14: Format answer and build return payload
	# Why? Join response fragments (Agent Framework typically returns single response)
	answer_joined = "".join(answer_fragments)
	log_joined = emit_util.get_log()

	# STEP 15: Build return payload based on return_mode
	# Why? Flexible output format - answer only, logs only, or both
	if return_mode == "both":
		payload = {"output_text": answer_joined or log_joined, "answer": answer_joined, "log": log_joined}
	elif return_mode == "answer":
		payload = answer_joined if answer_joined else log_joined
	else:
		payload = log_joined

	# STEP 16: Save JSON artifact if requested with graceful degradation
	# Why? Persist results for downstream processing, handle save failures gracefully
	if save_json:
		import json, pathlib
		try:
			p = pathlib.Path(save_json)
			p.parent.mkdir(parents=True, exist_ok=True)
			json.dump(
				{"output_text": answer_joined or log_joined, "answer": answer_joined, "log": log_joined},
				p.open('w', encoding='utf-8'),
				ensure_ascii=False,
				indent=2,
			)
		except Exception as save_exc:
			emit(f"[WARN] Failed to save JSON artefact: {save_exc}")
			log_joined = emit_util.get_log()
			# STEP 17: Update payload with warning if JSON save failed
			# Why? Ensure log reflects save failure for debugging
			if return_mode == "both":
				payload = {"output_text": answer_joined or log_joined, "answer": answer_joined, "log": log_joined}
			elif return_mode == "answer" and not answer_joined:
				payload = log_joined

	return payload


if __name__ == "__main__":
	question_arg = sys.argv[1] if len(sys.argv) > 1 and sys.argv[1].strip() else DEFAULT_QUESTION
	asyncio.run(run_azure_ai_search(question_arg))
