"""Shared Agent Configuration Loader - YAML-Based Agent Property Management.

Purpose:
--------
Provides centralized agent configuration loading from YAML files.
Eliminates hard-coded agent properties scattered across multiple files.

This module serves as configuration management compared to:
- Hard-coded values: Properties embedded in source code (maintenance nightmare)
- Environment variables: Flat key-value pairs (no structure, poor for multi-agent)
- JSON config: No comments, less human-friendly than YAML
- Database config: Overkill for static agent properties

Key Capabilities:
-----------------
1. YAML Configuration: Human-readable agent properties (name, instructions, description)
2. Multi-Agent Support: Single file with multiple sections (one per agent/tool)
3. Environment Override: AGENT_CONFIG_FILE env var for custom config paths
4. Lazy Resolution: Resolves config path at call time (supports late .env loading)
5. Validation: Checks required fields (name, instructions) with clear error messages
6. Path Expansion: Handles ~ (home directory) and relative paths automatically
7. Error Handling: Raises AgentConfigError with context for debugging

Architecture:
-------------
```
Application
    |
    v
load_agent_config(section)
    |
    +---> Resolve config file path
    |       |
    |       +---> Check AGENT_CONFIG_FILE env var
    |       +---> Fallback to "agent_config.yaml"
    |
    +---> Expand path (~, relative)
    |
    +---> Validate file exists
    |
    +---> Parse YAML (yaml.safe_load)
    |
    +---> Extract section (e.g., "azure_ai_search")
    |
    +---> Validate required fields (name, instructions)
    |
    +---> Return (name, instructions, description)
```

YAML Configuration Structure:
------------------------------
File: config/agent_config.yaml (or path from AGENT_CONFIG_FILE)

```yaml
# Azure AI Search agent configuration
azure_ai_search:
  name: "Azure AI Search Agent"
  instructions: |
    You are an intelligent search agent.
    Help users find information using Azure AI Search.
  description: "Agent for knowledge base search using Azure AI Search"

# Bing Search agent configuration
bingsearch:
  name: "Bing Search Agent"
  instructions: "You are a web search agent with Bing search capability..."
  description: null  # Optional field

# Multiple agent configurations in one file
yahoosearch:
  name: "Yahoo Search Agent"
  instructions: "Perform web searches using Yahoo..."
```

Why YAML Over JSON?
-------------------
✓ Comments: Document configuration inline (#-style comments)
✓ Multiline Strings: | for instructions (better readability)
✓ Human-Friendly: More readable for non-developers
✓ No Trailing Commas: Less syntax errors
✗ Parsing Overhead: Slightly slower than JSON (negligible)

Section-Based Organization:
----------------------------
Each agent/tool has its own section (key) in YAML:
- Section name: Identifies the agent (e.g., "azure_ai_search")
- name: Display name for the agent
- instructions: System prompt / behavior instructions
- description: Optional agent description (may be None)

Why Sections?
- Centralized: All agent configs in one file
- Scoped: Changes to one agent don't affect others
- Discoverable: Easy to see all agents at a glance

Environment Override Pattern:
------------------------------
Default: "agent_config.yaml" (in current directory)
Override: Set AGENT_CONFIG_FILE=/path/to/custom.yaml

Why Allow Override?
- Testing: Use different configs for dev/staging/prod
- Multi-Tenant: Different agent configs per customer
- CI/CD: Inject config paths via environment

Lazy Path Resolution:
---------------------
_resolve_default_config_file() reads env var at *call time*, not import time.

Why Lazy?
- Allows python-dotenv to load .env *after* importing this module
- Pattern:
  ```python
  from agent_config_loader import load_agent_config  # Import first
  from dotenv import load_dotenv
  load_dotenv()  # Load env vars after import
  config = load_agent_config('bingsearch')  # Now reads AGENT_CONFIG_FILE
  ```

Path Expansion Details:
-----------------------
Handles:
1. ~ (tilde): Expands to user home directory
   - Example: ~/configs/agents.yaml → /home/user/configs/agents.yaml
2. Relative paths: Converts to absolute based on current directory
   - Example: config/agents.yaml → /workspace/config/agents.yaml
3. Absolute paths: Used as-is
   - Example: /etc/agents/config.yaml (unchanged)

Why Expand?
- Consistency: All paths normalized to absolute
- Existence checks: os.path.isfile() more reliable with absolute paths
- Error messages: Show full path in errors (easier debugging)

Validation Strategy:
--------------------
Two-tier validation:
1. File-level: Check file exists, valid YAML syntax
2. Section-level: Check section exists, required fields present

Required fields:
- name: Agent display name (must be non-empty string)
- instructions: Agent behavior instructions (must be non-empty string)

Optional fields:
- description: Agent description (can be None or empty)

Why Strict Validation?
- Fail Fast: Catch config errors at startup, not during execution
- Clear Errors: Specific error messages guide users to fix
- Prevents Silent Failures: Missing instructions → broken agent

Error Handling Pattern:
-----------------------
All errors raise AgentConfigError with context:
- File not found: Shows expected path, suggests AGENT_CONFIG_FILE
- YAML parse error: Shows original yaml.YAMLError details
- Missing section: Lists available sections (future enhancement)
- Missing fields: Lists exactly which fields are missing

Why Custom Exception?
- Distinguishes config errors from other exceptions
- Callers can catch AgentConfigError specifically
- Provides structured error information

Example Usage:
--------------
```python
# Basic usage (default config file)
from helper.agent_config_loader import load_agent_config

name, instructions, description = load_agent_config('azure_ai_search')
print(f"Agent: {name}")
print(f"Instructions: {instructions}")

# Custom config file
name, instructions, desc = load_agent_config(
    'bingsearch',
    config_file='/path/to/custom.yaml'
)

# With environment override
import os
os.environ['AGENT_CONFIG_FILE'] = 'prod_agents.yaml'
name, instructions, desc = load_agent_config('yahoosearch')

# Error handling
try:
    name, instructions, desc = load_agent_config('nonexistent')
except AgentConfigError as e:
    print(f"Config error: {e}")
```

Performance Considerations:
---------------------------
- File read: ~1-10ms (depends on file size)
- YAML parsing: ~5-20ms (depends on complexity)
- Total: ~10-30ms per load_agent_config() call
- Caching: Not implemented (load on-demand)

Why No Caching?
- Config changes during development (want fresh reads)
- Low call frequency (typically once per agent initialization)
- Memory footprint minimal (few agents)

Best Practices:
---------------
1. Use comments in YAML to document agent purposes
2. Keep instructions concise but complete
3. Use multiline strings (|) for long instructions
4. Test config file syntax with YAML linter
5. Version control config files (track agent changes)

Security Considerations:
------------------------
- YAML safe_load: Prevents code execution attacks
- No secrets: Don't store API keys in agent config
- File permissions: Ensure config file readable by application
- Path traversal: os.path.expanduser() handles ~ safely

Limitations:
------------
- No schema validation (just field presence checks)
- No config reload (requires restart)
- No default values for optional fields
- No nested sections (flat structure)

Related Modules:
----------------
- helper/agent_trace_configurator.py: Agent tracing configuration
- config/agent_config.yaml: Default configuration file
- config/agentic_config.yaml: Alternative config for agentic workflows

Future Enhancements:
--------------------
- JSON schema validation for config structure
- Hot reload support (watch file changes)
- Default value injection for optional fields
- List available sections in error messages
"""

from __future__ import annotations
import os
from typing import Tuple, Optional
import yaml  # YAML parser (PyYAML library)

def _resolve_default_config_file() -> str:
    """Return the agent config file path with lazy environment variable resolution.

    Reads AGENT_CONFIG_FILE environment variable at *call time* (not import time).
    Falls back to "agent_config.yaml" if variable is unset.
    
    Why Lazy Resolution?
    --------------------
    Allows callers to load .env files (via python-dotenv) after importing this module.
    
    Pattern:
    ```python
    from agent_config_loader import load_agent_config  # Import (no env read yet)
    from dotenv import load_dotenv
    load_dotenv()  # Load environment variables from .env file
    config = load_agent_config('section')  # NOW reads AGENT_CONFIG_FILE
    ```
    
    Alternative (eager resolution):
    ```python
    # This would fail if .env loaded after import:
    DEFAULT_CONFIG = os.getenv("AGENT_CONFIG_FILE", "agent_config.yaml")  # Read at import time
    ```
    
    Returns:
        str: Path to agent config file (from env var or default "agent_config.yaml")
    
    Example:
        >>> os.environ['AGENT_CONFIG_FILE'] = '/custom/path.yaml'
        >>> _resolve_default_config_file()
        '/custom/path.yaml'
        
        >>> del os.environ['AGENT_CONFIG_FILE']
        >>> _resolve_default_config_file()
        'agent_config.yaml'
    """
    # Read environment variable at call time (lazy evaluation)
    # Default to "agent_config.yaml" in current directory
    # Why "agent_config.yaml"? Convention for agent configurations
    return os.getenv("AGENT_CONFIG_FILE", "agent_config.yaml")


class AgentConfigError(Exception):
    """Custom exception for agent configuration issues.
    
    Raised when:
    - Config file not found
    - YAML parsing fails
    - Required section missing
    - Required fields missing
    
    Why Custom Exception?
    ---------------------
    - Distinguishes config errors from other exceptions (ImportError, ValueError, etc.)
    - Allows specific error handling: try/except AgentConfigError
    - Provides structured error context for debugging
    
    Example:
        ```python
        try:
            config = load_agent_config('missing_section')
        except AgentConfigError as e:
            print(f"Config error: {e}")  # Specific config issue
        except Exception as e:
            print(f"Unexpected error: {e}")  # Other errors
        ```
    """


def load_agent_config(section: str, config_file: Optional[str] = None) -> Tuple[str, str, Optional[str]]:
    """Load agent configuration for a given section from YAML file.

    Reads YAML configuration file, extracts the specified section,
    validates required fields, and returns agent properties.
    
    Execution Flow:
    ---------------
    1. Resolve config file path (parameter > env var > default)
    2. Expand path (~ expansion, relative to absolute)
    3. Validate file exists
    4. Parse YAML content
    5. Extract section
    6. Validate required fields (name, instructions)
    7. Return tuple (name, instructions, description)

    Args:
        section (str): Section name to load from YAML (e.g., "azure_ai_search", "bingsearch")
                       Must match top-level key in YAML file
        
        config_file (str | None): Optional override for config file path
                                  If None, uses AGENT_CONFIG_FILE env var or "agent_config.yaml"
                                  Supports:
                                  - Absolute paths: /etc/agents/config.yaml
                                  - Relative paths: config/agents.yaml
                                  - Tilde expansion: ~/configs/agents.yaml

    Returns:
        Tuple[str, str, Optional[str]]: 
            - name (str): Agent display name (required, non-empty)
            - instructions (str): Agent behavior instructions (required, non-empty)
            - description (str | None): Agent description (optional, may be None)

    Raises:
        AgentConfigError: 
            - Config file not found at resolved path
            - YAML parsing failed (syntax error)
            - Section not found in config
            - Required field(s) missing (name, instructions)

    Example YAML Structure:
        ```yaml
        azure_ai_search:
          name: "Azure AI Search Agent"
          instructions: |
            You are an intelligent search agent.
            Help users find information using Azure AI Search.
          description: "Agent for Azure AI Search operations"
        
        bingsearch:
          name: "Bing Search Agent"
          instructions: "Perform web searches using Bing..."
          description: null  # Optional field
        ```

    Example Usage:
        ```python
        # Load with default config file
        name, instructions, desc = load_agent_config('azure_ai_search')
        print(f"Agent: {name}")
        
        # Load with custom config file
        name, instructions, desc = load_agent_config(
            'bingsearch',
            config_file='/custom/agents.yaml'
        )
        
        # Handle errors
        try:
            config = load_agent_config('unknown_section')
        except AgentConfigError as e:
            print(f"Configuration error: {e}")
        ```

    Performance:
        ~10-30ms per call (file read + YAML parse)
    
    Note:
        Description field is optional and may be None if not specified in YAML.
        Name and instructions are required and must be non-empty strings.
    """
    # STEP 1: Resolve config file path
    # Priority: config_file parameter > AGENT_CONFIG_FILE env var > "agent_config.yaml"
    cfg_path = config_file or _resolve_default_config_file()
    
    # STEP 2: Expand and normalize path
    # Expand user (~) and convert relative to absolute for robust file checks
    # Why not just use cfg_path? Relative paths may fail existence checks in some contexts
    # os.path.expanduser(): Converts ~ to /home/username (Unix) or C:\Users\username (Windows)
    # os.path.abspath(): Converts relative to absolute based on current working directory
    # isabs() check: Skip expansion if already absolute (performance optimization)
    cfg_path = os.path.abspath(os.path.expanduser(cfg_path)) if not os.path.isabs(cfg_path) else cfg_path
    
    # STEP 3: Validate file exists
    # Why check first? Provide clear "file not found" error before attempting parse
    if not os.path.isfile(cfg_path):
        # File doesn't exist - raise descriptive error
        # Error includes: actual path checked, suggestions for resolution
        raise AgentConfigError(
            f"Agent config file not found at '{cfg_path}'. Set AGENT_CONFIG_FILE or create the file."
        )
    
    # STEP 4: Parse YAML file
    try:
        # Open with UTF-8 encoding for international characters
        # Why UTF-8? Supports multi-language instructions, descriptions
        with open(cfg_path, 'r', encoding='utf-8') as f:
            # yaml.safe_load(): Parse YAML safely (prevents code execution)
            # Why safe_load? Avoids arbitrary Python object instantiation (security)
            # or {}: Handle empty file gracefully (returns None, default to empty dict)
            data = yaml.safe_load(f) or {}
    except yaml.YAMLError as exc:
        # YAML syntax error (invalid structure, indentation, etc.)
        # Raise with original error details for debugging
        raise AgentConfigError(f"Failed to parse YAML config '{cfg_path}': {exc}") from exc

    # STEP 5: Check section exists in config
    # Why check? Provide clear error if section name typo or config mismatch
    if section not in data:
        # Section not found - raise with section name for clarity
        # Future enhancement: List available sections in error message
        raise AgentConfigError(f"Section '{section}' not found in agent config '{cfg_path}'.")

    # STEP 6: Extract section data
    # or {}: Handle null section gracefully (YAML allows null values)
    sec = data[section] or {}
    
    # Get field values with .get() (returns None if missing)
    name = sec.get('name')
    instructions = sec.get('instructions')
    description = sec.get('description')  # Optional field
    
    # STEP 7: Validate required fields
    # List comprehension: Collect missing required fields
    # Why list? Can show multiple missing fields in one error message
    missing = [k for k, v in (('name', name), ('instructions', instructions)) if not v]
    
    if missing:
        # One or more required fields missing or empty
        # ', '.join(missing): Format list as "name, instructions" (user-friendly)
        raise AgentConfigError(
            f"Missing required field(s) in section '{section}': {', '.join(missing)}"
        )
    
    # STEP 8: Return validated configuration
    # Tuple order: (name, instructions, description)
    # description may be None (optional field)
    return name, instructions, description
