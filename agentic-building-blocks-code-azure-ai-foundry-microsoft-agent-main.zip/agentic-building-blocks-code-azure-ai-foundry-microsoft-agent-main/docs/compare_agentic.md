# Comparison: Agent vs Agentic Architecture for URL Summarization

## Overview

This document analyzes the architectural differences between two URL summarization implementations, explains the execution sequence, and shows why the agentic version delivers more insightful context.

## Implementation Comparison

### File Structure

| Component | Agent Version | Agentic Version |
|-----------|---------------|-----------------|
| Implementation | `agent/summariseURL.py` | `agentic/summariseURL.py` |
| Configuration | `config/agent_config.yaml` | `config/agentic_config.yaml` |

---

## Detailed Execution Sequence

### Agent Version (`agent/summariseURL.py`) - Sequential Two-Stage

```
┌─────────────────────────────────────────────────────────────────────┐
│ STAGE 1: URL Identification (Understanding Agent)                   │
└─────────────────────────────────────────────────────────────────────┘
1. User provides question: "Compare azure.com and aws.com"
2. Understanding Agent analyzes question using LLM
3. Understanding Agent extracts URLs: ["azure.com", "aws.com"]
4. Understanding Agent refines question
5. **Python code** calls extract_content_from_url() for EACH URL
   └─> helper/fetchurl.py::extract_content_from_url(url)
       Returns: (content, content_type, response_code)

┌─────────────────────────────────────────────────────────────────────┐
│ STAGE 2: Independent Summarization (Separate Summarizer Agents)     │
└─────────────────────────────────────────────────────────────────────┘
6. For URL #1 (azure.com):
   └─> Create NEW Summarizer Agent instance
   └─> Agent receives: URL + fetched content + refined question
   └─> Agent generates Summary A
   └─> DELETE agent

7. For URL #2 (aws.com):
   └─> Create ANOTHER NEW Summarizer Agent instance
   └─> Agent receives: URL + fetched content + refined question
   └─> Agent generates Summary B (NO knowledge of Summary A)
   └─> DELETE agent

┌─────────────────────────────────────────────────────────────────────┐
│ STAGE 3: Simple Concatenation (No Synthesis)                        │
└─────────────────────────────────────────────────────────────────────┘
8. Python code concatenates: Summary A + "\n\n#####\n\n" + Summary B
9. Return combined text (NO cross-URL analysis or comparison)
```

**Key Points:**
- ❌ **NO coordinator agent** - Python code handles orchestration
- ❌ **Separate agent instances** - Each summarizer is independent
- ❌ **NO agent calls extract_content_from_url** - Python code does this directly
- ❌ **NO aggregation phase** - Simple string concatenation
- ❌ **NO context sharing** - URL #2's agent doesn't know about URL #1

---

### Agentic Version (`agentic/summariseURL.py`) - Connected Agents

```
┌─────────────────────────────────────────────────────────────────────┐
│ INITIALIZATION: Create Agent Architecture                           │
└─────────────────────────────────────────────────────────────────────┘
1. Create URL Summarizer Agent (will be reused)
2. Wrap it as ConnectedAgentTool
3. Create Coordinator Agent with connected tool
4. Create single conversation thread

┌─────────────────────────────────────────────────────────────────────┐
│ PHASE 1: URL Identification (Coordinator Agent)                     │
└─────────────────────────────────────────────────────────────────────┘
5. User question sent to thread: "Compare azure.com and aws.com"
6. Coordinator Agent (Run #1) analyzes question
   └─> LLM identifies URLs intelligently from natural language
   └─> Returns: "https://azure.com, https://aws.com"
7. **Python code** extracts URLs using regex from coordinator response
   └─> NO agent tool call - Python regex parsing

┌─────────────────────────────────────────────────────────────────────┐
│ PHASE 2: URL Content Fetching (Python Code, NOT Agent)              │
└─────────────────────────────────────────────────────────────────────┘
8. For EACH identified URL:
   └─> **Python code** calls extract_content_from_url(url)
       └─> helper/fetchurl.py::extract_content_from_url(url)
           Returns: (content, content_type, response_code)
   
   └─> Python code creates message with fetched content
   └─> Message added to thread as USER message

   IMPORTANT: Agents do NOT call extract_content_from_url()
             fetch_url_content_tool_function() is NEVER used

┌─────────────────────────────────────────────────────────────────────┐
│ PHASE 3: URL Analysis (Coordinator May Delegate to Connected Agent) │
└─────────────────────────────────────────────────────────────────────┘
9. For URL #1 (azure.com):
   User Message: "Analyze this URL: azure.com\nContent: [...content...]"
   
   └─> Coordinator Agent (Run #2) processes message
       ├─> Option A: Coordinator summarizes directly
       └─> Option B: Coordinator DELEGATES to Connected URL Summarizer
           └─> Connected Agent Run (URL Summarizer)
           └─> Returns summary to coordinator
   
   └─> Coordinator adds summary to thread context

10. For URL #2 (aws.com):
    User Message: "Analyze this URL: aws.com\nContent: [...content...]"
    
    └─> Coordinator Agent (Run #3) processes message
        ├─> HAS ACCESS to URL #1's summary in thread history
        └─> May delegate to Connected URL Summarizer again
            └─> Connected Agent receives SAME context
            └─> Knows about URL #1's analysis
        
        └─> Coordinator adds summary to thread context

┌─────────────────────────────────────────────────────────────────────┐
│ PHASE 4: Final Aggregation (Coordinator Synthesizes Results)        │
└─────────────────────────────────────────────────────────────────────┘
11. Python code sends aggregation message to thread:
    "You have processed 2 URLs. Provide comprehensive response that:
     1. Aggregates all summaries
     2. Compares and contrasts content
     3. Addresses original question
     4. Provides key insights"

12. Coordinator Agent (Run #4) executes final synthesis
    └─> Reviews ALL summaries in thread history
    └─> Performs cross-URL comparison
    └─> Generates unified narrative with insights
    └─> Returns final comprehensive response

13. Cleanup: Delete both agents
```

**Key Points:**
- ✅ **Coordinator agent orchestrates** - Main workflow controller
- ✅ **Connected agent architecture** - URL Summarizer reused with shared context
- ✅ **Python code fetches URLs** - NOT done by agents (fetch_url_content_tool_function unused)
- ✅ **Explicit aggregation phase** - Coordinator synthesizes all findings
- ✅ **Full context sharing** - All summaries visible in thread history

---

## Critical Clarification: Who Calls `extract_content_from_url()`?

### ⚠️ **Python Code, NOT Agents**

Both implementations follow the same pattern for URL fetching:

```python
# In both agent/summariseURL.py and agentic/summariseURL.py:

for url in identified_urls:
    # PYTHON CODE (not an agent) calls the helper function
    content, content_type, response_code = extract_content_from_url(url)
    
    # Content is then passed to agent as a USER message
    agents_client.messages.create(
        thread_id=thread.id,
        role="user",
        content=f"URL: {url}\n\nContent:\n{content}"
    )
```

### Why Not Use Agent Tool Call?

The `fetch_url_content_tool_function` exists in `agentic/summariseURL.py` (lines 49-78) but is **NEVER registered** with any agent. This is by design:

**Advantages of Python-side fetching:**
1. **Reliability** - Direct HTTP requests vs unreliable agent tool calls
2. **Error handling** - Python can retry, handle timeouts explicitly
3. **Performance** - Parallel fetching possible (future enhancement)
4. **Token efficiency** - No LLM tokens spent on URL fetching logic
5. **Separation of concerns** - Agents focus on analysis, not web scraping

---

### 1. Orchestration Control

#### **Agent Version** (Python Orchestrates)
```
User Question → Understanding Agent → Summarizer Agent(s) → Individual Summaries
                 (extracts URLs)      (one per URL)         (no synthesis)
```

**Characteristics:**
- Stage 1: Understanding agent extracts URLs and refines question
- Stage 2: **Separate** summarizer agents process each URL independently
- No inter-agent communication during summarization
- No aggregation or synthesis of results

#### **Agentic Version** (Connected Agents with Orchestration)
```
User Question → Coordinator Agent → URL Summarizer Agent → Final Aggregation
                 (orchestrates)      (called multiple     (synthesis &
                                      times, maintains     comparison)
                                      context)
```

**Characteristics:**
- Coordinator agent orchestrates entire workflow
- **Connected** URL summarizer agent called multiple times with shared context
- Explicit aggregation and synthesis phase
- Cross-URL comparison and analysis

---

## 2. Instruction Quality Differences

### Understanding/Coordinator Instructions

#### **agent_config.yaml** (Basic)
```yaml
understanding:
  instructions: >-
    1. ANALYZE USER QUESTIONS
    2. INTELLIGENT URL EXTRACTION
    3. SEQUENTIAL URL PROCESSING
    4. Return two output strings: 
      - refined user question
      - repaired URLs
```

**Limitations:**
- Only focuses on URL extraction and question refinement
- No guidance for synthesis or aggregation
- No cross-URL analysis

#### **agentic_config.yaml** (Comprehensive)
```yaml
coordinator:
  instructions: |
    1. UNDERSTAND user question and extract/repair URLs
    2. DELEGATE each URL to connected summarizer agent
    3. COLLECT all individual summaries
    4. COMPARE AND CONTRAST content from multiple URLs
    5. AGGREGATE RESULTS into comprehensive, coherent response
    
    After processing ALL URLs:
    - Compile all summaries into final comprehensive response
    - Compare and contrast content from multiple URLs when appropriate
    - Highlight connections, contradictions, or complementary information
```

**Advantages:**
- Explicit aggregation step included in workflow
- Cross-URL comparison directive
- Synthesis guidance for coherent final response

---

### Summarizer Instructions

#### **agent_config.yaml** (Simple)
```yaml
summariser:
  instructions: >-
    Summarise the fetched content for URL: {url} based on the focuses 
    from the user question: {original_question}. 
    
    Word limit: <= {MAX_WORDS_PER_URL} words.
    The summary should be concise and focused on the key points.
```

**Characteristics:**
- Generic summarization instruction
- Word count limit
- No structural framework

#### **agentic_config.yaml** (Structured Framework)
```yaml
url_summarizer:
  instructions: |
    Analyze and summarize using this 4-part framework:
    
    1) **What it is** - Identify and describe the content/resource
       - What type of resource is this?
       - What is the main topic or subject?
    
    2) **Why it matters** - Explain relevance and importance
       - Why is this content significant?
       - What problems does it solve?
    
    3) **How it works** - Describe functionality, processes, mechanisms
       - What are the key features or components?
       - What methods or approaches are described?
    
    4) **Key Insights** - Highlight most important takeaways
       - What are the most critical points to remember?
       - What actionable insights can be derived?
```

**Advantages:**
- Structured 4-part analytical framework
- Guides deeper analysis beyond surface-level summarization
- Ensures comprehensive coverage of important aspects
- Promotes actionable insights

---

## 3. Workflow Orchestration

### Agent Version Workflow

```python
# Stage 1: Understanding
urls_str, refined_question = understanding_agent.run(user_question)

# Stage 2: Independent summarization
summaries = []
for url in urls:
    summary = summarizer_agent.run(url, refined_question)
    summaries.append(summary)

# Return concatenated summaries (no synthesis)
return "\n\n".join(summaries)
```

**Issues:**
- Each URL processed in isolation
- No shared context between summarizers
- Simple concatenation of results
- Missing synthesis step

### Agentic Version Workflow

```python
# Stage 1: Coordinator understands and delegates
coordinator.initiate(user_question)

# Stage 2: Connected summarizer (maintains context)
for url in urls:
    coordinator.delegate_to_summarizer(url)

# Stage 3: EXPLICIT AGGREGATION
final_message = f"""
You have now processed all {total_urls} URLs...
Please provide a comprehensive final response that:
1. Aggregates all the URL summaries
2. Compares and contrasts the content when appropriate  
3. Addresses the user's specific question
4. Provides key insights relevant to what they were asking for
"""
coordinator.aggregate(final_message)
```

**Advantages:**
- Context maintained across all URLs
- Explicit aggregation message template
- Cross-URL comparison directive
- Coherent synthesis of all findings

---

## 4. Final Aggregation Phase

### **Critical Difference: agentic_config.yaml includes explicit aggregation**

```yaml
messages:
  final_aggregation: >-
    You have now processed all {total_urls} URLs. 
    
    Please provide a comprehensive final response that:
    
    1. **Aggregates** all the URL summaries you generated
    2. **Compares and contrasts** the content from different URLs when appropriate
    3. **Addresses** the user's original question: "{original_question}"
    4. **Provides key insights** that are most relevant to what they were asking for
    
    Your final response should be well-organized, coherent, and provide a 
    synthesized view that helps the user understand the complete picture across 
    all the URLs they asked about.
```

**The agent version completely lacks this aggregation phase.**

---

## 5. Context Preservation and Synthesis

### Agent Version (Limited Context)

```
URL 1 → Summarizer Agent Instance 1 → Summary A
URL 2 → Summarizer Agent Instance 2 → Summary B  [No knowledge of Summary A]
URL 3 → Summarizer Agent Instance 3 → Summary C  [No knowledge of A or B]

Final Output = Summary A + Summary B + Summary C (concatenated)
```

**Result:** Isolated summaries with no cross-URL insights

### Agentic Version (Shared Context)

```
                  ┌─→ Process URL 1 → Summary A ─┐
                  │                               │
Coordinator ──────┼─→ Process URL 2 → Summary B ─┼──→ Aggregation → Synthesized
(maintains        │   (knows about A)             │    (compares    Response
context)          │                               │     A, B, C)
                  └─→ Process URL 3 → Summary C ─┘
                      (knows about A, B)
```

**Result:** Comparative analysis with cross-URL insights and coherent narrative

---

## Why Agentic Version Delivers More Insightful Context

### Summary of Advantages

| Aspect | Agent Version | Agentic Version |
|--------|---------------|-----------------|
| **Summarization Framework** | Generic instruction | 4-part What/Why/How/Insights structure |
| **Cross-URL Analysis** | None | Explicit comparison and contrast |
| **Context Sharing** | Isolated agents | Connected coordinator maintains context |
| **Aggregation Phase** | Simple concatenation | Comprehensive synthesis with final message |
| **Workflow Guidance** | Extract URLs → Summarize | Understand → Delegate → Collect → Compare → Aggregate |
| **Output Quality** | Individual summaries | Unified narrative with insights |

### The Five Critical Factors

1. **Explicit Aggregation Phase** - Final message template specifically requests comprehensive synthesis and cross-URL comparison

2. **Structured Summary Framework** - 4-part "What/Why/How/Insights" format guides deeper analytical thinking beyond surface-level summarization

3. **Connected Architecture** - Coordinator maintains full conversation context across all URLs, enabling comparative analysis

4. **Comparison Directive** - Instructions explicitly ask to "compare and contrast content from multiple URLs when appropriate"

5. **Coherent Synthesis** - Final aggregation creates a unified narrative addressing the user's original question, rather than isolated summaries

---

## Practical Example

### User Question
"Summarize these Azure AI tutorials: [URL1: Agents SDK], [URL2: Prompt Flow], [URL3: Model Catalog]"

### Agent Version Output
```
Summary for URL1: The Agents SDK allows building AI agents...

#####

Summary for URL2: Prompt Flow is a tool for orchestrating...

#####

Summary for URL3: Model Catalog provides access to...
```
*(Three separate summaries, no connection)*

### Agentic Version Output
```
Summary for URL1 - What/Why/How/Insights for Agents SDK...

Summary for URL2 - What/Why/How/Insights for Prompt Flow...

Summary for URL3 - What/Why/How/Insights for Model Catalog...

COMPREHENSIVE ANALYSIS:
All three tutorials cover Azure AI development but serve different purposes:

- **Agents SDK** focuses on building autonomous agents with tool calling
- **Prompt Flow** emphasizes orchestration and testing of LLM workflows
- **Model Catalog** provides the foundation models used by both approaches

KEY INSIGHT: Use Model Catalog to select models → Develop with either 
Agents SDK (for autonomous agents) OR Prompt Flow (for controlled workflows) 
depending on your use case. Agents SDK offers more autonomy but less control, 
while Prompt Flow provides precise orchestration.

RECOMMENDATION: Start with Prompt Flow for predictable workflows, graduate 
to Agents SDK when you need autonomous decision-making capabilities.
```
*(Synthesized response with cross-URL comparison and actionable insights)*

---

## Conclusion

The **agentic version delivers more insightful context** because it:

1. Uses a **structured analytical framework** (What/Why/How/Insights) that promotes deeper thinking
2. Includes an **explicit aggregation phase** that synthesizes all findings
3. Employs a **connected coordinator architecture** that maintains context across all URLs
4. Provides **cross-URL comparison** through specific instructions
5. Generates a **coherent narrative** that addresses the user's original question holistically

The agent version simply concatenates independent summaries, while the agentic version orchestrates a comprehensive analysis with synthesis, comparison, and actionable insights.

---

*Document created: November 12, 2025*
