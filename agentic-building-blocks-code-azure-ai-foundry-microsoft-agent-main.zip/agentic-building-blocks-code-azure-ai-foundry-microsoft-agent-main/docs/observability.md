# AI Workflow Observability with OpenTelemetry

## What is AI Process Observability?

When AI agents execute complex workflows—like fanning out queries to multiple search engines or chaining multiple LLM calls—you need visibility into what's happening under the hood. **Observability** gives you that x-ray vision.

Think of it as flight recorders for your AI workflows: capturing timing, message flow, and execution patterns so you can debug failures, optimize performance, and understand your system's behavior.

## Why OpenTelemetry?

**OpenTelemetry** is the industry standard for distributed tracing. It captures "spans" (units of work) with:
- **Timing**: How long each operation took
- **Context**: What triggered it and what it triggered
- **Attributes**: Custom metadata (executor IDs, message types, etc.)

This is critical for AI workflows because:
- LLM calls are expensive and slow—you need to know where time goes
- Fan-out patterns create parallel execution—wall-clock time ≠ sum of operations
- Message routing between agents needs tracking for debugging

---

## 🎯 Unified Tracing with UnifiedTraceManager

This repository provides a **unified tracing system** through the `UnifiedTraceManager` class that supports multiple tracing modes:

| Tracing Mode | Description | When to Use |
|--------------|-------------|-------------|
| **`both`** (default) | Azure Monitor + Console simultaneously | Production debugging - see traces in portal AND console |
| **`auto`** | Auto-detect based on connection string | Legacy compatibility |
| **`azure_monitor`** | Send traces to Azure AI Foundry only | Production monitoring in Azure |
| **`console`** | Print traces to console only | Local development and testing |
| **`none`** | Disable tracing | Performance-critical scenarios |

---

## Implementation Patterns

### For Agent-Based Applications

Agent-based apps (using Azure AI Agents SDK) automatically instrument operations like `create_agent`, `create_thread`, `create_message`, etc.

#### 1. Basic Setup

```python
from helper.unified_trace_manager import UnifiedTraceManager
from helper.emitter import create_emitter

# Create emitter for logging
emit_util = create_emitter(emitter)
emit = emit_util.emit

# Setup unified tracing
trace_mgr = UnifiedTraceManager(
    tracing_mode="both",  # Default: both Azure Monitor and Console
    emitter=emit,
    trace_type="agent"    # Use "agent" for Azure AI Agents SDK
)
tracer, trace_collector = trace_mgr.setup()
```

#### 2. Create Parent Span

```python
# Start parent span for the entire operation
trace_mgr.start_parent_span(
    span_name=f"run_bing_search: {question[:50]}",
    attributes={
        "question": question,
        "tracing_mode": tracing_mode,
    }
)

try:
    # Your agent code here
    agent = agents_client.create_agent(...)  # Auto-instrumented
    thread = agents_client.threads.create()  # Auto-instrumented
    run = agents_client.runs.create_and_process(...)  # Auto-instrumented
    
except Exception as exc:
    trace_mgr.record_exception(exc)
finally:
    trace_mgr.end_parent_span()
```

#### 3. Collect and Display Traces

```python
# Get formatted traces
trace_lines, trace_summary = trace_mgr.get_traces()

# Display in console logs
if trace_lines:
    emit("=" * 50)
    emit("OPENTELEMETRY TRACE SUMMARY")
    emit("=" * 50)
    emit(f"Total Spans: {trace_summary.get('total_spans', 0)}")
    emit(f"Agent Spans: {trace_summary.get('agent_spans', 0)}")
    emit(f"Thread Spans: {trace_summary.get('thread_spans', 0)}")
    emit(f"Message Spans: {trace_summary.get('message_spans', 0)}")
    emit(f"Main Elapsed: {trace_summary.get('main_elapsed_ms', 0):.2f}ms")
    
    for line in trace_lines:
        emit(line)
    emit("=" * 50)

# Return traces for UI display
return {
    "output_text": result_text,
    "log": log_text,
    "traces": trace_lines,        # For Streamlit UI expander
    "trace_summary": trace_summary # For metrics display
}
```

#### Examples in This Repo
- `agent/bingsearch.py` - Bing search agent with tracing
- `agent/yahoosearch.py` - Yahoo search agent with tracing
- `agent/aisearch.py` - Azure AI Search agent with tracing
- `agent/emailwriter.py` - Email composition agent with tracing

---

### For Workflow-Based Applications

Workflow-based apps (using Agent Framework) capture workflow lifecycle, executor processing, and message passing.

#### 1. Basic Setup

```python
from helper.unified_trace_manager import UnifiedTraceManager

# Setup unified tracing for workflows
trace_mgr = UnifiedTraceManager(
    tracing_mode="both",
    emitter=emit,
    trace_type="workflow"  # Use "workflow" for Agent Framework
)
tracer, trace_collector = trace_mgr.setup()
```

#### 2. Create Parent Span and Run Workflow

```python
# Start parent span
trace_mgr.start_parent_span(
    span_name=f"blast_web_search: {query[:50]}",
    attributes={
        "query": query,
        "num_results": num_results,
    }
)

try:
    # Build and run workflow - automatically instrumented
    builder = WorkflowBuilder().set_start_executor(dispatcher)...
    workflow = builder.build()  # Emits workflow.build spans
    
    async for event in workflow.run_stream(request):  # Emits workflow.run spans
        # Process events
        pass
        
except Exception as exc:
    trace_mgr.record_exception(exc)
finally:
    trace_mgr.end_parent_span()

# Get traces
trace_lines, trace_summary = trace_mgr.get_traces()
```

**Span categories captured for workflows**:
- 🔨 `workflow.build` - Workflow graph construction
- ▶️ `workflow.run` - Workflow execution lifecycle
- ⚙️ `executor.process` - Individual executor processing
- 📨 `message.send` - Inter-executor communication

#### Examples in This Repo
- `workflow/blastwebsearch.py` - Parallel web search workflow
- `workflow/checkSumSendEmail.py` - Email processing workflow
- `workflow/handoff_bidirectional.py` - Multi-agent handoff workflow

---

## Configuration

### Environment Variables

Add to your `.env` file:

```bash
# Azure Monitor (optional - only needed for azure_monitor or both modes)
APPLICATIONINSIGHTS_CONNECTION_STRING=InstrumentationKey=xxxxx;IngestionEndpoint=https://xxxxx...

# Tracing mode (optional - defaults to "both")
TRACING_MODE=both  # Options: both, auto, azure_monitor, console, none
```

Get the connection string from: **Azure AI Foundry Portal** → **Your Project** → **Tracing** tab

### Tracing Modes Explained

```python
# Mode 1: Both Azure Monitor and Console (DEFAULT)
trace_mgr = UnifiedTraceManager(tracing_mode="both", ...)
# ✅ Sends traces to Azure AI Foundry Portal
# ✅ Displays formatted traces in console
# ✅ Best for: Production debugging

# Mode 2: Auto-detect
trace_mgr = UnifiedTraceManager(tracing_mode="auto", ...)
# ✅ Uses Azure Monitor if connection string exists, else console only
# ✅ Best for: Legacy compatibility

# Mode 3: Azure Monitor only
trace_mgr = UnifiedTraceManager(tracing_mode="azure_monitor", ...)
# ✅ Sends traces to Azure AI Foundry Portal only
# ✅ Best for: Production monitoring

# Mode 4: Console only
trace_mgr = UnifiedTraceManager(tracing_mode="console", ...)
# ✅ Displays formatted traces in console only
# ✅ Best for: Local development, testing

# Mode 5: No tracing
trace_mgr = UnifiedTraceManager(tracing_mode="none", ...)
# ✅ Disables all tracing
# ✅ Best for: Performance-critical scenarios
```

---

## What You Get

### Console Output (tracing_mode="console" or "both")

```
==================================================
OPENTELEMETRY TRACE SUMMARY
==================================================
Total Spans: 45
Agent Spans: 3
Thread Spans: 2
Message Spans: 18
Run Spans: 4
HTTP Spans: 12
Main Elapsed: 3247.89ms

🔍 [agent.create] Create agent: bing-search-agent (12.45ms)
🧵 [thread.create] Create thread: thread_abc123 (5.23ms)
💬 [message.create] Create message in thread_abc123 (8.12ms)
⚡ [run.create] Create run in thread_abc123 (1842.34ms)
📊 [http] POST /agents (234.56ms)
==================================================
```

### Azure AI Foundry Portal (tracing_mode="azure_monitor" or "both")

After running your workflow with Azure Monitor enabled:

1. Go to **https://ai.azure.com**
2. Select your AI Foundry project
3. Click **"Tracing"** tab
4. Find your trace by the descriptive name (e.g., "run_bing_search: tell me about Microsoft Azure AI")

**Features**:
- 🎨 Rich visualization with timeline view
- 🔍 KQL query support for advanced filtering
- 👥 Team access and collaboration
- 📊 Built-in performance analytics
- 🚨 Alerting and monitoring capabilities
- ⏰ 90-day retention (configurable)

### Streamlit UI Display

The `apps/query_handlers.py` displays traces in collapsible expanders:

```python
# In your query handler
result = run_bing_search(question, emitter=emit, return_mode="both")
trace_lines = result.get("traces", [])
trace_summary = result.get("trace_summary", {})

if trace_lines:
    with st.expander("Show OpenTelemetry Traces", expanded=False):
        # Show summary metrics
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Total Spans", trace_summary.get('total_spans', 0))
            st.metric("🤖 Agent Operations", trace_summary.get('agent_spans', 0))
        with col2:
            st.metric("🧵 Thread Operations", trace_summary.get('thread_spans', 0))
            st.metric("⚡ Run Operations", trace_summary.get('run_spans', 0))
        with col3:
            st.metric("💬 Message Operations", trace_summary.get('message_spans', 0))
            elapsed_ms = trace_summary.get('main_elapsed_ms', 0)
            st.metric("⏱️ Elapsed", f"{elapsed_ms:.0f}ms")
        
        # Show detailed traces
        for trace_line in trace_lines:
            st.text(trace_line)
```

---

## Performance Insights

### For Agent-Based Applications

- **Operation timing**: See exactly how long each SDK call takes
- **Bottleneck detection**: Identify which operations are slowest
- **Thread lifecycle**: Track thread creation and message processing
- **HTTP overhead**: Understand network latency

### For Workflow-Based Applications

- **Parallel efficiency**: Wall-clock time vs sum of spans shows parallelization gains
- **Message routing**: Track message flow between executors
- **Executor performance**: Compare processing times across different executors
- **Workflow overhead**: Measure framework overhead vs actual work

Example insights:
```
Wall-clock: 3.2s
Sum of spans: 8.9s
Parallelization gain: 2.8x speedup

Bottleneck: yahoo_searcher took 2.1s (slowest executor)
Message overhead: ~3ms total (negligible)
```

---

## Local Trace Storage

For workflows, traces can be saved locally for historical analysis:

```python
from helper.storeotel import store_otel_traces_to_local

trace_file_path, log = store_otel_traces_to_local(
    traces=trace_lines,
    trace_summary=trace_summary,
    query=search_query,
    metadata=trace_collector.get_metadata(),
    prefix='blast_search'
)
# Saves to: opentele_local/blast_search_20251023-143022.json
```

This allows you to:
- ✅ Compare performance across runs
- ✅ Track regression when code changes
- ✅ Analyze production behavior patterns offline
- ✅ Keep permanent records for compliance

---

## Migration from Old Code

If you have code using the old tracing approach, migrate to `UnifiedTraceManager`:

### Before (Old Approach)
```python
from helper.agent_trace_configurator import AgentTraceConfigurator

configurator = AgentTraceConfigurator(agents_client)
configurator.setup_tracing(choice=1)  # Azure Monitor
```

### After (New Approach)
```python
from helper.unified_trace_manager import UnifiedTraceManager

trace_mgr = UnifiedTraceManager(
    tracing_mode="both",  # or "azure_monitor", "console", "auto", "none"
    emitter=emit,
    trace_type="agent"
)
tracer, trace_collector = trace_mgr.setup()

trace_mgr.start_parent_span(span_name="my_operation", attributes={...})
try:
    # Your code
    pass
finally:
    trace_mgr.end_parent_span()

trace_lines, trace_summary = trace_mgr.get_traces()
```

---

## When to Use Tracing

✅ **Use tracing when**:
- Workflows involve multiple agents/executors
- Performance optimization is needed
- Debugging complex message flows
- Production monitoring is required
- You need to understand execution patterns

❌ **Skip it for**:
- Simple single-agent calls during prototyping
- Performance-critical scenarios where 5-10ms overhead matters
- Quick experiments where observability isn't needed

---

## Summary

The `UnifiedTraceManager` provides production-grade observability with:

✅ **Single interface** for all tracing needs (agent and workflow)
✅ **Multiple modes** (both, auto, azure_monitor, console, none)
✅ **Automatic instrumentation** for Azure AI Agents SDK and Agent Framework
✅ **Rich formatting** with emojis and hierarchical display
✅ **Streamlit integration** with expandable trace displays
✅ **Azure AI Foundry** portal integration for team collaboration
✅ **Local storage** for historical analysis
✅ **OpenTelemetry standard** - portable to any backend

Your AI workflows become **transparent, debuggable, and optimizable** with minimal code changes!
