"""Google Custom Search Helper Module - Official Google Search API Integration.

Purpose:
--------
Provides web search functionality using Google Custom Search API (official, paid service).
Returns structured search results with titles, URLs, and snippets.

This module serves as a production-grade search implementation compared to:
- helper/headlesssearch.py: Google Search via googlesearch-python (unreliable, anti-bot issues)
- helper/yahoosearch.py: Yahoo Search via web scraping (no API, HTML parsing)
- agent/bingsearch.py: Bing Search via Azure Cognitive Services API (Microsoft alternative)

Key Capabilities:
-----------------
1. Official Google API: Uses Google Custom Search JSON API (reliable, stable)
2. Authenticated Access: Requires API key and Search Engine ID (no anti-bot blocks)
3. Rich Metadata: Returns title, URL, snippet for each result
4. Region/Language Control: Supports geolocation (gl), language (hl) parameters
5. Emitter Pattern: Consistent logging/UI update integration with other modules
6. Return Mode Flexibility: Supports 'answer', 'log', 'both' return formats
7. JSON Persistence: Optional save_json parameter for result caching
8. CLI Interface: Standalone testing via command line

Architecture:
-------------
```
User/Agent
    |
    v
perform_google_search()
    |
    +---> Validate environment variables (API key, CX)
    |
    +---> Build HTTP request with parameters
    |       |
    |       +---> key: GCS_DEVELOPER_KEY (authentication)
    |       +---> cx: GCS_CX (search engine ID)
    |       +---> q: query string
    |       +---> num: result count
    |       +---> gl: geolocation (Hong Kong)
    |       +---> hl: language (Chinese)
    |
    +---> Send HTTPS request to Google API
    |
    +---> Parse JSON response
    |
    +---> Extract results (title, URL, snippet)
    |
    +---> Format results
    |
    +---> Return based on mode
    |
    +---> Optional JSON save
```

Google Custom Search API:
--------------------------
Endpoint: https://www.googleapis.com/customsearch/v1

Required Configuration:
1. GCS_DEVELOPER_KEY: API key from Google Cloud Console
   - Create at: https://console.cloud.google.com/apis/credentials
   - Enable "Custom Search API" in project
   - Quota: 100 queries/day (free tier), paid plans available

2. GCS_CX: Custom Search Engine ID
   - Create at: https://programmablesearchengine.google.com/
   - Configure search scope (entire web or specific sites)
   - Copy "Search engine ID" from control panel

Why Custom Search API?
-----------------------
Compared to googlesearch-python library (headlesssearch.py):
✓ Reliable: No anti-bot blocks, consistent results
✓ Official: Supported by Google, stable API contract
✓ Quota Management: Clear limits, can purchase more
✓ Rich Features: Region, language, safe search controls
✗ Cost: Free tier limited to 100 queries/day
✗ Setup: Requires API key and search engine configuration

Request Parameters:
-------------------
- key: GCS_DEVELOPER_KEY (authentication token)
- cx: GCS_CX (search engine identifier)
- q: Search query string
- num: Number of results (1-10 per request, max 10)
- safe: Safe search filter ('off', 'medium', 'high')
- gl: Geolocation (ISO country code, e.g., 'hk', 'us')
- googlehost: Google domain (e.g., 'google.com', 'google.co.uk')
- hl: Language for UI elements (e.g., 'zh', 'en')

Hong Kong Configuration:
------------------------
Current defaults:
- gl='hk': Geolocation set to Hong Kong
- googlehost='google.com': Use international Google
- hl='zh': Chinese language interface

Why these settings?
- gl='hk': Biases results toward Hong Kong region
- hl='zh': Returns snippets in Chinese when available
- Customizable via params dict modification

Response Structure:
-------------------
```json
{
  "items": [
    {
      "title": "Page Title",
      "link": "https://example.com/page",
      "snippet": "Brief description of the page content..."
    }
  ]
}
```

Error Handling:
---------------
- Missing API credentials: Error logged, returns empty results
- Network errors (timeout, connection): Logged, returns empty
- JSON parse errors: Logged, returns empty
- API errors (quota exceeded, invalid key): Logged with error message
- HTTP errors (4xx, 5xx): Logged with status code
- No results: Warning logged, success=False

All errors use emitter for consistent logging pattern.

Pattern Consistency with Other Search Modules:
-----------------------------------------------
Mirrors agent/bingsearch.py, helper/yahoosearch.py, helper/headlesssearch.py:
- emit(): Streams log messages to console or UI (Streamlit)
- output_texts: Collects formatted results for UI display (expander)
- return_mode: 'answer' | 'log' | 'both' for flexible return values
- save_json: Optional persistence of results

Comparison Table - Search Module Selection:
--------------------------------------------
| Module           | Method        | Reliability | Cost      | Auth Required | Rate Limits   | Region Control |
|------------------|---------------|-------------|-----------|---------------|---------------|----------------|
| gcptxtsearch     | Official API  | Very High   | Paid      | Yes (API key) | 100/day free  | Yes (gl param) |
| bingsearch       | Azure API     | Very High   | Paid      | Yes (API key) | Per tier      | Yes            |
| yahoosearch      | Web Scraping  | High        | Free      | No            | None (risky)  | No             |
| headlesssearch   | Library       | Low-Medium  | Free      | No            | None (blocked)| No             |

Use This Module When:
----------------------
- Need reliable, production-grade search
- Google search quality required (vs Bing)
- Can afford API costs or within free tier (100/day)
- Need region/language control
- Willing to set up API credentials

Avoid This Module If:
---------------------
- Cannot afford API costs
- Don't want to create Google Cloud account
- Query volume exceeds quota (>100/day without payment)
- Prefer Microsoft ecosystem (use bingsearch instead)
- Just need quick prototyping (use yahoosearch)

Dependencies:
-------------
- requests: HTTP client library
  Install: pip install requests
  Why: Make HTTPS requests to Google API
  
- python-dotenv: Environment variable loader
  Install: pip install python-dotenv
  Why: Load GCS_DEVELOPER_KEY and GCS_CX from .env file
  
- helper.emitter: Centralized logging/UI update utility
  Why: Consistent log pattern across modules

Environment Variables (.env file):
-----------------------------------
```
GCS_DEVELOPER_KEY=AIzaSyB...your_api_key_here
GCS_CX=a1b2c3d4e5f6g7h8
```

Performance Considerations:
---------------------------
- HTTP request: ~200-500ms (network dependent)
- JSON parsing: ~10-50ms
- Total: ~300-600ms typical
- Much faster than web scraping (no HTML parsing)

Best Practices:
---------------
1. Store API key in .env file (never commit to git)
2. Monitor quota usage in Google Cloud Console
3. Cache results when possible (use save_json)
4. Handle quota exceeded errors gracefully
5. Consider batch processing for multiple queries
6. Use safe='off' only when appropriate

Security Considerations:
------------------------
- API key is sensitive (restrict access in Google Cloud Console)
- Use HTTPS (enforced by googleapis.com)
- Validate results before displaying (XSS prevention)
- Don't log API key in emitter output
- Rotate API keys periodically

Example Usage:
--------------
```python
# Basic usage (requires .env with credentials)
from helper.gcptxtsearch import perform_google_search

results = perform_google_search("Python tutorials")
print(results)

# Get structured results
result_dict = perform_google_search(
    "machine learning",
    num_results=10,
    return_mode="both"
)
if result_dict['success']:
    print(result_dict['output_text'])
else:
    print("Error:", result_dict['log'])

# With Streamlit UI updates
from helper.emitter import create_emitter
import streamlit as st
emitter = create_emitter(lambda msg: st.write(msg))
results = perform_google_search(
    "web scraping",
    emitter=emitter.emit
)

# Save results to JSON
perform_google_search(
    "Claude AI",
    save_json="cache/google_results.json"
)

# CLI usage
$ export GCS_DEVELOPER_KEY=your_key
$ export GCS_CX=your_cx
$ python helper/gcptxtsearch.py "Python tutorials" 10
```

Limitations:
------------
- Requires Google Cloud account and API setup
- Free tier: 100 queries/day (paid plans for more)
- Maximum 10 results per request
- Cannot control ranking algorithm
- Subject to Google's terms of service

Related Modules:
----------------
- agent/bingsearch.py: Bing Search via Azure (Microsoft alternative)
- helper/yahoosearch.py: Yahoo Search via web scraping (no API)
- helper/headlesssearch.py: Google Search via library (unreliable)
- helper/fetchurl.py: URL content extraction after search
"""

import json
import os
import sys
import requests  # HTTP client for API requests
from typing import List, Dict, Tuple, Any, Callable
from dotenv import load_dotenv  # Load environment variables from .env file

if __name__ == "__main__":  # pragma: no cover - path adjustment logic
    # Path adjustment for CLI usage
    # Why: When run as script, need to import from parent directory
    repo_root = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
    if repo_root not in sys.path:
        sys.path.insert(0, repo_root)

from helper.emitter import create_emitter

# Load environment variables from .env file
# Looks for .env in current directory and parent directories
# Required variables: GCS_DEVELOPER_KEY, GCS_CX
load_dotenv()

# Default configuration
DEFAULT_NUM_RESULTS = 5  # Reasonable default, API allows max 10 per request
DEFAULT_QUERY = "Python programming tutorials"  # Fallback query for CLI testing

def perform_google_search(
    query: str,
    num_results: int = DEFAULT_NUM_RESULTS,
    emitter: Callable[[str], None] | None = None,
    return_mode: str = "both",  # 'answer' | 'log' | 'both'
    save_json: str | os.PathLike | None = None,
):
    """Perform web search using Google Custom Search API with official authentication.
    
    Executes web search via Google Custom Search JSON API (official, paid service).
    Returns structured search results with titles, URLs, and snippets.
    
    Pattern mirrors agent/bingsearch.py and helper/yahoosearch.py for consistency:
    - emit(): Pushes application log lines (console / Streamlit log area)
    - output_texts: Collects formatted search results suitable for UI expander
    - return_mode: Flexible return format
    - save_json: Optional persistence
    
    Execution Flow:
    ---------------
    1. Initialize emitter and output collection
    2. Validate environment variables (GCS_DEVELOPER_KEY, GCS_CX)
    3. Build API request parameters
    4. Send HTTPS request to Google Custom Search API
    5. Parse JSON response
    6. Extract results (title, link, snippet)
    7. Format results for output
    8. Return based on return_mode
    9. Optional JSON save
    
    Args:
        query (str): The search query string
                     Example: "Python programming tutorials"
                     Passed directly to Google API (q parameter)
        
        num_results (int): Number of search results to return (default: 5)
                           Maximum: 10 (API limit per request)
                           For more results, need pagination (multiple requests)
        
        emitter: Optional callback(line: str) for streaming logs
                 Signature: (str) -> None
                 If None, prints to console
                 Used for UI updates (e.g., Streamlit)
        
        return_mode: Controls return value format:
            'answer' -> formatted results text (fallback to log if none)
                       Use when: Only need search results
            'log'    -> full log text only
                       Use when: Need diagnostic information
            'both'   -> dict { 'answers': [...], 'output_text': str, 'log': str, 'success': bool }
                       Use when: Need both results and diagnostics
        
        save_json: Optional path to persist results as JSON
                   Example: "search_results.json"
                   Directory created automatically if doesn't exist
                   Saves: answers, output_text, log, success
    
    Returns:
        str | dict depending on return_mode:
        
        'answer' mode:
            str: Formatted search results (or log if no results/error)
        
        'log' mode:
            str: Complete diagnostic log
        
        'both' mode:
            dict: {
                'answers': List[str],      # List of formatted result strings
                'output_text': str,        # Joined answers (or log if none)
                'log': str,                # Complete diagnostic log
                'success': bool            # True if results found
            }
    
    Environment Variables Required:
    -------------------------------
    GCS_DEVELOPER_KEY: Google API key from Cloud Console
        - Create at: https://console.cloud.google.com/apis/credentials
        - Enable "Custom Search API" in project
        - Example: "AIzaSyB...your_key_here"
    
    GCS_CX: Custom Search Engine ID
        - Create at: https://programmablesearchengine.google.com/
        - Configure search scope (entire web or specific sites)
        - Example: "a1b2c3d4e5f6g7h8"
    
    API Request Details:
    --------------------
    Endpoint: https://www.googleapis.com/customsearch/v1
    
    Parameters sent:
    - key: API key for authentication
    - cx: Search engine ID for configuration
    - q: Query string
    - num: Result count (1-10)
    - safe: 'off' (no safe search filtering)
    - gl: 'hk' (geolocation: Hong Kong)
    - googlehost: 'google.com' (use international Google)
    - hl: 'zh' (language: Chinese)
    
    Why Hong Kong settings?
    - gl='hk': Biases results toward Hong Kong region
    - hl='zh': Returns snippets in Chinese when available
    - Suitable for Hong Kong-based applications
    
    Example API Response:
    ---------------------
    ```json
    {
      "items": [
        {
          "title": "Python Tutorial - Official Documentation",
          "link": "https://docs.python.org/3/tutorial/",
          "snippet": "This tutorial introduces the reader informally..."
        }
      ]
    }
    ```
    
    Example Results Structure:
    --------------------------
    ```python
    [
        {
            "title": "Python Tutorial - Official Documentation",
            "url": "https://docs.python.org/3/tutorial/",
            "snippet": "This tutorial introduces the reader informally..."
        }
    ]
    ```
    
    Example Output Text:
    --------------------
    ```
    Search Results for: 'Python tutorials'
    Found: 3 results
    
    1. Python Tutorial - Official Documentation
       URL: https://docs.python.org/3/tutorial/
       Snippet: This tutorial introduces the reader informally...
    
    2. Learn Python - W3Schools
       URL: https://www.w3schools.com/python/
       Snippet: Well organized and easy to understand...
    ```
    
    Error Handling:
    ---------------
    - Missing credentials: Error logged, returns empty results with log
    - Network errors (timeout, connection): Logged, returns empty
    - JSON parse errors: Logged, returns empty
    - API errors (quota exceeded, invalid key): Logged with error message
    - HTTP errors (4xx, 5xx): Logged with status code
    - No results: Warning logged, success=False
    
    All errors logged via emitter, operation returns gracefully.
    
    Example Usage:
    --------------
    ```python
    # Basic usage (requires .env with credentials)
    results = perform_google_search("Python tutorials")
    print(results)
    
    # Get structured results
    result_dict = perform_google_search(
        "machine learning",
        num_results=10,
        return_mode="both"
    )
    if result_dict['success']:
        print(result_dict['output_text'])
    else:
        print("Error:", result_dict['log'])
    
    # With UI updates
    from helper.emitter import create_emitter
    emitter = create_emitter(lambda msg: st.write(msg))
    results = perform_google_search(
        "web scraping",
        emitter=emitter.emit
    )
    
    # Save to file
    perform_google_search(
        "Claude AI",
        save_json="cache/results.json"
    )
    ```
    
    Performance:
    ------------
    - HTTP request: ~200-500ms (network dependent)
    - JSON parsing: ~10-50ms
    - Total: ~300-600ms typical
    - Faster than web scraping (no HTML parsing)
    
    Quota Management:
    -----------------
    - Free tier: 100 queries/day
    - Paid plans: Up to 10,000 queries/day
    - Monitor usage in Google Cloud Console
    - Consider caching results to reduce API calls
    
    Limitations:
    ------------
    - Requires API key and CX setup
    - Free tier limited to 100 queries/day
    - Maximum 10 results per request
    - Pagination required for more results
    
    Note:
        Requires GCS_DEVELOPER_KEY and GCS_CX environment variables to be set.
        This is an official, paid API service (100 free queries/day).
        For unlimited free search, use helper/yahoosearch.py (web scraping).
    """
    # Track formatted output and success status
    output_texts: list[str] = []  # captured formatted results
    success = False  # Track operation success
    
    # STEP 1: Initialize emitter for progress logging
    # create_emitter wraps callback or creates console emitter
    emit_util = create_emitter(emitter)
    emit = emit_util.emit
    
    emit(f"[INFO] Performing Google Custom Search for: '{query}'")
    emit(f"[INFO] Requesting {num_results} results")
    emit("[INFO] Checking environment variables...")
    
    # STEP 2: Validate environment variables
    # os.getenv: Read from environment or .env file (loaded by load_dotenv())
    # Why check? API requires both key and CX to function
    gcs_api_key = os.getenv('GCS_DEVELOPER_KEY')
    gcs_cx = os.getenv('GCS_CX')
    
    if not gcs_api_key or not gcs_cx:
        # Missing credentials - cannot proceed
        emit("[ERROR] Missing GCS_DEVELOPER_KEY or GCS_CX in environment")
        emit("[ERROR] Please set these environment variables to use Google Custom Search API")
        
        # Return early with error log
        log_joined = emit_util.get_log()
        if return_mode == "both":
            return {
                "answers": [],
                "output_text": log_joined,
                "log": log_joined,
                "success": False,
            }
        return log_joined

    # STEP 3: Build API request parameters
    # API endpoint: Google Custom Search JSON API v1
    url = "https://www.googleapis.com/customsearch/v1"
    
    # API parameters
    # key: Authentication token (required)
    # cx: Search engine ID (required)
    # q: Query string (required)
    # num: Result count (optional, default 10, max 10)
    # safe: Safe search filter ('off', 'medium', 'high')
    # gl: Geolocation (ISO country code)
    # googlehost: Google domain to use
    # hl: Language for UI elements
    params = {
        'key': gcs_api_key,
        'cx': gcs_cx,
        'q': query,
        'num': num_results,
        'safe': 'off',            # No safe search filtering
        'gl': 'hk',               # Geolocation Hong Kong
        'googlehost': 'google.com',  # International Google
        'hl': 'zh',               # Chinese language interface        
    }

    # STEP 4: Send HTTPS request to Google API
    try:
        emit("[INFO] Making HTTP request to Google Custom Search API...")
        
        # requests.get: Send HTTP GET request
        # timeout=15: Fail after 15 seconds (prevent hanging)
        # Why timeout? API may be slow or unresponsive
        response = requests.get(url, params=params, timeout=15)
    except Exception as e:
        # Network error (timeout, connection refused, DNS failure)
        emit(f"[ERROR] HTTP request to Google Custom Search failed: {e}")
        
        # Return early with error log
        log_joined = emit_util.get_log()
        if return_mode == "both":
            return {
                "answers": [],
                "output_text": log_joined,
                "log": log_joined,
                "success": False,
            }
        return log_joined

    # STEP 5: Parse JSON response
    try:
        # Parse JSON response body
        # Why try-except? Response might not be valid JSON
        data = response.json()
    except Exception as e:
        # JSON parse error (invalid response format)
        emit(f"[ERROR] Failed to parse response from Google Custom Search API: {e}")
        
        # Return early with error log
        log_joined = emit_util.get_log()
        if return_mode == "both":
            return {
                "answers": [],
                "output_text": log_joined,
                "log": log_joined,
                "success": False,
            }
        return log_joined

    # STEP 6: Check for API errors
    # status_code != 200: HTTP error (4xx, 5xx)
    # 'error' in data: API error (quota exceeded, invalid key, etc.)
    if response.status_code != 200 or 'error' in data:
        # Extract error message from response
        # data.get('error', {}).get('message', ...): Nested dict access with fallback
        error_msg = data.get('error', {}).get('message', f'HTTP {response.status_code}')
        emit(f"[ERROR] Google API error: {error_msg}")
        
        # Return early with error log
        log_joined = emit_util.get_log()
        if return_mode == "both":
            return {
                "answers": [],
                "output_text": log_joined,
                "log": log_joined,
                "success": False,
            }
        return log_joined

    # STEP 7: Extract results from response
    # data.get('items', []): Get items array, default to empty list
    # Why default? API returns no 'items' key if no results
    results = []
    for item in data.get('items', []):
        # Extract title, URL (link), snippet
        # .get(): Safe access with fallback to empty string
        results.append({
            'title': item.get('title', ''),
            'url': item.get('link', ''),
            'snippet': item.get('snippet', '')
        })
    
    # STEP 8: Check if we got any results
    if len(results) == 0:
        # No results found - query too specific or no matches
        emit("[WARN] No results returned from Google Custom Search API")
    else:
        # Results found - mark success
        success = True
        emit(f"[INFO] Retrieved {len(results)} results successfully")
        
        # STEP 9: Format results for output
        formatted_results = f"Search Results for: '{query}'\n"
        formatted_results += f"Found: {len(results)} results\n\n"
        
        # Format each result with numbering
        # enumerate(results, 1): Start index from 1 (user-friendly)
        for i, result in enumerate(results, 1):
            formatted_results += f"{i}. {result['title']}\n"
            formatted_results += f"   URL: {result['url']}\n"
            formatted_results += f"   Snippet: {result['snippet']}\n\n"
        
        # Add to output collection
        output_texts.append(formatted_results)
        
        # Log as answer output (for UI expander)
        emit("[ANSWER OUTPUT]\n" + formatted_results)
    
    # STEP 10: Prepare return payload based on mode
    answers_joined = "\n\n".join(output_texts)
    log_joined = emit_util.get_log()
    
    if return_mode == "both":
        # Comprehensive mode: Return all information
        payload: dict | str = {
            "answers": output_texts,
            "output_text": answers_joined or log_joined,
            "log": log_joined,
            "success": success,
        }
    elif return_mode == "log":
        # Log mode: Return only diagnostic log
        payload = log_joined
    else:  # 'answer'
        # Answer mode: Return formatted results (or log if none)
        payload = answers_joined if answers_joined else log_joined
    
    # STEP 11: Save to JSON if requested
    if save_json:
        import pathlib
        try:
            # Create path object and ensure parent directory exists
            path_obj = pathlib.Path(save_json)
            path_obj.parent.mkdir(parents=True, exist_ok=True)
            
            # Write JSON with pretty formatting
            with path_obj.open('w', encoding='utf-8') as f:
                json.dump(
                    {
                        "answers": output_texts,
                        "output_text": answers_joined,
                        "log": log_joined,
                        "success": success,
                    },
                    f,
                    ensure_ascii=False,  # Preserve Unicode characters
                    indent=2,            # Pretty-print with 2-space indentation
                )
        except Exception as exc:  # pragma: no cover
            # JSON save failed - log warning but don't fail operation
            emit(f"[WARN] Failed to save JSON artefact: {exc}")
            
            # Update log in payload if mode is log or both
            log_joined2 = emit_util.get_log()
            if isinstance(payload, dict):
                payload["log"] = log_joined2
            elif return_mode == "log":
                payload = log_joined2
    
    return payload

if __name__ == "__main__":
    """Command-line interface for Google Custom Search testing.
    
    Purpose:
    --------
    Provides direct CLI access for testing Google Custom Search API.
    Useful for development, debugging, and standalone search operations.
    
    Requirements:
    -------------
    Environment variables must be set:
    - GCS_DEVELOPER_KEY: Google API key
    - GCS_CX: Custom Search Engine ID
    
    Usage:
    ------
    python gcptxtsearch.py [query] [num_results]
    
    Arguments:
    ----------
    query: Search query string (optional, default: "Python programming tutorials")
           If contains spaces, wrap in quotes
           Example: "Python web scraping"
    
    num_results: Number of results (optional, default: 5)
                 Must be positive integer
                 Maximum: 10 (API limit per request)
    
    Examples:
    ---------
    # Use default query and count
    python gcptxtsearch.py
    
    # Custom query (5 results)
    python gcptxtsearch.py "machine learning"
    
    # Custom query and count
    python gcptxtsearch.py "web scraping" 10
    
    # Single word query
    python gcptxtsearch.py Python
    
    Output:
    -------
    Prints to console:
    - Formatted search results (title, URL, snippet)
    - Diagnostic log messages ([INFO], [WARN], [ERROR])
    - Results not saved to JSON in default CLI mode
    
    Error Handling:
    ---------------
    - Missing credentials: Error message, exits gracefully
    - Network errors: Logged to console
    - API errors: Logged with error details
    - Parse errors: Logged, operation continues
    
    Note:
        Requires valid Google API credentials in environment.
        Free tier: 100 queries/day.
        All output goes to console (no Streamlit UI dependency).
    """
    # Parse command line arguments
    # sys.argv[0]: script name (gcptxtsearch.py)
    # sys.argv[1]: query (optional, uses DEFAULT_QUERY if not provided)
    # sys.argv[2]: num_results (optional, uses DEFAULT_NUM_RESULTS if not provided)
    if len(sys.argv) > 1:
        # Query provided via command line
        search_query = sys.argv[1]
        
        # Check for num_results argument
        # int(): Convert string to integer
        # Fallback to DEFAULT_NUM_RESULTS if not provided
        num_results = int(sys.argv[2]) if len(sys.argv) > 2 else DEFAULT_NUM_RESULTS
    else:
        # No arguments provided - use defaults
        # DEFAULT_QUERY: "Python programming tutorials" (defined at top of file)
        # DEFAULT_NUM_RESULTS: 5 (defined at top of file)
        search_query = DEFAULT_QUERY
        num_results = DEFAULT_NUM_RESULTS
    
    # Execute search with console output
    # emitter=None: Uses default console emitter (prints to stdout)
    # All emit() calls will print directly to console
    # No save_json: Results not persisted (CLI mode is for quick testing)
    # Why no save_json? CLI is for interactive testing, not data collection
    perform_google_search(search_query, num_results)
