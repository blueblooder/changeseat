# Bidirectional Handoff Workflow

## What Is This?

Imagine calling customer support and saying "I need a replacement for my broken item, and I also have a billing question." Instead of being transferred back and forth between departments, this workflow lets support specialists talk to *each other* to solve your problem, then come back to you with a complete answer.

That's what `handoff_bidirectional.py` does - but with AI agents instead of human support staff.

## The Problem It Solves

**Traditional Approach (Bad):**
- Customer explains problem to Agent A
- Agent A transfers to Agent B
- Customer re-explains problem to Agent B  
- Agent B says "you need Agent C"
- Customer re-explains *again* to Agent C
- Frustrating! 😤

**This Workflow (Good):**
- Customer explains problem once
- Triage agent routes to the right specialist
- Specialists can consult *each other* without bothering the customer
- Customer only gets asked for additional info when actually needed
- Much better experience! ✅

## Real-World Example

You contact support: *"Order 12345 arrived damaged. I want a replacement, and can you confirm I won't be charged shipping again?"*

Here's what happens behind the scenes:

1. **Triage Agent** reads your message and thinks: "This needs replacement AND billing"
2. Routes to **Replacement Agent** who processes the replacement request
3. **Replacement Agent** hands off to **Billing Agent**: "Hey, can you confirm no shipping charge?"
4. **Billing Agent** verifies the policy and responds
5. All three agents collaborate, then give you a complete answer

You never had to repeat yourself or wait for multiple transfers!

## How It Works (Simple Explanation)

Think of it like a team of specialists in different rooms:

```
┌─────────────────────────────────────────────────┐
│  YOU (Customer)                                  │
│  "I have a problem!"                            │
└────────────────┬────────────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────────────────┐
│  TRIAGE AGENT (Router)                          │
│  Reads your problem and decides who can help    │
└────────────┬────────────┬──────────────┬────────┘
             │            │              │
        ┌────▼───┐   ┌───▼────┐   ┌────▼─────┐
        │Replace │   │Delivery│   │ Billing  │
        │Specialist   │Specialist  │Specialist│
        └────┬───┘   └───┬────┘   └────┬─────┘
             │            │              │
             └────────────┴──────────────┘
                         │
    Specialists can talk to each other!
    They collaborate to solve your problem.
                         │
                         ▼
             Final answer comes back to YOU
```

**Key Point:** The specialists (AI agents) can pass information between themselves *without* asking you the same questions repeatedly.

## The Four Agents Explained

### 1. **Triage Agent** (The Router)
- **Job:** Read the customer's request and decide which specialist should handle it
- **Like:** A receptionist who knows which department handles which problems
- **Example:** Sees "replacement" in your message → routes to Replacement Agent

### 2. **Replacement Agent** (Product Returns)
- **Job:** Handle product replacement requests
- **Can ask for help from:** Delivery Agent (for shipping) or Billing Agent (for refunds)
- **Example:** "I'll process your replacement, but let me check with Delivery about shipping times"

### 3. **Delivery Agent** (Shipping & Tracking)
- **Job:** Answer questions about shipping, tracking, and delivery
- **Can ask for help from:** Billing Agent (if there are shipping charges to discuss)
- **Example:** "Your package arrives Tuesday. Let me check with Billing about that shipping fee"

### 4. **Billing Agent** (Money & Payments)
- **Job:** Handle payment questions, refunds, and billing issues
- **Can ask for help from:** Nobody (this is the final specialist)
- **Example:** "Confirmed - no shipping charge for replacements under warranty"

## Who Can Talk to Who?

The workflow has **rules** about which agents can hand off to which other agents:

```
Triage Agent can hand off to:
  ✅ Replacement Agent
  ✅ Delivery Agent  
  ✅ Billing Agent

Replacement Agent can hand off to:
  ✅ Delivery Agent
  ✅ Billing Agent
  ❌ Cannot go back to Triage

Delivery Agent can hand off to:
  ✅ Billing Agent
  ❌ Cannot go back to Triage or Replacement

Billing Agent:
  ❌ Cannot hand off to anyone (final stop)
```

This prevents agents from passing the problem around in circles!

## Quick Start - Running the Demo

### Option 1: Simple Command Line (Easiest!)

Just run this command to see a demonstration:

```bash
python workflow/handoff_bidirectional.py
```

This runs a **scripted demo** showing how the agents collaborate. You'll see:
- A customer with a complex request (replacement + shipping + billing)
- How the agents route the request between themselves
- The final complete conversation

### Option 2: Command Line with Your Own Question

Ask your own question instead of using the demo:

```bash
python workflow/handoff_bidirectional.py "I want to return order 99999 and get a refund"
```

The agents will process your custom question!

### Option 3: Interactive Mode (Streamlit GUI)

Run the Streamlit web interface:

```bash
streamlit run main.py
```

Then:
1. Select **"[Workflow] Multi-Tier Handoff (Bidirectional)"** from the dropdown
2. Type your question in the text box
3. Watch the agents collaborate in real-time
4. See the conversation history and OpenTelemetry traces

## Before You Run - Setup Required

### 1. Install Python Packages

```bash
pip install -r requirements.txt
```

This installs:
- `agent-framework` - The AI agent framework
- `azure-identity` - For Azure authentication  
- `opentelemetry-sdk` - For observability/tracing
- `streamlit` - For the web GUI

### 2. Azure CLI Login

The workflow uses Azure OpenAI, so you need to log in:

```bash
az login
```

This opens your browser for authentication. Once logged in, you're ready!

### 3. Azure OpenAI Configuration

Make sure your environment has access to:
- An Azure OpenAI endpoint **AZURE_OPENAI_ENDPOINT**
- GPT-4o model deployment **AZURE_OPENAI_CHAT_DEPLOYMENT_NAME**
- Proper credentials (handled by `AzureCliCredential`)

## Understanding the Code (For Developers)

### The Main Function: `run_handoff_bidirectional()`

This is the heart of the workflow. Here's what it does in plain English:

```python
async def run_handoff_bidirectional(
    query: str,                  # The customer's question
    emitter=None,                # For sending progress updates to the UI
    return_mode='both',          # Return conversation + logs
    save_json=True,              # Save traces to file
    num_responses=3,             # How many back-and-forth turns
    scripted_responses=None      # Pre-written customer responses for demo
):
```

**What happens inside:**

1. **Setup Phase:**
   - Connects to Azure OpenAI
   - Creates the 4 specialist agents
   - Sets up OpenTelemetry for tracking what the agents do

2. **Build the Workflow:**
   ```python
   workflow = (
       HandoffBuilder(name="multi_tier_support", participants=[...])
       .set_coordinator(triage)           # Triage agent starts
       .add_handoff(triage, [replacement, delivery, billing])  # Triage can route to anyone
       .add_handoff(replacement, [delivery, billing])          # Replacement can escalate
       .add_handoff(delivery, billing)                         # Delivery can escalate to billing
       .with_termination_condition(...)   # Stop after N customer messages
       .build()
   )
   ```

3. **Run the Conversation:**
   - Sends the customer's query to the triage agent
   - Agents process the request and hand off to each other
   - Collects all the messages and events
   - Saves traces so you can see what happened

4. **Return Results:**
   - Full conversation history (all messages)
   - Log of agent handoffs and decisions
   - OpenTelemetry traces (saved to `opentele_local/` folder)

### Key Concepts to Understand

#### 1. **What is HandoffBuilder?**

`HandoffBuilder` is like a blueprint for creating an agent workflow. Think of it as:

- **Chef's recipe:** It tells agents when they can talk to each other
- **Traffic rules:** It prevents agents from going in circles
- **Organizer:** It makes sure everything happens in the right order

```python
# This means: "Replacement agent can hand off to Delivery or Billing"
.add_handoff(replacement, [delivery, billing])
```

#### 2. **What are "Events"?**

As the workflow runs, it generates **events** - like notifications about what's happening:

- **StatusEvent**: "Workflow is running" or "Waiting for user input"
- **OutputEvent**: "Here's the conversation so far"
- **RequestEvent**: "Need the user to answer a question"

The code processes these events to:
- Show progress in the UI
- Extract the conversation history
- Know when to ask the user for more info

#### 3. **What is the "Emitter"?**

The emitter is like a messenger that sends updates to the UI in real-time:

```python
emitter.emit({"type": "agent", "content": "Triage agent is processing..."})
```

This makes the Streamlit UI update as agents work, so users see progress!

#### 4. **What is OpenTelemetry?**

OpenTelemetry tracks **what the agents are doing** so you can debug and optimize:

- Which agent handled the request?
- How long did each step take?
- Who handed off to whom?

It saves this data to JSON files in `opentele_local/` folder.

### The Agent Instructions

Each agent has **instructions** that tell it what to do:

```python
triage = chat_client.create_agent(
    instructions="""
    You are a triage agent for customer support.
    Read the customer's request and route to the appropriate specialist:
    - Product issues → call handoff_to_replacement_agent
    - Shipping questions → call handoff_to_delivery_agent  
    - Billing questions → call handoff_to_billing_agent
    """,
    name="triage_agent"
)
```

The instructions are like a **job description** - they tell the AI agent:
- What its role is
- What kinds of requests to handle
- When to hand off to another agent

### How Handoffs Actually Work

When an agent wants to hand off, it calls a special function:

```python
# Replacement agent's instructions include:
"If you need shipping information, call handoff_to_delivery_agent"
```

Behind the scenes:
1. Agent decides: "I need help from Delivery"
2. Calls the handoff function
3. Framework checks: "Is Replacement → Delivery allowed?" (YES!)
4. Passes the conversation to Delivery agent
5. Delivery agent continues where Replacement left off

The **conversation history** goes with the handoff, so Delivery knows everything that was discussed!

## What You'll See When You Run It

### Sample Output (Scripted Demo)

When you run `python workflow/handoff_bidirectional.py`, you'll see:

```
================================================================================
MULTI-TIER HANDOFF DEMONSTRATION
================================================================================

Scenario: Customer needs replacement + shipping + billing confirmation
Expected flow: User -> Triage -> Replacement -> Delivery -> Billing -> User

[User]: I need a replacement for order 12345 and want to know when it will arrive.

[Triage Agent]: I'll connect you to our replacement team and delivery team...

[Replacement Agent]: I'll process your replacement request. Let me check with delivery...

[Delivery Agent]: Your replacement will arrive in 3-5 business days. Let me verify billing...

[Billing Agent]: Confirmed - no additional shipping charge for warranty replacements.

=== Final Conversation ===
✅ All messages shown in order
✅ You can see how agents collaborated
✅ Complete conversation history saved
```

### Understanding the Output

The output shows:
- **[User]**: What the customer said
- **[Agent Name]**: Which agent responded
- **Agent collaboration**: You'll see agents handing off to each other
- **Final Conversation**: Complete message history

### Where Files Are Saved

After running, you'll find:

```
opentele_local/
  └── handoff_bidirect_20251028-132446.json  # OpenTelemetry traces

```

**OpenTelemetry Trace File** contains:
- Which agent handled each step
- How long each step took
- Message routing (who handed off to whom)
- Full execution timeline

You can view these traces in the Streamlit UI!

## Customizing for Your Use Case

### Adding a New Specialist Agent

Want to add a "Technical Support" agent? Here's how:

**Step 1: Create the agent**

```python
technical = chat_client.create_agent(
    instructions="""
    You handle technical troubleshooting for products.
    If the issue requires a replacement, call handoff_to_replacement_agent.
    If it's a billing issue, call handoff_to_billing_agent.
    """,
    name="technical_agent"
)
```

**Step 2: Add to the workflow**

```python
workflow = (
    HandoffBuilder(
        name="extended_support",
        participants=[triage, replacement, delivery, billing, technical],  # Add here
    )
    .set_coordinator(triage)
    .add_handoff(triage, [replacement, delivery, billing, technical])  # Triage can route to it
    .add_handoff(technical, [replacement, billing])  # It can hand off to others
    .build()
)
```

**Step 3: Update triage agent instructions**

```python
triage = chat_client.create_agent(
    instructions="""
    Route customer requests to the appropriate specialist:
    - Product issues → handoff_to_replacement_agent
    - Shipping questions → handoff_to_delivery_agent
    - Billing questions → handoff_to_billing_agent
    - Technical problems → handoff_to_technical_agent  # NEW!
    """,
    name="triage_agent"
)
```

Done! Now you have 5 specialists.

### Changing the Termination Rule

The workflow stops after a certain number of customer messages. You can change this:

```python
# Stop after 5 customer messages
.with_termination_condition(lambda conv: sum(1 for msg in conv if msg.role.value == "user") > 5)

# Stop when customer says "thanks" or "resolved"
.with_termination_condition(lambda conv: any(
    word in msg.text.lower() 
    for msg in conv 
    for word in ["thanks", "resolved", "all set"]
))

# Stop after 20 total messages (prevents very long conversations)
.with_termination_condition(lambda conv: len(conv) > 20)
```

### Using in Your Own Application

Want to integrate this into your app? Here's a minimal example:

```python
import asyncio
from workflow.handoff_bidirectional import run_handoff_bidirectional

async def handle_customer_request(customer_question: str):
    """Process a customer support request using the handoff workflow."""
    
    # Run the workflow
    conversation, logs = await run_handoff_bidirectional(
        query=customer_question,
        save_json=False,  # Don't save traces in production
        num_responses=3   # Allow 3 back-and-forth turns
    )
    
    # Extract the final agent response
    final_response = conversation[-1].text if conversation else "No response"
    
    return final_response

# Use it in your app
customer_question = "I need to return order 12345"
response = asyncio.run(handle_customer_request(customer_question))
print(response)
```

## Common Questions (FAQ)

### Q: What if an agent tries to hand off to someone it's not allowed to?

**A:** The framework prevents this! If Delivery Agent tries to hand off to Replacement Agent (which isn't in the rules), the handoff won't happen. The framework only allows handoffs you explicitly defined with `.add_handoff()`.

### Q: How do agents know when to hand off vs. answering directly?

**A:** It's in their **instructions**! Each agent's instructions tell it:
- What kinds of questions it should handle itself
- What kinds of questions need another specialist
- Which specialist to hand off to for each type of issue

The AI reads these instructions and decides based on the customer's message.

### Q: Can agents get stuck in a loop?

**A:** No! Three safety mechanisms prevent this:

1. **One-way routing:** Delivery can't hand back to Replacement
2. **Termination condition:** Stops after N customer messages
3. **Explicit handoff rules:** Agents can only hand off to allowed targets

### Q: What's the difference between this and regular chatbots?

**A:** Regular chatbots are one AI trying to handle everything. This workflow:
- Uses **multiple specialized AIs** (each expert in one area)
- Allows them to **collaborate** without user intervention
- Maintains **context** across all specialists
- Provides **structured routing** instead of random responses

### Q: Why use OpenTelemetry traces?

**A:** Traces show you:
- **Debugging:** Which agent failed or took too long
- **Optimization:** Where to improve response times
- **Analytics:** Which handoff paths are most common
- **Monitoring:** Track workflow health in production

### Q: Can I run this without Azure?

**A:** The framework supports other LLM providers! You'd need to:
1. Replace `AzureOpenAIChatClient` with another client (e.g., OpenAI, Anthropic)
2. Update authentication (remove `AzureCliCredential`)
3. Everything else stays the same!

### Q: How many agents can I have?

**A:** As many as you want! But consider:
- **More agents = more complex routing**
- **More agents = higher API costs** (each agent makes LLM calls)
- **Sweet spot:** 3-6 specialized agents for most use cases

### Q: What happens if Azure OpenAI is down?

**A:** The workflow will fail with an error. In production, you should:
- Add retry logic with exponential backoff
- Implement fallback responses
- Monitor with proper error handling
- Consider caching for common questions

## Real-World Use Cases

This workflow pattern works great for:

### 1. **E-Commerce Customer Support**
**Scenario:** Customer has multiple issues with one order
- "My order is late AND I was charged twice"
- Triage → Delivery (checks shipping) → Billing (fixes charge)
- Customer only explains once!

### 2. **Healthcare Patient Coordination**
**Scenario:** Patient needs multiple specialists
- "I have back pain and need to refill my prescription"
- Triage → Orthopedist (diagnoses) → Pharmacy (prescribes)
- Specialists share medical history automatically

### 3. **IT Service Desk**
**Scenario:** Complex technical issue requiring multiple teams
- "My email is down and I can't access the VPN"
- Triage → Network Team → Security Team → Resolution
- Each team builds on previous team's findings

### 4. **Banking & Finance**
**Scenario:** Account issue spanning multiple departments
- "I need to dispute a charge and update my address"
- Triage → Fraud Team → Account Services
- All changes coordinated in one session

### 5. **Travel Booking Support**
**Scenario:** Flight change affecting hotel and car rental
- "I need to change my flight and update my hotel dates"
- Triage → Flight Team → Hotel Team → Car Rental Team
- All changes synchronized

## Key Advantages Over Simple Chatbots

| Feature | Simple Chatbot | Bidirectional Handoff Workflow |
|---------|---------------|-------------------------------|
| **Expertise** | One AI tries to do everything | Multiple specialists, each expert in their domain |
| **Context** | Often forgets context | Full conversation history shared across all agents |
| **Collaboration** | Can't escalate | Agents can consult each other seamlessly |
| **User Experience** | Repeating info constantly | Explain once, agents handle the rest |
| **Debugging** | Hard to trace decisions | Full OpenTelemetry traces |
| **Scalability** | Gets worse as complexity grows | Add specialists as needed |


## Quick Reference

### Running the Workflow

```bash
# Demo mode
python workflow/handoff_bidirectional.py

# Custom query
python workflow/handoff_bidirectional.py "your question here"

# Streamlit GUI
streamlit run main.py
```

### Key Files

- `workflow/handoff_bidirectional.py` - Main workflow implementation
- `helper/otel_collector.py` - OpenTelemetry trace collector
- `apps/query_handlers.py` - Streamlit integration
- `config/agent_config.yaml` - Agent configuration (if used)

### Important Concepts

- **HandoffBuilder:** Creates the workflow with routing rules
- **Emitter:** Sends real-time updates to UI
- **OpenTelemetry:** Tracks execution for debugging
- **Termination Condition:** Prevents infinite loops

---

**Need Help?** Check the troubleshooting section or review the OpenTelemetry traces in `opentele_local/` to see exactly what happened during execution.
