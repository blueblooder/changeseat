"""Import management utilities for graceful handling of optional modules.

This module provides centralized, fault-tolerant importing of agent and tool functions.
It solves several key problems:

1. Optional Dependencies:
   - Not all users need all features (e.g., some may skip email functionality)
   - Allows partial installation (missing modules won't crash the app)
   - Graceful degradation (missing features simply don't appear in UI)

2. Import Path Flexibility:
   - Supports both package imports (from agent.aisearch) and direct imports
   - Handles different project structures
   - Makes codebase more portable

3. Centralized Loading:
   - Single location for all dynamic imports
   - Consistent error handling across all modules
   - Easy to add new agents/tools (follow existing pattern)

4. Default Question Management:
   - Each agent/tool defines its own default question
   - Centralized access prevents scattered hardcoded values
   - Easy to update defaults without touching UI code

Design Pattern:
Uses try/except blocks with fallback chains to attempt imports from different
locations, finally falling back to None if all attempts fail. This makes the
application resilient to missing dependencies.
"""

import importlib
from typing import Dict, Any, Optional


class ImportManager:
    """Manages dynamic imports and provides graceful fallbacks for missing modules.
    
    This class acts as a registry for all agent and tool functions in the application.
    It attempts to import each module at initialization time, caching successful
    imports for fast access and storing None for failed imports.
    
    Architecture Benefits:
    1. Fail-fast: Import errors surface during initialization, not during execution
    2. Caching: Functions imported once, accessed many times (performance)
    3. Isolation: Import failures don't affect other modules
    4. Testability: Easy to mock the entire import system
    
    State Management:
    - agent_functions: Dict mapping function names to callable objects (or None)
    - default_questions: Dict mapping mode names to their default questions
    
    Both dictionaries are populated during load_agent_functions() call.
    """
    
    def __init__(self):
        """Initialize empty registries for functions and default questions.
        
        Why not load functions in __init__?
        - Separation of concerns: Construction vs. initialization
        - Allows control over when expensive imports happen
        - Caller can handle import errors explicitly
        - Better for testing (can construct without side effects)
        """
        # Registry of loaded agent/tool functions
        # Key: function name (e.g., 'run_azure_ai_search')
        # Value: callable function object, or None if import failed
        self.agent_functions = {}
        
        # Registry of default questions for each query mode
        # Key: query mode string (e.g., 'aiSearch', 'BingSearch')
        # Value: default question string, or empty string if import failed
        self.default_questions = {}
    
    def load_agent_functions(self) -> Dict[str, Any]:
        """Load all agent functions with graceful fallbacks.
        
        This method attempts to import every agent/tool module used by the application.
        For each module, it:
        1. Tries primary import path (e.g., from agent.aisearch import ...)
        2. Falls back to alternative paths if primary fails
        3. Sets function to None if all import attempts fail
        4. Captures default questions alongside functions
        
        Import Strategy:
        Each import block follows this pattern:
        - try: Primary import path (standard package structure)
        - except ImportError: Try alternative path (compatibility)
        - except ImportError: Set to None (graceful degradation)
        
        Why this matters:
        - Application won't crash if optional dependencies are missing
        - Users can run subset of features based on what they've installed
        - Development is easier (don't need full environment for testing)
        
        Returns:
            Dictionary of loaded functions (same as self.agent_functions).
            Returned for convenience, but functions are also cached in instance.
        
        Side Effects:
        - Populates self.agent_functions dictionary
        - Populates self.default_questions dictionary
        - May print import warnings (from imported modules)
        """
        
        # SECTION 1: AI Search Agent
        # Primary search capability using Azure AI Search
        # Demonstrates: Basic agent with tool calling
        try:
            from agent.aisearch import (
                run_azure_ai_search,
                DEFAULT_QUESTION as AI_DEFAULT_QUESTION,
            )
            self.agent_functions['run_azure_ai_search'] = run_azure_ai_search
            self.default_questions['aiSearch'] = AI_DEFAULT_QUESTION
        except ImportError:
            # Fallback: Try importing from root level (alternative project structure)
            # Why fallback? Some deployment scenarios may flatten the package structure
            try:
                from azure_ai_search import run_azure_ai_search, DEFAULT_QUESTION as AI_DEFAULT_QUESTION
                self.agent_functions['run_azure_ai_search'] = run_azure_ai_search
                self.default_questions['aiSearch'] = AI_DEFAULT_QUESTION
            except ImportError:
                # Both import attempts failed, mark as unavailable
                # Setting to None instead of raising ensures app continues running
                self.agent_functions['run_azure_ai_search'] = None
                self.default_questions['aiSearch'] = ""
        
        # SECTION 2: Bing Search Agent
        # Web search using Bing API
        # Demonstrates: Agent with external API integration
        # Note: One function serves both BingSearch and BingSearchSendEmail modes
        # The send_email flag is controlled by query_handlers, not here
        try:
            from agent.bingsearch import run_bing_search, DEFAULT_QUESTION as BING_DEFAULT_QUESTION
            self.agent_functions['run_bing_search'] = run_bing_search
            # Same default question for both variants (with/without email)
            # Why? The query itself doesn't change, only the post-processing action
            self.default_questions['BingSearch'] = BING_DEFAULT_QUESTION
            self.default_questions['BingSearchSendEmail'] = BING_DEFAULT_QUESTION
        except ImportError:
            self.agent_functions['run_bing_search'] = None
            self.default_questions['BingSearch'] = ""
            self.default_questions['BingSearchSendEmail'] = ""
        
        # SECTION 3: Yahoo Search Agent
        # Alternative web search provider
        # Demonstrates: Multiple search provider options
        try:
            from agent.yahoosearch import run_yahoo_search, DEFAULT_QUESTION as YAHOO_DEFAULT_QUESTION
            self.agent_functions['run_yahoo_search'] = run_yahoo_search
            self.default_questions['YahooSearch'] = YAHOO_DEFAULT_QUESTION
            self.default_questions['YahooSearchSendEmail'] = YAHOO_DEFAULT_QUESTION
        except ImportError:
            self.agent_functions['run_yahoo_search'] = None
            self.default_questions['YahooSearch'] = ""
            self.default_questions['YahooSearchSendEmail'] = ""
        
        # SECTION 4: Headless Browser Search (Tool)
        # Direct Google search via Selenium headless browser
        # Demonstrates: Tool-based approach (no agent layer)
        # Note: Wrapper function adapts helper's interface to match agent convention
        try:
            from helper.headlesssearch import perform_web_search, DEFAULT_QUERY as HEADLESS_DEFAULT_QUERY
            
            # Wrap the helper function to match naming convention
            # Why wrap? Helper functions use different parameter names/defaults
            # Wrapper provides consistent interface for query_handlers
            def run_headless_search(question, emitter=None, return_mode="both", save_json=None):
                return perform_web_search(question, num_results=5, emitter=emitter, return_mode=return_mode, save_json=save_json)
            
            self.agent_functions['run_headless_search'] = run_headless_search
            self.default_questions['HeadlessSearch'] = HEADLESS_DEFAULT_QUERY
        except ImportError:
            self.agent_functions['run_headless_search'] = None
            self.default_questions['HeadlessSearch'] = ""
        
        # SECTION 5: Google Custom Search API (Tool)
        # Search using Google Programmable Search Engine
        # Demonstrates: API-based search (lighter than headless browser)
        try:
            from helper.gcptxtsearch import perform_google_search, DEFAULT_QUERY as GCP_DEFAULT_QUERY
            
            # Wrap the helper function to match naming convention
            # Same rationale as headless search wrapper above
            def run_gcp_txt_search(question, emitter=None, return_mode="both", save_json=None):
                return perform_google_search(question, num_results=5, emitter=emitter, return_mode=return_mode, save_json=save_json)
            
            self.agent_functions['run_gcp_txt_search'] = run_gcp_txt_search
            self.default_questions['GCPTXTSearch'] = GCP_DEFAULT_QUERY
        except ImportError:
            self.agent_functions['run_gcp_txt_search'] = None
            self.default_questions['GCPTXTSearch'] = ""
        
        # SECTION 6: Email Writer Agent
        # Generates email content using LLM
        # Demonstrates: Content generation capability
        # Note: No default question (used as sub-component, not standalone mode)
        try:
            from agent.emailwriter import write_email_body
            self.agent_functions['write_email_body'] = write_email_body
        except ImportError:
            self.agent_functions['write_email_body'] = None
        
        # SECTION 7: Email Sender (Tool)
        # Sends emails via Logic App HTTP endpoint
        # Demonstrates: External service integration
        # Note: No default question (used as sub-component, not standalone mode)
        try:
            from helper.logicappemail import send_email
            self.agent_functions['send_email'] = send_email
        except ImportError:
            self.agent_functions['send_email'] = None
        
        # SECTION 8: URL Summarizer Agent
        # Fetches and summarizes web page content
        # Demonstrates: Multi-step agent workflow (fetch + summarize)
        try:
            from agent.summariseURL import run_summarise_url, DEFAULT_QUESTION as SUMM_DEFAULT_QUESTION
            self.agent_functions['run_summarise_url'] = run_summarise_url
            # Same default for both variants (with/without email+mp3)
            self.default_questions['summariseURL'] = SUMM_DEFAULT_QUESTION
            self.default_questions['summariseURLsendEmailmp3'] = SUMM_DEFAULT_QUESTION
        except ImportError:
            self.agent_functions['run_summarise_url'] = None
            self.default_questions['summariseURL'] = ""
            self.default_questions['summariseURLsendEmailmp3'] = ""
        
        # SECTION 9: Agentic URL Summarizer
        # Multi-agent version: separate agents for fetching and summarizing
        # Demonstrates: Agent-to-agent communication and handoff patterns
        try:
            from agentic.summariseURL import run_summarise_url_agentic, DEFAULT_QUESTION as AGENTIC_SUMM_DEFAULT_QUESTION
            self.agent_functions['run_summarise_url_agentic'] = run_summarise_url_agentic
            self.default_questions['agentic_summariseURL'] = AGENTIC_SUMM_DEFAULT_QUESTION
        except ImportError:
            self.agent_functions['run_summarise_url_agentic'] = None
            self.default_questions['agentic_summariseURL'] = ""
        
        # SECTION 10: Email Checker Agent
        # Fetches and filters emails from mailbox
        # Demonstrates: External data source integration (Microsoft Graph API)
        # Note: Used as component in multiple workflows (checkEmail*)
        try:
            from agent.checkemail import run_check_emails
            self.agent_functions['run_check_emails'] = run_check_emails
        except ImportError:
            self.agent_functions['run_check_emails'] = None
        
        # SECTION 11: Blast Web Search Workflow
        # Parallel web searches across multiple providers
        # Demonstrates: Concurrent operations, workflow orchestration
        # Note: Async function wrapped for synchronous interface compatibility
        try:
            from workflow.blastwebsearch import run_blast_search, DEFAULT_QUERY as BLAST_DEFAULT_QUERY
            import asyncio
            
            # Wrap async function to match naming convention and interface
            # Why asyncio.run? Streamlit is synchronous, workflow is async
            # asyncio.run creates new event loop, runs coroutine, closes loop
            def run_blast_websearch(question, emitter=None, return_mode="both", save_json=None, 
                                   send_email=False, recipient_email=None):
                """Wrapper for blast web search workflow to match agent interface.
                
                Adapts async workflow function to synchronous interface expected
                by query handlers. Handles event loop management automatically.
                """
                return asyncio.run(run_blast_search(
                    query=question,
                    num_results=5,
                    emitter=emitter,
                    return_mode=return_mode,
                    save_json=save_json,
                    send_email=send_email,
                    recipient_email=recipient_email
                ))
            
            self.agent_functions['run_blast_websearch'] = run_blast_websearch
            self.default_questions['BlastWebSearch'] = BLAST_DEFAULT_QUERY
            self.default_questions['BlastWebSearchSendEmail'] = BLAST_DEFAULT_QUERY
        except ImportError:
            self.agent_functions['run_blast_websearch'] = None
            self.default_questions['BlastWebSearch'] = ""
            self.default_questions['BlastWebSearchSendEmail'] = ""
        
        # SECTION 12: Check Email + Summarize + Send Email Workflow
        # Sequential workflow: fetch emails → summarize → send results
        # Demonstrates: Linear workflow with state passing between steps
        try:
            from workflow.checkSumSendEmail import run_check_sum_send_email, DEFAULT_QUESTION as CHECK_SUM_SEND_DEFAULT_QUESTION
            
            self.agent_functions['run_check_sum_send_email'] = run_check_sum_send_email
            self.default_questions['checkEmailsummariseSendEmail_workflow'] = CHECK_SUM_SEND_DEFAULT_QUESTION
        except ImportError:
            self.agent_functions['run_check_sum_send_email'] = None
            self.default_questions['checkEmailsummariseSendEmail_workflow'] = ""
        
        # SECTION 13: Handoff Bidirectional Workflow
        # Multi-tier agent handoff with bidirectional communication
        # Demonstrates: Complex agent orchestration, hierarchical delegation
        try:
            from workflow.handoff_bidirectional import run_handoff_bidirectional, DEFAULT_QUESTION as HANDOFF_BIDIRECT_DEFAULT_QUESTION
            import asyncio
            
            # Wrap async function to match naming convention and interface
            # Same async-to-sync adaptation pattern as blast web search
            def run_handoff_bidirect(question, emitter=None, return_mode="both", save_json=None):
                """Wrapper for handoff bidirectional workflow to match agent interface.
                
                Adapts async workflow to sync interface. Includes default num_responses
                parameter for demo purposes (4 scripted conversation turns).
                """
                return asyncio.run(run_handoff_bidirectional(
                    query=question,
                    emitter=emitter,
                    return_mode=return_mode,
                    save_json=save_json,
                    num_responses=4  # Default to 4 scripted responses
                ))
            
            self.agent_functions['run_handoff_bidirect'] = run_handoff_bidirect
            self.default_questions['HandoffBidirectional'] = HANDOFF_BIDIRECT_DEFAULT_QUESTION
        except ImportError:
            self.agent_functions['run_handoff_bidirect'] = None
            self.default_questions['HandoffBidirectional'] = ""
        
        # SECTION 14: Agentic URL Summary → Email Workflow
        # Sequential workflow: URL summarization (connected agents) → email composition → optional send
        # Demonstrates: Integration of agentic architecture with workflow pattern
        try:
            from workflow.agenticsumurlsdemail import run_agentic_sum_urls_email, DEFAULT_QUESTION as AGENTIC_SUM_URLS_EMAIL_DEFAULT_QUESTION
            
            self.agent_functions['run_agentic_sum_urls_email'] = run_agentic_sum_urls_email
            self.default_questions['agenticSumURLsSendEmail'] = AGENTIC_SUM_URLS_EMAIL_DEFAULT_QUESTION
        except ImportError:
            self.agent_functions['run_agentic_sum_urls_email'] = None
            self.default_questions['agenticSumURLsSendEmail'] = ""
        
        return self.agent_functions
    
    def get_function(self, name: str) -> Optional[Any]:
        """Get a loaded function by name.
        
        Provides dictionary-style access to loaded functions with None fallback.
        
        Args:
            name: Function name key (e.g., 'run_azure_ai_search')
        
        Returns:
            Callable function object if loaded successfully, None otherwise.
        
        Usage:
            func = import_manager.get_function('run_bing_search')
            if func:
                result = func(query)
            else:
                # Handle missing function (show error, disable feature, etc.)
        
        Why Optional[Any] return type?
        - None indicates function not available (import failed)
        - Any indicates we don't know exact function signature at compile time
        - Caller should check for None before invoking
        """
        return self.agent_functions.get(name)
    
    def get_default_question(self, query_mode: str) -> str:
        """Get default question for a query mode.
        
        Retrieves the predefined default question associated with a mode.
        Returns empty string if mode not found or import failed.
        
        Args:
            query_mode: Mode identifier (e.g., 'aiSearch', 'BingSearch')
        
        Returns:
            Default question string, or empty string if not available.
        
        Why return empty string instead of None?
        - Empty string is safer for UI rendering (no None checks needed)
        - Can be used directly in text inputs without conversion
        - Consistent with Python's "empty value" convention for strings
        
        Default Questions Purpose:
        - Provide examples of what each mode can do
        - Help users get started quickly (one-click demo)
        - Serve as templates for similar queries
        """
        return self.default_questions.get(query_mode, "")