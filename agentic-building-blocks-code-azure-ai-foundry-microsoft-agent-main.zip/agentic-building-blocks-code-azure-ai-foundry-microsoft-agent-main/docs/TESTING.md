# Testing Guide

This document covers testing methods for all building blocks in this repository. You can test these components in two ways:

1. **Interactive Testing via Streamlit GUI** - Run the full application and test through the web interface
2. **Direct Python Module Testing** - Run individual building blocks directly from the command line

---

## Table of Contents

- [Testing Methods Overview](#testing-methods-overview)
  - [Method 1: Streamlit GUI Testing](#method-1-streamlit-gui-testing)
  - [Method 2: Direct Python Module Testing](#method-2-direct-python-module-testing)
- [Building Block Testing Reference](#building-block-testing-reference)
  - [agent\aisearch.py](#agentaisearchpy)
  - [agent\bingsearch.py](#agentbingsearchpy)
  - [agent\checkemail.py](#agentcheckemailpy)
  - [agent\emailwriter.py](#agentemailwriterpy)
  - [agent\summariseURL.py](#agentsummariseurlpy)
  - [agentfx\aisearch.py](#agentfxaisearchpy)
  - [agentfx\bingsearch.py](#agentfxbingsearchpy)
  - [agentic\summariseURL.py](#agenticsummariseurlpy)
  - [workflow\blastwebsearch.py](#workflowblastwebsearchpy)

---

## Check the .env parameters

Before testing any building blocks, ensure your `.env` file is properly configured. Copy `.env-sample` to `.env` and fill in the required values:

```powershell
Copy-Item .env-sample .env
```

### Required Environment Variables

#### Agent Framework Configuration
These variables are used by building blocks in the `agentfx\` folder:

- **`AZURE_AI_PROJECT_ENDPOINT`** - Your Azure AI project endpoint URL
  - Format: `https://<your-project>.openai.azure.com/`
  - Used by: `agentfx\aisearch.py`, `agentfx\bingsearch.py`

- **`AZURE_AI_MODEL_DEPLOYMENT_NAME`** - Name of your deployed model
  - Example: `gpt-4o`, `gpt-35-turbo`
  - Used by: `agentfx\aisearch.py`, `agentfx\bingsearch.py`

- **`AZURE_AI_SEARCH_INDEX_NAME`** - Azure AI Search index name
  - Used by: `agentfx\aisearch.py`

- **`BING_CONNECTION_ID`** - Bing search connection identifier
  - Used by: `agentfx\bingsearch.py`

#### Agent Framework with Azure OpenAI Configuration
These variables are used when working with Agent Framework using Azure OpenAI directly:

- **`AZURE_OPENAI_ENDPOINT`** - Your Azure OpenAI endpoint URL
  - Format: `https://<your-openai-resource>.openai.azure.com/`
  - Used by: `workflow\handoff_bidirectional.py` (AzureOpenAIChatClient)

- **`AZURE_OPENAI_CHAT_DEPLOYMENT_NAME`** - Chat model deployment name for Azure OpenAI
  - Example: `gpt-4o`, `gpt-35-turbo`
  - Used by: `workflow\handoff_bidirectional.py` (AzureOpenAIChatClient)

#### Agent Service SDK Configuration
These variables are used by building blocks in the `agent\` folder:

- **`PROJECT_ENDPOINT`** - Azure AI project endpoint URL
  - Format: `https://<your-project>.openai.azure.com/`
  - Used by: Most modules in `agent\` folder

- **`MODEL_DEPLOYMENT_NAME`** - Model deployment name
  - Example: `gpt-4o`, `gpt-35-turbo`
  - Used by: Most modules in `agent\` folder

- **`AI_SEARCH_CONNECTION_NAME`** - Azure AI Search connection name
  - Used by: `agent\aisearch.py`

- **`AI_SEARCH_INDEX_NAME`** - Search index name
  - Used by: `agent\aisearch.py`

- **`BING_CONNECTION_NAME`** - Bing search connection name
  - Used by: `agent\bingsearch.py`, `workflow\blastwebsearch.py`

#### Email and M365 Configuration

- **`UTC_OFFSET`** - Your timezone offset from UTC (default: 8)
  - Example: 8 for UTC+8, -5 for UTC-5
  - Used by: `agent\checkemail.py`

- **`EMAIL_STARTTIME`** - Default start time for email retrieval
  - Format: `YYYY-MM-DDTHH:MM:SS`
  - Example: `2025-01-01T00:00:00`
  - Used by: `agent\checkemail.py`

- **`EMAIL_ENDTIME`** - Default end time for email retrieval
  - Format: `YYYY-MM-DDTHH:MM:SS`
  - Example: `2025-12-31T23:59:59`
  - Used by: `agent\checkemail.py`

- **`M365_CLIENT_ID`** - Azure AD application (client) ID
  - Required for Microsoft Graph API access
  - Used by: `agent\checkemail.py`

- **`M365_TENANT_ID`** - Azure AD tenant ID
  - Required for Microsoft Graph API access
  - Used by: `agent\checkemail.py`

- **`M365_DOMAIN`** - Your organization's domain name
  - Example: `contoso.com`
  - Used by: `agent\checkemail.py`

- **`DEFAULT_EMAIL_RECIPIENT`** - Default email address for testing
  - Used by: Email workflow features

- **`DEFAULT_EMAIL_SENDER_FILTER`** - Comma-separated list of email sender addresses to filter
  - Format: `sender1@domain.com,sender2@domain.com`
  - Used by: `agent\checkemail.py` for filtering emails by sender

- **`LOGIC_APP_EMAIL_URL`** - Logic App endpoint for sending emails
  - Format: Full HTTPS URL to your Logic App
  - Used by: Email sending workflows

#### Agent Configuration Files

- **`AGENT_CONFIG_FILE`** - Path to agent configuration YAML
  - Default: `.\config\agent_config.yaml`
  - Used by: `agent\summariseURL.py`

- **`AGENTIC_CONFIG_FILE`** - Path to agentic configuration YAML
  - Default: `.\config\agentic_config.yaml`
  - Used by: `agentic\summariseURL.py`

#### Azure Speech Service (Optional)

- **`SPEECH_REGION`** - Azure Speech service region
  - Example: `eastasia`, `westus`
  - Used by: Text-to-speech features

- **`SPEECH_VOICE`** - Voice model to use
  - Example: `en-US-JennyNeural`, `en-US-GuyNeural`
  - Used by: Text-to-speech features

- **`SPEECH_RESOURCE_ID`** - Azure Speech resource ID
  - Used by: Text-to-speech features

#### Google Custom Search (Optional)

Before testing components that use **Google Custom Search** (, Blast Web Search workflow), you need to set up a Google Cloud Platform account and obtain API credentials.

📘 **Required Setup**: Follow the [**Google Custom Search API Setup Guide**](prepare_gcp_search_steps.md) to obtain:

- **`GCS_CX`** - Google Custom Search Engine ID
  - Required for 
  - Used by: `helper\gcptxtsearch.py`, `workflow\blastwebsearch.py`

- **`GCS_DEVELOPER_KEY`** - Google API Key
  - Required for 
  - Used by: `helper\gcptxtsearch.py`, `workflow\blastwebsearch.py`

> **Note**: If you skip this setup, the  component will fail, but other search components (Bing Search, Headless Search, Azure AI Search) will continue to work.

#### Azure Blob Storage (Optional)

- **`BLOB_CONNECTION_STRING`** - Azure Blob Storage connection string
  - Format: `DefaultEndpointsProtocol=https;AccountName=...`
  - Used by: Storage-related features (if implemented)

#### OpenTelemetry Configuration (Optional)

- **`ENABLE_OTEL`** - Enable OpenTelemetry tracing and logging
  - Values: `true` or `false`
  - Default: `true`

- **`OTEL_TRACES_EXPORTER`** - Traces exporter type
  - Example: `console`, `otlp`
  - Default: `console`

- **`OTEL_LOGS_EXPORTER`** - Logs exporter type
  - Example: `console`, `otlp`
  - Default: `console`

- **`APPLICATIONINSIGHTS_CONNECTION_STRING`** - Azure Application Insights connection string
  - Format: `InstrumentationKey=...;IngestionEndpoint=...;LiveEndpoint=...`
  - Used by: OpenTelemetry integration for exporting traces to Application Insights
  - Required when using Azure Monitor integration for production observability


## Testing Methods Overview
After configuring your `.env` file, verify your setup:

**Check Azure Authentication**:
   ```powershell
   az login
   ```

### Method 1: Streamlit GUI Testing

The Streamlit application provides an interactive web interface to test all building blocks with real-time logging.

#### Running Streamlit

```powershell
# From repository root
.venv\scripts\activate

streamlit run main.py
```

#### Using the Streamlit Interface

1. **Select Query Mode**: Use the sidebar dropdown to select the building block you want to test
2. **Configure Parameters**: Adjust any mode-specific parameters (email dates, search results count, etc.)
3. **Enter Question**: Type your query in the text input field
4. **View Results**: 
   - The main output appears in the primary area
   - Logs are displayed in an expandable "Show Logs" section
   - Check the log for detailed execution steps, agent outputs, and diagnostics

#### Available Query Modes in Streamlit

- [Agent] AI Search
- [Agent] Bing Search
- [Agent] Bing Search + Send Email
- [Tool] Headless Google Search
- [Tool] 
- [Agent] Summarise URL
- [Agent] Summarise URL + Send Email + MP3
- [Agentic] Summarise URL (Connected Agents)
- [Tool] Check Email
- [Agent] Check Email + Summarise
- [Agent] Check Email + Summarise + Send Email
- [Workflow] Blast Web Search
- [Workflow] Blast Web Search + Send Email

---

### Method 2: Direct Python Module Testing

Each building block can be run directly from the command line for focused testing without the GUI.

**Azure AI Search (FoundrySDK)**
```powershell
python agent\aisearch.py
```

**Bing Search (FoundrySDK)**
```powershell
python agent\bingsearch.py
```

**Email Checker (M365Graph)**
```powershell
python agent\checkemail.py
```

**Summarise URL (FoundrySDK)**
```powershell
python agent\summariseURL.py
```

**Yahoo Search (FoundrySDK)**
```powershell
python agent\yahoosearch.py
```

**Azure AI Search (AgentFx)**
```powershell
python agentfx\aisearch.py
```

**Bing Search (AgentFx)**
```powershell
python agentfx\bingsearch.py
```

**Summarise URL (Connected Agents)**
```powershell
python agentic\summariseURL.py
```

**Blast Web Search (Workflow)**
```powershell
python workflow\blastwebsearch.py
```

**Check Email + Summarise + Send Email (Workflow)**
```powershell
python workflow\checkSumSendEmail.py
```

**Bidirectional Handoff (Workflow)**
```powershell
python workflow\handoff_bidirectional.py
```

---

# Building Block Testing Reference

## agent\aisearch.py

**Purpose**: Query Azure AI Search index using an agent with vector search capabilities.

#### Input
- **Question (string)**: Natural language query to search the knowledge base

#### Output
- Agent's answer with inline URL citations from the search index
- Logs showing search tool calls and index queries

#### Default Question
```
"tell me the Compliance Hotline"
```

#### Testing via Streamlit
1. Select "Azure AI Search (FoundrySDK)" mode
2. Enter your question
3. Click "Send"
4. Check logs for:
   - Agent creation
   - Thread creation
   - Search tool calls with input/output
   - Agent responses with citations

#### Direct Testing

```powershell
# Using default question
python -m agent.aisearch

# Custom question
python -m agent.aisearch "what are the medical benefits?"

# Or directly
python .\agent\aisearch.py "tell me about employee policies"
```

#### Configuration Requirements
- `PROJECT_ENDPOINT` - Azure AI project endpoint
- `MODEL_DEPLOYMENT_NAME` - Model deployment name
- `AI_SEARCH_CONNECTION_NAME` - Azure AI Search connection name
- `AI_SEARCH_INDEX_NAME` - Search index name

---

## agent\bingsearch.py

**Purpose**: Perform web searches using Bing Grounding tool for current information.

#### Input
- **Question (string)**: Search query for web information

#### Output
- Agent's answer with web citations
- Logs showing Bing tool calls and search results

#### Default Question
```
"tell me something about agunesmusic"
```

#### Testing via Streamlit
1. Select "Bing Search (FoundrySDK)" mode
2. Enter your search query
3. Click "Send"
4. Check logs for:
   - Agent creation and configuration
   - Bing grounding tool initialization
   - Tool calls with search results
   - Agent synthesis with citations

#### Direct Testing

```powershell
# Using default question
python -m agent.bingsearch

# Custom question
python -m agent.bingsearch "latest news on artificial intelligence"

# Or directly
python .\agent\bingsearch.py "weather in Seattle"
```

#### Configuration Requirements
- `PROJECT_ENDPOINT` - Azure AI project endpoint
- `MODEL_DEPLOYMENT_NAME` - Model deployment name
- `BING_CONNECTION_NAME` - Bing search connection name

---

## agent\checkemail.py

**Purpose**: Retrieve and optionally analyze Outlook emails from specified date range using Microsoft Graph API.

#### Input
- **Start DateTime (string)**: ISO 8601 format (e.g., "2025-09-01T00:00:00Z")
- **End DateTime (string)**: ISO 8601 format (e.g., "2025-09-30T23:59:59Z")
- **Max Items (int)**: Maximum number of emails to retrieve (default: 25)
- **Analyze with Agent (bool)**: Whether to process emails through AI agent
- **Store Local (bool)**: Whether to save emails to JSON file

#### Output
- When `store_local=True`: File path to saved emails JSON
- When `analyze_with_agent=True`: Agent analysis of emails
- Otherwise: Raw email content as JSON
- Logs showing token acquisition, email retrieval, and processing

#### Default Configuration
```python
# From .env file
EMAIL_STARTTIME="2025-09-01T00:00:00"
EMAIL_ENDTIME="2025-09-30T23:59:59"
UTC_OFFSET=8
```

#### Testing via Streamlit
1. Select "Email Checker" mode
2. Configure date range in sidebar
3. Set max items count
4. Toggle "Analyze with Agent" if needed
5. Click "Send"
6. Check logs for:
   - Token acquisition (interactive auth if needed)
   - Email retrieval progress
   - Email summary
   - Agent analysis (if enabled)

#### Direct Testing

```powershell
# Using default configuration from .env
python -m agent.checkemail

# Or directly
python .\agent\checkemail.py
```

#### Configuration Requirements
- `PROJECT_ENDPOINT` - Azure AI project endpoint (if analyzing)
- `MODEL_DEPLOYMENT_NAME` - Model deployment name (if analyzing)
- Azure AD authentication configured for Microsoft Graph API
- Proper permissions for Mail.Read scope

---

## agent\emailwriter.py

**Purpose**: Compose professional email body using AI agent based on provided content or context.

#### Input
- **Raw Body (string)**: Draft email content or context information
- **Attachments (list[string], optional)**: List of attachment filenames (names only, not processed)
- **User Question (string, optional)**: Original user question for context

#### Output
- Professionally formatted email body (may include HTML)
- Logs showing agent composition process

#### Default Behavior
The agent will:
- Refine and professionalize the provided content
- Maintain context from the original question
- Format output as ready-to-send email body

#### Testing via Streamlit
1. Select "Email Writer" mode
2. Enter the draft email content or context
3. Click "Send"
4. Check logs for:
   - Agent initialization
   - Instruction formatting
   - Agent composition
   - Final email output

#### Direct Testing

```powershell
# This module is typically imported and used programmatically
# Example in Python:
python -c "from agent.emailwriter import write_email_body; result = write_email_body('Please confirm receipt of documents', return_mode='answer'); print(result)"
```

**Note**: This module is designed to be called by other components (like workflow) rather than directly from CLI. For testing, use Streamlit or import it in a Python script.

#### Configuration Requirements
- `PROJECT_ENDPOINT` - Azure AI project endpoint
- `MODEL_DEPLOYMENT_NAME` - Model deployment name

---

## agent\summariseURL.py

**Purpose**: Multi-stage URL analysis using two-agent pattern (Understanding + Summariser agents).

#### Input
- **Question (string)**: Question containing URLs or URL-related query

#### Output
- Per-URL summaries focused on answering the user's question
- Logs showing:
  - Understanding agent analysis
  - URL extraction and normalization
  - Content fetching metadata
  - Individual summariser agent outputs

#### Default Question
```
"Compare docs.micrsoft.com/azure and aws.amason.com/docmentation for cloud services"
```

#### Architecture
1. **Understanding Agent**: Analyzes question to extract URLs and refine query intent
2. **Summariser Agents**: One agent per URL, provides targeted summary

#### Testing via Streamlit
1. Select "Summarise URL (FoundrySDK)" mode
2. Enter question with URLs
3. Click "Send"
4. Check logs for:
   - Understanding agent output
   - Refined question
   - URL extraction
   - Content fetching per URL
   - Summariser agent outputs
   - Resource creation summary

#### Direct Testing

```powershell
# Using default question
python -m agent.summariseURL

# Custom question with URLs
python -m agent.summariseURL "Compare https://python.org and https://golang.org programming languages"

# Or directly
python .\agent\summariseURL.py "Analyze https://github.com/features"
```

#### Configuration Requirements
- `PROJECT_ENDPOINT` - Azure AI project endpoint
- `MODEL_DEPLOYMENT_NAME` - Model deployment name
- `AGENT_CONFIG_FILE` - Path to agent_config.yaml (default: "config/agent_config.yaml")

---

## agent\yahoosearch.py

**Purpose**: Perform web searches using Yahoo Search for alternative search results.

#### Input
- **Question (string)**: Search query for web information

#### Output
- Search results from Yahoo
- Logs showing search execution

#### Default Question
```
"tell me something about agunesmusic"
```

#### Testing via Streamlit
1. Select "Yahoo Search" mode
2. Enter your search query
3. Click "Send"
4. Check logs for search execution and results

#### Direct Testing

```powershell
# Using default question
python agent\yahoosearch.py

# Custom question
python agent\yahoosearch.py "latest technology news"
```

#### Configuration Requirements
- `PROJECT_ENDPOINT` - Azure AI project endpoint
- `MODEL_DEPLOYMENT_NAME` - Model deployment name

---

## agentfx\aisearch.py

**Purpose**: Query Azure AI Search using Agent Framework (async pattern with HostedFileSearchTool).

#### Input
- **Question (string)**: Natural language query to search the knowledge base

#### Output
- Agent's answer from search results
- Logs showing agent framework initialization and execution

#### Default Question
```
"tell me the Compliance Hotline"
```

#### Key Differences from agent\aisearch.py
- Uses Agent Framework (`agent_framework` library)
- Async/await pattern
- HostedFileSearchTool instead of direct Azure SDK
- Cleaner agent lifecycle management

#### Testing via Streamlit
1. Select "Azure AI Search (FX)" mode
2. Enter your question
3. Click "Send"
4. Check logs for:
   - Agent Framework client initialization
   - ChatAgent creation
   - Agent execution
   - Response output

#### Direct Testing

```powershell
# Using default question
python -m agentfx.aisearch

# Custom question
python -m agentfx.aisearch "what are the vacation policies?"

# Or directly
python .\agentfx\aisearch.py "company benefits information"
```

#### Configuration Requirements
- `AZURE_AI_PROJECT_ENDPOINT` - Azure AI project endpoint
- `AZURE_AI_MODEL_DEPLOYMENT_NAME` - Model deployment name
- `AZURE_AI_SEARCH_INDEX_NAME` - Search index name

---

## agentfx\bingsearch.py

**Purpose**: Perform web searches using Agent Framework with HostedWebSearchTool.

#### Input
- **Question (string)**: Search query for web information

#### Output
- Agent's answer with web information
- Logs showing agent framework execution

#### Default Question
```
"tell me something about agunesmusic"
```

#### Key Differences from agent\bingsearch.py
- Uses Agent Framework pattern
- Async/await pattern
- HostedWebSearchTool for Bing integration
- Simplified tool configuration

#### Testing via Streamlit
1. Select "Bing Search (FX)" mode
2. Enter your search query
3. Click "Send"
4. Check logs for:
   - Agent Framework initialization
   - Web search tool creation
   - Agent execution
   - Search results

#### Direct Testing

```powershell
# Using default question
python -m agentfx.bingsearch

# Custom question
python -m agentfx.bingsearch "latest developments in quantum computing"

# Or directly
python .\agentfx\bingsearch.py "current stock market trends"
```

#### Configuration Requirements
- `PROJECT_ENDPOINT` - Azure AI project endpoint
- `MODEL_DEPLOYMENT_NAME` - Model deployment name
- Bing connection configured (auto-detected via `BING_CONNECTION_ID`)

---

## agentic\summariseURL.py

**Purpose**: Advanced URL summarization using Connected Agents pattern (Coordinator + URL Summariser agents).

#### Input
- **Question (string)**: Question containing URLs or URL-related query

#### Output
- Aggregated analysis from connected agents
- Logs showing:
  - Connected agents architecture setup
  - Coordinator agent orchestration
  - URL identification and processing
  - Connected agent tool calls
  - Final aggregation

#### Default Question
```
"Compare https://docs.microsoft.com/azure and https://aws.amazon.com/documentation for cloud services"
```

#### Architecture
1. **Coordinator Agent**: Main orchestrator that delegates tasks
2. **URL Summariser Agent**: Connected agent specializing in URL content analysis
3. **Connected Agent Tool**: Enables coordinator to invoke URL summariser

#### Testing via Streamlit
1. Select "Summarise URL (Agentic)" mode
2. Enter question with URLs
3. Click "Send"
4. Check logs for:
   - Connected agents setup
   - Coordinator agent creation
   - URL identification phase
   - URL content pre-fetching
   - Connected agent delegation
   - Final aggregation

#### Direct Testing

```powershell
# Using default question
python -m agentic.summariseURL

# Custom question
python -m agentic.summariseURL "Compare https://react.dev and https://vuejs.org frameworks"

# Or directly
python .\agentic\summariseURL.py "Analyze https://www.tensorflow.org"
```

#### Configuration Requirements
- `PROJECT_ENDPOINT` - Azure AI project endpoint
- `MODEL_DEPLOYMENT_NAME` - Model deployment name
- `AGENTIC_CONFIG_FILE` - Path to agentic_config.yaml (default: "config/agentic_config.yaml")

---

## workflow\blastwebsearch.py

**Purpose**: Parallel web search workflow using fan-out/fan-in pattern to query multiple search engines concurrently.

#### Input
- **Query (string)**: Search query
- **Num Results (int, optional)**: Number of results per search source (default: 5)
- **Send Email (bool, optional)**: Whether to send results via email (default: False)
- **Recipient Email (string, optional)**: Email recipient if send_email=True

#### Output
- **Aggregated Search Results**: Combined positive results from all sources
- **Bing Search Result**: Individual Bing search output
- **Headless Search Result**: Individual headless browser search output
- ** Result**: Individual Google Custom Search output
- Logs showing fan-out/fan-in workflow execution

#### Default Question
```
"what is Claude AI"
```

#### Architecture
1. **Dispatcher Executor**: Fans out query to 3 search executors
2. **Search Executors**: 
   - BingSearchExecutor (uses `agent\bingsearch.py`)
   - HeadlessSearchExecutor (uses `helper\headlesssearch.py`)
   - GCPTextSearchExecutor (uses `helper\gcptxtsearch.py`)
3. **Aggregator Executor**: Fans in all results
4. **Email Writer Executor** (optional): Composes and sends professional email

#### Testing via Streamlit
1. Select "Blast Web Search (Workflow)" mode
2. Configure number of results in sidebar
3. Toggle "Send Email" if desired
4. Enter recipient email (if sending)
5. Enter search query
6. Click "Send"
7. Check logs for:
   - Workflow initialization
   - Fan-out dispatch to 3 sources
   - Parallel execution logs from each executor
   - Fan-in aggregation
   - Email composition and sending (if enabled)
   - Final results summary

#### Direct Testing

```powershell
# Using default query
python -m workflow.blastwebsearch

# Custom query with result count
python -m workflow.blastwebsearch "Python machine learning libraries" 10

# Or directly
python .\workflow\blastwebsearch.py "climate change solutions" 5
```

**Note**: Direct CLI testing does not support email sending. For email workflow testing, use Streamlit or modify the script to call `run_blast_search()` with `send_email=True`.

#### Configuration Requirements
- `PROJECT_ENDPOINT` - Azure AI project endpoint (for Bing search)
- `MODEL_DEPLOYMENT_NAME` - Model deployment name
- `BING_CONNECTION_NAME` - Bing search connection
- `GOOGLE_API_KEY` - Google Custom Search API key
- `GOOGLE_CX` - Google Custom Search Engine ID
- `LOGIC_APP_EMAIL_URL` - Logic App endpoint for email (if using email workflow)

---

## workflow\checkSumSendEmail.py

**Purpose**: Integrated workflow combining email checking, URL summarization, and email sending.

#### Input
- **Start DateTime (string)**: ISO 8601 format for email retrieval start time
- **End DateTime (string)**: ISO 8601 format for email retrieval end time
- **Max Items (int, optional)**: Maximum number of emails to retrieve
- **Recipient Email (string, optional)**: Email recipient for sending results

#### Output
- Email summaries with URL content analysis
- Professional email sent to recipient
- Logs showing complete workflow execution

#### Default Configuration
Uses `.env` file settings for email date range and recipient.

#### Testing via Streamlit
1. Select "Check Email + Summarise + Send Email" mode
2. Configure date range in sidebar
3. Set recipient email
4. Click "Send"
5. Check logs for:
   - Email retrieval
   - URL extraction from emails
   - Content summarization
   - Email composition and sending

#### Direct Testing

```powershell
# Using default configuration from .env
python workflow\checkSumSendEmail.py
```

#### Configuration Requirements
- `PROJECT_ENDPOINT` - Azure AI project endpoint
- `MODEL_DEPLOYMENT_NAME` - Model deployment name
- `M365_CLIENT_ID` - Azure AD application ID
- `M365_TENANT_ID` - Azure AD tenant ID
- `EMAIL_STARTTIME` - Email retrieval start time
- `EMAIL_ENDTIME` - Email retrieval end time
- `LOGIC_APP_EMAIL_URL` - Logic App endpoint for sending emails
- `DEFAULT_EMAIL_RECIPIENT` - Default recipient email

---

## workflow\handoff_bidirectional.py

**Purpose**: Demonstrates bidirectional handoff pattern between multiple specialized agents.

#### Input
- **Question (string)**: User query that may require multiple agent specializations

#### Output
- Coordinated responses from multiple agents
- Logs showing agent handoff orchestration
- Final aggregated answer

#### Default Question
```
"I need help with both technical and business aspects"
```

#### Architecture
- **Primary Agent**: Initial query handler
- **Specialized Agents**: Domain-specific agents (technical, business, etc.)
- **Handoff Mechanism**: Bidirectional communication between agents

#### Testing via Streamlit
1. Select "Bidirectional Handoff" mode
2. Enter your question
3. Click "Send"
4. Check logs for:
   - Primary agent initialization
   - Handoff triggers
   - Specialized agent responses
   - Response aggregation

#### Direct Testing

```powershell
# Using default question
python workflow\handoff_bidirectional.py

# Custom question
python workflow\handoff_bidirectional.py "Complex query requiring multiple experts"
```

#### Configuration Requirements
- `PROJECT_ENDPOINT` - Azure AI project endpoint
- `MODEL_DEPLOYMENT_NAME` - Model deployment name
- Agent configuration files for specialized agents

---

# Tips for Effective Testing

## Streamlit Testing
- Use the **"Show Logs"** expander to see detailed execution traces
- Test with different questions to understand agent behavior
- Check the logs for diagnostic information when issues occur
- Use sidebar parameters to experiment with different configurations

## Direct Testing
- Start with default questions to verify basic functionality
- Use custom questions to test specific scenarios
- Redirect output to files for analysis: `python -m agent.aisearch "query" > output.txt`
- Set environment variable `return_mode="both"` in code to get structured output with logs

## Debugging
- Check `.env` file for correct configuration values
- Ensure Azure CLI authentication is configured: `az login`
- Verify connection names and endpoints match your Azure resources
- Review logs for [ERROR] tags indicating configuration or runtime issues
- For email-related modules, ensure proper Azure AD app registration and permissions

## Performance Testing
- Use workflow\blastwebsearch.py to compare performance across search sources
- Monitor logs for execution time and resource creation counts
- Test with varying `num_results` parameters to understand scaling

## Observability and Tracing
- View detailed execution traces in **Azure AI Foundry Portal** for workflows that support OpenTelemetry
- See the **[Observability Guide](observability.md)** for:
  - Viewing traces in Azure AI Foundry Portal
  - Understanding workflow performance metrics
  - Debugging complex multi-agent workflows
  - Comparing OpenTelemetry-only vs Azure Monitor integration
- Workflows with tracing support: `workflow\blastwebsearch.py`, `workflow\handoff_bidirectional.py`, `workflow\checkSumSendEmail.py`
- Agents with Azure Monitor support: `agent\aisearch.py`

---

# Common Issues and Solutions

## Authentication Errors
**Symptom**: "DefaultAzureCredential failed" or authentication failures

**Solution**: 
```powershell
az login
az account set --subscription <your-subscription-id>
```

## Missing Environment Variables
**Symptom**: [ERROR] messages about missing configuration

**Solution**: Check `.env` file and ensure all required variables are set

## Email Retrieval Issues
**Symptom**: Token errors or permission denied for emails

**Solution**: 
- Ensure Azure AD app has Mail.Read permissions
- Run interactive token acquisition once to grant consent
- Check `UTC_OFFSET` matches your timezone

## Agent Configuration Errors
**Symptom**: [ERROR] about missing agent configuration

**Solution**: 
- Verify `config/agent_config.yaml` or `config/agentic_config.yaml` exists
- Check YAML structure matches expected format
- Ensure agent names and instructions are properly defined

## Import Errors
**Symptom**: "No module named..." errors

**Solution**:
```powershell
pip install -r requirements.txt
```

---
