import datetime as dt
import json
import requests
from typing import List, Dict, Tuple, Optional, Callable
from helper.emitter import create_emitter

GRAPH_BASE = "https://graph.microsoft.com/v1.0"

"""Microsoft Graph API Email Integration Module

Provides functionality to fetch Outlook email messages via Microsoft Graph API.
This module handles:
- OAuth2 authentication with Microsoft Graph
- Pagination through large result sets
- ISO 8601 datetime normalization
- Field selection for bandwidth optimization
- Progress tracking via emitter callbacks

=== Overview ===

Microsoft Graph is the unified API for Microsoft 365 services.
This module specifically focuses on retrieving email messages from
Outlook/Exchange Online mailboxes.

=== Authentication ===

Requires OAuth2 bearer token with Mail.Read permission.
Token acquisition is handled separately (see helper/gettoken.py).

Required Scope:
- Mail.Read (or Mail.ReadWrite for broader access)

=== API Endpoint ===

Uses: https://graph.microsoft.com/v1.0/me/mailfolders/inbox/messages

Why /me/? 
- Represents current authenticated user
- Simplifies code (no need to lookup user ID)
- Works with both personal and work accounts

Why /inbox/?
- Focuses on inbox folder specifically
- Excludes sent items, drafts, deleted items
- Can be changed to /messages for all folders

=== Date Filtering ===

Uses OData $filter query parameter:
receivedDateTime ge <start> and receivedDateTime le <end>

Format: ISO 8601 with UTC timezone (2025-09-17T00:00:00Z)

Why receivedDateTime?
- When email arrived in mailbox (not sent time)
- Indexed for efficient queries
- Consistent across time zones

=== Pagination ===

Graph API returns results in pages (@odata.nextLink).
This module automatically follows pagination links until:
- No more results
- Safety cap reached (1000 messages)
- Error encountered

Why Pagination?
- Graph limits response size (default max 1000 items)
- Prevents timeout on large result sets
- Enables progressive processing

=== Field Selection ===

$select parameter limits returned fields:
- Reduces bandwidth (important for mobile/slow connections)
- Improves performance (Graph processes less data)
- Focuses on needed data (e.g., skip body for preview lists)

Example:
select=['subject', 'from', 'receivedDateTime']
Returns only these 3 fields instead of all ~40 available fields.

=== Usage Example ===

```python
from helper.graphapi import get_outlook_emails
from helper.gettoken import get_graph_token

# Get OAuth2 token
token = get_graph_token()

# Fetch emails from Sept 16, 2025
emails, log = get_outlook_emails(
    token=token,
    start_datetime='2025-09-16T00:00:00Z',
    end_datetime='2025-09-17T23:59:59Z',
    top=50,  # 50 results per page
    select=['subject', 'from', 'receivedDateTime', 'body']
)

# Process results
print(f"Retrieved {len(emails)} emails")
for email in emails:
    print(f"{email['subject']} from {email['from']['emailAddress']['address']}")
```

=== Error Handling ===

- Missing token: Returns empty list with error log
- API errors: Stops pagination, returns partial results
- Invalid dates: Attempts normalization, falls back to original
- Network errors: Raises requests exceptions (caller should handle)

=== References ===

Microsoft Graph Message Resource:
https://learn.microsoft.com/en-us/graph/api/resources/message

Available Message Properties (~40 fields):
- Core: id, subject, body, bodyPreview, importance
- Dates: receivedDateTime, sentDateTime, createdDateTime, lastModifiedDateTime
- People: from, sender, toRecipients, ccRecipients, bccRecipients, replyTo
- Status: isRead, isDraft, isDeliveryReceiptRequested, isReadReceiptRequested
- Organization: parentFolderId, conversationId, categories, flag
- Content: hasAttachments, attachments, internetMessageId, internetMessageHeaders
- AI: inferenceClassification, mentions
"""

def get_outlook_emails(
    token: str, 
    start_datetime: str, 
    end_datetime: str, 
    top: int = 25, 
    select: Optional[List[str]] = None,
    from_addresses: Optional[List[str]] = None,
    emitter: Optional[Callable[[str], None]] = None
) -> Tuple[List[Dict], str]:
    """Retrieve Outlook email messages between start_datetime and end_datetime (inclusive).
    
    Queries Microsoft Graph API to fetch email messages from the authenticated
    user's inbox within the specified time range. Automatically handles
    pagination, datetime normalization, and field selection.
    
    This is the main entry point for email retrieval in the application.
    
    === Parameters ===
    
    token: str
        OAuth2 bearer token with Mail.Read scope.
        
        Obtain via helper.gettoken.get_graph_token() or similar.
        
        Token Format: Long alphanumeric string (typically 1000+ characters)
        Example: "eyJ0eXAiOiJKV1QiLCJhbGc..."
        
        Why Required?
        - Microsoft Graph requires authentication for all operations
        - Token identifies user and permissions
        - Token expires (typically 1 hour), caller should handle refresh
        
    start_datetime: str
        Start of date range in ISO 8601 format (UTC).
        
        Format: YYYY-MM-DDTHH:MM:SSZ
        Examples:
        - "2025-09-16T00:00:00Z" (midnight UTC)
        - "2025-09-16T08:30:00Z" (8:30 AM UTC)
        
        Inclusive: Emails received exactly at this time are included.
        
        Timezone Handling:
        - If 'Z' suffix present: Treated as UTC
        - If no timezone: Assumed UTC
        - Other timezones: Converted to UTC
        
    end_datetime: str
        End of date range in ISO 8601 format (UTC).
        
        Format: Same as start_datetime
        Example: "2025-09-17T23:59:59Z" (end of day UTC)
        
        Inclusive: Emails received exactly at this time are included.
        
        Date Range:
        - Can span minutes, hours, days, or weeks
        - Large ranges may return many results (see pagination)
        - Empty range (start > end) returns no results
        
    top: int = 25
        Maximum items per page in Graph API response.
        
        Default: 25 (balances response size vs number of requests)
        Graph Limits: 1-1000 (Graph may cap at 1000 regardless)
        
        Why Configurable?
        - Small top: More requests, less memory per request
        - Large top: Fewer requests, more memory per request
        - For slow networks: Use smaller values (faster first response)
        - For fast networks: Use larger values (fewer round trips)
        
        Pagination:
        Function automatically follows @odata.nextLink until all
        results retrieved or safety cap (1000 total) reached.
        
    select: Optional[List[str]] = None
        List of message fields to return (reduces payload size).
        
        Default: None (returns all fields)
        
        Common Fields:
        - 'subject': Email subject line
        - 'from': Sender information (dict with emailAddress)
        - 'receivedDateTime': When email arrived (ISO string)
        - 'body': Email body content (dict with contentType, content)
        - 'bodyPreview': First 255 characters of body (plain text)
        - 'toRecipients': List of To recipients
        - 'ccRecipients': List of CC recipients
        - 'bccRecipients': List of BCC recipients (if sent by user)
        - 'attachments': List of attachment metadata
        - 'hasAttachments': Boolean, True if attachments present
        - 'isRead': Boolean, read status
        - 'importance': low/normal/high
        
        Example:
        select=['subject', 'from', 'receivedDateTime', 'bodyPreview']
        
        Why Use Select?
        - Performance: Less data transferred
        - Speed: Faster Graph processing
        - Bandwidth: Important for mobile/metered connections
        - Focus: Only get what you need
        
        Field Selection Impact:
        - No select: ~5-10 KB per message (all fields)
        - With select: ~1-2 KB per message (typical subset)
        - For 100 messages: 500 KB vs 150 KB (3x reduction)
        
    emitter: Optional[Callable[[str], None]] = None
        Optional callback function for progress updates.
        
        Signature: (message: str) -> None
        
        Default: None (uses print to console)
        
        Common Usage:
        - StreamlitEmitterUtil.emit for UI updates
        - Logger function for file logging
        - Lambda for filtering: lambda msg: logger.info(msg) if 'ERROR' in msg else None
        
        Emitted Messages Include:
        - Search parameters: "[GRAPH] Searching emails from X to Y"
        - HTTP requests: "[HTTP] GET https://graph.microsoft.com/..."
        - Progress: "[INFO] Retrieved 25 messages (total so far 75)"
        - Completion: "[COMPLETE] Finished retrieving emails. Total: 100"
        - Errors: "[ERROR] Graph call failed: 401 Unauthorized"
        - Warnings: "[WARN] Reached safety cap of 1000 messages"
        
        Why Emitter Pattern?
        - Decouples progress reporting from execution
        - Supports different output destinations (console, UI, logs)
        - Enables real-time feedback during long operations
        - Testable: Can capture and assert on emitted messages
    
    === Returns ===
    
    Tuple[List[Dict], str]: (messages_list, log_string)
    
    messages_list: List[Dict]
        List of email message objects from Graph API.
        
        Each dict contains message properties (all or subset based on select).
        
        Structure Example (without select):
        ```python
        {
            'id': '...',
            'subject': 'Meeting Tomorrow',
            'receivedDateTime': '2025-09-16T14:30:00Z',
            'from': {
                'emailAddress': {
                    'name': 'John Doe',
                    'address': 'john@example.com'
                }
            },
            'toRecipients': [
                {'emailAddress': {'name': 'Jane', 'address': 'jane@example.com'}}
            ],
            'body': {
                'contentType': 'html',
                'content': '<html>...</html>'
            },
            'bodyPreview': 'Let\'s meet tomorrow at 2pm...',
            'hasAttachments': False,
            'isRead': True,
            'importance': 'normal'
        }
        ```
        
        Empty List:
        - No emails in date range
        - Token invalid/expired
        - API error occurred
        - Check log_string for details
        
    log_string: str
        Multi-line human-readable action log.
        
        Contains all emitted messages joined with newlines.
        
        Use Cases:
        - Display to user for transparency
        - Save to file for debugging
        - Parse for error detection: if '[ERROR]' in log_string
        - Extract metadata: message counts, timing, etc.
        
        Example Log:
        ```
        [GRAPH] Searching emails from 2025-09-16T00:00:00Z to 2025-09-17T23:59:59Z
        [GRAPH] Using field selection: subject, from, receivedDateTime
        [HTTP] GET https://graph.microsoft.com/v1.0/me/mailfolders/inbox/messages
        [INFO] Retrieved 25 messages (total so far 25)
        [HTTP] GET https://graph.microsoft.com/v1.0/me/mailfolders/inbox/messages?$skiptoken=...
        [INFO] Retrieved 25 messages (total so far 50)
        [INFO] Retrieved 10 messages (total so far 60)
        [COMPLETE] Finished retrieving emails. Total: 60
        ```
    
    === Error Handling ===
    
    Missing Token:
    - Returns: ([], log_with_error)
    - Log contains: "[ERROR] Missing token"
    - Does not raise exception
    
    API Errors (non-200 status):
    - Returns: (partial_results, log_with_error)
    - Log contains: "[ERROR] Graph call failed: <status> <response>"
    - Stops pagination, returns messages retrieved before error
    - Common errors:
      * 401: Token expired or invalid
      * 403: Insufficient permissions (need Mail.Read scope)
      * 404: Mailbox not found
      * 429: Rate limit exceeded (too many requests)
      * 500: Graph API internal error
    
    Network Errors:
    - Raises: requests.exceptions.RequestException
    - Caller should wrap in try/except
    - Common: timeout, DNS failure, connection refused
    
    Invalid Dates:
    - Attempts normalization via normalize_iso()
    - If normalization fails: Uses original string (may cause API error)
    - API returns 400 if date format invalid
    
    === Performance Characteristics ===
    
    Time Complexity:
    - O(n) where n = total number of messages
    - Each page: 1 HTTP request (~200-500ms)
    - 1000 messages with top=25: ~40 requests, ~10-20 seconds
    
    Memory:
    - O(n) for messages_list
    - O(n) for log (each message logged)
    - 1000 messages: ~5-10 MB (full messages) or ~1-2 MB (selected fields)
    
    Network:
    - Bandwidth: ~5-10 KB per message (full) or ~1-2 KB (selected)
    - Latency: 200-500ms per request (depends on region, load)
    - Safety cap: 1000 messages (prevents runaway loops)
    
    === Usage Examples ===
    
    Basic Usage:
    ```python
    from helper.graphapi import get_outlook_emails
    
    messages, log = get_outlook_emails(
        token=my_token,
        start_datetime='2025-09-16T00:00:00Z',
        end_datetime='2025-09-16T23:59:59Z'
    )
    
    print(f"Found {len(messages)} emails")
    print(log)  # View what happened
    ```
    
    With Field Selection:
    ```python
    # Only fetch fields needed for summary view
    messages, log = get_outlook_emails(
        token=my_token,
        start_datetime='2025-09-16T00:00:00Z',
        end_datetime='2025-09-16T23:59:59Z',
        select=['subject', 'from', 'receivedDateTime', 'bodyPreview'],
        top=50  # Larger pages for faster retrieval
    )
    ```
    
    With Streamlit Emitter:
    ```python
    import streamlit as st
    from helper.emitter import create_streamlit_emitter
    
    status_area = st.empty()
    emitter = create_streamlit_emitter(status_area)
    
    messages, log = get_outlook_emails(
        token=my_token,
        start_datetime='2025-09-16T00:00:00Z',
        end_datetime='2025-09-16T23:59:59Z',
        emitter=emitter.emit  # Real-time UI updates
    )
    ```
    
    Error Handling:
    ```python
    try:
        messages, log = get_outlook_emails(...)
        
        if '[ERROR]' in log:
            st.error("Failed to retrieve emails")
            st.text(log)
        else:
            st.success(f"Retrieved {len(messages)} emails")
            
    except requests.exceptions.Timeout:
        st.error("Request timed out - check network connection")
    except requests.exceptions.RequestException as e:
        st.error(f"Network error: {e}")
    ```
    """
    # STEP 1: Initialize emitter utility
    # create_emitter wraps callback (or uses print as default)
    emit_util = create_emitter(emitter)
    
    # Initialize messages list (will accumulate across pages)
    messages: List[Dict] = []

    # Convenience wrapper for emitting messages
    # Why wrapper? Shorter code, clearer intent
    def emit(msg: str):
        emit_util.emit(msg)

    # STEP 2: Validate token
    # Early exit if no token (common mistake)
    if not token:
        emit("[ERROR] Missing token")
        # Return empty results with error log
        return messages, emit_util.get_log()

    # STEP 3: Normalize datetime strings to ISO 8601 UTC
    # Graph API requires specific format: YYYY-MM-DDTHH:MM:SSZ
    def normalize_iso(ts: str) -> str:
        """Normalize datetime string to ISO 8601 UTC format.
        
        Handles common datetime format variations:
        - Already UTC with 'Z': Pass through unchanged
        - Naive datetime (no timezone): Assume UTC, add 'Z'
        - Other timezones: Convert to UTC, add 'Z'
        
        Why Normalization?
        - Graph API requires UTC with 'Z' suffix
        - Users may provide various formats
        - Prevents API errors from format mismatches
        - Handles timezone-aware datetimes correctly
        
        Args:
            ts: Datetime string in ISO 8601 or similar format
        
        Returns:
            Normalized string in YYYY-MM-DDTHH:MM:SSZ format
            Original string if parsing fails (let API handle error)
        
        Examples:
        - "2025-09-16T08:00:00Z" -> "2025-09-16T08:00:00Z" (unchanged)
        - "2025-09-16T08:00:00" -> "2025-09-16T08:00:00Z" (added Z)
        - "2025-09-16T08:00:00+05:00" -> "2025-09-16T03:00:00Z" (converted to UTC)
        """
        # Handle empty string
        if not ts:
            return ts
        
        # Already has 'Z' suffix, assume correct format
        # Why early return? Avoid unnecessary parsing
        if ts.endswith('Z'):
            return ts
        
        try:
            # Parse ISO format string
            # .replace('Z','') handles edge case where Z is present but not at end
            parsed = dt.datetime.fromisoformat(ts.replace('Z',''))
            
            # Check if timezone info present
            if parsed.tzinfo is None:
                # Naive datetime, assume UTC
                # Why assume UTC? Common convention for API integrations
                parsed = parsed.replace(tzinfo=dt.timezone.utc)
            
            # Convert to UTC (no-op if already UTC)
            # Format with 'Z' suffix for Graph API
            return parsed.astimezone(dt.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
            
        except Exception:  # pylint: disable=broad-except
            # Parsing failed, return original
            # Let Graph API handle invalid format (will return 400 error)
            # Why not raise? Graceful degradation, API error more helpful
            return ts

    # Normalize both start and end dates
    start_iso = normalize_iso(start_datetime)
    end_iso = normalize_iso(end_datetime)

    # Emit search parameters for transparency
    emit(f"[GRAPH] Searching emails from {start_iso} to {end_iso}")

    # STEP 4: Build OData filter for date range query
    # OData is the query language for Microsoft Graph API
    # Filter syntax: receivedDateTime ge <start> and receivedDateTime le <end>
    # ge = greater than or equal (>=), le = less than or equal (<=)
    # Why receivedDateTime? When email arrived in mailbox (indexed, fast queries)
    odata_filter = f"receivedDateTime ge {start_iso} and receivedDateTime le {end_iso}"
    
    # Add sender filter if specified
    # Builds OR conditions for multiple senders using OData syntax
    # Example: (from/emailAddress/address eq 'news@example.com' or from/emailAddress/address eq 'updates@example.com')
    if from_addresses:
        sender_conditions = [f"from/emailAddress/address eq '{addr}'" for addr in from_addresses]
        sender_filter = " or ".join(sender_conditions)
        odata_filter = f"({odata_filter}) and ({sender_filter})"
        emit(f"[GRAPH] Filtering by {len(from_addresses)} sender(s): {', '.join(from_addresses)}")
    
    # STEP 5: Configure Graph API endpoint
    # /me: Current authenticated user
    # /mailfolders/inbox: Inbox folder specifically
    # /messages: Messages in that folder
    # Why inbox only? Most common use case, excludes sent/deleted/drafts
    # To query all folders: Use /me/messages instead
    url = f"{GRAPH_BASE}/me/mailfolders/inbox/messages"

    # STEP 6: Build query parameters
    # $top: Max items per page (Graph enforces 1-1000 range)
    # $orderby: Sort by receivedDateTime descending (newest first)
    #           Why DESC? Recent emails usually more relevant
    # $filter: OData filter expression for date range
    params = {
        '$top': top,
        '$orderby': 'receivedDateTime DESC',
        '$filter': odata_filter,
    }
    
    # Add field selection if specified
    # $select: Comma-separated list of field names
    # Why conditional? Graph returns all fields if $select omitted
    if select:
        params['$select'] = ','.join(select)
        emit(f"[GRAPH] Using field selection: {', '.join(select)}")

    # STEP 7: Initialize HTTP session
    # Session reuses TCP connection across requests (faster pagination)
    # Why session? Connection pooling, cookie persistence, better performance
    session = requests.Session()
    
    # Configure headers for all requests
    # Authorization: Bearer token for OAuth2 authentication
    # Accept: Request JSON response format (Graph default, but explicit is good)
    headers = { 'Authorization': f'Bearer {token}', 'Accept': 'application/json' }

    # STEP 8: Pagination loop to retrieve all results
    # Graph API returns results in pages, must follow @odata.nextLink
    while True:
        # Emit HTTP request for transparency (truncate long URLs)
        # Why truncate? Full URL with query params can be 200+ chars
        emit(f"[HTTP] GET {url[:100]}{'...' if len(url) > 100 else ''}")
        
        # Execute HTTP GET request
        # timeout=30: Prevent hanging indefinitely (30 seconds reasonable for API)
        # Why timeout? Network issues can cause indefinite hangs
        resp = session.get(url, headers=headers, params=params, timeout=30)
        
        # Check for HTTP errors (non-200 status codes)
        if resp.status_code != 200:
            # Log error with status code and response body
            # Don't raise exception, return partial results
            # Why partial? User may want to see what was retrieved before error
            emit(f"[ERROR] Graph call failed: {resp.status_code} {resp.text}")
            break  # Exit loop, return messages collected so far
        
        # Parse JSON response
        # Graph response structure: { "value": [...], "@odata.nextLink": "..." }
        data = resp.json()
        
        # Extract messages from current page
        # .get('value', []) handles missing 'value' gracefully (returns empty list)
        batch = data.get('value', [])
        
        # Add current batch to accumulated results
        # extend() adds all items from batch to messages list
        messages.extend(batch)
        
        # Emit progress update
        # Shows current batch size and running total
        # Useful for monitoring progress during long operations
        emit(f"[INFO] Retrieved {len(batch)} messages (total so far {len(messages)})")
        
        # Check for pagination link
        # @odata.nextLink: Full URL to next page of results
        # Present when more results available, absent when done
        next_link = data.get('@odata.nextLink')
        
        if not next_link:
            # No more pages, we're done
            emit(f"[COMPLETE] Finished retrieving emails. Total: {len(messages)}")
            break  # Exit loop
        
        # Prepare for next page
        # Graph returns full URL with encoded query params in nextLink
        # Must use nextLink as-is, don't combine with original params
        url = next_link
        params = None  # Clear params, already encoded in nextLink URL
        # Why None? Prevent duplicate query params from being added
        
        # Safety mechanism: Prevent runaway loops
        # Reasonable cap at 1000 messages to prevent memory issues
        # Typical inbox queries return < 1000 results
        if len(messages) >= 1000:
            emit('[WARN] Reached safety cap of 1000 messages, stopping pagination.')
            break  # Exit loop with 1000 messages
            # Why cap? Prevents infinite loops from API bugs or misconfiguration
            # 1000 messages is ~5-10 MB memory, reasonable limit

    # STEP 9: Return results and log
    # messages: Accumulated list of all retrieved messages
    # emit_util.get_log(): All emitted messages joined with newlines
    return messages, emit_util.get_log()


# === Microsoft Graph Message Resource Reference ===
#
# Complete documentation:
# https://learn.microsoft.com/en-us/graph/api/resources/message?view=graph-rest-1.0#properties
#
# Commonly available properties for /me/messages endpoint:
#
# === Core Properties ===
# - id: Unique message identifier (string)
# - subject: Email subject line (string)
# - body: Email body content (object with contentType and content)
# - bodyPreview: First 255 characters of body, plain text (string)
# - importance: low | normal | high (string)
#
# === Date/Time Properties ===
# - receivedDateTime: When message arrived in mailbox (ISO 8601 string)
# - sentDateTime: When sender sent the message (ISO 8601 string)
# - createdDateTime: When message was created (ISO 8601 string)
# - lastModifiedDateTime: When message was last changed (ISO 8601 string)
#
# === People Properties ===
# - from: Sender information (object with emailAddress)
# - sender: Actual sender if different from 'from' (object with emailAddress)
# - toRecipients: List of To recipients (array of emailAddress objects)
# - ccRecipients: List of CC recipients (array of emailAddress objects)
# - bccRecipients: List of BCC recipients (array, usually empty unless sent by user)
# - replyTo: List of Reply-To addresses (array of emailAddress objects)
#
# === Status Properties ===
# - isRead: Whether message has been read (boolean)
# - isDraft: Whether message is a draft (boolean)
# - isDeliveryReceiptRequested: Sender requested delivery receipt (boolean)
# - isReadReceiptRequested: Sender requested read receipt (boolean)
#
# === Organization Properties ===
# - parentFolderId: ID of containing folder (string)
# - conversationId: ID of conversation thread (string)
# - conversationIndex: Position in conversation (binary string, base64 encoded)
# - categories: User-applied categories/tags (array of strings)
# - flag: Follow-up flag information (object with status, dueDateTime)
#
# === Content Properties ===
# - hasAttachments: Whether attachments present (boolean)
# - attachments: List of attachment objects (array, requires $expand=attachments)
# - internetMessageId: Standard Message-ID header (string, RFC 5322)
# - internetMessageHeaders: Raw email headers (array of name-value pairs, requires select)
#
# === AI/ML Properties ===
# - inferenceClassification: focused | other (string, auto-categorization)
# - mentions: @mentions in message (array of mention objects)
#
# === Extension Properties ===
# - singleValueExtendedProperties: Custom single-value properties (array)
# - multiValueExtendedProperties: Custom multi-value properties (array)
#
# === Other Properties ===
# - webLink: URL to open message in Outlook web (string)
#
# === Field Selection Best Practices ===
#
# Minimal (for list views):
#   ['subject', 'from', 'receivedDateTime', 'hasAttachments', 'isRead']
#   ~1 KB per message
#
# Standard (for preview):
#   ['subject', 'from', 'toRecipients', 'receivedDateTime', 'bodyPreview', 'hasAttachments', 'isRead']
#   ~2 KB per message
#
# Full (for detail view):
#   ['subject', 'from', 'toRecipients', 'ccRecipients', 'receivedDateTime', 'sentDateTime',
#    'body', 'hasAttachments', 'attachments', 'isRead', 'importance', 'flag']
#   ~5-10 KB per message (more if large body or many attachments)
#
# Everything:
#   Don't specify $select parameter
#   ~10-20 KB per message (includes all ~40 properties)
#

if __name__ == '__main__':
    """Manual testing when GRAPH_TEST_TOKEN environment variable is set.
    
    Usage:
    1. Obtain OAuth2 token with Mail.Read scope
    2. Set environment: $env:GRAPH_TEST_TOKEN = "your_token_here"
    3. Run: python graphapi.py
    
    This will fetch emails from Sept 16-17, 2025 and display:
    - Complete log of operation
    - Number of messages retrieved
    - First message details (truncated to 1200 chars)
    
    Why Test Here?
    - Validates token acquisition
    - Tests API connectivity
    - Verifies date filtering
    - Demonstrates field selection
    - Useful for debugging Graph API issues
    """
    import os
    
    # Try to get test token from environment
    token = os.getenv('GRAPH_TEST_TOKEN')
    
    if not token:
        print('Set GRAPH_TEST_TOKEN to test manually.')
        print('Example: $env:GRAPH_TEST_TOKEN = "eyJ0eXAi..."')
        print('Token needs Mail.Read scope.')
    else:
        # Retrieve comprehensive set of fields for testing
        # This demonstrates field selection for detail view
        select_fields = [
            'subject', 'receivedDateTime', 'from', 
            'toRecipients', 'ccRecipients', 'bccRecipients',
            'body', 'bodyPreview', 'attachments', 
            'isRead', 'sentDateTime', 'hasAttachments'
        ]
        
        # Execute query with test parameters
        msgs, log = get_outlook_emails(
            token, 
            '2025-09-16T00:00:00Z',  # Start of Sept 16
            '2025-09-17T23:59:59Z',  # End of Sept 17
            select=select_fields
        )
        
        # Display results
        print(log)  # Show complete operation log
        print(f"\nFetched {len(msgs)} messages")
        
        # Display first message sample if any results
        if msgs:
            print("\nFirst message sample (truncated):")
            # json.dumps formats nicely with indentation
            # [:1200] truncates to prevent overwhelming output
            print(json.dumps(msgs[0], indent=2)[:1200])
