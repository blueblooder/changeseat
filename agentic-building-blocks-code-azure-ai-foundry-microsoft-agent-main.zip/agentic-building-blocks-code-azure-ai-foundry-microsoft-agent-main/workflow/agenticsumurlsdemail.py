"""Sequential workflow for URL summarization and email delivery.

This workflow implements a two-stage sequential pipeline combining agentic URL analysis with email composition.

Workflow Architecture:
    Connected Agents (Stage 1) → Email Writer (Stage 2) → Email Sender (Stage 3)
    
    URLSummarizerExecutor - Uses connected agents architecture from agentic/summariseURL.py
                          - Coordinator agent + URL summarizer agent
                          - Identifies URLs, fetches content, generates comprehensive summaries
    
    EmailWriterExecutor   - Wraps agent/emailwriter.py write_email_body()
                          - Takes URL summary as input
                          - Generates professional HTML email with subject#####body format
    
    EmailSenderExecutor   - Wraps helper/logicappemail.py send_email()
                          - Sends composed email via Azure Logic App
                          - Optional (skips if recipient_email is None)

Workflow State Machine Flow:
    IDLE → IDLE_WITH_PENDING_REQUESTS (URLSummaryRequest received)
         → PROCESSING (URLSummarizerExecutor analyzes URLs with connected agents)
         → PROCESSING (EmailWriterExecutor composes professional email)
         → PROCESSING (EmailSenderExecutor sends via Logic App if recipient configured)
         → COMPLETED (email sent or composed, workflow ends)

Message Flow:
    URLSummaryRequest → URLSummarizerExecutor → URLSummaryResult
                     → EmailWriterExecutor → EmailContent
                     → EmailSenderExecutor → Final Output

Prerequisites:
    - Azure AI Project endpoint for connected agents
    - Azure AI Model deployment for URL summarization and email writing
    - Azure Logic App endpoint for email sending (optional)
    
Execution Flow:
    1. User provides question with URLs (e.g., "Compare docs.microsoft.com/azure and aws.amazon.com")
    2. URLSummarizerExecutor:
       - Creates coordinator agent and URL summarizer connected agent
       - Coordinator identifies URLs from question
       - Fetches content for each URL
       - Delegates summarization to connected agent
       - Aggregates final comprehensive analysis
    3. EmailWriterExecutor:
       - Receives URL summary as raw text
       - Generates professional email with proper subject and HTML body
       - Returns formatted email (subject#####body)
    4. EmailSenderExecutor:
       - Parses subject and body from email writer output
       - Sends email via Logic App if recipient configured
       - Returns final output (subject + body)

Design Decisions:
    - Email sending controlled by recipient_email parameter (optional)
    - URL summary passed directly to email writer (no enrichment)
    - Workflow continues even if no URLs found (graceful degradation)
    - Subject line auto-generated from email writer agent response
    - Combined JSON artifact saved with URL summary + email content
"""

import os
import sys
from datetime import datetime
from typing import Optional, Callable
from dataclasses import dataclass

if __name__ == "__main__":
    repo_root = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
    if repo_root not in sys.path:
        sys.path.insert(0, repo_root)

from agent_framework import (
    Executor,
    WorkflowBuilder,
    WorkflowContext,
    WorkflowOutputEvent,
    handler,
    get_logger,
)
from agentic.summariseURL import run_summarise_url_agentic
from agent.emailwriter import write_email_body
from helper.logicappemail import send_email
from helper.emitter import create_emitter

DEFAULT_QUESTION = "Compare docs.microsoft.com/azure and aws.amazon.com/documentation for cloud services"

logger = get_logger()

# ============================================================================
# Dataclasses for Message Flow
# ============================================================================

@dataclass
class URLSummaryRequest:
    """Initial request to analyze URLs from user question."""
    question: str
    tracing_mode: str = "auto"


@dataclass
class URLSummaryResult:
    """URL analysis results from connected agents."""
    summary_text: str
    question: str
    url_count: int  # Number of URLs processed (for metadata)


@dataclass
class EmailContent:
    """Email composed from URL summary."""
    subject: str
    body: str  # HTML email body
    raw_summary: str  # Original URL summary for reference


# ============================================================================
# Executor Implementations
# ============================================================================

class URLSummarizerExecutor(Executor):
    """Analyzes URLs using connected agents architecture (coordinator + summarizer)."""
    
    def __init__(self, emitter: Optional[Callable[[str], None]] = None, tracing_mode: str = "auto", id: str = "url_summarizer"):
        super().__init__(id=id)
        self.emitter = emitter
        self.tracing_mode = tracing_mode
    
    @handler
    async def summarize_urls(self, request: URLSummaryRequest, ctx: WorkflowContext[URLSummaryResult]) -> None:
        """Execute URL summarization with connected agents."""
        emit = create_emitter(self.emitter).emit
        
        emit(f"[URLSummarizer] Starting URL analysis...")
        emit(f"[URLSummarizer] Question: {request.question}")
        emit(f"[URLSummarizer] Tracing mode: {self.tracing_mode}")
        
        # Run connected agents workflow (coordinator + url_summarizer)
        # Returns dict with 'summaries', 'output_text', 'log', 'traces', 'trace_summary'
        result = run_summarise_url_agentic(
            question=request.question,
            emitter=self.emitter,
            return_mode="both",
            tracing_mode=self.tracing_mode  # Inherit from workflow
        )
        
        # Extract summary text from result
        if isinstance(result, dict):
            summary_text = result.get("output_text", "")
            summaries_list = result.get("summaries", [])
            url_count = len(summaries_list) if summaries_list else 0
        else:
            summary_text = str(result)
            url_count = 0
        
        if not summary_text or summary_text.strip() == "":
            emit(f"[URLSummarizer] No summary generated - using fallback message")
            summary_text = f"No URLs were identified in the question: {request.question}"
            url_count = 0
        
        emit(f"[URLSummarizer] ✓ Analysis complete ({len(summary_text)} chars, {url_count} URLs)")
        
        # Send to email writer
        url_summary = URLSummaryResult(
            summary_text=summary_text,
            question=request.question,
            url_count=url_count
        )
        await ctx.send_message(url_summary, target_id="email_writer")


class EmailWriterExecutor(Executor):
    """Composes professional email from URL summary using Azure AI agent."""
    
    def __init__(self, emitter: Optional[Callable[[str], None]] = None, id: str = "email_writer"):
        super().__init__(id=id)
        self.emitter = emitter
    
    @handler
    async def compose_email(self, summary: URLSummaryResult, ctx: WorkflowContext[EmailContent]) -> None:
        """Generate professional email from URL summary."""
        emit = create_emitter(self.emitter).emit
        
        emit(f"[EmailWriter] Composing email from URL summary...")
        emit(f"[EmailWriter] Summary length: {len(summary.summary_text)} chars")
        
        # Use email writer agent to compose professional email
        # Pass URL summary as raw_body, original question as user_question for context
        result = write_email_body(
            raw_body=summary.summary_text,
            user_question=summary.question,
            emitter=self.emitter,
            return_mode="both",
            tracing_mode="none"  # Inherit workflow context, don't create duplicate parent span
        )
        
        if isinstance(result, dict):
            email_content = result.get("answer", result.get("output_text", ""))
        else:
            email_content = str(result)
        
        # Parse subject and body from agent response
        # Expected format: subject#####body
        if "#####" in email_content:
            subject_part, body_part = email_content.split("#####", 1)
            subject = subject_part.strip()
            body = body_part.strip()
        else:
            # Fallback: Auto-generate subject from question
            # Extract first 50 chars of question for subject
            question_preview = summary.question[:50]
            if len(summary.question) > 50:
                question_preview += "..."
            subject = f"URL Analysis Summary: {question_preview}"
            body = email_content
        
        emit(f"[EmailWriter] Email composed with subject: {subject}")
        emit(f"[EmailWriter] Body length: {len(body)} chars")
        
        # Send to email sender
        email_obj = EmailContent(
            subject=subject,
            body=body,
            raw_summary=summary.summary_text
        )
        await ctx.send_message(email_obj, target_id="email_sender")


class EmailSenderExecutor(Executor):
    """Sends email via Azure Logic App (optional)."""
    
    def __init__(self, emitter: Optional[Callable[[str], None]] = None, recipient_email: Optional[str] = None, id: str = "email_sender"):
        super().__init__(id=id)
        self.emitter = emitter
        self.recipient_email = recipient_email
    
    @handler
    async def send_email_output(self, email: EmailContent, ctx: WorkflowContext[str]) -> None:
        """Send composed email via Logic App or yield output."""
        emit = create_emitter(self.emitter).emit
        
        emit(f"[EmailSender] Processing email output...")
        emit(f"[EmailSender] Subject: {email.subject}")
        
        # Send email if recipient configured
        if self.recipient_email:
            emit(f"[EmailSender] Sending email to {self.recipient_email}...")
            
            send_result = send_email(
                to=self.recipient_email,
                subject=email.subject,
                body=email.body,
                emitter=self.emitter,
                return_mode="both",
                tracing_mode="none"  # Inherit workflow context
            )
            
            emit(f"[EmailSender] ✓ Email sent successfully")
        else:
            emit(f"[EmailSender] No recipient configured, skipping email send")
        
        # Yield final output - format as text
        output_text = f"{email.subject}\n\n{email.body}"
        await ctx.yield_output(output_text)


# ============================================================================
# Workflow Builder
# ============================================================================

def build_workflow(emitter: Optional[Callable[[str], None]] = None, recipient_email: Optional[str] = None, tracing_mode: str = "auto"):
    """Build the sequential URL summarization to email workflow with OpenTelemetry tracing.
    
    Workflow flow:
        URLSummarizerExecutor → EmailWriterExecutor → EmailSenderExecutor → Output
    """
    
    # Create executors
    url_summarizer = URLSummarizerExecutor(emitter=emitter, tracing_mode=tracing_mode)
    email_writer = EmailWriterExecutor(emitter=emitter)
    email_sender = EmailSenderExecutor(emitter=emitter, recipient_email=recipient_email)
    
    # Build sequential workflow
    workflow = (
        WorkflowBuilder()
        .set_start_executor(url_summarizer)
        .add_edge(url_summarizer, email_writer)
        .add_edge(email_writer, email_sender)
        .build()
    )
    
    return workflow


# ============================================================================
# Public Interface
# ============================================================================

def run_agentic_sum_urls_email(
    question: str,
    emitter: Optional[Callable[[str], None]] = None,
    return_mode: str = "both",
    recipient_email: Optional[str] = None,
    tracing_mode: str = "auto",  # 'auto' | 'both' | 'azure_monitor' | 'console' | 'none'
    save_json: Optional[str] = None,
) -> str | dict:
    """Run the URL summarization to email workflow.
    
    This is a synchronous wrapper around the async workflow execution.
    
    Parameters
    ----------
    question : str
        User question containing URLs to analyze (e.g., "Compare docs.microsoft.com/azure and aws.amazon.com").
    emitter : Callable[[str], None]
        Optional callback for streaming log lines.
    return_mode : str
        'log' | 'answer' | 'both' (default: 'both')
    recipient_email : str
        Email address to send summary to (if None, email not sent, only composed).
    tracing_mode : str
        Controls where traces are sent:
        'auto' (default) -> Azure Monitor if APPLICATIONINSIGHTS_CONNECTION_STRING is set, else console
        'both' -> Send to both Azure Monitor and local file
        'azure_monitor' -> Send to Azure Monitor / Application Insights (viewable in Azure AI Foundry)
        'console' -> Print traces to console
        'none' -> Disable tracing
    save_json : str
        Optional path to save combined artifact (URL summary + email content).
    
    Returns
    -------
    str | dict
        Depending on return_mode:
        - 'log': Full execution log
        - 'answer': Email output text (subject + body)
        - 'both': {'output_text': str, 'answer': str, 'log': str, 'traces': list, 'trace_summary': dict, 'trace_file': str}
    """
    # Validate recipient_email if provided
    if recipient_email is not None and recipient_email.strip() == "":
        error_msg = "[ERROR] recipient_email is empty string. Please provide valid email address or use None to skip sending."
        if emitter:
            emitter(error_msg)
        
        # Return error based on return_mode
        if return_mode == "log":
            return error_msg
        elif return_mode == "answer":
            return error_msg
        else:  # both
            return {
                "output_text": "",
                "answer": error_msg,
                "log": error_msg,
                "traces": [],
                "trace_summary": {},
                "trace_file": ""
            }
    
    import asyncio
    return asyncio.run(_run_agentic_sum_urls_email_async(
        question=question,
        emitter=emitter,
        return_mode=return_mode,
        recipient_email=recipient_email,
        tracing_mode=tracing_mode,
        save_json=save_json
    ))


async def _run_agentic_sum_urls_email_async(
    question: str,
    emitter: Optional[Callable[[str], None]] = None,
    return_mode: str = "both",
    recipient_email: Optional[str] = None,
    tracing_mode: str = "auto",
    save_json: Optional[str] = None,
) -> str | dict:
    """Async implementation of the URL summarization to email workflow.
    
    Execution Flow:
        1. Create emitter utility for logging
        2. Auto-detect tracing mode if 'auto'
        3. Setup unified trace manager
        4. Emit workflow header
        5. Build sequential workflow (url_summarizer -> email_writer -> email_sender)
        6. Start parent tracing span
        7. Create URLSummaryRequest
        8. Execute workflow stream
        9. Capture final output
        10. End parent span
        11. Collect trace lines and summary
        12. Store traces to local file if enabled
        13. Emit trace summary
        14. Save combined JSON artifact if requested
        15. Return payload based on return_mode
    """
    
    # STEP 1: Create centralized emitter utility
    # Why? Enable consistent logging with flexible emitter injection for UI integration
    emit_util = create_emitter(emitter)
    emit = emit_util.emit
    
    # STEP 2: Auto-detect tracing mode if set to 'auto'
    # Why? Intelligently enable Azure Monitor tracing when connection string exists, fallback to console
    if tracing_mode == "auto":
        application_insights_connection_string = os.environ.get("APPLICATIONINSIGHTS_CONNECTION_STRING")
        if application_insights_connection_string and application_insights_connection_string.strip():
            tracing_mode = "both"
            emit("[TRACING] Auto-detected APPLICATIONINSIGHTS_CONNECTION_STRING - using dual tracing mode")
        else:
            tracing_mode = "console"
            emit("[TRACING] No APPLICATIONINSIGHTS_CONNECTION_STRING found - using console tracing")
    
    # STEP 3: Setup tracing using UnifiedTraceManager
    # Why? Initialize OpenTelemetry instrumentation for workflow/executor/message span capture
    from helper.unified_trace_manager import UnifiedTraceManager
    trace_mgr = UnifiedTraceManager(tracing_mode=tracing_mode, trace_type="workflow", emitter=emit)
    trace_mgr.setup()
    
    # STEP 4: Enhanced logging for observability
    # Why? Record workflow initiation in both application logger and emitter for debugging
    logger.info(f"Starting URL summarization to email workflow: {question[:100]}")
    emit("[OBSERVABILITY] OpenTelemetry tracing enabled - capturing spans")
    
    # STEP 5: Emit workflow header
    # Why? Provide visibility into workflow configuration for user/debugger
    emit("=" * 80)
    emit("URL SUMMARIZATION -> EMAIL COMPOSITION -> SEND WORKFLOW")
    emit("=" * 80)
    emit(f"Question: {question}")
    emit(f"Recipient: {recipient_email if recipient_email else 'None (email will be composed but not sent)'}")
    emit(f"Tracing mode: {tracing_mode}")
    emit("")
    
    # STEP 6: Build sequential workflow
    # Why? Create executor pipeline: URLSummarizer -> EmailWriter -> EmailSender
    emit("[OBSERVABILITY] Building workflow - this will emit workflow.build spans")
    workflow = build_workflow(emitter=emitter, recipient_email=recipient_email, tracing_mode=tracing_mode)
    logger.info("Workflow graph built successfully")
    emit("[OBSERVABILITY] Workflow built - ready to execute")
    
    # STEP 7: Start parent span for tracing
    # Why? Capture end-to-end telemetry with workflow-level metadata
    question_preview = question[:50]
    trace_mgr.start_parent_span(
        span_name=f"agentic_sum_urls_email: {question_preview}",
        attributes={
            "question": question,
            "has_recipient": recipient_email is not None,
            "tracing_mode": tracing_mode,
            "recipient_email": recipient_email if recipient_email else ""
        }
    )
    
    # STEP 8: Create URLSummaryRequest
    # Why? Package workflow parameters into dataclass for executor consumption
    request = URLSummaryRequest(
        question=question,
        tracing_mode=tracing_mode
    )
    
    # STEP 9: Execute workflow stream
    # Why? Run sequential pipeline with async streaming to capture final output
    emit("\n[WORKFLOW] Starting execution...")
    emit("[OBSERVABILITY] Running workflow - workflow.run, executor.process, and message.send spans will be nested under parent")
    logger.info("Starting workflow execution")
    workflow_start_time = datetime.now()
    
    final_output = None
    success = False
    try:
        async for event in workflow.run_stream(request):
            if isinstance(event, WorkflowOutputEvent):
                final_output = event.data
                emit("")
                emit("=" * 30)
                emit("WORKFLOW COMPLETE")
                emit("=" * 30)
        
        # STEP 10: Calculate workflow elapsed time
        # Why? Provide performance visibility for pipeline execution
        workflow_end_time = datetime.now()
        workflow_elapsed = (workflow_end_time - workflow_start_time).total_seconds() * 1000
        
        output_text = final_output if final_output else "No output from workflow"
        success = final_output is not None
        emit(f"\n[WORKFLOW] ✓ Completed in {workflow_elapsed:.0f}ms ({workflow_elapsed/1000:.2f}s)")
        emit("=" * 80)
        
        logger.info("Workflow completed successfully")
        
    except Exception as exc:
        # STEP 11: Handle workflow exceptions with telemetry recording
        # Why? Capture unexpected failures in both logs and traces for debugging
        emit(f"\n[WORKFLOW] ✗ Failed: {exc}")
        logger.error(f"Workflow exception: {exc}", exc_info=True)
        import traceback
        emit(f"[DEBUG] Traceback:\n{traceback.format_exc()}")
        output_text = f"[ERROR] Workflow failed: {exc}"
        workflow_elapsed = 0
        
        trace_mgr.record_exception(exc, f"Workflow exception: {exc}")
    finally:
        # STEP 12: End parent span regardless of success/failure
        # Why? Ensure telemetry span is closed properly for complete trace capture
        trace_mgr.end_parent_span()
    
    # STEP 13: Collect complete log from emitter
    # Why? Extract all emitted messages for log-based return modes and JSON artifact
    log_joined = emit_util.get_log()
    
    # STEP 14: Get traces from unified trace manager
    # Why? Retrieve OpenTelemetry spans and summary statistics for observability
    trace_lines = trace_mgr.get_traces()
    trace_summary = {}
    trace_file = None
    
    # STEP 15: Emit Azure Monitor tracing confirmation if applicable
    # Why? Inform user where to view traces when Azure Monitor mode is active
    if tracing_mode == "azure_monitor" or tracing_mode == "both":
        emit("")
        emit("AZURE MONITOR TRACING")
        emit("✅ Workflow traces have been sent to Azure Monitor / Application Insights")
        emit("📊 View traces in Azure AI Foundry Portal: https://ai.azure.com")
        emit("")
    
    # STEP 16: Store traces to local file and emit summary if console/both/local mode
    # Why? Persist telemetry for offline analysis and display span statistics for visibility
    if tracing_mode in ["console", "both", "local"]:
        # Get trace summary if available
        if trace_lines:
            trace_summary = {'total_spans': len(trace_lines), 'workflow_elapsed_ms': workflow_elapsed}
            
            # Store traces to local file if enabled
            if tracing_mode in ["console", "both", "local"]:
                from helper.storeotel import store_otel_traces_to_local
                from helper.otel_collector import get_span_collector
                span_collector = get_span_collector()
                metadata = span_collector.get_metadata() if span_collector else {}
                trace_file, store_log = store_otel_traces_to_local(
                    traces=trace_lines,
                    trace_summary=trace_summary,
                    query=f"URL summary email: {question[:50]}",
                    metadata=metadata,
                    prefix='agenticsumurlsemail',
                    emitter=emit
                )
                if trace_file:
                    emit(f"[OTEL] Traces saved to: {trace_file}")
            
            # Add trace summary to log
            emit("")
            emit("=" * 30)
            emit("OPENTELEMETRY TRACE SUMMARY")
            emit("=" * 30)
            emit(f"Total Spans: {trace_summary['total_spans']}")
            emit(f"Workflow Elapsed Time: {trace_summary['workflow_elapsed_ms']:.2f}ms ({trace_summary['workflow_elapsed_ms']/1000:.2f}s)")
            emit("")
    
    # STEP 17: Save combined JSON artifact if requested
    # Why? Persist complete workflow results (URL summary + email) for offline analysis
    if save_json:
        import json
        import pathlib
        try:
            path_obj = pathlib.Path(save_json)
            path_obj.parent.mkdir(parents=True, exist_ok=True)
            
            artifact = {
                "question": question,
                "output_text": output_text,
                "log": log_joined,
                "success": success,
                "architecture": "sequential_workflow",
                "stages": ["url_summarization", "email_composition", "email_sending"],
                "traces": trace_lines,
                "trace_summary": trace_summary,
                "timestamp": datetime.now().isoformat()
            }
            
            json.dump(
                artifact,
                path_obj.open('w', encoding='utf-8'),
                ensure_ascii=False,
                indent=2,
            )
            emit(f"[ARTIFACT] Combined workflow results saved to: {save_json}")
        except Exception as exc:
            emit(f"[WARN] Failed to save JSON artifact: {exc}")
            # Update log with latest messages
            log_joined = emit_util.get_log()
    
    # STEP 18: Return payload based on return_mode
    # Why? Support three return formats: 'both' (dict), 'answer' (str), 'log' (str)
    if return_mode == "both":
        return {
            "output_text": output_text,
            "answer": output_text,
            "log": log_joined,
            "success": success,
            "traces": trace_lines,
            "trace_summary": trace_summary,
            "trace_file": trace_file
        }
    elif return_mode == "answer":
        return output_text
    else:  # 'log'
        return log_joined


# ============================================================================
# CLI Entry Point
# ============================================================================

if __name__ == "__main__":
    from dotenv import load_dotenv
    
    load_dotenv()
    
    # Get configuration from environment or command line
    question = sys.argv[1] if len(sys.argv) > 1 and sys.argv[1].strip() else DEFAULT_QUESTION
    tracing_mode = sys.argv[2] if len(sys.argv) > 2 else "auto"
    recipient = os.getenv("DEFAULT_EMAIL_RECIPIENT")
    
    print(f"\nRunning URL Summarization -> Email Composition -> Send Workflow")
    print(f"Question: {question}")
    print(f"Recipient: {recipient if recipient else 'None (email will be composed but not sent)'}")
    print(f"Tracing mode: {tracing_mode}")
    print("\nAvailable tracing modes:")
    print("  - 'auto': Use Azure Monitor if configured, else console (default)")
    print("  - 'both': Send to both Azure Monitor and local file")
    print("  - 'azure_monitor': Send traces to Azure AI Foundry")
    print("  - 'console': Print traces to console")
    print("  - 'none': Disable tracing")
    print()
    
    # Run workflow
    result = run_agentic_sum_urls_email(
        question=question,
        recipient_email=recipient,
        return_mode="both",
        tracing_mode=tracing_mode,
        save_json=f"opentele_local/agentic_sum_urls_email_{datetime.now().strftime('%Y%m%d-%H%M%S')}.json"
    )
    
    # Display results
    if isinstance(result, dict):
        print("\n" + "=" * 80)
        print("WORKFLOW RESULT")
        print("=" * 80)
        print(f"\nOutput:\n{result.get('output_text', '')}")
        
        trace_summary = result.get('trace_summary', {})
        if trace_summary:
            print("\n" + "-" * 80)
            print("TRACE SUMMARY")
            print("-" * 80)
            print(f"Total Spans: {trace_summary.get('total_spans', 0)}")
            elapsed_ms = trace_summary.get('workflow_elapsed_ms', 0)
            print(f"⏱️  Workflow Elapsed: {elapsed_ms:.0f}ms" if elapsed_ms < 1000 else f"{elapsed_ms/1000:.2f}s")
        
        trace_file = result.get('trace_file')
        if trace_file:
            print(f"\n📁 Traces saved to: {trace_file}")
    else:
        print(f"\nResult: {result}")
