# From Rule-Based to Agentic: A Paradigm Shift in AI Application Design

## The Core Concept: Beyond the First Hop

In this repository, you'll find two implementations of URL summarization:
- **`agent/summariseURL.py`** - The traditional rule-based approach
- **`agentic/summariseURL.py`** - The modern agentic approach

**Why build the same functionality twice?** Because it demonstrates a fundamental evolution in human-computer interaction and application design.

---

## The Evolution of Human-Computer Interaction

### The Past: GUI-Driven Applications

```
┌─────────────────────────────────────────────────────────────┐
│  Traditional GUI Application Architecture                    │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  User learns GUI → Clicks buttons → Fills forms              │
│                           ↓                                   │
│                  Rule-Based Logic                             │
│                           ↓                                   │
│  if (button == "Submit") { validate(); process(); }           │
│  if (checkbox == checked) { enableField(); }                  │
│  if (dropdown == "Option A") { showPanelA(); }                │
│                           ↓                                   │
│                      Predictable Outputs                      │
│                                                               │
└─────────────────────────────────────────────────────────────┘
```

**Characteristics:**
- ✅ **Bounded input space**: Users can only interact through predefined UI elements
- ✅ **Predictable**: Every button, dropdown, checkbox has a known function
- ✅ **Rule-based logic works perfectly**: `if-else` statements cover all possible GUI interactions

**Example - Traditional URL Input Form:**
```
┌────────────────────────────────┐
│ Enter URL 1: [              ] │
│ Enter URL 2: [              ] │
│ [ Compare URLs ]  Button      │
└────────────────────────────────┘
```
Rule-based code handles this easily:
```python
if url1.startswith("http") and url2.startswith("http"):
    compare(url1, url2)
else:
    show_error("Invalid URL format")
```

---

### The Present: Natural Language Interface

```
┌─────────────────────────────────────────────────────────────┐
│  Modern Agentic Application Architecture                     │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  User speaks/types naturally → "Compare the Azure and AWS     │
│  documentation, I think the URLs are docs.microsoft and       │
│  aws.amazon or something like that"                           │
│                           ↓                                   │
│               🤖 LLM-Driven Intelligence                      │
│                           ↓                                   │
│  ┌─────────────────────────────────────────────────┐         │
│  │ LLM Interprets Intent:                          │         │
│  │ • "docs.microsoft" → docs.microsoft.com/azure   │         │
│  │ • "aws.amazon" → aws.amazon.com/documentation   │         │
│  │ • "or something like that" → infer full URLs    │         │
│  │ • "Compare" → need summaries of both            │         │
│  └─────────────────────────────────────────────────┘         │
│                           ↓                                   │
│         LLM Orchestrates Workflow (Not Your Code)             │
│                           ↓                                   │
│                    Intelligent Outputs                        │
│                                                               │
└─────────────────────────────────────────────────────────────┘
```

**The Problem with Halfway Solutions:**

❌ **Common Mistake - Only Using LLM for "First Hop":**
```python
# Use LLM to understand natural language...
user_input = "Compare docs.microsoft and aws.amazon"
structured_data = llm.extract_urls(user_input)  # LLM extracts URLs

# ...but then fall back to rule-based logic!
for url in structured_data.urls:
    if not url.startswith("http"):
        url = "https://" + url  # ← Still writing rules!
    if "microsoft" in url:
        url = url + "/azure"    # ← Still hardcoding logic!
    # More rule-based code...
```

**Why this fails:**
- You've moved the **interface** to natural language, but kept the **logic** rule-based
- You still need to anticipate and code every possible variation
- The moment users express something unexpected, you need to update your rules

---

## The Breakthrough: Fully Agentic Design

**True agentic design means:**
> **Passing control to the LLM not just for understanding input, but for orchestrating the entire application logic through declarative instructions.**

Instead of:
```python
# Rule-based: You write the logic
if url_is_incomplete(url):
    url = repair_url(url)
if url_mentions_microsoft(url):
    url = complete_microsoft_url(url)
```

You do:
```yaml
# Agentic: You write the instruction, LLM executes the logic
instructions: |
  When the user mentions URLs (complete or incomplete):
  1. Intelligently infer the complete, valid URL
  2. Handle common patterns (e.g., "docs.microsoft" → "https://docs.microsoft.com/azure")
  3. Use context clues from the question to determine the specific documentation page
  4. Normalize all URLs to valid https:// format
```

---

## Concrete Example: URL Typos and Incomplete References

### Scenario: User Input with Imperfect URLs

**User says:**
> *"Can you summarize **docs.micrsoft.com/azure** and **aws.amazon/documentation**? Also check the **kubernetes docs**."*

**Issues:**
1. ❌ `docs.micrsoft.com` - Typo: "micrsoft" instead of "microsoft"
2. ❌ `aws.amazon/documentation` - Missing `.com` and `https://`
3. ❌ `kubernetes docs` - Not a URL at all, just a reference

---

### Rule-Based Approach (`agent/summariseURL.py`)

**What happens:**

```python
# Step 1: Regex extraction
url_pattern = r'(?:https?://)?(?:www\.)?[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}...'
found_urls = re.findall(url_pattern, user_input)
# Result: ['docs.micrsoft.com/azure', 'aws.amazon/documentation']

# Step 2: Manual repair logic
for url in found_urls:
    if not url.startswith("http"):
        url = "https://" + url  # Fix missing protocol
    # But "micrsoft" typo remains!
    # "kubernetes docs" is completely missed!
```

**Problems:**
- ❌ Typo `micrsoft.com` stays wrong → **fetching fails**
- ❌ `kubernetes docs` not recognized → **ignored entirely**
- ❌ Need to write **typo correction dictionary** for every possible mistake
- ❌ Need to write **inference rules** for mapping "kubernetes docs" → `kubernetes.io/docs`

**To fix this, you'd need:**
```python
# Typo correction dictionary
COMMON_TYPOS = {
    "micrsoft": "microsoft",
    "gogle": "google",
    "amazn": "amazon",
    # ... hundreds more
}

# Reference-to-URL mapping
KNOWN_DOCS = {
    "kubernetes docs": "https://kubernetes.io/docs",
    "react docs": "https://react.dev/docs",
    # ... hundreds more
}

# Then update your code to use these dictionaries...
# And redeploy every time you find a new pattern!
```

---

### Agentic Approach (`agentic/summariseURL.py`)

**What happens:**

```yaml
# From config/agentic_config.yaml
coordinator:
  instructions: |
    Analyze the user's question and identify all URLs or documentation references.
    
    For incomplete or ambiguous references:
    - Infer the complete, valid URL using context and common knowledge
    - Correct common typos in domain names
    - Map documentation references to their actual URLs
    
    Examples:
    - "docs.micrsoft.com" → "https://docs.microsoft.com" (correct typo)
    - "aws.amazon/docs" → "https://aws.amazon.com/documentation/" (complete URL)
    - "kubernetes docs" → "https://kubernetes.io/docs" (infer from reference)
```

**The LLM coordinator reasons:**

```
🤖 Coordinator Agent's Internal Reasoning:

Input: "docs.micrsoft.com/azure and aws.amazon/documentation? Also check the kubernetes docs"

Analysis:
1. "docs.micrsoft.com/azure"
   → Likely typo: "micrsoft" should be "microsoft"
   → Complete URL: https://docs.microsoft.com/azure

2. "aws.amazon/documentation"
   → Missing TLD and protocol
   → Complete URL: https://aws.amazon.com/documentation/

3. "kubernetes docs"
   → Common documentation reference
   → Resolve to: https://kubernetes.io/docs/

Identified URLs:
- https://docs.microsoft.com/azure
- https://aws.amazon.com/documentation/
- https://kubernetes.io/docs/
```

**Result:**
✅ Typo corrected automatically  
✅ Incomplete URL completed  
✅ Documentation reference resolved  
✅ **No code changes needed**  
✅ **No typo dictionary maintained**  
✅ **No URL mapping database required**  

---

## Why This Matters: The Impossibility of Complete Rule Coverage

### Traditional Rule-Based Programming Assumption:
> "If I enumerate all possible inputs and write rules for each, my application will work."

**This worked when:**
- Input was constrained (GUI buttons, dropdowns)
- Users were trained to use specific formats
- Edge cases were manageable

**This breaks when:**
- Input is natural language (infinite variations)
- Users express intent in unpredictable ways
- Context changes the meaning of the same words

---

### The Infinite Variation Problem

**All these mean the same thing:**
- "Check docs.microsoft.com/azure and aws.amazon.com/documentation"
- "Compare the Azure and AWS docs"
- "I want to see the main pages for Azure and AWS documentation"
- "Can you pull up the Microsoft Azure docs and the Amazon Web Services guides?"
- "docs.microsoft and aws.amazon (you know what I mean)"
- "The usual Azure and AWS documentation pages"

**In rule-based programming, you'd need:**
```python
if "azure" in query and "aws" in query and ("compare" in query or "check" in query):
    urls = ["https://docs.microsoft.com/azure", "https://aws.amazon.com/documentation"]
elif "Azure docs" in query and "AWS" in query:
    urls = ["https://docs.microsoft.com/azure", "https://aws.amazon.com/documentation"]
elif "microsoft" in query and "amazon web services" in query:
    urls = ["https://docs.microsoft.com/azure", "https://aws.amazon.com/documentation"]
# ... infinite variations
```

**In agentic programming, you write once:**
```yaml
instructions: |
  Identify URLs or documentation references in the user's question.
  Use context and inference to resolve ambiguous or incomplete references.
```

**The LLM handles all variations automatically.**

---

## Key Architectural Differences

### 1. **URL Detection & Extraction**

| Aspect | Rule-Based (`agent/`) | Agentic (`agentic/`) |
|--------|----------------------|---------------------|
| **URL Detection** | Hardcoded regex parsing: `url_pattern = r'(?:https?://)?(?:www\.)?[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}...'` | **LLM identifies URLs** through natural language understanding |
| **Typo Handling** | ❌ No typo correction - requires manual dictionary | ✅ **LLM corrects typos** using language understanding (e.g., `micrsoft` → `microsoft`) |
| **Incomplete URLs** | Manual repair logic: `if not url.startswith(('http://', 'https://')): url = 'https://' + url` | **LLM infers and normalizes** based on context |
| **Ambiguous References** | ❌ Cannot handle "check the Microsoft docs and AWS guides" | ✅ LLM resolves to actual URLs: `docs.microsoft.com/azure`, `aws.amazon.com/documentation` |

**Example from `agent/summariseURL.py`:**
```python
def parse_understanding_response(response_text: str) -> tuple[str, List[str]]:
    """
    Parse the understanding agent response to extract refined question and URLs.
    """
    # Complex regex parsing logic - cannot handle typos or inference
    url_pattern = r'(?:https?://)?(?:www\.)?[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}(?:[/\w\-._~:/?#@!$&\'()*+,;=%]*)?'
    found_urls = re.findall(url_pattern, response_text)
    
    for url in found_urls:
        url = url.strip('`*\"\'()[]{}.,;')
        if not url.startswith(('http://', 'https://')):
            url = 'https://' + url  # Manual normalization - typos remain!
```

**Contrast with `agentic/summariseURL.py`:**
```python
# No complex regex! The coordinator agent identifies URLs intelligently
identification_message = load_message_template('url_identification', question=question)
agents_client.messages.create(thread_id=main_thread.id, role="user", content=identification_message)

# The LLM coordinator returns clean, normalized URLs with typos corrected
all_urls = re.findall(r'https://[^\s<>"{}|\\^`\[\]*]+', coordinator_response)
```

---

### 2. **Agent Orchestration**

| Aspect | Rule-Based | Agentic |
|--------|-----------|---------|
| **Workflow Control** | **Hardcoded sequence** in Python code:<br>1. Understanding agent<br>2. Parse response<br>3. For each URL → create summarizer agent<br>4. Aggregate results | **LLM-driven delegation**:<br>Coordinator decides when/how to delegate to connected agents |
| **Agent Creation** | **One agent per URL** (resource-intensive) | **Reusable connected agents** |
| **Decision Making** | **Procedural**: `for url in urls: create_agent(url)` | **Intelligent**: Coordinator assesses and delegates |

**Example from `agent/summariseURL.py` (Sequential Pipeline):**
```python
# Step 1: Create understanding agent
understanding_agent = agents_client.create_agent(...)
run1 = agents_client.runs.create_and_process(...)

# Step 2: Parse the understanding agent's response using regex
refined_question, urls = parse_understanding_response(understanding_output)

# Step 3: Loop through URLs and create one agent per URL
for url in urls:
    summariser_agent = agents_client.create_agent(...)  # New agent for each URL!
    thread = agents_client.threads.create()  # New thread for each URL!
    run2 = agents_client.runs.create_and_process(...)
    agents_client.delete_agent(summariser_agent.id)  # Cleanup after each URL
```

**Contrast with `agentic/summariseURL.py` (Connected Agents):**
```python
# Step 1: Create ONE reusable URL summarizer agent
url_summarizer_agent = agents_client.create_agent(...)

# Step 2: Create connected agent tool
connected_summarizer = ConnectedAgentTool(id=url_summarizer_agent.id, ...)

# Step 3: Create coordinator with connected agent
coordinator_agent = agents_client.create_agent(..., tools=connected_summarizer.definitions)

# Step 4: Coordinator intelligently delegates to the connected agent as needed
# No loops, no manual parsing - the LLM decides everything!
run_result = agents_client.runs.create_and_process(thread_id=main_thread.id, agent_id=coordinator_agent.id)
```

---

### 3. **Prompt Engineering vs. Code Logic**

| Aspect | Rule-Based | Agentic |
|--------|-----------|---------|
| **Business Logic** | **In Python code**: `if`, `for`, `while`, `try/except` | **In prompts/instructions**: Template-driven messages in YAML config |
| **Adaptability** | Change code → Redeploy | Change prompt → No redeployment |
| **Error Handling** | **Explicit try/catch** blocks for every scenario | **LLM reasoning** handles unexpected cases gracefully |

**Example from `agent/summariseURL.py` (Code-Driven Logic):**
```python
def parse_understanding_response(response_text: str) -> tuple[str, List[str]]:
    # 50+ lines of parsing logic with conditionals
    in_refined_question = False
    in_repaired_urls = False
    
    for line in lines:
        if "**REFINED USER QUESTION:**" in line.upper():
            in_refined_question = True
            in_repaired_urls = False
        elif "**REPAIRED URLS:**" in line.upper():
            in_refined_question = False
            in_repaired_urls = True
        # ... more conditional logic
```

**Contrast with `agentic/summariseURL.py` (Prompt-Driven Logic):**
```yaml
# From config/agentic_config.yaml
coordinator:
  messages:
    url_identification: |
      Analyze this question and identify all URLs mentioned or implied:
      {question}
      
      Correct any typos in domain names and provide clean, normalized URLs.
      
    url_analysis: |
      Please analyze URL {url_index} of {total_urls}:
      URL: {url}
      Content Type: {content_type}
      
      Delegate to the URL summarizer specialist to create a focused summary.
```

---

## Visual Comparison: Architecture Diagrams

### Rule-Based Architecture (`agent/summariseURL.py`)

```
┌────────────────────────────────────────────────────────────┐
│                     User Question                          │
│  "Compare docs.micrsoft.com/azure and aws.amazon/docs"     │
└────────────────┬───────────────────────────────────────────┘
                 │
                 ▼
┌────────────────────────────────────────────────────────────┐
│  Understanding Agent (Agent 1)                             │
│  • Processes question                                      │
│  • Returns structured text                                 │
└────────────────┬───────────────────────────────────────────┘
                 │
                 ▼
┌────────────────────────────────────────────────────────────┐
│  Python Regex Parser (Your Code)                          │
│  • Extracts URLs with regex                                │
│  • Manual normalization (typos remain!)                    │
│  Result: ['docs.micrsoft.com', 'aws.amazon/docs']          │
└────────────────┬───────────────────────────────────────────┘
                 │
        ┌────────┴────────┐
        │                 │
        ▼                 ▼
┌──────────────┐  ┌──────────────┐
│ Summarizer   │  │ Summarizer   │
│ Agent 2      │  │ Agent 3      │
│ (URL 1)      │  │ (URL 2)      │
│              │  │              │
│ ❌ Fails!    │  │ ❌ Fails!    │
│ Typo causes  │  │ Incomplete   │
│ fetch error  │  │ URL error    │
└──────────────┘  └──────────────┘
```

**Resource Count:**
- 3 agents created (1 understanding + 2 summarizers)
- 3 threads created
- Manual parsing code required
- ❌ Fails on typos and incomplete URLs

---

### Agentic Architecture (`agentic/summariseURL.py`)

```
┌────────────────────────────────────────────────────────────┐
│                     User Question                          │
│  "Compare docs.micrsoft.com/azure and aws.amazon/docs"     │
└────────────────┬───────────────────────────────────────────┘
                 │
                 ▼
┌────────────────────────────────────────────────────────────┐
│  Coordinator Agent (Main LLM Orchestrator)                 │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ 🤖 LLM Reasoning:                                    │  │
│  │ • Detects typo: "micrsoft" → "microsoft"            │  │
│  │ • Completes: "aws.amazon" → "aws.amazon.com"        │  │
│  │ • Normalizes to: https:// URLs                      │  │
│  │                                                      │  │
│  │ Identified:                                          │  │
│  │ 1. https://docs.microsoft.com/azure                 │  │
│  │ 2. https://aws.amazon.com/docs                      │  │
│  └──────────────────────────────────────────────────────┘  │
│                                                             │
│  Delegates to Connected Agent ──────────────────────────┐  │
└──────────────────────────────────────────────────────────┼──┘
                                                           │
                                                           ▼
                                           ┌───────────────────────────┐
                                           │ URL Summarizer            │
                                           │ (Connected Agent)         │
                                           │                           │
                                           │ ✅ Processes URL 1        │
                                           │ ✅ Processes URL 2        │
                                           │ (Same agent, reused)      │
                                           └───────────────────────────┘
```

**Resource Count:**
- 2 agents created (1 coordinator + 1 reusable summarizer)
- 1 thread (shared conversation)
- No parsing code needed
- ✅ Handles typos and incomplete URLs automatically

---

## Real-World Scenario: Handling Complex Variations

### **User Question:**
*"I'm preparing a presentation comparing cloud platforms. Can you summarize the main Azure and AWS documentation pages people usually reference?"*

### Rule-Based Approach (`agent/summariseURL.py`)

**❌ Challenges:**
1. **No explicit URLs** - Regex finds nothing: `found_urls = []`
2. **"Usually reference"** - No database of "usual pages" in code
3. **Vague intent** - Is it compute, storage, networking, or all services?

**What happens:**
```python
urls = parse_understanding_response(understanding_output)
if not urls:
    emit("[INFO] No URLs detected in the question.")
    return emit_util.get_log()  # Process stops here!
```

**To fix this, you'd need to:**
- Add a knowledge base mapping "Azure documentation" → `docs.microsoft.com/azure`
- Write rules to infer "main pages" 
- Handle "usually reference" with hardcoded defaults
- **Redeploy the entire application**

---

### Agentic Approach (`agentic/summariseURL.py`)

**✅ Success:**
The coordinator agent **reasons** through the request:

1. **Infers URLs:**
   - "Azure documentation" → `https://docs.microsoft.com/azure/`
   - "AWS documentation" → `https://aws.amazon.com/documentation/`

2. **Understands "main pages":**
   - Focuses on overview/getting started sections
   - Prioritizes commonly referenced topics

3. **Adapts to "presentation" context:**
   - Highlights comparison-friendly information
   - Structures output for presentation format

**The code:**
```python
# The coordinator agent identifies URLs through LLM reasoning
identification_message = load_message_template('url_identification', question=question)
agents_client.messages.create(thread_id=main_thread.id, role="user", content=identification_message)

# LLM returns: https://docs.microsoft.com/azure/, https://aws.amazon.com/documentation/
# No hardcoded mapping needed!
```

---

## The Philosophy: "More Agentic" Means LLM-Driven Intelligence

### ❌ **NOT Agentic:**
*"An application that calls an LLM API to generate text"*
```python
# This is just using LLM as a text generator
response = llm.complete("Summarize this: " + content)
print(response)
```

### ❌ **HALF Agentic (First Hop Only):**
*"Using LLM for input parsing, then falling back to rule-based logic"*
```python
# Use LLM to parse input...
parsed = llm.extract_entities(user_input)

# ...but then hardcode the rest
if parsed.intent == "compare":
    if parsed.url1 and parsed.url2:
        # Still writing rules for every scenario
        result = compare_urls(parsed.url1, parsed.url2)
```

### ✅ **Truly Agentic:**
*"An application where the LLM makes decisions, adapts to context, and orchestrates workflows"*
```python
# LLM decides what to do, when, and how
coordinator_agent = create_agent(
    instructions="Analyze the question, determine what information is needed, "
                 "correct any typos or incomplete references, "
                 "delegate to specialists as appropriate, and synthesize results."
)
# The LLM handles the complexity, not your code
```

---

## Key Insight: Bypassing Application Logic with Declarative Instructions

### Traditional Programming (Rule-Based):
```
User Input → Parse → Validate → Route → Process → Format → Output
     ↑                                                         ↓
     └────── All logic hardcoded in your application ─────────┘
```

**Every edge case needs a new rule.**

**Example:**
```python
# You write the logic for everything
def process_urls(user_input):
    urls = extract_urls_regex(user_input)
    for url in urls:
        if not is_valid(url):
            url = repair_url(url)  # Your logic
        if has_typo(url):
            url = correct_typo(url)  # Your logic
        if is_incomplete(url):
            url = complete_url(url)  # Your logic
        # More and more rules...
```

---

### Agentic Programming:
```
User Input → LLM Coordinator → [Interprets Intent] → Delegates to Specialists → Output
                    ↑                                           ↓
                    └───── LLM reasons about the workflow ──────┘
```

**The LLM adapts to edge cases using its training.**

**Example:**
```yaml
# You write the instructions, LLM executes
instructions: |
  Process user questions about URLs:
  - Identify URLs (complete or partial)
  - Correct typos in domain names
  - Complete incomplete URLs
  - Resolve documentation references to actual URLs
  - Delegate summarization to the URL specialist
```

---

## What Rule-Based Programming Cannot Do (But Agentic Can)

| Scenario | Rule-Based | Agentic |
|----------|-----------|---------|
| **Typo correction** | ❌ Requires typo dictionary | ✅ LLM corrects based on language understanding |
| **Incomplete URLs** | ❌ Manual repair: `"https://" + url` | ✅ LLM infers complete URL from context |
| **Ambiguous references** | ❌ "Check the docs" - which docs? | ✅ Infers from context |
| **Multi-step reasoning** | ❌ Requires explicit flowchart | ✅ LLM plans the steps |
| **Context switching** | ❌ "Also, what about...?" breaks the flow | ✅ Adapts mid-conversation |
| **Implicit knowledge** | ❌ "The usual suspects" - undefined | ✅ Uses world knowledge |
| **Graceful degradation** | ❌ Error on unexpected input | ✅ Attempts best interpretation |

---

## Resource Efficiency

### Rule-Based Approach:
```
Understanding Agent (1) + Summarizer Agents (N, one per URL) = N+1 agents
Threads: N+1 (one per agent)
Messages: 2N+2
```

**Example:** 5 URLs = **6 agents, 6 threads, 12 messages**

---

### Agentic Approach:
```
Coordinator Agent (1) + URL Summarizer Agent (1) = 2 agents (reused)
Threads: 1 (shared conversation)
Messages: Variable based on delegation (typically fewer)
```

**Example:** 5 URLs = **2 agents, 1 thread, ~8 messages**

---

## Benefits of Connected Agents (Agentic Approach)

| Benefit | Description | Impact |
|---------|-------------|--------|
| **Simplified Workflow Design** | Breaks down complex tasks across specialized agents with clear responsibilities | Reduces complexity, improves code clarity, better separation of concerns |
| **No Custom Orchestration** | Main agent uses natural language to route tasks instead of hardcoded logic | More flexible, adaptive workflow without constant code changes |
| **Easy Extensibility** | Add new connected agents without modifying main coordinator | Modular architecture supports growth, clean dependency management |
| **Improved Reliability** | Focused responsibilities per agent make debugging easier | Better auditability, easier maintenance, clearer error tracking |
| **Natural Language Coordination** | Agents communicate using instructions, not API calls | More intuitive interactions, reduced integration complexity |
| **Resource Efficiency** | Reusable connected agents vs. creating new agents per task | Lower agent count, shared threads, reduced API overhead |

---

## When to Use Each Approach

| Criteria | Rule-Based (`agent/`) | Agentic (`agentic/`) |
|----------|----------------------|---------------------|
| **Input Type** | Strictly controlled (GUI, forms) | Natural language, voice, varied input |
| **Requirements** | 100% predictable, stable | Evolving, adaptive needs |
| **Behavior** | Deterministic (same input → same output) | Intelligent (context-dependent interpretation) |
| **Maintenance** | Low if requirements don't change | Low even as requirements evolve |
| **Compliance** | Auditable hardcoded logic | LLM reasoning with instruction traceability |
| **Edge Cases** | Must code every scenario | LLM handles gracefully with inference |
| **Typo/Error Handling** | Requires explicit dictionaries | Automatic correction via understanding |
| **Cost** | Lower LLM usage | Higher LLM usage, lower development cost |
| **Best For** | Banking, medical devices, regulated systems | Customer support, content analysis, research tools |

---

## The Future is Agentic

### Evolution of AI Applications:

```
1990s-2000s: Rule-Based Systems
   ↓ "If user says X, do Y"
   
2010s: Machine Learning APIs
   ↓ "Call ML model for predictions"
   
2020s: LLM Integration
   ↓ "Use LLM to generate responses"
   
2024+: Agentic AI
   ↓ "Let LLM orchestrate workflows and make decisions"
```

**The paradigm shift:**
- **Old (GUI Era):** Design forms → Users learn your interface → Rule-based code handles structured input
- **Transition (First Hop):** Natural language input → LLM parses → Rule-based code processes
- **New (Agentic):** Natural language throughout → LLM orchestrates everything → Declarative instructions replace imperative code

---

## Conclusion

The two implementations in this repository aren't just different coding styles—they represent **two fundamentally different philosophies** of building AI applications:

1. **`agent/summariseURL.py`** - **Code is king**: Every decision is a Python statement
2. **`agentic/summariseURL.py`** - **Intelligence is king**: The LLM makes the decisions

**The Critical Insight:**

When we evolved from **GUI to natural language interfaces**, we couldn't just change the front door (input method) and keep the house (application logic) the same. We needed to redesign the entire architecture.

**Rule-based programming** was perfect for the GUI era because:
- Users could only click predefined buttons
- Input space was finite
- Every interaction could be mapped to code

**Agentic programming** is essential for the natural language era because:
- Users can express infinite variations
- Intent is ambiguous and context-dependent
- Writing rules for every scenario is impossible

The agentic approach doesn't just call an LLM; it **trusts the LLM to be intelligent**. Instead of programming every possible scenario (including typos, incomplete references, and vague descriptions), you provide context, instructions, and tools—then let the AI reason about the best approach.

**This is the essence of being "more agentic": delegating complexity to AI intelligence rather than encoding it in application logic.**

---

## Usage Examples

### Sequential/Rule-Based Approach
```python
from agent.summariseURL import run_summarise_url

# Basic usage
result = run_summarise_url("Compare https://docs.microsoft.com/azure and https://aws.amazon.com/documentation")

# With emitter for progress tracking
def my_emitter(message):
    print(f"[PROGRESS] {message}")

result = run_summarise_url(
    question="Your question with URLs",
    emitter=my_emitter,
    return_mode="both",  # Get both summaries and logs
    save_json="output/results.json"
)
```

### Connected Agents/Agentic Approach
```python
from agentic.summariseURL import run_summarise_url_agentic

# Basic usage - handles typos and incomplete URLs automatically
result = run_summarise_url_agentic("Compare docs.microsoft and aws.amazon")

# With emitter for progress tracking
def my_emitter(message):
    print(f"[PROGRESS] {message}")

result = run_summarise_url_agentic(
    question="Your question with URLs or doc references",
    emitter=my_emitter,
    return_mode="both",  # Get both summaries and logs
    save_json="output/results.json"
)
```

---

## Technical Implementation: ConnectedAgentTool Setup

The agentic approach uses Azure AI's `ConnectedAgentTool` to enable agent-to-agent delegation:

```python
from azure.ai.agents.models import ConnectedAgentTool

# Step 1: Create the specialized URL summarizer agent
url_summarizer_agent = agents_client.create_agent(
    model=model_deployment_name,
    name="url_content_summarizer",
    description="Specialized agent for summarizing URL content with detailed analysis",
    instructions=build_url_summarizer_instructions()
)

# Step 2: Create ConnectedAgentTool wrapper
connected_summarizer = ConnectedAgentTool(
    id=url_summarizer_agent.id,
    name="url_content_summarizer", 
    description="Summarizes content from URLs with intelligent analysis"
)

# Step 3: Create coordinator agent with connected tools
coordinator_agent = agents_client.create_agent(
    model=model_deployment_name,
    name="url_analysis_coordinator",
    description="Main coordinator that orchestrates URL analysis and delegates tasks",
    instructions=build_coordinator_instructions(question),
    tools=connected_summarizer.definitions  # ← Connect the URL summarizer
)

# Step 4: The coordinator now automatically delegates to the connected agent
# No manual loops or parsing needed!
run_result = agents_client.runs.create_and_process(
    thread_id=main_thread.id, 
    agent_id=coordinator_agent.id
)
```

### Natural Language Routing

The coordinator agent automatically determines when to:
- Use the connected URL summarizer for content analysis
- Process multiple URLs efficiently through delegation
- Coordinate between different specialized agents (extensible)
- Compile results into coherent, aggregated responses

**Key Difference from Rule-Based:**
```python
# Rule-Based: You write the loop
for url in urls:
    agent = create_agent_for_url(url)  # Manual orchestration
    process(agent, url)

# Agentic: The coordinator decides
# Just provide instructions - the LLM figures out the workflow
coordinator_instructions = """
Identify URLs, delegate summarization to the URL specialist,
and compile an aggregated analysis.
"""
```

---

## Example Output Comparison

### Sequential/Rule-Based Approach Output
```
[AGENT CREATE] Creating understanding agent with name: url_understanding_agent
Created agent ID: asst_abc123
[THREAD CREATE] Creating understanding thread
[UNDERSTANDING OUTPUT]
REFINED USER QUESTION: Compare cloud documentation
REPAIRED URLS: https://docs.microsoft.com/azure, https://aws.amazon.com/docs

===== SOURCE: https://docs.microsoft.com/azure =====
[AGENT CREATE] Creating summarizer agent for URL
[SUMMARY OUTPUT]
Azure provides comprehensive cloud services...
===== END SUMMARY =====

===== SOURCE: https://aws.amazon.com/docs =====
[AGENT CREATE] Creating summarizer agent for URL
[SUMMARY OUTPUT]
AWS offers extensive documentation...
===== END SUMMARY =====

[SUMMARY] Total Agents Created: 3
[SUMMARY] Total Threads Created: 3
```

### Connected Agents/Agentic Approach Output
```
[AGENTIC ARCHITECTURE] Creating connected agents setup...
[AGENT CREATE] Creating URL Summarizer agent with name: url_content_summarizer
[CONNECTED AGENT] Created URL Summarizer agent ID: asst_xyz789
[AGENT CREATE] Creating Coordinator agent with name: url_analysis_coordinator
[MAIN AGENT] Created Coordinator agent ID: asst_def456

[COORDINATOR IDENTIFIED URLS]
I've identified the following URLs:
- https://docs.microsoft.com/azure
- https://aws.amazon.com/documentation

[WORKFLOW] Processing 2 URLs through intelligent coordinator...

[FINAL AGGREGATED OUTPUT]
After analyzing both documentation sources:

Azure Documentation:
- Comprehensive cloud services with focus on enterprise integration...

AWS Documentation:
- Extensive service catalog with detailed API references...

Comparison Summary:
Both platforms offer robust cloud solutions, with Azure emphasizing...

[SUMMARY] Total Agents Created: 2
[SUMMARY] Total Threads Created: 1
```

**Notice:**
- **Agentic**: Single aggregated response, fewer agents/threads, intelligent synthesis
- **Rule-Based**: Multiple separate summaries, more resources, manual aggregation needed

---

## Test Cases to Compare Both Approaches

Try both implementations with these scenarios to see the differences:

| Test Case | Input | Rule-Based Result | Agentic Result |
|-----------|-------|-------------------|----------------|
| **Perfect URLs** | `"Compare https://docs.microsoft.com/azure and https://aws.amazon.com/documentation"` | ✅ Works | ✅ Works |
| **Typos** | `"Compare docs.micrsoft.com/azure and aws.amazn.com/docs"` | ❌ Fetch fails on typos | ✅ Auto-corrects typos |
| **Incomplete URLs** | `"Compare docs.microsoft and aws.amazon"` | ⚠️ Partial - may fail | ✅ Completes URLs intelligently |
| **References Only** | `"Compare Azure docs and AWS documentation"` | ❌ No URLs detected | ✅ Infers actual URLs |
| **Vague Intent** | `"Compare the main cloud platform documentation pages"` | ❌ No explicit URLs | ✅ Determines Azure/AWS from context |
| **Mixed Quality** | `"Check docs.micrsoft.com and the kubernetes docs"` | ❌ Typo fails, "kubernetes docs" missed | ✅ Corrects typo, resolves "kubernetes docs" |

---

## Architecture Patterns Comparison

### Sequential/Rule-Based Pattern
```
┌─────────────────────────────────────────────────────┐
│ Sequential Pipeline Architecture                    │
├─────────────────────────────────────────────────────┤
│                                                      │
│ 1. Understanding Agent (Agent 1)                    │
│    ├── Analyzes question                            │
│    └── Returns structured text                      │
│                                                      │
│ 2. Python Regex Parser (Your Code)                  │
│    ├── Extracts URLs with pattern matching          │
│    ├── Manual normalization                         │
│    └── Creates URL list                             │
│                                                      │
│ 3. For each URL (Loop in Your Code):                │
│    ├── Summarizer Agent N (New Agent)               │
│    ├── New Thread                                   │
│    ├── Process content                              │
│    └── Delete agent                                 │
│                                                      │
│ 4. Manual Aggregation (Your Code)                   │
│    └── Combine summaries                            │
│                                                      │
└─────────────────────────────────────────────────────┘
```

### Connected Agents/Agentic Pattern
```
┌─────────────────────────────────────────────────────┐
│ Connected Agents Architecture                       │
├─────────────────────────────────────────────────────┤
│                                                      │
│ 1. Coordinator Agent (Main LLM)                     │
│    ├── Analyzes question                            │
│    ├── Identifies/corrects/completes URLs           │
│    ├── Delegates to connected agent                 │
│    └── Aggregates results intelligently             │
│         │                                            │
│         └──> ConnectedAgentTool                     │
│                   │                                  │
│                   ▼                                  │
│ 2. URL Summarizer Agent (Connected, Reusable)       │
│    ├── Receives delegation from coordinator         │
│    ├── Processes URL content                        │
│    └── Returns summary to coordinator               │
│                                                      │
│ Single Thread, Single Conversation Context          │
│                                                      │
└─────────────────────────────────────────────────────┘
```

| Pattern Aspect | Sequential/Rule-Based | Connected Agents/Agentic |
|----------------|----------------------|--------------------------|
| **Orchestration** | Manual Python loops | LLM-driven delegation |
| **Agent Lifecycle** | Create → Use → Delete per URL | Create once, reuse |
| **Communication** | None (isolated agents) | Agent-to-agent via ConnectedAgentTool |
| **Thread Management** | One per agent (N+1 threads) | Shared conversation (1 thread) |
| **Workflow Logic** | Hardcoded in Python | Declared in instructions |
| **Aggregation** | Manual string concatenation | Intelligent synthesis by coordinator |
| **Error Handling** | Try/catch per URL | LLM graceful degradation |
| **Extensibility** | Modify code + redeploy | Add connected agents, update instructions |

---

## Further Reading

- **Rule-Based Implementation:** `agent/summariseURL.py`
- **Agentic Implementation:** `agentic/summariseURL.py`
- **Configuration Comparison:**
  - `config/agent_config.yaml` - Rule-based configuration with parsing instructions
  - `config/agentic_config.yaml` - Agentic configuration with message templates for delegation

**Recommended Exploration Path:**
1. Run both implementations with the same perfect URL input
2. Try with typos and incomplete URLs
3. Test with vague references ("Azure docs")
4. Compare the logs to see resource usage differences
5. Examine the configuration files to understand instruction design
