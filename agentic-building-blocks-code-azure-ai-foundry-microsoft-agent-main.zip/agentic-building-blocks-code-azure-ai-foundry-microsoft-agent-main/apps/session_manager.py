"""Session state management for Streamlit application.

This module encapsulates all Streamlit session state management logic,
providing a clean interface for state initialization, updates, and queries.

Why Session State Matters in Streamlit:
Streamlit reruns the entire script on every user interaction. Without session
state, variables would reset to their initial values on each rerun, making it
impossible to maintain application state across interactions.

Key Challenges Solved:
1. State Persistence: Keep values across Streamlit reruns
2. Mode Transitions: Detect when user switches modes and clean up old state
3. Question Management: Update default questions when mode changes
4. Email Parameters: Store date ranges and limits for email filtering
5. UI Contamination: Prevent old output from appearing in new mode

Design Decisions:
- Centralized Management: All state logic in one class (not scattered)
- Defensive Initialization: Check 'key not in session_state' before setting
- Prefix-based Clearing: Clear output* keys instead of maintaining explicit list
- Flag-based Updates: Use 'question_needs_update' instead of direct updates
- Immutable Methods: Getters don't modify state (predictable behavior)

Streamlit Session State Behavior:
- st.session_state is a dictionary-like object
- Persists across reruns within same browser session
- Unique per browser tab/session
- Reset when user refreshes page (F5)
- Not shared between users (server-side session management)
"""

import streamlit as st
from apps.config import AppConfig


class SessionStateManager:
    """Manages Streamlit session state variables for application lifecycle.
    
    This class provides the single interface for all session state operations,
    ensuring consistent state management across the application.
    
    Responsibilities:
    1. Initialize state with sensible defaults (first run)
    2. Detect mode changes (to trigger cleanup)
    3. Clear output state (prevent UI contamination)
    4. Manage question updates (mode-specific defaults)
    5. Handle email parameters (date ranges, limits)
    
    State Categories:
    - Mode Tracking: prev_query_mode (for change detection)
    - User Input: user_question (text input value)
    - Update Flags: question_needs_update (signal for question change)
    - Email Config: email_start_dt, email_end_dt, email_max_items
    - Output State: output*, output_lines*, auth_log_lines* (cleared on mode change)
    
    Usage Pattern:
    ```python
    session_mgr = SessionStateManager()  # Initializes state if needed
    
    if session_mgr.mode_changed(current_mode):
        session_mgr.clear_context(current_mode)
    
    if session_mgr.should_update_question(mode, default):
        session_mgr.set_user_question(default)
    ```
    """
    
    def __init__(self):
        """Initialize session state manager and ensure state variables exist.
        
        Constructor Pattern:
        Calls _initialize_state() which sets defaults for any missing keys.
        This ensures all expected state keys exist before they're accessed,
        preventing KeyError exceptions throughout the application.
        
        Why in __init__ instead of lazy initialization?
        - Fail fast: Missing config detected early
        - Predictable: State always in known good state
        - Debuggable: Easy to see what state exists
        """
        self._initialize_state()
    
    def _initialize_state(self):
        """Initialize session state variables with defaults.
        
        Sets up default values for all session state keys used by the application.
        Only initializes keys that don't already exist (preserves existing values).
        
        Initialization Strategy:
        - Check if key exists before setting (idempotent)
        - Use config-based defaults where applicable (email settings from env)
        - Use sensible hardcoded defaults otherwise (prev_query_mode=None)
        
        Why This Matters:
        Streamlit reruns this code on every interaction. Without the "if not in"
        check, we'd reset state to defaults on every rerun, losing user's values.
        
        State Keys Initialized:
        - prev_query_mode: None (no previous mode on first run)
        - user_question: "" (empty until user types)
        - question_needs_update: False (no pending update)
        - email_start_dt: From EMAIL_STARTTIME env var (default: 2025-01-01)
        - email_end_dt: From EMAIL_ENDTIME env var (default: 2025-12-31)
        - email_max_items: 25 (reasonable default for email fetching)
        """
        # Get email defaults from environment configuration
        # These come from .env file or system environment variables
        # Centralized in AppConfig for consistency
        email_config = AppConfig.get_email_config()
        
        # Define all default values in one dictionary for clarity
        # Makes it easy to see all state keys and their initial values
        defaults = {
            # Mode change tracking
            'prev_query_mode': None,  # No previous mode on first load
            
            # User input state
            'user_question': "",  # Empty question until user types
            
            # Update coordination flags
            'question_needs_update': False,  # No pending question update
            
            # Email filtering parameters (from environment config)
            'email_start_dt': email_config['default_start'],
            'email_end_dt': email_config['default_end'],
            'email_max_items': 25,  # Reasonable default (not too many)
            'email_sender_filter': email_config['default_sender_filter']  # From environment variable
        }
        
        # Initialize each key only if it doesn't already exist
        # Why this pattern? Idempotent - safe to call multiple times
        # First call: Sets defaults
        # Subsequent calls: Preserves existing values
        for key, default_value in defaults.items():
            if key not in st.session_state:
                st.session_state[key] = default_value
    
    def mode_changed(self, current_mode: str) -> bool:
        """Check if query mode has changed since last run.
        
        Detects mode transitions by comparing current mode to previous mode
        stored in session state. Used to trigger context clearing.
        
        Args:
            current_mode: Currently selected mode identifier
        
        Returns:
            True if mode different from previous, False otherwise.
            Also returns True on first run (prev_query_mode is None).
        
        Why Detect Mode Changes?
        When user switches modes (e.g., BingSearch → aiSearch):
        - Old output shouldn't display in new mode's UI
        - Default question should update to new mode's default
        - Trace data should clear to avoid confusion
        - Email expanders should reset
        
        First Run Behavior:
        Returns True on first run (prev_query_mode=None) to trigger
        initialization of default question.
        """
        return st.session_state['prev_query_mode'] != current_mode
    
    def clear_context(self, current_mode: str):
        """Clear output context when mode changes.
        
        Removes all output-related session state to prevent UI contamination
        when user switches between modes.
        
        Problem Being Solved:
        Without clearing, scenario like this occurs:
        1. User runs BingSearch (creates output_lines_bing in session state)
        2. User switches to aiSearch  
        3. Old BingSearch output still in session state
        4. If aiSearch handler checks for output_lines_bing, shows wrong data
        5. User confused by seeing BingSearch results in aiSearch mode
        
        Clearing Strategy:
        Uses prefix matching to identify all output-related keys:
        - 'auth_log_lines*': Authentication/authorization logs
        - 'output_lines*': Handler-specific output  
        - 'output*': Generic output keys
        
        Why Prefix Matching vs Explicit Key List?
        - More maintainable: New output keys automatically cleared
        - Safer: Catches dynamically generated keys
        - Flexible: Handles mode-specific output keys
        
        Args:
            current_mode: Mode user just switched to
        
        Side Effects:
        - Deletes multiple session state keys
        - Sets question_needs_update=True (signal to update default question)
        - Updates prev_query_mode tracker (for next change detection)
        """
        # STEP 1: Identify all output-related keys
        # List comprehension finds keys to delete
        # Why list first, then delete? Can't modify dict during iteration
        # Prefixes chosen to catch all output variations:
        # - auth_log_lines*: OAuth/API authentication logs
        # - output_lines*: Mode-specific output (output_lines_bing, etc.)
        # - output*: Generic catch-all (output_text, output_data, etc.)
        keys_to_clear = [k for k in st.session_state.keys() 
                        if k.startswith(('auth_log_lines', 'output_lines', 'output'))]
        
        # STEP 2: Delete all identified keys
        # Safe to delete: We just collected the keys, so we know they exist
        for key in keys_to_clear:
            del st.session_state[key]
        
        # STEP 3: Signal that question should update to new mode's default
        # Why flag instead of direct update? Separation of concerns:
        # - clear_context handles clearing
        # - UI code handles question updates (has access to text input widget)
        # Flag coordinates between them
        st.session_state['question_needs_update'] = True
        
        # STEP 4: Update mode tracker for future change detection
        # Next time mode_changed() is called, will compare against this value
        st.session_state['prev_query_mode'] = current_mode
    
    def should_update_question(self, query_mode: str, default_question: str) -> bool:
        """Check if question text input should be updated with mode's default.
        
        Determines whether to replace current question with the default question
        for the selected mode. Used by UI code to decide when to update text input.
        
        Update Conditions (OR logic - any true triggers update):
        1. question_needs_update flag is True (mode just changed)
        2. Question is empty AND default question exists (helpful first-run behavior)
        
        Why Two Conditions?
        Condition 1: Mode change scenario
        - User switches modes
        - clear_context() sets question_needs_update=True
        - This method returns True
        - UI updates question to new mode's default
        
        Condition 2: Empty question scenario  
        - User hasn't typed anything yet
        - Default question helps them get started
        - Shows example of what mode can do
        
        Args:
            query_mode: Current mode (currently unused, for future extensions)
            default_question: The default question for current mode
        
        Returns:
            True if question should be updated, False otherwise
        
        Side Effects:
        - Clears question_needs_update flag after checking
        - Why clear? Prevent infinite update loop:
          * First call: Returns True, flag cleared
          * Second call: Returns False (flag now False)
          * Update happens once, then stops
        """
        current_question = self.get_user_question()
        needs_update = st.session_state.get('question_needs_update', False)
        
        # Determine if update should happen
        # Condition 1: Flag explicitly set (mode change)
        # Condition 2: Question empty and default available (helpful default)
        should_update = needs_update or (not current_question and default_question)
        
        # Clear the update flag after checking
        # Important: Prevents repeated updates on subsequent reruns
        # Only clears if flag was set (avoids unnecessary state write)
        if needs_update:
            st.session_state['question_needs_update'] = False
            
        return should_update
    
    def get_email_params(self) -> dict:
        """Get email filtering parameters from session state.
        
        Retrieves the current email filter settings (date range and limit)
        that user has configured via UI inputs.
        
        Returns:
            Dictionary with email filtering parameters:
            - start_dt: Start datetime string (local time)
            - end_dt: End datetime string (local time)
            - max_items: Maximum number of emails to fetch
            - sender_filter: Comma-separated sender email addresses
        
        Usage:
        These parameters are passed to email checking handlers which convert
        local times to UTC before calling Microsoft Graph API.
        
        Why Dictionary Return?
        - Clean interface: Single return value with named fields
        - Extensible: Easy to add new parameters
        - Self-documenting: Keys explain what each value means
        """
        return {
            'start_dt': st.session_state.get('email_start_dt'),
            'end_dt': st.session_state.get('email_end_dt'),
            'max_items': st.session_state.get('email_max_items', 25),  # Default to 25 if missing
            'sender_filter': st.session_state.get('email_sender_filter', '')  # Default to empty (no filter)
        }
    
    def update_email_params(self, start_dt: str, end_dt: str, max_items: int, sender_filter: str = ''):
        """Update email filtering parameters in session state.
        
        Stores user-configured email filter settings for use across reruns.
        Called when user modifies date inputs or max items slider in sidebar.
        
        Args:
            start_dt: Start datetime string in local time (ISO format)
            end_dt: End datetime string in local time (ISO format)
            max_items: Maximum number of emails to retrieve (1-100)
            sender_filter: Comma-separated sender email addresses (optional)
        
        Why Separate Update Method?
        - Encapsulation: Hide direct session state access
        - Validation point: Could add parameter validation here
        - Consistency: All updates go through same path
        - Testability: Can mock this method in tests
        """
        st.session_state['email_start_dt'] = start_dt
        st.session_state['email_end_dt'] = end_dt
        st.session_state['email_max_items'] = max_items
        st.session_state['email_sender_filter'] = sender_filter
    
    def get_user_question(self) -> str:
        """Get current user question from session state.
        
        Returns:
            Current question text, or empty string if not set.
        
        Safe Access:
        Uses .get() with default to avoid KeyError if question not initialized.
        Should always be initialized by _initialize_state(), but defensive.
        """
        return st.session_state.get('user_question', '')
    
    def set_user_question(self, question: str):
        """Set user question in session state.
        
        Updates the stored question text. Used when:
        - Loading default question for mode
        - User modifies question in text input
        - Programmatic question updates
        
        Args:
            question: New question text to store
        
        Direct Assignment:
        Uses direct assignment (not .get()) because we're writing, not reading.
        """
        st.session_state['user_question'] = question