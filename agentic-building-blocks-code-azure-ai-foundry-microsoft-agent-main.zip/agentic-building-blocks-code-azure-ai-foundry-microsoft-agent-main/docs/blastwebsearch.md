# Blast Web Search Workflow

## What Is This?

Imagine you need to research a topic quickly. Instead of searching on Google, then Bing, then another search engine one by one, this workflow does all three searches **at the same time** and combines the results for you. Even better - it can email you a nice summary when it's done!

That's what `blastwebsearch.py` does - it's like having three research assistants working in parallel, then one coordinator who puts all their findings together.

## The Problem It Solves

**Traditional Approach (Slow):**
- Search on Google → wait for results
- Search on Bing → wait for results  
- Search on another engine → wait for results
- Manually compare and combine results
- Takes 3x longer! ⏰

**This Workflow (Fast):**
- All three searches happen **simultaneously**
- Results automatically combined in one report
- Optional: Get a professional email summary
- Much faster and more comprehensive! ⚡

## Real-World Example

You ask: *"What are the latest Python asyncio tutorials?"*

Here's what happens behind the scenes in **parallel**:

1. **Bing Searcher** searches Bing for "Python asyncio tutorials" (takes 2 seconds)
2. **Yahoo Searcher** searches Yahoo at the same time (takes 2 seconds)
3. **Custom Search** uses Google Custom Search API simultaneously (takes 2 seconds)
4. **Aggregator** waits for all three, then combines successful results
5. **Optional:** Email Writer composes a summary and sends it to you

**Total time: ~2 seconds** instead of 6 seconds if done sequentially!

Even if one search fails (like Google blocks you), the others still work and you get results.

## How It Works (Simple Explanation)

Think of it like a boss delegating work to three employees at once:

```
┌─────────────────────────────────────────────────┐
│  YOU                                             │
│  "Search for: Python tutorials"                 │
└────────────────┬────────────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────────────────┐
│  DISPATCHER (The Boss)                          │
│  Sends same task to 3 workers simultaneously    │
└───┬──────────────┬──────────────┬───────────────┘
    │              │              │
    ▼              ▼              ▼
┌────────┐    ┌────────┐    ┌────────┐
│  Bing  │    │ Yahoo  │    │  GCP   │
│Searcher│    │Searcher│    │Searcher│
└───┬────┘    └───┬────┘    └───┬────┘
    │             │             │
    │  All work at the same time! (Parallel)
    │             │             │
    └─────────────┼─────────────┘
                  │
            ┌─────▼──────┐
            │ AGGREGATOR │
            │ Combines   │
            │  Results   │
            └─────┬──────┘
                  │
            ┌─────▼──────┐
            │Email Writer│ (Optional)
            │ Sends      │
            │ Summary    │
            └────────────┘
```

**Key Points:**
- All three searchers work **at the same time** (not one after another)
- Even if one fails, the others keep working
- You get all results combined in one place

## The Four Components Explained

### 1. **Dispatcher** (The Coordinator)
- **Job:** Takes your search query and sends it to all three search engines at once
- **Like:** A manager delegating the same task to multiple team members
- **Example:** You ask "Python tutorials" → Dispatcher tells all 3 searchers to search for it

### 2. **Three Search Workers** (Running in Parallel)

#### **Bing Searcher**
- **Uses:** Azure AI with Bing Grounding Tool (enterprise-grade search)
- **Strength:** Professional, filtered results
- **Example:** Good for business/technical searches

#### **Yahoo Searcher** 
- **Uses:** Azure AI agent with Yahoo web search (web scraping approach)
- **Strength:** Diverse results, no API key required
- **Limitation:** Web scraping approach, may be rate-limited

#### **Google Custom Searcher**
- **Uses:** Google Custom Search API (official API)
- **Strength:** Reliable, structured results with URLs
- **Example:** Best for consistent, production use

### 3. **Aggregator** (The Combiner)
- **Job:** Waits for all three searchers to finish, then combines successful results
- **Like:** A secretary collecting reports from three departments
- **Smart:** Includes only successful results (filters out failures)
- **Example:** "Bing found 5 results, Google failed, GCP found 10 → shows 15 total"

### 4. **Email Writer** (Optional Reporter)
- **Job:** Writes a professional email summarizing the search results
- **Uses:** AI agent to compose the email content
- **Sends:** Via Azure Logic App integration
- **Example:** "Here's a summary of your search for 'Python tutorials'..."

## Quick Start - Running the Demo

### Option 1: Simple Command Line (Easiest!)

Just run this command to see a demonstration:

```bash
python workflow/blastwebsearch.py
```

This searches for a **default query** and shows you results from all three search engines.

### Option 2: Search Your Own Topic

Ask your own question:

```bash
python workflow/blastwebsearch.py "machine learning tutorials"
```

Want more results? Add a number:

```bash
python workflow/blastwebsearch.py "Claude AI 2025" 10
```

This gets 10 results from each search engine (30 total if all succeed).

### Option 3: Interactive Mode (Streamlit GUI)

Run the Streamlit web interface:

```bash
streamlit run main.py
```

Then:
1. Select **"[Workflow] Blast Web Search"** from the dropdown
2. Type your search query in the text box
3. Click search
4. Watch results appear in real-time from all three engines
5. See aggregated results and OpenTelemetry traces

## Before You Run - Setup Required

### 1. Install Python Packages

```bash
pip install -r requirements.txt
```

This installs:
- `agent-framework` - The AI agent framework
- `azure-identity` - For Azure authentication  
- `googlesearch-python` - For GCP Custom Search (not used by headless Yahoo)
- `google-api-python-client` - For GCP Custom Search
- `opentelemetry-sdk` - For observability/tracing
- `streamlit` - For the web GUI

### 2. Azure CLI Login

The workflow uses Azure AI for Bing search, so log in:

```bash
az login
```

### 3. Set Up Environment Variables

You need API keys for the search engines. Create a `.env` file or set these:

```bash
# For Bing Search (via Azure AI)
PROJECT_ENDPOINT=<your-azure-ai-project-endpoint>
MODEL_DEPLOYMENT_NAME=<your-model-deployment-name>
BING_CONNECTION_NAME=<your-bing-connection-name>

# For GCP Custom Search
GCS_DEVELOPER_KEY=<your-google-custom-search-api-key>
GCS_CX=<your-google-custom-search-engine-id>

# For Email (optional - only if you want email summaries)
LOGIC_APP_EMAIL_URL=<your-azure-logic-app-endpoint>
```

**Note:** Yahoo search uses web scraping and needs no API setup!

## Understanding the Code (For Developers)

### The Main Function: `run_blast_search()`

This is the heart of the workflow. Here's what it does in plain English:

```python
async def run_blast_search(
    query: str,                  # What you want to search for
    num_results: int = 5,        # How many results per search engine
    emitter=None,                # For sending updates to the UI
    return_mode='both',          # Return results + logs
    save_json=None,              # Save results to file (optional)
    send_email=False,            # Send email summary (optional)
    recipient_email=None         # Who gets the email
):
```

**What happens inside:**

1. **Setup Phase:**
   - Creates three search executors (Bing, Yahoo, GCP)
   - Creates an aggregator to combine results
   - Sets up OpenTelemetry for tracking

2. **Build the Workflow:**
   ```python
   workflow = (
       Executor(name="blast_search")
       .add_executor(bing_searcher)      # Add Bing
       .add_executor(yahoo_searcher)     # Add Yahoo
       .add_executor(gcptxt_searcher)    # Add GCP
       .add_executor(aggregator)         # Add combiner
       .add_executor(email_writer)       # Add email (optional)
       .build()
   )
   ```

3. **Run All Searches in Parallel:**
   - Dispatcher sends query to all three searchers **at the same time**
   - Each searcher does its job independently
   - Aggregator waits for all three to finish
   - Combines successful results

4. **Optional Email:**
   - If `send_email=True`, the Email Writer creates and sends a summary

5. **Return Results:**
   - Aggregated results (combined from all sources)
   - Individual results from each search engine
   - Logs and traces (saved to `opentele_local/` folder)

### Key Concepts to Understand

#### 1. **What is an Executor?**

An `Executor` is like a worker that does a specific job. Think of it as:

- **Assembly line worker:** Each executor has one task
- **Independent:** If one fails, others keep working
- **Reusable:** You can add the same executor to different workflows

```python
# This creates a search worker
bing_searcher = BingSearchExecutor(
    executor_id="bing_searcher",
    input_type=SearchRequest,
    output_type=SearchResponse
)
```

#### 2. **What is Parallel Execution?**

Instead of doing tasks one after another (sequential), we do them all at once:

**Sequential (Slow):**
- Search Bing (2 sec) → Search Google (2 sec) → Search GCP (2 sec) = **6 seconds total**

**Parallel (Fast):**
- Search all three at the same time (2 sec) = **2 seconds total**

The `Executor` framework handles this automatically!

#### 3. **What are SearchRequest and SearchResponse?**

These are like forms that get passed between workers:

**SearchRequest** (Input form):
```python
@dataclass
class SearchRequest:
    query: str           # "Python tutorials"
    num_results: int     # 5
```

**SearchResponse** (Output form):
```python
@dataclass
class SearchResponse:
    executor_id: str         # "bing_searcher"
    status: str              # "success" or "error"
    results: list[dict]      # The actual search results
    success: bool            # True or False
```

#### 4. **What is the Aggregator?**

The aggregator is like a secretary collecting reports from three departments:

```python
# Receives three SearchResponses (from Bing, Google, GCP)
# Combines only the successful ones
# Returns one BlastSearchOutput with everything
```

It's smart enough to:
- Filter out failed searches
- Combine successful results
- Keep individual results separate for debugging

#### 5. **What is OpenTelemetry?**

OpenTelemetry tracks **what each executor is doing** so you can:

- See which search engines responded fastest
- Debug failures (which one failed and why)
- Optimize performance
- Monitor in production

It saves data to JSON files in `opentele_local/` folder.

## What You'll See When You Run It

### Sample Output

When you run `python workflow/blastwebsearch.py "Python tutorials"`, you'll see:

```
======================================================================
AGGREGATED RESULTS (Successful Searches Only)
======================================================================
=== AGGREGATED SEARCH RESULTS ===
Total Results: 11

--- BING (1 results) ---
1. Python Tutorial - W3Schools
   Learn Python programming with examples and exercises...

--- HEADLESS (0 results) ---
(Yahoo search encountered issues - that's okay!)

--- GCP (10 results) ---
1. Python Tutorial - Real Python
   URL: https://realpython.com/python-basics/
   Learn Python from scratch with hands-on tutorials...

2. Official Python Tutorial
   URL: https://docs.python.org/3/tutorial/
   The official Python documentation and beginner guide...

[... more results ...]

======================================================================
INDIVIDUAL RESULTS (All Engines - Success & Failures)
======================================================================

[Bing Search]
Status: success
Success: True
Results Count: 1
--------------------------------------------------
1. Python Tutorial - W3Schools
   [Full result details...]

----------------------------------------------------------------------

[Headless Search]
Status: no_results
Success: False
Results Count: 0
--------------------------------------------------
WARNING: No results. Yahoo search encountered an issue.

----------------------------------------------------------------------

[Google Custom Search]
Status: success
Success: True  
Results Count: 10
--------------------------------------------------
1. Python Tutorial - Real Python
   [Full result details...]
```

### Understanding the Output

The output has **two sections**:

#### 1. **Aggregated Results** (The Good Stuff)
- Only shows **successful** searches
- Combines results from all working engines
- Shows total count
- Easy to read summary

#### 2. **Individual Results** (Detailed View)
- Shows **all three engines** (successful + failed)
- Includes error messages if searches failed
- Good for debugging
- Shows exactly what each engine returned

### Where Files Are Saved

After running, you'll find:

```
opentele_local/
  └── blast_search_20251028-143022.json  # OpenTelemetry traces

emails_local/
  └── emails_20251028-143022.json  # Email data (if send_email=True)
```

**OpenTelemetry Trace File** contains:
- Which executors ran (bing, headless, gcp, aggregator)
- How long each took (in milliseconds)
- Message routing between executors
- Full execution timeline

You can view these traces in the Streamlit UI!

## Using in Your Own Application

Want to integrate this into your app? Here are practical examples:

### Basic Search Integration

```python
import asyncio
from workflow.blastwebsearch import run_blast_search

async def search_topic(topic: str):
    """Search for a topic across multiple engines."""
    
    # Run the search
    results = await run_blast_search(
        query=topic,
        num_results=5,
        save_json=False  # Don't save files in production
    )
    
    # Get just the aggregated results
    return results.aggregated_search_results

# Use it
topic = "machine learning basics"
results = asyncio.run(search_topic(topic))
print(results)
```

### Search with Email Notification

```python
import asyncio
from workflow.blastwebsearch import run_blast_search

async def research_and_notify(query: str, recipient: str):
    """Search and email results to someone."""
    
    result = await run_blast_search(
        query=query,
        num_results=10,
        send_email=True,
        recipient_email=recipient,
        save_json=True,  # Save for records
        return_mode="both"  # Get results + logs
    )
    
    return result

# Use it
asyncio.run(research_and_notify(
    query="Latest AI breakthroughs 2025",
    recipient="boss@company.com"
))
```

### Access Individual Engine Results

```python
import asyncio
from workflow.blastwebsearch import run_blast_search

async def compare_search_engines(query: str):
    """See which engine gives best results."""
    
    output = await run_blast_search(query=query, num_results=5)
    
    print("Bing Results:")
    print(output.bingsearch_result)
    
    print("\nGoogle Results:")
    print(output.headless_result)
    
    print("\nGCP Results:")
    print(output.gcptxt_result)
    
    print("\nAggregated (Best of All):")
    print(output.aggregated_search_results)

asyncio.run(compare_search_engines("Python vs JavaScript"))
```

## Common Questions (FAQ)

### Q: Why use three search engines instead of just one?

**A:** Multiple benefits:
- **Redundancy:** If one fails, you still get results from the others
- **Diversity:** Different engines find different content
- **Speed:** Parallel searching is faster than sequential
- **Quality:** More sources = more comprehensive results

### Q: What if Yahoo search fails?

**A:** No problem! The workflow handles this gracefully:
- Bing and GCP searches still work
- Aggregator only includes successful results
- You get a clear message: "Yahoo search encountered an issue"
- The workflow doesn't crash or fail

### Q: How fast is this compared to searching manually?

**A:** Much faster!
- **Manual:** 3 searches × 2 seconds each = 6 seconds
- **This workflow:** All 3 at once = 2 seconds
- **Speed up:** ~3x faster!

### Q: Do I need all three API keys?

**A:** Not necessarily!
- **Minimum:** Just Azure (for Bing search)
- **Recommended:** Azure + GCP (most reliable combination)
- **Optional:** Yahoo search (free web scraping, no API needed)

The workflow works even if you only configure some engines.

### Q: Can I add more search engines?

**A:** Yes! Just create a new executor:

```python
# Create your custom search executor
duckduckgo_searcher = DuckDuckGoExecutor(
    executor_id="ddg_searcher",
    input_type=SearchRequest,
    output_type=SearchResponse
)

# Add it to the workflow
workflow.add_executor(duckduckgo_searcher)
```

### Q: How much does this cost?

**A:** Costs depend on API usage:
- **Yahoo Search:** Free (web scraping approach)
- **GCP Custom Search:** First 100 queries/day free, then $5 per 1000 queries
- **Azure Bing:** Depends on your Azure AI pricing tier

For occasional use, it's essentially free!

### Q: What happens if my Azure account expires?

**A:** The workflow will fail with an authentication error. Solutions:
1. Re-login: `az login`
2. Use a different credential provider
3. Disable Bing search and use only GCP/Yahoo

### Q: Can I run this without email?

**A:** Absolutely! Email is optional:

```python
# No email - just get search results
results = await run_blast_search(
    query="your topic",
    send_email=False  # Default setting
)
```

## Real-World Use Cases

This workflow pattern is perfect for:

### 1. **Research & Competitive Analysis**
**Scenario:** Company researching competitors
- Search "competitor product reviews" across all engines
- Get comprehensive view from different sources (Bing, Yahoo, GCP)
- Email summary to marketing team
- Make informed business decisions

### 2. **News Monitoring & Alerts**
**Scenario:** Track breaking news on specific topics
- Search "company name + crisis" every hour
- Aggregate results from multiple news sources
- Email alerts when significant news appears
- Stay ahead of PR issues

### 3. **Academic Research**
**Scenario:** Student researching a topic
- Search "quantum computing applications"
- Get results from Bing (academic sources), Yahoo (diverse), GCP (specialized)
- Save comprehensive results for paper
- More thorough than single-source research

### 4. **SEO & Content Analysis**
**Scenario:** SEO specialist checking keyword rankings
- Search target keywords across engines
- Compare how different engines rank content
- Identify opportunities and gaps
- Optimize content strategy

### 5. **Job Search Automation**
**Scenario:** Finding job opportunities
- Search "Python developer remote" on all engines
- Aggregate listings from different job boards
- Email daily digest of opportunities
- Never miss a posting

## Key Advantages Over Manual Searching

| Feature | Manual Search | Blast Web Search Workflow |
|---------|--------------|---------------------------|
| **Speed** | Search each engine separately (slow) | All engines at once (3x faster) |
| **Reliability** | If one fails, you're stuck | If one fails, others still work |
| **Completeness** | Easy to miss results | Comprehensive coverage |
| **Time Investment** | Repetitive, tedious | Automated, efficient |
| **Comparison** | Manual copy-paste | Automatic aggregation |
| **Tracking** | No history | OpenTelemetry traces |
| **Notifications** | Manual sharing | Automatic emails |

## Troubleshooting

### Problem: "Azure CLI authentication failed"

**Solution:**
```bash
# Re-login to Azure
az login

# Verify you're logged in
az account show
```

### Problem: "Headless search always returns no results"

**Solution:**
This can happen if Yahoo encounters rate limiting or connection issues. Options:
1. Ignore Yahoo results (Bing + GCP are usually sufficient)
2. Add delays between searches (slower but less likely to be rate-limited)
3. Check internet connection

The workflow handles this gracefully - you still get Bing and GCP results.

### Problem: "GCP search says 'API key invalid'"

**Solution:**
```bash
# Check your environment variables
echo $env:GCS_DEVELOPER_KEY
echo $env:GCS_CX

# Make sure they're set correctly
# Get a new API key from Google Cloud Console if needed
```

### Problem: "All three searches fail"

**Solution:**
Check your internet connection and API credentials:
1. Test Bing: Verify Azure login (`az account show`)
2. Test GCP: Verify API key is valid
3. Test Yahoo: Try from a different network if rate-limited

### Problem: "Email not being sent"

**Solution:**
```bash
# Verify Logic App URL is set
echo $env:LOGIC_APP_EMAIL_URL

# Test the Logic App endpoint manually
# Make sure recipient_email is provided
```

### Problem: "Searches are slow"

**Solution:**
- **Expected:** 2-5 seconds for all three searches
- **If slower:** Check your internet connection
- **Remember:** Parallel is still 3x faster than sequential!

### Problem: "Results seem incomplete"

**Solution:**
- Increase `num_results` parameter: `run_blast_search(query, num_results=20)`
- Check which engines succeeded in the Individual Results section
- Some topics have fewer results naturally

## How Email Integration Works

### The Email Writer Component

When `send_email=True`, here's what happens:

1. **Analyzes Results:**
   - Checks if searches were successful
   - Counts total results found
   - Determines tone (success or apologetic)

2. **Generates Content:**
   - Uses an AI agent to write professional email
   - Adapts content based on success/failure
   - Includes search query and key findings

3. **Sends Email:**
   - Formats email with subject and body
   - Sends via Azure Logic App
   - Returns confirmation

### Example Email (Successful Search)

```
Subject: Search Results: Python tutorials

Dear User,

Here are the search results for "Python tutorials":

We found 15 results across multiple search engines:

**Top Results:**
1. Python Tutorial - Real Python
   URL: https://realpython.com/python-basics/
   
2. Official Python Tutorial
   URL: https://docs.python.org/3/tutorial/

[... more results ...]

Best regards,
Search Assistant
```

### Example Email (Failed Search)

```
Subject: Search Attempted: obscure-topic-xyz

Dear User,

We attempted to search for "obscure-topic-xyz" but were unable to find results from our search engines.

Suggestions:
- Try a different search term
- Check spelling
- Use more general keywords

Best regards,
Search Assistant
```

## Next Steps

### Learn More

- **Agent Framework Docs:** Understand the Executor pattern
- **Other Samples:** Check `workflow/handoff_bidirectional.py` for HandoffBuilder pattern
- **Observability:** Read `docs/observability.md` for OpenTelemetry details

### Experiment and Customize

1. **Try different queries** - See how results vary
2. **Adjust num_results** - Get more or fewer results per engine
3. **Add new search engines** - Create custom executors
4. **Integrate with your app** - Use the Python API examples
5. **Set up email notifications** - Automate research tasks

### Production Considerations

Before deploying to production:
- ✅ Set up proper API key management (use Azure Key Vault)
- ✅ Implement rate limiting to avoid API costs
- ✅ Add error monitoring and alerts
- ✅ Cache frequent searches to reduce API calls
- ✅ Set up proper logging
- ✅ Test with real-world queries
- ✅ Monitor costs (especially GCP and Azure)

---

## Quick Reference

### Running the Workflow

```bash
# Default demo
python workflow/blastwebsearch.py

# Custom query
python workflow/blastwebsearch.py "your search topic"

# Custom query with more results
python workflow/blastwebsearch.py "your topic" 10

# Streamlit GUI
streamlit run main.py
```

### Key Files

- `workflow/blastwebsearch.py` - Main workflow implementation
- `agent/bingsearch.py` - Bing search executor
- `agent/yahoosearch.py` - Yahoo search executor
- `helper/gcptxtsearch.py` - GCP Custom Search executor
- `agent/emailwriter.py` - Email composition executor
- `apps/query_handlers.py` - Streamlit integration

### Important Concepts

- **Executor:** A worker that does one specific task
- **Parallel Execution:** Running multiple tasks simultaneously
- **Aggregator:** Combines results from multiple executors
- **Emitter:** Sends real-time updates to UI
- **OpenTelemetry:** Tracks execution for debugging

### Environment Variables Needed

```bash
# Bing Search (required for Bing)
PROJECT_ENDPOINT=<azure-endpoint>
MODEL_DEPLOYMENT_NAME=<model-name>
BING_CONNECTION_NAME=<bing-connection>

# GCP Search (required for GCP)
GCS_DEVELOPER_KEY=<api-key>
GCS_CX=<search-engine-id>

# Email (optional)
LOGIC_APP_EMAIL_URL=<logic-app-url>
```

---

**Need Help?** Check the troubleshooting section or review the OpenTelemetry traces in `opentele_local/` to see exactly what happened during execution.
