"""Blast Web Search Workflow - Fan-out/Fan-in pattern for concurrent web search.

This workflow implements parallel web search with concurrent agent execution.

Workflow State Machine Flow:
    IDLE → IDLE_WITH_PENDING_REQUESTS (SearchRequest received)
         → PROCESSING (DispatchSearchQuery fans out to 3 search executors)
         → PROCESSING (BingSearchExecutor, YahooSearchExecutor, GCPSearchExecutor run concurrently)
         → PROCESSING (AggregatorExecutor fans in results from all 3 sources)
         → COMPLETED (aggregated output ready)

Fan-out/Fan-in Pattern:
    1. Fan-out Phase: DispatchSearchQuery sends same query to 3 search agents simultaneously
    2. Concurrent Execution: Bing, Yahoo, GCP search agents execute in parallel
    3. Fan-in Phase: AggregatorExecutor collects all results and produces 4 outputs:
       - aggregated_search_results: Combined positive results from all sources
       - bingsearch_result: Individual Bing output (success/no_results/error)
       - yahoo_result: Individual Yahoo output (success/no_results/error)
       - gcptxt_result: Individual GCP output (success/no_results/error)

Executor Flow:
    SearchRequest → DispatchSearchQuery → [Bing, Yahoo, GCP] → AggregatorExecutor → BlastSearchOutput

Usage:
    From command line:
        python -m workflow.blastwebsearch "search query" [num_results]
        python workflow/blastwebsearch.py "Python tutorials" 10
    
    From another module:
        from workflow.blastwebsearch import run_blast_search
        result = await run_blast_search("search query", num_results=5)
"""

import asyncio
import json
import os
import sys
from dataclasses import dataclass, asdict
from typing import Never, TYPE_CHECKING, Callable

if TYPE_CHECKING:
    from typing import Any

from agent_framework import (
    Executor,
    WorkflowBuilder,
    WorkflowContext,
    WorkflowOutputEvent,
    handler,
    get_logger,
)
from agent_framework.observability import setup_observability
from opentelemetry import trace

if __name__ == "__main__":
    repo_root = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
    if repo_root not in sys.path:
        sys.path.insert(0, repo_root)

# Import search modules
from agent.bingsearch import run_bing_search
from agent.yahoosearch import run_yahoo_search
from helper.gcptxtsearch import perform_google_search
from helper.emitter import create_emitter
from helper.agent_trace_configurator import AgentTraceConfigurator
from agent.emailwriter import write_email_body
from helper.logicappemail import send_email as send_email_via_logic_app
from helper.otel_collector import get_span_collector
from helper.storeotel import store_otel_traces_to_local

DEFAULT_QUERY = "what is Claude AI"

logger = get_logger()

@dataclass
class SearchRequest:
    """Request payload sent to all search executors."""
    query: str
    num_results: int


@dataclass
class SearchResponse:
    """Response from individual search executor."""
    executor_id: str
    status: str  # 'success', 'no_results', 'error'
    results: list[dict]  # Structured search results
    raw_output: str  # Full formatted response text
    log: str  # Diagnostic logs
    success: bool  # Overall success flag


@dataclass
class BlastSearchOutput:
    """Final aggregated output from workflow."""
    aggregated_search_results: str  # Combined positive results only
    bingsearch_result: str  # Individual Bing result (all)
    yahoo_result: str  # Individual Yahoo result (all)
    gcptxt_result: str


class DispatchSearchQuery(Executor):
    """Dispatcher that fans out search requests to all search executors."""
    
    def __init__(self, search_executor_ids: list[str], emitter_func: Callable[[str], None] | None = None, id: str | None = None):
        super().__init__(id=id or "search_dispatcher")
        self._search_executor_ids = search_executor_ids
        self._emit = emitter_func or print
    
    @handler
    async def dispatch(
        self,
        request: SearchRequest,
        ctx: WorkflowContext[SearchRequest],
    ) -> None:
        """Fan out search request to all configured search executors."""
        logger.info(f"Dispatcher fanning out query: '{request.query}' to {len(self._search_executor_ids)} executors")
        self._emit(f"[DISPATCHER] Fanning out query '{request.query}' to {len(self._search_executor_ids)} search agents")
        
        for executor_id in self._search_executor_ids:
            logger.debug(f"Sending message to executor: {executor_id}")
            self._emit(f"[DISPATCHER] -> Sending to {executor_id}")
            
            current_span = trace.get_current_span()
            if current_span:
                current_span.set_attribute('message.from', self.id)
                current_span.set_attribute('message.to', executor_id)
                current_span.set_attribute('message.type', type(request).__name__)
            
            await ctx.send_message(request, target_id=executor_id)


class BingSearchExecutor(Executor):
    """Executor wrapping Bing search agent."""
    
    def __init__(self, emitter_func: Callable[[str], None] | None = None, id: str = "bing_searcher"):
        super().__init__(id=id)
        self._emit = emitter_func or print
    
    @handler
    async def search(
        self,
        request: SearchRequest,
        ctx: WorkflowContext[SearchResponse],
    ) -> None:
        """Execute Bing search and send response to aggregator."""
        logger.info(f"BingSearchExecutor starting search for: '{request.query}'")
        self._emit(f"[{self.id}] Starting Bing search for: '{request.query}'")
        
        try:
            # Run Bing search with 'both' mode to get full details
            result = run_bing_search(
                question=request.query,
                return_mode='both',
                emitter=self._emit
            )
            
            # Extract structured data
            success = result.get('success', False)
            status = 'success' if success else 'error'
            answers = result.get('answers', [])
            output_text = result.get('output_text', '')
            log = result.get('log', '')
            
            # Format results as list of dicts
            results_list = []
            if success and answers:
                for i, answer in enumerate(answers, 1):
                    results_list.append({
                        'source': 'bing',
                        'rank': i,
                        'content': answer[:200] + '...' if len(answer) > 200 else answer,
                        'full_content': answer
                    })
            
            # Create response
            response = SearchResponse(
                executor_id=self.id,
                status=status,
                results=results_list,
                raw_output=output_text,
                log=log,
                success=success
            )
            
            self._emit(f"[{self.id}] Completed - Status: {status}, Results: {len(results_list)}")
            
        except Exception as exc:
            self._emit(f"[{self.id}] Exception: {exc}")
            response = SearchResponse(
                executor_id=self.id,
                status='error',
                results=[],
                raw_output='',
                log=f"Exception: {exc}",
                success=False
            )
        
        # Set span attributes for message tracing
        current_span = trace.get_current_span()
        if current_span:
            current_span.set_attribute('message.from', self.id)
            current_span.set_attribute('message.to', 'search_aggregator')
            current_span.set_attribute('message.type', 'SearchResponse')
        
        # Send to aggregator
        await ctx.send_message(response, target_id="search_aggregator")


class YahooSearchExecutor(Executor):
    """Executor wrapping Yahoo search agent."""
    
    def __init__(self, emitter_func: Callable[[str], None] | None = None, id: str = "yahoo_searcher"):
        super().__init__(id=id)
        self._emit = emitter_func or print
    
    @handler
    async def search(
        self,
        request: SearchRequest,
        ctx: WorkflowContext[SearchResponse],
    ) -> None:
        """Execute Yahoo search and send response to aggregator."""
        logger.info(f"YahooSearchExecutor starting search for: '{request.query}'")
        self._emit(f"[{self.id}] Starting Yahoo search for: '{request.query}'")
        
        try:
            # Run Yahoo search with 'both' mode to get full details
            result = run_yahoo_search(
                question=request.query,
                return_mode='both',
                emitter=self._emit
            )
            
            # Extract structured data
            success = result.get('success', False)
            status = 'success' if success else 'error'
            answers = result.get('answers', [])
            output_text = result.get('output_text', '')
            log = result.get('log', '')
            
            # Format results as list of dicts
            results_list = []
            if success and answers:
                for i, answer in enumerate(answers, 1):
                    results_list.append({
                        'source': 'yahoo',
                        'rank': i,
                        'content': answer[:200] + '...' if len(answer) > 200 else answer,
                        'full_content': answer
                    })
            
            # Create response
            response = SearchResponse(
                executor_id=self.id,
                status=status,
                results=results_list,
                raw_output=output_text,
                log=log,
                success=success
            )
            
            self._emit(f"[{self.id}] Completed - Status: {status}, Results: {len(results_list)}")
            
        except Exception as exc:
            self._emit(f"[{self.id}] Exception: {exc}")
            response = SearchResponse(
                executor_id=self.id,
                status='error',
                results=[],
                raw_output='',
                log=f"Exception: {exc}",
                success=False
            )
        
        # Set span attributes for message tracing
        current_span = trace.get_current_span()
        if current_span:
            current_span.set_attribute('message.from', self.id)
            current_span.set_attribute('message.to', 'search_aggregator')
            current_span.set_attribute('message.type', 'SearchResponse')
        
        # Send to aggregator
        await ctx.send_message(response, target_id="search_aggregator")


class GCPTextSearchExecutor(Executor):
    """Executor wrapping Google Custom Search (Google Custom Search)."""
    
    def __init__(self, emitter_func: Callable[[str], None] | None = None, id: str = "gcptxt_searcher"):
        super().__init__(id=id)
        self._emit = emitter_func or print
    
    @handler
    async def search(
        self,
        request: SearchRequest,
        ctx: WorkflowContext[SearchResponse],
    ) -> None:
        """Execute Google Custom Search and send response to aggregator."""
        self._emit(f"[{self.id}] Starting Google Custom Search for: '{request.query}'")
        
        try:
            # Run GCP search (synchronous function) - returns dict with return_mode='both'
            result = perform_google_search(request.query, request.num_results, return_mode='both', emitter=self._emit)
            
            # Extract data from the result dict
            success = result.get('success', False)
            status = 'success' if success else 'error'
            answers = result.get('answers', [])
            log = result.get('log', '')
            output_text = result.get('output_text', '')
            
            # Parse the output text to extract structured results
            top_results = []
            if answers:
                # Parse the formatted answer text
                answer_text = answers[0] if isinstance(answers, list) and answers else ''
                lines = answer_text.split('\n')
                current_result = {}
                for line in lines:
                    line = line.strip()
                    if line and line[0].isdigit() and '. ' in line:
                        if current_result:
                            top_results.append(current_result)
                        current_result = {'title': line.split('. ', 1)[1] if '. ' in line else line}
                    elif line.startswith('URL:'):
                        current_result['url'] = line.replace('URL:', '').strip()
                    elif line.startswith('Snippet:'):
                        current_result['snippet'] = line.replace('Snippet:', '').strip()
                if current_result:
                    top_results.append(current_result)
            
            # Format results
            results_list = []
            for i, result in enumerate(top_results, 1):
                results_list.append({
                    'source': 'gcp',
                    'rank': i,
                    'title': result.get('title', 'No title'),
                    'url': result.get('url', ''),
                    'snippet': result.get('snippet', '')
                })
            
            # Create response
            response = SearchResponse(
                executor_id=self.id,
                status=status,
                results=results_list,
                raw_output=output_text,
                log=log,
                success=success
            )
            
            self._emit(f"[{self.id}] Completed - Status: {status}, Results: {len(results_list)}")
            
        except Exception as exc:
            self._emit(f"[{self.id}] Exception: {exc}")
            response = SearchResponse(
                executor_id=self.id,
                status='error',
                results=[],
                raw_output='',
                log=f"Exception: {exc}",
                success=False
            )
        
        # Set span attributes for message tracing
        current_span = trace.get_current_span()
        if current_span:
            current_span.set_attribute('message.from', self.id)
            current_span.set_attribute('message.to', 'search_aggregator')
            current_span.set_attribute('message.type', 'SearchResponse')
        
        # Send to aggregator
        await ctx.send_message(response, target_id="search_aggregator")


# ======================== Aggregator Executor ========================

class AggregateSearchResults(Executor):
    """Aggregator that fans in all search results into final output."""
    
    def __init__(self, has_email_writer: bool = False, emitter_func: Callable[[str], None] | None = None, id: str = "search_aggregator"):
        super().__init__(id=id)
        self._emit = emitter_func or print
        self._has_email_writer = has_email_writer
    
    @handler
    async def aggregate(
        self,
        results: list[SearchResponse],
        ctx: WorkflowContext[BlastSearchOutput, BlastSearchOutput],
    ) -> None:
        """Fan in all search responses and produce consolidated output."""
        self._emit(f"[{self.id}] Aggregating {len(results)} search results")
        
        # Separate results by executor
        by_executor = {r.executor_id: r for r in results}
        
        # Extract individual results
        bing_response = by_executor.get('bing_searcher')
        yahoo_response = by_executor.get('yahoo_searcher')
        gcptxt_response = by_executor.get('gcptxt_searcher')
        
        # Format individual outputs
        bingsearch_result = self._format_individual_result(bing_response, 'Bing Search')
        yahoo_result = self._format_individual_result(yahoo_response, 'Yahoo Search')
        gcptxt_result = self._format_individual_result(gcptxt_response, 'Google Custom Search')
        
        # Aggregate only positive results
        aggregated_results = self._aggregate_positive_results(results)
        
        # Create final output
        output = BlastSearchOutput(
            aggregated_search_results=aggregated_results,
            bingsearch_result=bingsearch_result,
            yahoo_result=yahoo_result,
            gcptxt_result=gcptxt_result
        )
        
        self._emit(f"[{self.id}] Aggregation complete")
        
        # If email writer is part of workflow, send message to it
        # Otherwise, just yield output
        if self._has_email_writer:
            self._emit(f"[{self.id}] Sending results to email writer")
            
            # Set span attributes for message tracing
            current_span = trace.get_current_span()
            if current_span:
                current_span.set_attribute('message.from', self.id)
                current_span.set_attribute('message.to', 'email_writer')
                current_span.set_attribute('message.type', 'BlastSearchOutput')
            
            await ctx.send_message(output, target_id="email_writer")
        else:
            await ctx.yield_output(output)
    
    def _format_individual_result(self, response: SearchResponse | None, source_name: str) -> str:
        """Format individual search result (includes both positive and negative)."""
        if response is None:
            return f"[{source_name}] No response received"
        
        lines = [
            f"[{source_name}]",
            f"Status: {response.status}",
            f"Success: {response.success}",
            f"Results Count: {len(response.results)}",
            "-" * 50,
        ]
        
        if response.success and response.results:
            lines.append("Results:")
            for i, result in enumerate(response.results[:5], 1):  # Show top 5
                lines.append(f"\n{i}. {result.get('title', result.get('content', 'No title')[:50])}")
                if 'url' in result:
                    lines.append(f"   URL: {result['url']}")
                if 'description' in result:
                    lines.append(f"   Desc: {result['description'][:100]}")
                elif 'snippet' in result:
                    lines.append(f"   Snippet: {result['snippet'][:100]}")
        else:
            lines.append(f"No results. Log: {response.log[:200]}")
        
        return "\n".join(lines)
    
    def _aggregate_positive_results(self, responses: list[SearchResponse]) -> str:
        """Aggregate only successful results from all sources."""
        all_positive_results = []
        
        for response in responses:
            if response.success and response.status == 'success':
                for result in response.results:
                    all_positive_results.append(result)
        
        if not all_positive_results:
            return "No successful search results from any source."
        
        # Group by source
        by_source = {'bing': [], 'yahoo': [], 'gcp': []}
        for result in all_positive_results:
            source = result.get('source', 'unknown')
            if source in by_source:
                by_source[source].append(result)
        
        lines = [
            "=== AGGREGATED SEARCH RESULTS (Positive Results Only) ===",
            f"Total Results: {len(all_positive_results)}",
            ""
        ]
        
        # Format by source
        for source, source_results in by_source.items():
            if source_results:
                lines.append(f"--- {source.upper()} ({len(source_results)} results) ---")
                for i, result in enumerate(source_results[:5], 1):  # Top 5 per source
                    # Fix: Get full content from full_content field for Bing/Yahoo, or title for GCP
                    title = result.get('title') or result.get('full_content') or result.get('content', 'No title')
                    lines.append(f"{i}. {title}")
                    if 'url' in result:
                        lines.append(f"   {result['url']}")
                    if 'description' in result:
                        lines.append(f"   {result['description'][:150]}")
                    elif 'snippet' in result:
                        lines.append(f"   {result['snippet'][:150]}")
                    lines.append("")
        
        return "\n".join(lines)


# ======================== Email Writer Executor ========================

class EmailWriterExecutor(Executor):
    """Executor that composes and sends email with search results."""
    
    def __init__(self, 
                 user_question: str,
                 recipient_email: str,
                 emitter_func: Callable[[str], None] | None = None, 
                 id: str = "email_writer"):
        super().__init__(id=id)
        self._emit = emitter_func or print
        self._user_question = user_question
        self._recipient_email = recipient_email
    
    @handler
    async def compose_and_send(
        self,
        blast_output: BlastSearchOutput,
        ctx: WorkflowContext[Never, BlastSearchOutput],
    ) -> None:
        """Compose professional email from search results and send it."""
        self._emit(f"[{self.id}] Composing email for search results")
        
        try:
            # Determine if we have successful results
            has_success = (blast_output.aggregated_search_results and 
                          "No successful search results" not in blast_output.aggregated_search_results)
            
            # Prepare content for email writer
            if has_success:
                email_context = (
                    f"Search Results (Successful):\n\n"
                    f"{blast_output.aggregated_search_results}"
                )
            else:
                email_context = (
                    "Search Results (No Results Found):\n\n"
                    "=== INDIVIDUAL SEARCH RESULTS ===\n\n"
                    f"{blast_output.bingsearch_result}\n\n"
                    f"{blast_output.yahoo_result}\n\n"
                    f"{blast_output.gcptxt_result}"
                )
            
            # Call email writer agent to compose professional email
            self._emit(f"[{self.id}] Invoking email writer agent...")
            result = write_email_body(
                email_context,
                user_question=self._user_question,
                return_mode='both',
                emitter=self._emit
            )
            
            email_body = result.get('output_text', '') if isinstance(result, dict) else result
            
            # Parse subject and body
            if "#####" in email_body:
                subject_part, body_part = email_body.split("#####", 1)
                subject = subject_part.strip()
                body = body_part.strip()
            else:
                subject = f"Search Results: {self._user_question[:50]}"
                body = email_body
            
            self._emit(f"[{self.id}] Email composed. Subject: {subject}")
            
            # Send email
            self._emit(f"[{self.id}] Sending email to {self._recipient_email}...")
            send_result = send_email_via_logic_app(
                to=self._recipient_email,
                subject=subject,
                body=body,
                attachments=[],
                emitter=self._emit,
                return_mode='both'
            )
            
            if isinstance(send_result, dict):
                send_log = send_result.get('log', '')
                if 'Email sent to' in send_log:
                    self._emit(f"[{self.id}] ✅ Email sent successfully")
                else:
                    self._emit(f"[{self.id}] ⚠️ Email send status unclear")
            else:
                self._emit(f"[{self.id}] Email send completed")
                
        except Exception as exc:
            self._emit(f"[{self.id}] ❌ Exception during email composition/send: {exc}")
        
        # Yield the original output so workflow completes properly
        await ctx.yield_output(blast_output)


# ======================== Main Workflow Function ========================

async def run_blast_search(
    query: str,
    num_results: int = 5,
    emitter: Callable[[str], None] | None = None,
    return_mode: str = "both",  # 'output' | 'log' | 'both'
    save_json: str | os.PathLike | None = None,
    send_email: bool = False,
    recipient_email: str | None = None,
    tracing_mode: str = "both",  # 'auto' | 'both' | 'azure_monitor' | 'console' | 'none'
) -> BlastSearchOutput | dict | str:
    """Execute blast web search workflow with fan-out/fan-in pattern.
    
    Pattern aligned with agent modules (aisearch.py, bingsearch.py):
    - Application/diagnostic lines are emitted via emitter (if provided) and collected in the log
    - Final workflow output is captured separately as output_text
    - return_mode controls returned data:
        'output' -> output text only
        'log'    -> full log only
        'both'   -> dict { 'output_text': str, 'log': str, 'success': bool, 'results': BlastSearchOutput }
    
    Execution Flow:
        1. Validate recipient_email if send_email is requested
        2. Create emitter utility for logging
        3. Setup unified trace manager
        4. Default query if empty
        5. Create search executors (Bing, Yahoo, GCP)
        6. Create dispatcher for fan-out
        7. Create aggregator for fan-in
        8. Build workflow graph with fan-out/fan-in edges
        9. Add email writer executor if requested
        10. Create search request
        11. Start parent span for tracing
        12. Execute workflow and collect output
        13. End parent span and get trace summary
        14. Determine success from aggregated results
        15. Emit formatted results
        16. Format output_text based on success
        17. Collect traces and save locally
        18. Save JSON artifact if requested
        19. Return payload based on return_mode
    
    Args:
        query: Search query string
        num_results: Number of results to request from each search agent (default: 5)
        emitter: Optional callback(string) for incremental UI updates
        return_mode: Controls return payload as described above
        save_json: Optional path to save results as JSON
        send_email: If True, adds email writer executor to workflow to send results (default: False)
        recipient_email: Email recipient (required if send_email=True)
        tracing_mode: Controls where traces are sent:
            'auto' (default) -> Azure Monitor if APPLICATIONINSIGHTS_CONNECTION_STRING is set, else local
            'local' -> Save to local JSON file only
            'azure_monitor' -> Send to Azure Monitor / Application Insights (viewable in Azure AI Foundry)
            'console' -> Print traces to console
            'none' -> Disable tracing
    
    Returns:
        BlastSearchOutput | dict | str depending on return_mode
    """
    # STEP 1: Validate recipient_email if send_email is requested
    # Why? Fail fast with clear error message before executing expensive search workflow
    if send_email and (not recipient_email or recipient_email.strip() == ""):
        error_msg = "[ERROR] DEFAULT_EMAIL_RECIPIENT is not configured. Please set it in .env file before using send email functionality."
        if emitter:
            emitter(error_msg)
        logger.error(error_msg)
        
        # Return error based on return_mode
        if return_mode == "output":
            return error_msg
        elif return_mode == "log":
            return error_msg
        else:  # both
            return {
                "output_text": "",
                "log": error_msg,
                "success": False,
                "results": None
            }
    
    # STEP 2: Create centralized emitter utility
    # Why? Enable consistent logging with flexible emitter injection for UI integration
    emit_util = create_emitter(emitter)
    emit = emit_util.emit
    
    # STEP 3: Setup unified tracing using UnifiedTraceManager
    # Why? Initialize OpenTelemetry instrumentation for workflow/executor/message span capture
    from helper.unified_trace_manager import UnifiedTraceManager
    
    trace_mgr = UnifiedTraceManager(
        tracing_mode=tracing_mode,
        emitter=emit,
        trace_type="workflow"
    )
    tracer, span_collector = trace_mgr.setup()

    # STEP 4: Enhanced logging for observability
    # Why? Record workflow initiation in both application logger and emitter for debugging
    logger.info(f"Starting blast web search workflow: query='{query}', num_results={num_results}")
    emit("[OBSERVABILITY] OpenTelemetry tracing enabled - capturing spans")
    
    # STEP 5: Default query if empty
    # Why? Ensure valid query exists before building workflow executors
    if not query or not query.strip():
        query = DEFAULT_QUERY
    
    # STEP 6: Emit workflow header
    # Why? Provide visibility into workflow configuration for user/debugger
    emit("=" * 30)
    emit("BLAST WEB SEARCH WORKFLOW - Fan-out/Fan-in Pattern")
    emit("=" * 30)
    emit(f"Query: {query}")
    emit(f"Results per source: {num_results}")
    emit("")
    
    # STEP 7: Create search executors with emitter injection
    # Why? Instantiate Bing, Yahoo, GCP executors for parallel search execution
    bing_executor = BingSearchExecutor(emitter_func=emit, id="bing_searcher")
    yahoo_executor = YahooSearchExecutor(emitter_func=emit, id="yahoo_searcher")
    gcptxt_executor = GCPTextSearchExecutor(emitter_func=emit, id="gcptxt_searcher")
    
    executor_ids = [bing_executor.id, yahoo_executor.id, gcptxt_executor.id]
    
    # STEP 8: Create dispatcher for fan-out pattern
    # Why? Dispatcher broadcasts search request to all three search executors simultaneously
    dispatcher = DispatchSearchQuery(search_executor_ids=executor_ids, emitter_func=emit, id="dispatcher")
    
    # STEP 9: Determine if email writer is needed
    # Why? Aggregator behavior changes based on whether to yield output or send to email writer
    has_email_writer = send_email and recipient_email is not None
    
    # STEP 10: Create aggregator for fan-in pattern
    # Why? Aggregator collects results from all three search executors and produces final output
    aggregator = AggregateSearchResults(has_email_writer=has_email_writer, emitter_func=emit, id="search_aggregator")
    
    # STEP 11: Build workflow graph with fan-out/fan-in edges
    # Why? Configure Agent Framework workflow with dispatcher->executors (fan-out) and executors->aggregator (fan-in)
    logger.info("Building workflow graph with fan-out/fan-in pattern")
    emit("[OBSERVABILITY] Building workflow - this will emit workflow.build spans")
    
    builder = (
        WorkflowBuilder()
        .set_start_executor(dispatcher)
        .add_fan_out_edges(dispatcher, [bing_executor, yahoo_executor, gcptxt_executor])
        .add_fan_in_edges([bing_executor, yahoo_executor, gcptxt_executor], aggregator)
    )
    
    # STEP 12: Add email writer executor if requested
    # Why? Optional executor to compose and send professional email with search results
    if send_email:
        if not recipient_email:
            emit("[WARN] send_email=True but no recipient_email provided. Skipping email executor.")
        else:
            email_writer = EmailWriterExecutor(
                user_question=query,
                recipient_email=recipient_email,
                emitter_func=emit,
                id="email_writer"
            )
            builder.add_edge(aggregator, email_writer)
            emit(f"[WORKFLOW] Email writer executor added. Will send to: {recipient_email}")
    
    # STEP 13: Build workflow from configuration
    # Why? Compile workflow graph into executable workflow instance
    workflow = builder.build()
    
    logger.info("Workflow graph built successfully")
    emit("[OBSERVABILITY] Workflow built - ready to execute")
    
    # STEP 14: Create search request
    # Why? Package query and num_results into dataclass for executor consumption
    search_request = SearchRequest(query=query, num_results=num_results)
    
    # STEP 15: Start parent span for workflow tracing
    # Why? Capture end-to-end telemetry with workflow-level metadata
    trace_mgr.start_parent_span(
        span_name=f"blast_web_search: {query[:50]}",
        attributes={
            "query": query,
            "num_results": num_results,
            "tracing_mode": tracing_mode,
            "send_email": send_email,
            "recipient_email": recipient_email if recipient_email else None
        }
    )
    
    # STEP 16: Run workflow and collect output
    # Why? Execute fan-out/fan-in pattern with async streaming to capture final output
    logger.info("Starting workflow execution")
    emit("[OBSERVABILITY] Running workflow - workflow.run, executor.process, and message.send spans will be nested under parent")
    
    final_output = None
    try:
        async for event in workflow.run_stream(search_request):
            if isinstance(event, WorkflowOutputEvent):
                final_output = event.data
                logger.info("Workflow completed successfully")
                emit("")
                emit("=" * 30)
                emit("WORKFLOW COMPLETE")
                emit("=" * 30)
    except Exception as exc:
        # STEP 17: Handle workflow exceptions with telemetry recording
        # Why? Capture unexpected failures in both logs and traces for debugging
        logger.error(f"Workflow exception: {exc}", exc_info=True)
        emit(f"[ERROR] Workflow exception: {exc}")
        trace_mgr.record_exception(exc)
    
    # STEP 18: End parent span and get trace summary
    # Why? Close telemetry span and extract span statistics for reporting
    trace_mgr.end_parent_span()
    
    # STEP 19: Determine success from aggregated results
    # Why? Check if any search executor returned positive results for success flag
    success = False
    if final_output:
        # Check if aggregated_search_results has positive results
        if final_output.aggregated_search_results and "No successful search results" not in final_output.aggregated_search_results:
            success = True
    
    # STEP 20: Emit formatted results for user visibility
    # Why? Display aggregated and individual results in structured format for Streamlit/CLI capture
    if final_output:
        emit("")
        emit("=" * 30)
        emit("AGGREGATED RESULTS (Positive Only)")
        emit("=" * 30)
        emit(final_output.aggregated_search_results)
        emit("")
        emit("=" * 30)
        emit("INDIVIDUAL RESULTS (All - Positive & Negative)")
        emit("=" * 30)
        emit("")
        emit(final_output.bingsearch_result)
        emit("")
        emit("-" * 70)
        emit("")
        emit(final_output.yahoo_result)
        emit("")
        emit("-" * 70)
        emit("")
        emit(final_output.gcptxt_result)
    
    # STEP 21: Format output_text based on success status
    # Why? Return aggregated results if successful, otherwise return all individual results for diagnostics
    if final_output:
        if success:
            # If we have positive results, send only aggregated results
            output_text = final_output.aggregated_search_results
        else:
            # If no positive results, send all individual results
            output_text = (
                "No successful search results from any source.\n\n"
                "=== INDIVIDUAL SEARCH RESULTS ===\n\n"
                f"{final_output.bingsearch_result}\n\n"
                f"{final_output.yahoo_result}\n\n"
                f"{final_output.gcptxt_result}"
            )
    else:
        # STEP 22: Handle missing workflow output
        # Why? Return error message if workflow failed to produce any output
        output_text = "[ERROR] No output received from workflow"
        success = False
    
    # STEP 23: Collect complete log from emitter
    # Why? Extract all emitted messages for log-based return modes and JSON artifact
    log_joined = emit_util.get_log()
    
    # STEP 24: Get traces from unified trace manager
    # Why? Retrieve OpenTelemetry spans and summary statistics for observability
    trace_lines, trace_summary = trace_mgr.get_traces()
    trace_file_path = None
    
    # STEP 25: Store traces to local file and emit trace summary
    # Why? Persist telemetry for offline analysis and display span statistics for visibility
    if trace_lines:
        # Store traces to local file if needed
        metadata = span_collector.get_metadata() if span_collector else {}
        trace_file_path, store_log = store_otel_traces_to_local(
            traces=trace_lines,
            trace_summary=trace_summary,
            query=query,
            metadata=metadata,
            prefix='blast_search',
            emitter=emit
        )
        if trace_file_path:
            emit(f"[OTEL] Traces saved to: {trace_file_path}")
        
        # Add trace summary to log
        if trace_lines:
            emit("")
            emit("=" * 30)
            emit("OPENTELEMETRY TRACE SUMMARY")
            emit("=" * 30)
            emit(f"Total Spans: {trace_summary['total_spans']}")
            emit(f"Workflow Build: {trace_summary['workflow_build_spans']} spans")
            emit(f"Workflow Run: {trace_summary['workflow_run_spans']} spans")
            emit(f"Executor Process: {trace_summary['executor_spans']} spans")
            emit(f"Message Send: {trace_summary['message_spans']} spans")
            emit(f"Workflow Elapsed Time: {trace_summary['workflow_elapsed_ms']:.2f}ms ({trace_summary['workflow_elapsed_ms']/1000:.2f}s)")
            emit(f"Sum of All Spans: {trace_summary['sum_of_spans_ms']:.2f}ms (includes parallel execution)")
            emit("")
    
    # STEP 26: Save JSON artifact if requested
    # Why? Persist workflow results with traces for offline analysis and debugging
    if save_json and final_output:
        import pathlib
        try:
            path_obj = pathlib.Path(save_json)
            path_obj.parent.mkdir(parents=True, exist_ok=True)
            with path_obj.open('w', encoding='utf-8') as f:
                json.dump(
                    {
                        "output_text": output_text,
                        "log": log_joined,
                        "success": success,
                        "results": asdict(final_output),
                    },
                    f,
                    ensure_ascii=False,
                    indent=2,
                )
            emit(f"Results saved to: {save_json}")
        except Exception as exc:
            # STEP 27: Handle JSON save failures gracefully
            # Why? Ensure workflow completes even if file write fails
            emit(f"[WARN] Failed to save JSON: {exc}")
    
    # STEP 28: Return payload based on return_mode
    # Why? Support three return formats: 'both' (dict), 'log' (str), 'output' (str)
    if return_mode == "both":
        return {
            "output_text": output_text,
            "log": log_joined,
            "success": success,
            "results": final_output,
            "traces": trace_lines,  # Add trace lines for UI display
            "trace_summary": trace_summary,
            "trace_file": trace_file_path,  # Add saved file path
        }
    elif return_mode == "log":
        return log_joined
    else:  # 'output'
        return output_text


def print_results(output: BlastSearchOutput) -> None:
    """Pretty print the blast search results."""
    print("\n" + "=" * 70)
    print("AGGREGATED RESULTS (Positive Only)")
    print("=" * 70)
    print(output.aggregated_search_results)
    
    print("\n" + "=" * 70)
    print("INDIVIDUAL RESULTS (All - Positive & Negative)")
    print("=" * 70)
    
    print("\n" + output.bingsearch_result)
    print("\n" + "-" * 70)
    print("\n" + output.yahoo_result)
    print("\n" + "-" * 70)
    print("\n" + output.gcptxt_result)


# ======================== CLI Entry Point ========================

async def main() -> None:
    """CLI entry point for blast web search."""
    if len(sys.argv) > 1:
        query = sys.argv[1]
        num_results = int(sys.argv[2]) if len(sys.argv) > 2 else 5
        tracing_mode = sys.argv[3] if len(sys.argv) > 3 else "auto"
    else:
        query = DEFAULT_QUERY
        num_results = 5
        tracing_mode = "auto"
    
    print(f"\n🔍 Query: {query}")
    print(f"📊 Results per source: {num_results}")
    print(f"📝 Tracing mode: {tracing_mode}")
    print("\nAvailable tracing modes:")
    print("  - 'auto': Use Azure Monitor if configured, else local (default)")
    print("  - 'local': Save traces to local JSON file")
    print("  - 'azure_monitor': Send traces to Azure AI Foundry")
    print("  - 'console': Print traces to console")
    print("  - 'none': Disable tracing")
    print()
    
    result = await run_blast_search(query, num_results, return_mode="both", tracing_mode=tracing_mode)
    
    if isinstance(result, dict) and result.get('results'):
        print_results(result['results'])
    else:
        print("\n[ERROR] No output received from workflow")


if __name__ == "__main__":
    asyncio.run(main())
