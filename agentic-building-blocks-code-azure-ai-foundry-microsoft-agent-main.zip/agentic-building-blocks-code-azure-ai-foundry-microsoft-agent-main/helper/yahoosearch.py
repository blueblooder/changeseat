"""Yahoo Search Integration via Web Scraping

Provides web search functionality using Yahoo Search through web scraping techniques.
Returns structured search results with titles, URLs, and descriptions.

Purpose:
========
1. Web Search: Perform searches against Yahoo Search engine
2. Result Extraction: Parse HTML to extract structured result data
3. Result Formatting: Format results for display in UI or agents
4. Emitter Integration: Progress logging for UI updates
5. JSON Persistence: Optional save of results to disk

Architecture:
=============
Search Flow:
  Encode search query
       ↓
  Construct Yahoo search URL
       ↓
  HTTP request with browser headers
       ↓
  Parse HTML with BeautifulSoup
       ↓
  Extract result containers (div.algo)
       ↓
  Parse title, URL, description
       ↓
  Filter ads and invalid URLs
       ↓
  Return structured results

Web Scraping Strategy:
----------------------
Unlike API-based search (Bing, Google Custom Search):
- No API key required (free to use)
- Direct HTML parsing
- Relies on Yahoo's HTML structure
- Subject to breaking if Yahoo changes layout

HTML Structure (Yahoo Search):
```html
<div class="algo">                      <!-- Result container -->
  <h3 class="title">                    <!-- Title -->
    <a href="...">Result Title</a>
  </h3>
  <div class="compTitle">               <!-- Link container -->
    <a href="actual-url">...</a>
  </div>
  <div class="compText">                <!-- Description -->
    <p>Result description...</p>
  </div>
</div>
```

Browser Headers:
================
Requests use browser-like headers to avoid being blocked:
- User-Agent: Identifies as Chrome browser
- Accept: Standard browser content types
- Accept-Language: Prefer English
- Accept-Encoding: Support compression
- Connection: Keep connection alive
- Upgrade-Insecure-Requests: Support HTTPS upgrades

Why mimic browser?
- Yahoo may block requests without proper headers
- User-Agent identifies as legitimate browser
- Reduces chance of rate limiting
- Common practice for web scraping

Result Filtering:
=================
Filters applied to ensure quality results:
1. Skip results without href (invalid links)
2. Skip anchors (href="#")
3. Skip Yahoo redirect URLs (yahoo.com/r/)
4. Limit to requested num_results

Why filter?
- Yahoo HTML includes ads, related searches, etc.
- Want only organic search results
- Ensure URLs are actual destinations, not internal links

Return Modes:
=============
Flexible return format for different use cases:

1. 'answer' mode (simple):
   Returns: "Yahoo Search Results for: 'query'\\n..." (formatted text)
   Use case: Caller only needs search results

2. 'log' mode (diagnostic):
   Returns: "[INFO] Performing Yahoo web search..." (log string)
   Use case: Caller needs diagnostic information

3. 'both' mode (comprehensive):
   Returns: {"answers": [...], "output_text": "...", "log": "...", "success": bool}
   Use case: Caller needs both results and diagnostics

Pattern Consistency:
====================
Aligned with other search modules (bingsearch, headlesssearch):
- emit(): Application log lines
- output_texts: Formatted search results
- return_mode: Flexible return format
- save_json: Optional persistence

Comparison with Other Search Modules:
======================================
| Feature          | yahoosearch.py      | bingsearch.py       | headlesssearch.py   |
|------------------|---------------------|---------------------|---------------------|
| Method           | Web scraping        | Bing API            | Selenium (headless) |
| API key required | No                  | Yes                 | No                  |
| Rate limits      | Informal (scraping) | Formal (API quota)  | Informal (scraping) |
| JavaScript       | No (static HTML)    | N/A (API)           | Yes (executes JS)   |
| Reliability      | Medium (fragile)    | High (stable API)   | Medium (fragile)    |
| Cost             | Free                | API costs apply     | Free                |

Dependencies:
=============
- requests: HTTP client for fetching search results
- beautifulsoup4: HTML parsing and extraction
- urllib.parse: URL encoding for query strings
- helper.emitter: Progress logging pattern

Error Handling:
===============
Common errors and handling:
1. Network errors (RequestException): Logged, returns empty results
2. Parse errors (invalid HTML): Logged, skips problematic result
3. No results found: Warning logged, success=False
4. Unexpected exceptions: Error logged, success=False

All errors logged via emitter, operation continues where possible.

Performance:
============
- HTTP request: ~500ms-2s (network dependent)
- HTML parsing: ~50-200ms (result count dependent)
- Total: ~1-3s for typical query
- No rate limiting built in (rely on Yahoo's tolerance)

Best Practices:
===============
1. Don't overuse (respect Yahoo's service)
2. Consider caching results for repeated queries
3. Handle empty results gracefully
4. Monitor for HTML structure changes (brittle scraping)
5. Use API-based search (Bing, Google) for production

Security Considerations:
========================
1. No authentication required (public search)
2. Query URL-encoded to prevent injection
3. HTML parsing safe (BeautifulSoup escapes)
4. No user credentials involved
5. Results may contain untrusted content (sanitize if displaying)

Example Usage:
==============
Basic search:
```python
from helper.yahoosearch import perform_web_search

results, log = perform_web_search("Python tutorials", num_results=5)
print(results)
```

With return mode:
```python
result_dict = perform_web_search(
    "machine learning",
    num_results=10,
    return_mode="both"
)
if result_dict['success']:
    for answer in result_dict['answers']:
        print(answer)
```

With JSON persistence:
```python
perform_web_search(
    "Claude AI",
    num_results=5,
    save_json="search_results.json"
)
```

With emitter for UI:
```python
from helper.emitter import create_emitter

emitter = create_emitter(lambda msg: print(f"[UI] {msg}"))
results = perform_web_search(
    "web scraping best practices",
    emitter=emitter.emit
)
```

Command line:
```bash
python helper/yahoosearch.py "Python programming" 10
```

Usage:
    From command line:
        python helper/yahoosearch.py "search query" [num_results]
        python helper/yahoosearch.py "Python programming" 10
    
    From another module:
        from helper.yahoosearch import perform_web_search
        results, log = perform_web_search("search query", 5)

Dependencies:
    - requests: pip install requests
    - beautifulsoup4: pip install beautifulsoup4
"""

import json
import os
import sys
import requests
from typing import List, Dict, Tuple, Any, Callable
from bs4 import BeautifulSoup
from urllib.parse import quote_plus

# Path adjustment for direct script execution
# Adds parent directory (project root) to sys.path
# Why needed? Allows importing helper modules when running as script
if __name__ == "__main__":  # pragma: no cover - path adjustment logic
    repo_root = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
    if repo_root not in sys.path:
        sys.path.insert(0, repo_root)

from helper.emitter import create_emitter

# Default configuration for CLI and fallback
# DEFAULT_NUM_RESULTS: Typical number of results for most queries
# DEFAULT_QUERY: Example query for testing/demonstration
DEFAULT_NUM_RESULTS = 5
DEFAULT_QUERY = "Python programming tutorials"

def perform_web_search(
    query: str,
    num_results: int = DEFAULT_NUM_RESULTS,
    emitter: Callable[[str], None] | None = None,
    return_mode: str = "both",  # 'answer' | 'log' | 'both'
    save_json: str | os.PathLike | None = None,
):
    """Perform a web search using Yahoo search and return structured results.
    
    Executes web search via Yahoo Search using HTTP requests and HTML parsing.
    Returns formatted search results with titles, URLs, and descriptions.
    
    Pattern mirrors agent/bingsearch.py and helper/headlesssearch.py for consistency:
    - emit(): Pushes application log lines (console / Streamlit log area)
    - output_texts: Collects formatted search results suitable for UI expander
    - return_mode: Flexible return format
    - save_json: Optional persistence
    
    Execution Flow:
    ---------------
    1. Initialize emitter and output collection
    2. Encode query for URL
    3. Construct Yahoo search URL
    4. Send HTTP request with browser headers
    5. Parse HTML response
    6. Extract result containers (div.algo)
    7. For each result:
       - Extract title, URL, description
       - Filter ads and invalid URLs
       - Add to results list
    8. Format results for output
    9. Return based on return_mode
    
    Args:
        query (str): The search query string
                     Example: "Python programming tutorials"
                     URL-encoded automatically
        
        num_results (int): Number of search results to return (default: 5)
                           Actual results may be fewer if Yahoo returns less
                           Maximum practical: ~10-20 (Yahoo search page limit)
        
        emitter: Optional callback(line: str) for streaming logs
                 Signature: (str) -> None
                 If None, prints to console
                 Used for UI updates (e.g., Streamlit)
        
        return_mode: Controls return value format:
            'answer' -> formatted results text (fallback to log if none)
                       Use when: Only need search results
            'log'    -> full log text only
                       Use when: Need diagnostic information
            'both'   -> dict { 'answers': [...], 'output_text': str, 'log': str, 'success': bool }
                       Use when: Need both results and diagnostics
        
        save_json: Optional path to persist results as JSON
                   Example: "search_results.json"
                   Directory created automatically if doesn't exist
                   Saves: answers, output_text, log, success
    
    Returns:
        str | dict depending on return_mode:
        
        'answer' mode:
            str: Formatted search results (or log if no results)
        
        'log' mode:
            str: Complete diagnostic log
        
        'both' mode:
            dict: {
                'answers': List[str],      # List of formatted result strings
                'output_text': str,        # Joined answers (or log if none)
                'log': str,                # Complete diagnostic log
                'success': bool            # True if results found
            }
    
    Web Scraping Details:
    ---------------------
    Uses requests + BeautifulSoup to scrape Yahoo search results.
    
    URL format:
    https://search.yahoo.com/search?p={encoded_query}
    
    Headers (browser mimicry):
    - User-Agent: Chrome 91 on Windows 10
    - Accept: HTML and related formats
    - Accept-Language: English preferred
    
    HTML parsing targets:
    - Container: <div class="algo">
    - Title: <h3 class="title">
    - Link: <div class="compTitle"> <a>
    - Description: <div class="compText"> <p>
    
    Filtering:
    - Skip results without href
    - Skip anchor links (href="#")
    - Skip Yahoo redirect URLs (yahoo.com/r/)
    
    Example Results Structure:
    --------------------------
    ```python
    [
        {
            "title": "Python Tutorial - W3Schools",
            "url": "https://www.w3schools.com/python/",
            "description": "Learn Python programming..."
        },
        {
            "title": "Official Python Documentation",
            "url": "https://docs.python.org/",
            "description": "The official Python docs..."
        }
    ]
    ```
    
    Example Output Text:
    --------------------
    ```
    Yahoo Search Results for: 'Python tutorials'
    Found: 5 results
    
    1. Python Tutorial - W3Schools
       URL: https://www.w3schools.com/python/
       Description: Learn Python programming...
    
    2. Official Python Documentation
       URL: https://docs.python.org/
       Description: The official Python docs...
    ```
    
    Error Handling:
    ---------------
    - Network errors (RequestException): Logged, returns empty results
    - Parse errors: Logged, skips problematic result, continues
    - No results: Warning logged, success=False
    - Unexpected exceptions: Error logged, success=False
    
    All errors logged via emitter, operation continues where possible.
    
    Example Usage:
    --------------
    ```python
    # Simple usage
    results = perform_web_search("Python tutorials")
    print(results)
    
    # Get structured results
    result_dict = perform_web_search(
        "machine learning",
        num_results=10,
        return_mode="both"
    )
    if result_dict['success']:
        print(result_dict['output_text'])
    
    # With UI updates
    from helper.emitter import create_emitter
    emitter = create_emitter(lambda msg: print(f"[UI] {msg}"))
    results = perform_web_search(
        "web scraping",
        emitter=emitter.emit
    )
    
    # Save to file
    perform_web_search(
        "Claude AI",
        save_json="search_results.json"
    )
    ```
    
    Performance:
    ------------
    - HTTP request: ~500ms-2s (network dependent)
    - HTML parsing: ~50-200ms
    - Total: ~1-3s typical
    
    Limitations:
    ------------
    - No rate limiting built in (rely on Yahoo's tolerance)
    - Subject to breaking if Yahoo changes HTML structure
    - May not work with VPNs or certain regions
    - JavaScript-heavy content not executed
    
    Note:
        Uses web scraping with requests and BeautifulSoup4 to fetch Yahoo search results.
        Results quality and availability may vary based on Yahoo's service.
        For production use, consider API-based search (Bing, Google Custom Search).
    """
    # Track formatted output and success status
    output_texts: list[str] = []  # captured formatted results
    success = False  # Track operation success
    
    # STEP 1: Initialize emitter for progress logging
    # create_emitter wraps callback or creates console emitter
    emit_util = create_emitter(emitter)
    emit = emit_util.emit
    
    emit(f"[INFO] Performing Yahoo web search for: '{query}'")
    emit(f"[INFO] Requesting {num_results} results")
    
    try:
        # Initialize results list
        results = []
        
        emit("[INFO] Executing Yahoo search via web scraping...")
        try:
            # STEP 2: Construct Yahoo search URL
            # quote_plus: URL-encodes query, converts spaces to +
            # Why quote_plus? Yahoo expects + for spaces (not %20)
            encoded_query = quote_plus(query)
            search_url = f"https://search.yahoo.com/search?p={encoded_query}"
            
            # STEP 3: Set browser-like headers
            # User-Agent: Identifies as Chrome browser (avoids blocking)
            # Accept: Standard browser content types
            # Why mimic browser? Yahoo may block automated requests
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Accept-Encoding': 'gzip, deflate',
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1'
            }
            
            # STEP 4: Send HTTP request
            emit(f"[INFO] Fetching: {search_url}")
            # timeout=10: Fail after 10 seconds (prevent hanging)
            # raise_for_status(): Raise exception for HTTP errors (4xx, 5xx)
            response = requests.get(search_url, headers=headers, timeout=10)
            response.raise_for_status()
            
            # STEP 5: Parse HTML response
            # 'html.parser': Built-in parser (no external deps)
            # Alternative parsers: 'lxml' (faster), 'html5lib' (more lenient)
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # STEP 6: Find search result containers
            # class_='algo': Yahoo's CSS class for organic results
            # limit=num_results * 2: Get extra in case some are ads
            # Why extra? Some containers may be ads or empty
            result_divs = soup.find_all('div', class_='algo', limit=num_results * 2)
            
            emit(f"[INFO] Found {len(result_divs)} potential result containers")
            
            # STEP 7: Extract data from each result
            for div in result_divs:
                # Stop if we have enough results
                if len(results) >= num_results:
                    break
                
                try:
                    # Extract title from h3.title tag
                    title_tag = div.find('h3', class_='title')
                    if not title_tag:
                        # No title found, skip this result
                        continue
                    
                    # get_text(strip=True): Extract text, remove whitespace
                    title = title_tag.get_text(strip=True) or "No title"
                    
                    # Get the link - look for the main link in compTitle div
                    # Yahoo wraps actual link in nested divs
                    link_tag = div.find('div', class_='compTitle')
                    if link_tag:
                        link_tag = link_tag.find('a')
                    
                    # Validate link exists and has href attribute
                    if not link_tag or not link_tag.get('href'):
                        continue
                    
                    url = link_tag.get('href', '')
                    
                    # Extract description from compText div
                    desc_div = div.find('div', class_='compText')
                    if desc_div:
                        desc_tag = desc_div.find('p')
                        description = desc_tag.get_text(strip=True) if desc_tag else "No description available"
                    else:
                        description = "No description available"
                    
                    # STEP 8: Filter out ads and invalid URLs
                    # Skip anchors (href="#")
                    # Skip Yahoo redirect URLs (yahoo.com/r/)
                    # Why filter? Yahoo HTML includes ads, related searches
                    if url and not url.startswith('#') and 'yahoo.com/r/' not in url:
                        results.append({
                            "title": title,
                            "url": url,
                            "description": description
                        })
                except Exception as parse_error:
                    # Parse error for this specific result
                    # Log warning but continue processing other results
                    emit(f"[WARN] Failed to parse result: {parse_error}")
                    continue
            
        except requests.RequestException as req_error:
            # Network error (timeout, connection refused, HTTP error)
            emit(f"[ERROR] Yahoo search request failed: {req_error}")
        except Exception as search_error:
            # Other errors (parsing, unexpected structure)
            emit(f"[ERROR] Yahoo search failed: {search_error}")
        
        # STEP 9: Check if we got any results
        if len(results) == 0:
            # No results found - could be network issue or query too specific
            emit("[WARN] No results returned from Yahoo search.")
            emit("[WARN] This may be due to network issues or service limitations.")
        else:
            # Results found - mark success
            success = True
            emit(f"[INFO] Retrieved {len(results)} results")
            
            # STEP 10: Format results for output
            formatted_results = f"Yahoo Search Results for: '{query}'\n"
            formatted_results += f"Found: {len(results)} results\n\n"
            
            # Format each result with numbering
            for i, result in enumerate(results, 1):
                formatted_results += f"{i}. {result['title']}\n"
                formatted_results += f"   URL: {result['url']}\n"
                formatted_results += f"   Description: {result['description']}\n\n"
            
            # Add to output collection
            output_texts.append(formatted_results)
            
            # Log as answer output (for UI expander)
            emit("[ANSWER OUTPUT]\n" + formatted_results)
        
    except Exception as e:
        # Unexpected exception (shouldn't normally happen)
        emit(f"[ERROR] Unexpected exception: {e}")
        success = False
    
    # STEP 11: Prepare return payload based on mode
    answers_joined = "\n\n".join(output_texts)
    log_joined = emit_util.get_log()
    
    if return_mode == "both":
        # Comprehensive mode: Return all information
        payload: dict | str = {
            "answers": output_texts,
            "output_text": answers_joined or log_joined,
            "log": log_joined,
            "success": success,
        }
    elif return_mode == "log":
        # Log mode: Return only diagnostic log
        payload = log_joined
    else:  # 'answer'
        # Answer mode: Return formatted results (or log if none)
        payload = answers_joined if answers_joined else log_joined
    
    # STEP 12: Save to JSON if requested
    if save_json:
        import pathlib
        try:
            # Create path object and ensure parent directory exists
            path_obj = pathlib.Path(save_json)
            path_obj.parent.mkdir(parents=True, exist_ok=True)
            
            # Write JSON with pretty formatting
            with path_obj.open('w', encoding='utf-8') as f:
                json.dump(
                    {
                        "answers": output_texts,
                        "output_text": answers_joined,
                        "log": log_joined,
                        "success": success,
                    },
                    f,
                    ensure_ascii=False,  # Preserve Unicode
                    indent=2,            # Pretty-print
                )
        except Exception as exc:  # pragma: no cover
            # JSON save failed - log warning but don't fail operation
            emit(f"[WARN] Failed to save JSON artefact: {exc}")
            
            # Update log in payload if mode is log or both
            log_joined2 = emit_util.get_log()
            if isinstance(payload, dict):
                payload["log"] = log_joined2
            elif return_mode == "log":
                payload = log_joined2
    
    return payload

if __name__ == "__main__":
    """Command-line interface for Yahoo search testing.
    
    Purpose:
    --------
    Provides direct CLI access for testing Yahoo search functionality.
    Useful for development, debugging, and standalone search operations.
    
    Usage:
    ------
    python yahoosearch.py [query] [num_results]
    
    Arguments:
    ----------
    query: Search query string (optional, default: "Python programming")
           If contains spaces, wrap in quotes
           Example: "Python web scraping"
    
    num_results: Number of results (optional, default: 5)
                 Must be positive integer
                 Example: 10
    
    Examples:
    ---------
    # Use default query and count
    python yahoosearch.py
    
    # Custom query (5 results)
    python yahoosearch.py "machine learning"
    
    # Custom query and count
    python yahoosearch.py "web scraping" 10
    
    # Single word query
    python yahoosearch.py Python
    
    Output:
    -------
    Prints to console:
    - Formatted search results (title, URL, description)
    - Diagnostic log messages ([INFO], [WARN], [ERROR])
    - Results not saved to JSON in default CLI mode
    
    Error Handling:
    ---------------
    - Invalid num_results: Uses default (5)
    - Network errors: Logged to console
    - Parse errors: Logged, operation continues
    
    Note:
        All output goes to console (no Streamlit UI dependency).
        Emitter callback is None, so emit() defaults to print().
    """
    # Parse command line arguments
    # sys.argv[0]: script name (yahoosearch.py)
    # sys.argv[1]: query (optional, uses DEFAULT_QUERY if not provided)
    # sys.argv[2]: num_results (optional, uses DEFAULT_NUM_RESULTS if not provided)
    if len(sys.argv) > 1:
        # Query provided via command line
        search_query = sys.argv[1]
        
        # Check for num_results argument
        # int(): Convert string to integer
        # Fallback to DEFAULT_NUM_RESULTS if not provided or invalid
        num_results = int(sys.argv[2]) if len(sys.argv) > 2 else DEFAULT_NUM_RESULTS
    else:
        # No arguments provided - use defaults
        # DEFAULT_QUERY: "Python programming" (defined at top of file)
        # DEFAULT_NUM_RESULTS: 5 (defined at top of file)
        search_query = DEFAULT_QUERY
        num_results = DEFAULT_NUM_RESULTS
    
    # Execute search with console output
    # emitter=None: Uses default console emitter (prints to stdout)
    # All emit() calls will print directly to console
    # No save_json: Results not persisted (CLI mode is for quick testing)
    perform_web_search(search_query, num_results)
