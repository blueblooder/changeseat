# Setup Guide

This guide walks you through the complete setup process for the Common AgentSDK and AgentFramework Samples repository.

## Prerequisites

This setup procedure assumes you have the following already installed on your Windows machine:

- ✅ **Python 3.8+** - Python runtime environment
- ✅ **Azure CLI** - Azure command-line interface
- ✅ **PowerShell** - Windows PowerShell or PowerShell Core
- ✅ **Git** - Version control system

If you don't have these installed, please install them before proceeding.

---

## 1. Local Environment Setup

### Step 1: Clone the Repository

Open PowerShell and clone the repository:

```pwsh
git clone https://github.com/denlai-mshk/Common-AgentSDK-Samples.git
cd Common-AgentSDK-Samples
```

### Step 2: Create Virtual Environment

Create a Python virtual environment to isolate dependencies:

```pwsh
python -m venv .venv
```

### Step 3: Activate Virtual Environment

Activate the virtual environment:

```pwsh
.\.venv\Scripts\activate
```

After activation, you should see `(.venv)` prefix in your PowerShell prompt.

### Step 4: Install Python Dependencies

Install all required Python packages:

```pwsh
pip install -r requirements.txt
```

This will install:
- `azure-ai-projects` - Azure AI Agent SDK and Framework
- `azure-identity` - Azure authentication
- `azure-search-documents` - Azure AI Search integration
- `msal` - Microsoft Authentication Library
- `streamlit` - Web UI framework
- And other supporting libraries

### Step 5: Azure CLI Login

Login to Azure to authenticate with your Azure subscription:

```pwsh
az login
```

Ensure you have the **Azure AI User** RBAC role assignment against your Azure AI Foundry resource and project.

---

## 2. Azure & External Resources Provisioning

You need to provision the following Azure and external resources. Refer to the `.env-sample` file for all required environment variables.

### 1. Azure AI Foundry Project
**Purpose**: Core AI project with model deployments for agent creation

**What you need**:
- Project endpoint URL
- Model deployment name (e.g., `gpt-4o`, `gpt-4`)

**Environment Variables**:
```env
# For Agent Framework
AZURE_AI_PROJECT_ENDPOINT=https://your-project.cognitiveservices.azure.com/
AZURE_AI_MODEL_DEPLOYMENT_NAME=gpt-4o

# For Agent SDK
PROJECT_ENDPOINT=https://your-project.cognitiveservices.azure.com/
MODEL_DEPLOYMENT_NAME=gpt-4o
```

**How to create**:
- Navigate to [Azure AI Foundry](https://ai.azure.com/)
- Create a new project or use existing one
- Deploy a model (GPT-4 or GPT-4o recommended)

### 2. Azure AI Search
**Purpose**: Vector search index for RAG (Retrieval-Augmented Generation) capabilities

**What you need**:
- Search service connection name
- Search index name

**Environment Variables**:
```env
# For Agent Framework
AZURE_AI_SEARCH_INDEX_NAME=your-index-name

# For Agent SDK
AI_SEARCH_CONNECTION_NAME=your-search-connection-name
AI_SEARCH_INDEX_NAME=your-index-name
```

**How to create**:
- Create an [Azure AI Search service](https://learn.microsoft.com/azure/search/search-create-service-portal)
- [Create a search index](https://learn.microsoft.com/azure/search/search-how-to-create-search-index?tabs=portal)
- Connect it to your AI Foundry project

### 3. Bing Search Resource
**Purpose**: Web search grounding for agents

**What you need**:
- Bing Search connection name or connection ID

**Environment Variables**:
```env
# For Agent Framework
BING_CONNECTION_ID=your-bing-connection-id

# For Agent SDK
BING_CONNECTION_NAME=your-bing-connection-name
```

**How to create**:
- Create a [Bing Search resource](https://learn.microsoft.com/bing/search-apis/bing-web-search/create-bing-search-service-resource)
- Connect it to your AI Foundry project

### 4. Azure Speech Service
**Purpose**: Text-to-speech synthesis for MP3 audio generation

**What you need**:
- Speech service region
- Speech resource ID
- Voice name

**Environment Variables**:
```env
SPEECH_REGION=eastasia
SPEECH_VOICE=en-US-JennyNeural
SPEECH_RESOURCE_ID=/subscriptions/{sub-id}/resourceGroups/{rg}/providers/Microsoft.CognitiveServices/accounts/{name}
```

**How to create**:
- Create an [Azure Speech Service resource](https://learn.microsoft.com/azure/ai-services/speech-service/overview)
- Note the region and resource ID

### 5. Azure Logic Apps (for Email Sending)
**Purpose**: HTTP endpoint for automated email delivery

**What you need**:
- Logic App HTTP trigger URL

**Environment Variables**:
```env
LOGIC_APP_EMAIL_URL=https://your-logic-app.azurewebsites.net:443/workflows/.../triggers/manual/paths/invoke?...
```

**Setup instructions**: See [Section 4: Logic App Setup](#4-logic-app-setup) below

### Azure Blob Storage (Optional)
**Purpose**: Store email data and MP3 files

**Environment Variables**:
```env
BLOB_CONNECTION_STRING=DefaultEndpointsProtocol=https;AccountName=...;AccountKey=...;EndpointSuffix=core.windows.net
```

### Google Custom Search API (Optional External Resources)
**Purpose**: Alternative search capability using Google Custom Search

**What you need**:
- Google Custom Search API key
- Custom Search Engine ID (CX)

**Environment Variables**:
```env
GCS_CX=your-custom-search-engine-id
GCS_DEVELOPER_KEY=your-google-api-key
```

**How to create**:
- Create a [Google Custom Search Engine](https://programmablesearchengine.google.com/)
- Enable the [Custom Search API](https://developers.google.com/custom-search/v1/overview) and get an API key


### Email Configuration
```env
DEFAULT_EMAIL_RECIPIENT=your-email@example.com
UTC_OFFSET=8
EMAIL_STARTTIME=2025-01-01T00:00:00
EMAIL_ENDTIME=2025-12-31T23:59:59
```

### Agent Configuration Files
```env
AGENT_CONFIG_FILE=.\config\agent_config.yaml
AGENTIC_CONFIG_FILE=.\config\agentic_config.yaml
```

### Create .env File

After provisioning resources, create a `.env` file in the root directory:

```pwsh
Copy-Item .env-sample .env
```

Then edit `.env` and fill in your actual values for each environment variable.


---

## 3. RBAC Permissions Reference

When you run "az login", make sure you have the following RBAC permission granted.

### User Permissions (Az Login Users)

| Azure Resource | Required RBAC Role(s) | Purpose | Scope |
|----------------|----------------------|---------|-------|
| **Azure AI Search** | Search Index Data Reader | Read access to search indexes and query data | Resource level |
| | Search Service Contributor | Manage search service configuration | Resource level |
| | Search Index Data Contributor | Create, update, delete search index data | Resource level |
| **Azure AI Foundry** | Azure AI User | Access AI services, models, and endpoints | Resource level |
| **Storage Account** | Storage Blob Data Contributor | Read, write, delete blob data for workshop files | Resource level |
| **Speech Service** | Cognitive Services Speech Contributor | Manage speech service resources and configurations | Resource level |
| | Cognitive Services Speech User | Use speech-to-text and text-to-speech APIs | Resource level |

### Service-to-Service Permissions (Managed Identity / System Assigned Identity)

In addition to user permissions, the following RBAC roles must be assigned to enable service-to-service communication:

| Source Service | Target Resource | Required RBAC Role(s) | Purpose | Scope |
|----------------|-----------------|----------------------|---------|-------|
| **Azure AI Search** | **Storage Account** | Storage Blob Data Reader | Read blob data from storage account for building search indexes | Resource level |
| **Azure AI Search** | **Azure AI Foundry** | Azure AI User | Convert user questions to vectors for RAG (Retrieval-Augmented Generation) | Resource level |
| **Azure AI Foundry** | **Bing Search Resource** | Grounding with Bing User | Enable grounding with Bing search capabilities | Resource level |
| **Azure AI Foundry** | **Azure AI Search** | Search Index Data Reader | Read search index data for RAG queries | Resource level |
| | | Search Service Contributor | Manage and configure search service for RAG integration | Resource level |

**Note**: These service-to-service permissions are typically assigned to the managed identity of the source service. Ensure that managed identity is enabled on the source service and the appropriate role assignments are configured in the target resource's Access Control (IAM) settings.



---

## 4. Microsoft 365 Graph API - App Registration Setup

To use the CheckEmail features that access Microsoft 365 emails, you need to create an Azure AD App Registration.

### Why App Registration is Required

The CheckEmail functionality uses Microsoft Graph API to access user emails from Microsoft 365. This requires proper OAuth2 authentication through an Azure AD App Registration configured as a **Public Client** application.

### Step-by-Step App Registration Setup

#### Step 1: Create a New App Registration

1. Navigate to [Azure Portal](https://portal.azure.com/)
2. Go to **Microsoft Entra ID** > **App registrations**
3. Click **+ New registration**
4. Fill in the registration details:
   - **Name**: `M365-Email-CheckEmail-App` (or your preferred name)
   - **Supported account types**: Choose based on your needs (Single tenant for most of the cases):
     - **Single tenant** - Only your organization
     - Multitenant - Any Azure AD directory
     - Multitenant + personal accounts - Recommended for flexibility
   - **Redirect URI**: Leave blank for now
5. Click **Register**

#### Step 2: Configure as Public Client Application

1. After registration, go to **Authentication** in the left menu
2. Click **+ Add a platform**
3. Select **Mobile and desktop applications**
4. Check the box for:
   - `https://login.microsoftonline.com/common/oauth2/nativeclient`
5. Under **Advanced settings**, set:
   - **Allow public client flows**: **Yes**
6. Click **Configure** and then **Save**

![App Registration - Step 3](../appreg/m365_checkemail_graphapi_3.png)


This configuration enables device code flow authentication, which is suitable for command-line and desktop applications.

#### Step 3: Add API Permissions

1. Go to **API permissions** in the left menu
2. Click **+ Add a permission**
3. Select **Microsoft Graph**
4. Choose **Delegated permissions**
5. Search for and expand **Mail**
6. Check the box for:
   - **Mail.Read** - Read user mail
7. Click **Add permissions**

![App Registration - Step 1](../appreg/m365_checkemail_graphapi_1.png)

#### Step 4: Grant admin consent

8. **(Optional)** If you're the admin, click **Grant admin consent for [Your Organization]**
   - If not granted, users will need to consent on first login

![App Registration - Step 2](../appreg/m365_checkemail_graphapi_2.png)

#### Step 5: Expose API

![App Registration - Step 4](../appreg/m365_checkemail_graphapi_4.png)

#### Step 6: Copy Application Details

1. Go to **Overview** in the left menu
2. Copy the following values:
   - **Application (client) ID** - This is your `M365_CLIENT_ID`
   - **Directory (tenant) ID** - This is your `M365_TENANT_ID`

#### Step 7: Update .env File

Add the app registration details to your `.env` file:

```env
M365_CLIENT_ID=your-application-client-id-here
M365_TENANT_ID=your-tenant-id-here
M365_DOMAIN=yourdomain.onmicrosoft.com
```

### Authentication Flow

The CheckEmail feature uses **device code flow** authentication:

1. First time running, you'll see a device code in the terminal
2. Open the provided URL in a browser
3. Enter the device code
4. Sign in with your Microsoft 365 account
5. Grant permission to read mail
6. Token is cached locally for future use

### Token Caching

The system uses two token cache files:
- `.msal_token_cache.json` - MSAL library cache (refresh tokens)
- `.sso_token_cache.json` - Access token cache

**To switch accounts**: Delete `.sso_token_cache.json` and re-authenticate

**To completely reset**: Delete both cache files

See the [Testing Guide](TESTING.md) for more details on authentication management.

---

## 5. Logic App Setup

To enable email sending functionality, you need to create an Azure Logic App with an HTTP trigger and Office 365 Outlook connector.

### Why Logic App is Required

The email sending functionality uses Azure Logic Apps as a serverless integration platform to:
- Receive email requests via HTTP endpoint
- Send emails through Office 365 Outlook connector
- Handle HTML formatting and attachments
- Provide reliable delivery with built-in retry logic

### Architecture

```
Agent/Tool → HTTP Request → Logic App → Office 365 Connector → Send Email
```

### Step-by-Step Logic App Setup

#### Step 1: Create Logic App

1. Navigate to [Azure Portal](https://portal.azure.com/)
2. Click **Create a resource**
3. Search for **Logic App**
4. Click **Create**
5. Fill in the details:
   - **Subscription**: Your Azure subscription
   - **Resource Group**: Create new or use existing
   - **Logic App Name**: `email-sender-logicapp` (or your preferred name)
   - **Region**: Choose your preferred region
   - **Plan Type**: **Consumption** (pay-per-execution)
6. Click **Review + Create**, then **Create**

#### Step 2: Design the Workflow

Once the Logic App is created:

1. Go to the Logic App resource
2. Click **Logic app designer** in the left menu
3. Start with a blank Logic App

#### Step 3: Add HTTP Request Trigger

1. Search for **When a HTTP request is received**
2. Click on it to add as the trigger
3. Click **Use sample payload to generate schema**
4. Copy the JSON schema from `.\logicapp\httprequest.json`:

```json
{
  "type": "object",
  "properties": {
    "email_to": {
      "type": "string"
    },
    "email_subject": {
      "type": "string"
    },
    "email_body": {
      "type": "string"
    },
    "attachments": {
      "type": "array",
      "items": {
        "type": "object",
        "properties": {
          "filename": {
            "type": "string"
          },
          "content_base64": {
            "type": "string"
          },
          "contentType": {
            "type": "string"
          }
        }
      }
    }
  }
}
```

5. Paste it and click **Done**
6. The schema will be auto-generated based on this payload

#### Step 4: Add Office 365 Outlook Connector

1. Click **+ New step**
2. Search for **Office 365 Outlook**
3. Select **Send an email (V2)**
4. Sign in with your Office 365 account when prompted
   - This creates a connection named `office365` (or similar)
5. Configure the email action using the JSON from `.\logicapp\sendemail.json`:

**Field Mappings**:
- **To**: Click in the field → Dynamic content → `email_to`
- **Subject**: Click in the field → Dynamic content → `email_subject`
- **Body**: 
  - Switch to **Code view** (click `</>` icon)
  - Enter: `<p class="editor-paragraph">@{triggerBody()?['email_body']}</p>`
- **Attachments**: Click in the field → Dynamic content → `attachments`
- **Importance**: Select **Normal**

**Advanced Options** (click **Show advanced options**):
- **Is HTML**: Select **Yes**

#### Step 5: Add HTTP Response (Optional but Recommended)

1. Click **+ New step**
2. Search for **Response**
3. Select **Response** action
4. Configure using `.\logicapp\response.json`:
   - **Status Code**: `200`
   - Leave **Body** empty

This sends a confirmation response back to the calling agent.

#### Step 6: Save and Get HTTP URL

1. Click **Save** at the top of the designer
2. Go back to the **HTTP Request** trigger (first step)
3. Copy the **HTTP POST URL** that was generated
   - It looks like: `https://prod-xx.region.logic.azure.com:443/workflows/.../triggers/manual/paths/invoke?api-version=2016-10-01&sp=...&sig=...`

#### Step 7: Update .env File

Add the Logic App URL to your `.env` file:

```env
LOGIC_APP_EMAIL_URL=https://prod-xx.region.logic.azure.com:443/workflows/.../triggers/manual/paths/invoke?...
```

### Logic App Configuration Reference Files

The repository includes reference JSON files for each Logic App component:

| File | Purpose | Location |
|------|---------|----------|
| `httprequest.json` | HTTP trigger schema definition | `.\logicapp\httprequest.json` |
| `sendemail.json` | Office 365 send email action configuration | `.\logicapp\sendemail.json` |
| `response.json` | HTTP response action configuration | `.\logicapp\response.json` |

You can use these files as reference when configuring your Logic App manually or for automation scripts.

### Testing the Logic App

You can test the Logic App directly using PowerShell:

```pwsh
$body = @{
    email_to = "your-email@example.com"
    email_subject = "Test Email from Logic App"
    email_body = "<h2>Hello!</h2><p>This is a test email.</p>"
    attachments = @()
} | ConvertTo-Json

Invoke-RestMethod -Uri $env:LOGIC_APP_EMAIL_URL -Method Post -Body $body -ContentType "application/json"
```

If successful, you should receive an email at the specified address.

### HTML Email Support

The Logic App is configured to support HTML emails by default:
- The `email_body` field accepts HTML content
- The `Body` field uses `<p class="editor-paragraph">@{triggerBody()?['email_body']}</p>` wrapper
- The `Is HTML` option should be set to **Yes**

The helper function `send_email` in `helper/logicappemail.py` automatically handles HTML formatting and linkification.

### Troubleshooting

**Logic App fails to send email**:
- Check Office 365 connector authentication
- Verify the sender account has permission to send emails
- Check the Logic App run history for error details

**HTTP request fails**:
- Verify the `LOGIC_APP_EMAIL_URL` in `.env` is correct
- Check that the URL includes the `api-version` and signature parameters
- Ensure the Logic App is enabled (not disabled)

**Attachments not working**:
- Verify `content_base64` is properly base64 encoded
- Check `contentType` matches the file type (e.g., `audio/mpeg` for MP3)
- Ensure `filename` includes the file extension

---

## 6. Verify Setup

After completing all setup steps, verify your environment:

### Check Python Environment

```pwsh
python --version
pip list | Select-String -Pattern "azure-ai-projects|streamlit|msal"
```

### Check .env File

```pwsh
Get-Content .env
```

Ensure all required variables are filled in (no empty values).

### Test Azure Authentication

```pwsh
az account show
```

This should display your current Azure subscription details.

### Test Agent Configuration

```pwsh
python -c "from helper.agent_config_loader import load_agent_config; print(load_agent_config())"
```

This should load and display your agent configuration without errors.

---

## Next Steps

✅ Setup complete! You're now ready to test the samples.

Continue to the [Testing Guide](TESTING.md) to learn how to:
- Run samples via Streamlit GUI
- Execute individual agents from command line
- Understand parameters for each use case
- Manage authentication tokens

---

## Troubleshooting Common Issues

### Issue: "Module not found" errors

**Solution**: Ensure virtual environment is activated and dependencies are installed:
```pwsh
.\.venv\Scripts\activate
pip install -r requirements.txt
```

### Issue: "Azure authentication failed"

**Solution**: Login to Azure CLI:
```pwsh
az login
az account show
```

### Issue: "Environment variable not found"

**Solution**: Verify `.env` file exists and contains all required variables:
```pwsh
Test-Path .env
Get-Content .env
```

### Issue: "Token cache errors"

**Solution**: Delete token cache files and re-authenticate:
```pwsh
Remove-Item .msal_token_cache.json -ErrorAction SilentlyContinue
Remove-Item .sso_token_cache.json -ErrorAction SilentlyContinue
```

### Issue: Logic App returns 404 or 401

**Solution**: 
- Verify `LOGIC_APP_EMAIL_URL` includes the full URL with signature
- Check that the Logic App is saved and enabled
- Test the URL directly with Postman or PowerShell

---

## Additional Resources

- [Azure AI Foundry Documentation](https://learn.microsoft.com/azure/ai-studio/)
- [Azure AI Search Documentation](https://learn.microsoft.com/azure/search/)
- [Microsoft Graph API Documentation](https://learn.microsoft.com/graph/)
- [Azure Logic Apps Documentation](https://learn.microsoft.com/azure/logic-apps/)
- [MSAL Python Documentation](https://msal-python.readthedocs.io/)

---

[← Back to README](../README.md) | [Next: Testing Guide →](TESTING.md)
