"""Centralized emitter utility for consistent logging and UI updates.

This module provides the EmitterUtil class that standardizes emit functionality
across all agent and helper modules, supporting both callback-based emission
(for UI updates like Streamlit) and direct console printing.

Key Responsibilities:
1. Message Logging: Store all emitted messages for later retrieval
2. Callback Support: Forward messages to registered callback functions
3. Console Fallback: Print to console when no callback registered
4. Streamlit Integration: Specialized real-time UI updates via StreamlitEmitterUtil

Design Patterns:
- Observer Pattern: Callbacks notify UI of new messages
- Dual Output: Both log storage AND immediate display/callback
- Buffering: Messages accumulated for bulk retrieval via get_log()
- Inheritance: StreamlitEmitterUtil extends base EmitterUtil

Why This Abstraction?
- Decoupling: Agents don't need to know about UI framework (Streamlit)
- Testability: Can inject mock emitters for testing
- Flexibility: Same agent code works in CLI, Streamlit, or other UIs
- Logging: Automatic message capture without manual log.append() everywhere

Common Usage Patterns:
```python
# Console output (development/CLI)
emitter = EmitterUtil()
emitter.emit("Processing...")  # Prints to console

# Streamlit integration (production UI)
placeholder = st.empty()
emitter = StreamlitEmitterUtil(placeholder)
emitter.emit("Processing...")  # Updates Streamlit UI in real-time

# Callback-based (custom UI)
def my_callback(msg):
    my_ui.update(msg)
emitter = EmitterUtil(emitter=my_callback)
emitter.emit("Processing...")  # Calls my_callback(msg)
```
"""

from typing import Optional, Callable, List


class EmitterUtil:
    """Utility class for consistent emit behavior across the application.
    
    This class manages message logging and emission, providing a standardized
    interface for both console output and callback-based UI updates.
    
    Architecture:
    - Stores all messages in self.messages list (complete log)
    - Optionally forwards each message to callback function (UI updates)
    - Falls back to console print if no callback registered
    
    Thread Safety:
    NOT thread-safe. If used in multi-threaded context, external synchronization
    needed for self.messages list operations.
    
    Memory Considerations:
    All messages stored in memory. For long-running processes with many messages,
    consider periodically calling clear_messages() to prevent unbounded growth.
    """
    
    def __init__(self, emitter: Optional[Callable[[str], None]] = None):
        """Initialize the emitter utility.
        
        Sets up the emitter with optional callback and initializes message buffer.
        
        Parameters
        ----------
        emitter : Optional[Callable[[str], None]]
            Optional callback function for handling emit messages (e.g., for UI updates).
            If None, messages will be printed to console.
            Callback receives single string argument (the message).
            
            Example callbacks:
            - Streamlit: lambda msg: st.write(msg)
            - Logger: lambda msg: logger.info(msg)
            - Custom UI: lambda msg: my_ui.append_text(msg)
        
        Why Optional Callback?
        - Flexibility: Works in both UI and CLI contexts
        - Testing: Can create emitter without UI dependency
        - Development: Console output useful for debugging
        """
        # Store callback function (or None for console fallback)
        self.emitter = emitter
        
        # Initialize message buffer for complete log storage
        # Why list instead of string? 
        # - Efficient append operations
        # - Preserves individual messages (can process separately if needed)
        # - Easy to get count, slice, filter, etc.
        self.messages: List[str] = []
    
    def emit(self, message: str) -> None:
        """Emit a message through the configured emitter and store in message log.
        
        This is the primary method called by agents and helpers to output progress,
        status, and diagnostic information.
        
        Execution Flow:
        1. Append message to internal log (self.messages)
        2. If callback registered: Call callback with message
        3. Else: Print to console with flush
        
        Why Store Then Emit?
        - Log persists even if callback raises exception
        - Ensures message captured for debugging
        - Allows post-execution log retrieval via get_log()
        
        Parameters
        ----------
        message : str
            The message to emit and log.
            Should be human-readable status/progress text.
            Common formats:
            - "[INFO] Operation started"
            - "[ERROR] Failed to connect: <reason>"
            - "[DEBUG] Processing item 5/10"
            - "✅ Successfully completed"
        
        Side Effects:
        - Appends to self.messages (grows memory)
        - Calls self.emitter callback if registered
        - Prints to console if no callback (visible in logs/terminal)
        
        Thread Safety:
        If called from multiple threads, messages may interleave.
        Consider using threading.Lock for thread-safe emission.
        """
        # STEP 1: Always log the message
        # Ensures message captured even if callback fails
        self.messages.append(message)
        
        # STEP 2: Emit via callback or console
        if self.emitter:
            # Callback mode: Forward to registered handler
            # UI frameworks like Streamlit use this path
            self.emitter(message)
        else:
            # Console mode: Direct output to stdout
            # flush=True ensures immediate visibility (important for long-running operations)
            # Why flush? Python buffers stdout by default, flush ensures real-time output
            print(message, flush=True)
    
    def get_log(self) -> str:
        """Get all logged messages as a joined string.
        
        Useful for:
        - Displaying complete execution log in UI
        - Saving log to file
        - Sending log via email
        - Debugging failed operations
        
        Returns
        -------
        str
            All logged messages joined with newlines.
            Empty string if no messages.
        
        Example Output:
        ```
        [INFO] Starting search operation
        [DEBUG] Querying API endpoint
        [INFO] Received 5 results
        ✅ Search completed successfully
        ```
        
        Why Join With Newlines?
        - Human-readable format
        - Compatible with text files and UI text areas
        - Preserves message boundaries
        """
        return "\n".join(self.messages)
    
    def get_messages(self) -> List[str]:
        """Get the list of logged messages.
        
        Returns a copy of the message list to prevent external modification
        of the internal buffer.
        
        Use Cases:
        - Processing messages individually (filtering, searching)
        - Counting specific message types (errors, warnings)
        - Exporting to structured formats (JSON, CSV)
        
        Returns
        -------
        List[str]
            List of all logged messages (copy of internal buffer).
        
        Why Return Copy?
        - Encapsulation: Prevents external code from modifying internal state
        - Safety: Caller can modify returned list without affecting emitter
        - Immutability: Original log remains unchanged
        
        Performance Note:
        Creates a new list copy. For large logs (thousands of messages),
        consider using get_log() if you just need the text.
        """
        # .copy() creates shallow copy (sufficient for list of strings)
        # Prevents: emitter.get_messages().clear() from clearing internal buffer
        return self.messages.copy()
    
    def clear_messages(self) -> None:
        """Clear all logged messages.
        
        Use this to:
        - Free memory in long-running processes
        - Reset log between operations
        - Prevent log from growing unbounded
        
        Warning:
        Clears the complete message history. If you need to preserve logs,
        call get_log() or get_messages() before clearing.
        
        Common Pattern:
        ```python
        # Save log before clearing
        log_text = emitter.get_log()
        save_to_file(log_text)
        
        # Clear for next operation
        emitter.clear_messages()
        ```
        """
        # .clear() removes all elements from list efficiently
        # More efficient than self.messages = [] (which creates new list object)
        self.messages.clear()


class StreamlitEmitterUtil(EmitterUtil):
    """Specialized emitter utility for Streamlit integration.
    
    This class extends EmitterUtil to provide real-time UI updates
    for Streamlit applications by maintaining a display buffer.
    
    Key Differences from Base EmitterUtil:
    1. Dual Buffers: 
       - self.messages: Complete log (inherited)
       - self.display_lines: UI-specific display buffer
    
    2. Real-time UI Updates:
       - Each emit() updates Streamlit placeholder immediately
       - Formatted with HTML for word-wrapping and code styling
    
    3. Streamlit-specific Rendering:
       - Uses markdown with unsafe_allow_html for custom styling
       - Wraps in <div><code> for monospace, wrapped display
       - Accumulates all lines in single placeholder (smooth updates)
    
    Why Separate Class Instead of Flags?
    - Cleaner separation of concerns (Streamlit logic isolated)
    - Can extend with Streamlit-specific features
    - Doesn't pollute base EmitterUtil with UI framework dependencies
    - Follows Open/Closed Principle (extend, don't modify)
    
    Streamlit Rendering Strategy:
    Instead of creating new st.text() for each message (slow, cluttered):
    - Use single st.empty() placeholder
    - Update placeholder with ALL lines on each emit
    - Streamlit efficiently diffs and updates only changed parts
    
    This provides:
    - Smooth, flicker-free updates
    - Single scrollable text area
    - Better performance (one widget vs hundreds)
    """
    
    def __init__(self, placeholder=None):
        """Initialize the Streamlit emitter utility.
        
        Parameters
        ----------
        placeholder : Optional[streamlit.empty]
            Streamlit placeholder for real-time text updates.
            Created via: placeholder = st.empty()
            
            If None, falls back to standard EmitterUtil behavior (console output).
            
        Typical Usage:
        ```python
        import streamlit as st
        
        # Create placeholder in Streamlit UI
        status_area = st.empty()
        
        # Create emitter with placeholder
        emitter = StreamlitEmitterUtil(status_area)
        
        # Messages will appear in real-time in the placeholder
        emitter.emit("[INFO] Starting process...")
        run_agent(emitter=emitter.emit)
        ```
        
        Why Require Placeholder?
        - Allows caller to position output in UI layout
        - Supports multiple emitters in different UI sections
        - Gives control over when/where output appears
        """
        # Store placeholder for UI updates
        self.placeholder = placeholder
        
        # Display buffer: UI-visible lines (subset of full log)
        # Why separate from self.messages?
        # - Can filter/format for display differently
        # - Might truncate for performance (show last N lines)
        # - Might add UI-specific formatting
        self.display_lines: List[str] = []
        
        # Initialize parent class with custom emitter callback
        # If placeholder exists: Use _streamlit_emit
        # If placeholder None: Use default console behavior
        super().__init__(emitter=self._streamlit_emit if placeholder else None)
    
    def _streamlit_emit(self, message: str) -> None:
        """Internal method for Streamlit-specific emission.
        
        This method is called by parent's emit() when callback registered.
        Handles the Streamlit UI update logic.
        
        Update Strategy:
        1. Add message to display_lines buffer
        2. Regenerate complete HTML content from all lines
        3. Update placeholder with new content
        
        Why Regenerate All Lines?
        - Streamlit doesn't support "append" to existing widget
        - Must replace entire content on each update
        - Streamlit efficiently diffs and minimizes DOM changes
        
        Parameters
        ----------
        message : str
            The message to display in Streamlit UI.
        
        HTML Styling Breakdown:
        - <div>: Container for styling control
        - white-space: pre-wrap: Preserve newlines and spaces, but allow wrapping
        - word-break: break-word: Break long words to prevent horizontal scroll
        - width: 100%: Full width of container
        - overflow-x: auto: Horizontal scroll if needed (fallback)
        - <code>: Monospace font (good for logs)
        - chr(10).join(): Join lines with actual newline character
        
        Why unsafe_allow_html=True?
        - Needed to inject custom HTML/CSS
        - Safe here: We control the content (no user input)
        - Allows custom styling not possible with safe markdown
        """
        # STEP 1: Add message to display buffer
        self.display_lines.append(message)
        
        # STEP 2: Update Streamlit UI if placeholder available
        if self.placeholder:
            # Generate HTML with all accumulated lines
            # chr(10) is newline character (\n)
            # Why chr(10)? Explicit, avoids escaping issues in f-strings
            all_lines = chr(10).join(self.display_lines)
            
            # Update placeholder with formatted HTML
            # Streamlit handles efficient DOM diffing
            self.placeholder.markdown(
                f"<div style='white-space: pre-wrap; word-break: break-word; width: 100%; overflow-x: auto;'><code>{all_lines}</code></div>",
                unsafe_allow_html=True
            )            
    
    def emit(self, message: str) -> None:
        """Emit a message with Streamlit UI updates.
        
        Overrides parent's emit() to ensure proper method resolution.
        Actually just calls parent's emit(), which calls our _streamlit_emit callback.
        
        Why Override If Just Calling Super?
        - Explicit interface: Makes it clear this class has emit() method
        - Future extensibility: Can add Streamlit-specific logic here
        - Documentation: Can add Streamlit-specific usage notes
        
        Parameters
        ----------
        message : str
            The message to emit and display.
        
        Execution Path:
        1. super().emit(message) called
        2. Parent appends to self.messages
        3. Parent calls self.emitter(message) → self._streamlit_emit(message)
        4. _streamlit_emit updates Streamlit UI
        """
        super().emit(message)
    
    def get_display_text(self) -> str:
        """Get the current display text for Streamlit.
        
        Returns the text currently visible in the Streamlit UI.
        Similar to get_log() but from display_lines instead of messages.
        
        Use Cases:
        - Saving displayed content to file
        - Copying UI output for sharing
        - Testing: Verify what's actually shown to user
        
        Returns
        -------
        str
            All display lines joined with newlines.
            Includes trailing newline if lines exist.
        
        Why Trailing Newline?
        - Consistent output format
        - Better for file writing (proper line termination)
        - Matches typical text editor behavior
        """
        return "\n".join(self.display_lines) + "\n" if self.display_lines else ""


def create_emitter(emitter_callback: Optional[Callable[[str], None]] = None) -> EmitterUtil:
    """Factory function to create an appropriate emitter utility.
    
    Provides a clean way to create emitters without directly instantiating classes.
    
    Benefits of Factory Function:
    - Simple API for common case
    - Can add creation logic (validation, configuration)
    - Easier to mock in tests
    - Consistent with create_streamlit_emitter
    
    Parameters
    ----------
    emitter_callback : Optional[Callable[[str], None]]
        Optional callback function for handling emit messages.
    
    Returns
    -------
    EmitterUtil
        Configured emitter utility instance.
    
    Usage:
    ```python
    # Console emitter
    emitter = create_emitter()
    
    # Custom callback emitter
    emitter = create_emitter(lambda msg: my_logger.info(msg))
    ```
    """
    return EmitterUtil(emitter_callback)


def create_streamlit_emitter(placeholder=None) -> StreamlitEmitterUtil:
    """Factory function to create a Streamlit-specific emitter utility.
    
    Parallel to create_emitter() but for Streamlit context.
    
    Parameters
    ----------
    placeholder : Optional[streamlit.empty]
        Streamlit placeholder for real-time text updates.
    
    Returns
    -------
    StreamlitEmitterUtil
        Configured Streamlit emitter utility instance.
    
    Usage:
    ```python
    import streamlit as st
    
    # Create placeholder
    status = st.empty()
    
    # Create emitter
    emitter = create_streamlit_emitter(status)
    
    # Use emitter
    emitter.emit("Processing...")
    ```
    """
    return StreamlitEmitterUtil(placeholder)