# Check Email, Summarize & Send Workflow

## What Is This?

Imagine you get back from vacation and have 50 unread emails. Instead of reading them all one by one, this workflow automatically:
1. **Grabs** all your emails from a specific time period
2. **Reads and analyzes** them using AI to find key points
3. **Emails you** a nice summary of what you missed

That's what `checkSumSendEmail.py` does - it's like having a personal assistant who reads your emails and sends you the highlights!

## The Problem It Solves

**Traditional Approach (Tedious):**
- Open email inbox
- Read email 1... email 2... email 3... (takes forever!)
- Try to remember important points
- Manually write notes or summary
- Email yourself reminders
- Very time-consuming! ⏰

**This Workflow (Automatic):**
- Script fetches emails for you (e.g., "last week's emails")
- AI reads and understands all emails at once
- Creates a smart summary with action items
- Emails the summary to you automatically
- You get the highlights in 2 minutes! ⚡

## Real-World Example

You ask: *"Summarize my emails from October 1-23"*

Here's what happens behind the scenes:

1. **Email Fetcher** logs into your Microsoft 365 account and grabs 12 emails from that date range
2. **Email Analyzer** (AI agent) reads all 12 emails and finds:
   - 5 emails about project updates
   - 3 meeting requests
   - 2 budget approvals needed
   - 2 vendor communications
3. **Email Sender** writes a professional summary email and sends it to you

**Result:** Instead of reading 12 emails manually (15+ minutes), you get a smart 2-minute summary in your inbox!

## How It Works (Simple Explanation)

Think of it like an assembly line with three workers, each doing one job:

```
┌─────────────────────────────────────────────────┐
│  YOU                                             │
│  "Summarize emails from Oct 1-23"               │
└────────────────┬────────────────────────────────┘
                 │
                 ▼
         ┌───────────────┐
         │ EMAIL FETCHER │  Step 1
         │ "I'll get     │
         │  the emails"  │
         └───────┬───────┘
                 │
         [Fetches 12 emails from Outlook]
                 │
                 ▼
         ┌───────────────┐
         │EMAIL ANALYZER │  Step 2
         │ "I'll read &  │
         │  analyze them"│
         └───────┬───────┘
                 │
    [AI reads & summarizes all emails]
                 │
                 ▼
         ┌───────────────┐
         │ EMAIL SENDER  │  Step 3
         │ "I'll send    │
         │  the summary" │
         └───────┬───────┘
                 │
         [Emails you the summary]
                 │
                 ▼
         📧 Summary in your inbox!
```

**Key Points:**
- Each step happens **one after another** (not at the same time)
- Each worker waits for the previous one to finish
- Like a relay race - you pass the baton to the next runner

## The Three Workers Explained

### 1. **Email Fetcher** (The Collector)
- **Job:** Log into your Microsoft 365 account and grab emails from a specific date range
- **Uses:** Microsoft Graph API (official way to access Outlook emails)
- **Like:** A secretary going through your inbox and collecting relevant emails
- **Example:** "Get all emails from October 1-23" → Returns 12 emails

**What it collects:**
- Email sender
- Subject line
- Date received
- Email body (preview)
- Any important metadata

### 2. **Email Analyzer** (The AI Reader)
- **Job:** Read all the emails and understand what's important
- **Uses:** Azure AI (GPT-4 level intelligence)
- **Like:** A smart assistant who reads everything and highlights key points
- **Example:** Reads 12 emails → Finds action items, deadlines, important topics

**What it analyzes:**
- Main topics across all emails
- Action items you need to do
- Important deadlines
- Priority messages
- Overall summary

### 3. **Email Sender** (The Reporter)
- **Job:** Write a professional summary email and send it to you
- **Uses:** Another AI agent for writing + Azure Logic App for sending
- **Like:** A communications specialist who formats and delivers the report
- **Example:** Creates summary → Sends to your email address

**What it sends:**
- Subject: "Email Analysis Summary - Oct 1-23, 2025"
- Body: Organized summary with action items, key findings, priorities
- Professional formatting

## Quick Start - Running the Demo

### Option 1: Simple Command Line (Easiest!)

Just run this command:

```bash
python workflow/checkSumSendEmail.py
```

This will:
- Use default date range from your `.env` file (if configured)
- Fetch emails from your Outlook
- Analyze them with AI
- Send summary to the default recipient email

**First time?** It will ask you to log in to Microsoft 365 through your browser (one-time setup).

### Option 2: Interactive Mode (Streamlit GUI)

Run the Streamlit web interface:

```bash
streamlit run main.py
```

Then:
1. Select **"[Workflow] Check, Summarize & Send Email"** from the dropdown
2. Pick a date range using the calendar interface
3. (Optional) Add a specific question like "What action items do I have?"
4. Enter your email address
5. Click run and watch the workflow execute!
6. Check your inbox for the summary email

## Before You Run - Setup Required

### 1. Install Python Packages

```bash
pip install -r requirements.txt
```

This installs:
- `agent-framework` - The AI agent framework
- `azure-identity` - For Microsoft 365 authentication
- `msal` - Microsoft authentication library
- `microsoft-graph-client` - For accessing Outlook emails
- `opentelemetry-sdk` - For observability/tracing
- `streamlit` - For the web GUI

### 2. Set Up Azure App Registration

You need to register an app in Azure to access Microsoft 365 emails:

**Steps:**
1. Go to [Azure Portal](https://portal.azure.com) → Azure Active Directory
2. Click "App registrations" → "New registration"
3. Name it (e.g., "Email Summary App")
4. Select "Accounts in this organizational directory only"
5. **Important:** Set redirect URI to: `http://localhost` (Public client)
6. After creation, note down:
   - **Application (client) ID**
   - **Directory (tenant) ID**

**API Permissions:**
1. Click "API permissions" → "Add a permission"
2. Select "Microsoft Graph" → "Delegated permissions"
3. Add these permissions:
   - `Mail.Read` - To read your emails
   - `User.Read` - Basic user info
4. Click "Grant admin consent" (if you're an admin)

### 3. Set Up Environment Variables

Create a `.env` file or set these environment variables:

```bash
# Microsoft 365 Authentication
AZURE_CLIENT_ID=<your-app-client-id>
AZURE_TENANT_ID=<your-azure-ad-tenant-id>

# Azure AI (for analysis)
PROJECT_ENDPOINT=<your-azure-ai-project-endpoint>
MODEL_DEPLOYMENT_NAME=<your-model-deployment-name>

# Email Delivery (Azure Logic App)
LOGIC_APP_EMAIL_URL=<your-azure-logic-app-endpoint>

# Date Range (Optional - defaults)
EMAIL_STARTTIME=2025-10-01T00:00:00
EMAIL_ENDTIME=2025-10-23T23:59:59
UTC_OFFSET=8  # Your timezone offset from UTC

# Recipient
DEFAULT_EMAIL_RECIPIENT=your-email@example.com
```

### 4. First-Time Authentication

The first time you run the workflow:

1. You'll see: "To sign in, use a web browser to open https://microsoft.com/devicelogin and enter code XXXXXXX"
2. Open that URL in your browser
3. Enter the code shown
4. Log in with your Microsoft 365 account
5. Approve the permissions
6. Done! The workflow will cache your token in `.token_cache.bin`

**Next time:** You won't need to log in again (token is cached)!

## Understanding the Code (For Developers)

### The Main Function: `run_check_sum_send_email()`

This is the heart of the workflow. Here's what it does in plain English:

```python
def run_check_sum_send_email(
    start_datetime: str,         # "2025-10-01T00:00:00Z"
    end_datetime: str,           # "2025-10-23T23:59:59Z"
    max_items: int = 25,         # How many emails to fetch
    user_question: str = "",     # Optional: "What are my action items?"
    recipient_email: str = None, # Where to send the summary
    emitter=None,                # For UI progress updates
    return_mode='both'           # Return output + logs
):
```

**What happens inside:**

1. **Setup Phase:**
   - Creates three executors (Email Fetcher, Email Analyzer, Email Sender)
   - Sets up OpenTelemetry for tracking
   - Prepares the email request with date range

2. **Build the Workflow:**
   ```python
   workflow = (
       Executor(name="email_workflow")
       .add_executor(email_fetcher)    # Step 1: Get emails
       .add_executor(email_analyzer)   # Step 2: Analyze with AI
       .add_executor(email_sender)     # Step 3: Send summary
       .build()
   )
   ```

3. **Run the Workflow (Sequential):**
   - Email Fetcher goes first → gets emails from Outlook
   - Email Analyzer goes second → analyzes those emails
   - Email Sender goes third → sends the summary
   - Each waits for the previous to finish!

4. **Return Results:**
   - Email summary (what was sent)
   - Execution logs
   - OpenTelemetry traces (saved to `opentele_local/` folder)

### Key Concepts to Understand

#### 1. **What is Sequential Processing?**

Unlike parallel workflows (like `blastwebsearch.py`), this workflow runs steps **one after another**:

**Sequential (This Workflow):**
```
Fetch emails (2 sec) → Analyze (5 sec) → Send (2 sec) = 9 seconds total
```

Each step must wait for the previous step to finish because:
- Analyzer needs the emails from Fetcher
- Sender needs the analysis from Analyzer

**Why Sequential?**
- Data dependencies (each step needs previous step's output)
- Order matters (can't analyze emails before fetching them!)
- Simpler to understand and debug

#### 2. **What are the Data Structures?**

Think of these as forms that get passed between workers:

**EmailRequest** (Initial form):
```python
@dataclass
class EmailRequest:
    start_datetime: str    # "2025-10-01T00:00:00Z"
    end_datetime: str      # "2025-10-23T23:59:59Z"
    max_items: int         # 25
    user_question: str     # "What are my action items?"
```

**EmailData** (Fetcher → Analyzer):
```python
@dataclass
class EmailData:
    emails: list          # List of 12 email objects
    count: int            # 12
    user_question: str    # "What are my action items?"
```

**EmailAnalysis** (Analyzer → Sender):
```python
@dataclass
class EmailAnalysis:
    analysis_text: str    # The AI's summary
    email_count: int      # 12
    user_question: str    # Original question
```

**EmailSummary** (Final output):
```python
@dataclass
class EmailSummary:
    subject: str          # "Email Analysis Summary - Oct 1-23"
    body: str             # The formatted summary
    analysis_text: str    # Full AI analysis
```

#### 3. **How Does Microsoft 365 Authentication Work?**

The workflow uses **Device Code Flow** (OAuth 2.0):

1. **First run:**
   - Workflow generates a code (e.g., "ABC123")
   - You open `https://microsoft.com/devicelogin` in browser
   - Enter the code
   - Log in with Microsoft 365 account
   - Approve permissions

2. **Token is saved:**
   - Stored in `.token_cache.bin` file
   - Valid for hours (auto-refreshed when expired)

3. **Subsequent runs:**
   - Reads token from cache
   - No need to log in again!

4. **Security:**
   - Token is encrypted
   - Only works for the specific app (your Azure App Registration)
   - You can revoke access anytime in Azure AD

#### 4. **How Does the AI Analyzer Work?**

The Email Analyzer uses an Azure AI agent (GPT-4 level):

```python
# The analyzer gets all emails and processes them
agent_prompt = f"""
You are analyzing {email_count} emails.
User question: {user_question}

Emails:
{email_1_content}
{email_2_content}
...

Please provide:
1. Key topics
2. Action items
3. Important deadlines
4. Priority messages
"""

# AI responds with intelligent summary
```

The AI understands:
- Context across multiple emails
- What's urgent vs. informational
- Action items and deadlines
- Relationships between emails

#### 5. **What is OpenTelemetry Tracking?**

OpenTelemetry tracks **every step** of the workflow:

- How long did email fetching take? (2.3 seconds)
- How many emails were retrieved? (12)
- How long did AI analysis take? (5.1 seconds)
- Did email sending succeed? (Yes)
- Total workflow time? (9.4 seconds)

This data is saved to JSON files in `opentele_local/` for debugging and optimization.

## What You'll See When You Run It

### Sample Output (Console)

When you run `python workflow/checkSumSendEmail.py`, you'll see:

```
================================================================================
EMAIL CHECK -> SUMMARIZE -> SEND WORKFLOW
================================================================================

[WORKFLOW] Starting execution...

[EmailFetcher] Starting email retrieval...
[EmailFetcher] Date range: 2025-10-01 to 2025-10-23
[EmailFetcher] Max items: 25
[EmailFetcher] ✓ Retrieved 12 emails

[EmailAnalyzer] Starting analysis of 12 emails...
[EmailAnalyzer] Question: "What are my action items?"
[EmailAnalyzer] ✓ Analysis complete (1,247 characters)

[EmailSender] Composing email summary...
[EmailSender] Email subject: "Email Analysis Summary - Oct 1-23, 2025"
[EmailSender] Sending to: your-email@example.com...
[EmailSender] ✓ Email sent successfully!

======================================================================
WORKFLOW COMPLETE
======================================================================

[WORKFLOW] ✓ Completed in 9,234 ms
📁 Traces saved to: opentele_local/checksumsend_20251023-142256.json
================================================================================
```

### Understanding the Output

The output shows:
- **[EmailFetcher]**: How many emails were retrieved
- **[EmailAnalyzer]**: AI processing status
- **[EmailSender]**: Email delivery confirmation
- **Total time**: How long everything took (usually 8-15 seconds)
- **Trace file**: Where execution details were saved

### What the Summary Email Looks Like

Here's an example of what you'll receive in your inbox:

```
From: Email Summary Bot
To: your-email@example.com
Subject: Email Analysis Summary - Oct 1-23, 2025

================================================================================
EMAIL SUMMARY REPORT
Period: October 1-23, 2025 | Total Emails Analyzed: 12
================================================================================

KEY FINDINGS:
• 5 emails related to project updates and milestone tracking
• 3 emails containing meeting requests and scheduling
• 2 emails with budget approval requests
• 2 emails regarding vendor communications

ACTION ITEMS:
1. Review and approve Q4 budget proposal (due Oct 25)
2. Schedule project review meeting with stakeholders  
3. Respond to vendor RFP by Oct 30
4. Update project timeline based on recent delays

PRIORITY MESSAGES:
• URGENT: Approval needed for cloud infrastructure expansion
• IMPORTANT: Client meeting rescheduled to Oct 26 at 2 PM
• DEADLINE: Quarterly report submission - Oct 27

DETAILED BREAKDOWN:

📧 Project Updates (5 emails)
- Team progress report shows 85% completion
- New milestone: Sprint 12 completed ahead of schedule
- Risk identified: Resource constraint in testing phase

📧 Meetings & Scheduling (3 emails)
- Weekly standup moved to Thursdays
- All-hands meeting invitation for Oct 30
- 1:1 with manager scheduled for Oct 24

📧 Budget & Finance (2 emails)
- Q4 budget increase request for $50K
- Invoice approval needed for vendor payment

📧 Vendor Communications (2 emails)
- RFP response due Oct 30
- Contract renewal discussion scheduled

================================================================================
This summary was automatically generated by Azure AI.
Report generated: October 23, 2025 at 2:42 PM
================================================================================
```

### Where Files Are Saved

After running, you'll find:

```
opentele_local/
  └── checksumsend_20251023-142256.json  # OpenTelemetry traces

.token_cache.bin  # Microsoft 365 authentication token (hidden file)
```

**OpenTelemetry Trace File** contains:
- Each executor's execution time
- Number of emails processed
- Success/failure status for each step
- Full execution timeline
- Message passing between executors

You can view these traces in the Streamlit UI!

## Using in Your Own Application

Want to integrate this into your app? Here are practical examples:

### Basic Email Summary

```python
import asyncio
from workflow.checkSumSendEmail import run_check_sum_send_email

async def summarize_last_week():
    """Get a summary of last week's emails."""
    
    result = await run_check_sum_send_email(
        start_datetime="2025-10-16T00:00:00Z",  # Last Monday
        end_datetime="2025-10-20T23:59:59Z",     # Last Friday
        max_items=50,
        user_question="Summarize my work emails from last week",
        recipient_email="me@example.com"
    )
    
    print("Summary email sent!")
    return result

# Use it
asyncio.run(summarize_last_week())
```

### Daily Digest (Automated)

```python
import asyncio
from datetime import datetime, timedelta
from workflow.checkSumSendEmail import run_check_sum_send_email

async def daily_digest():
    """Send daily email digest at end of day."""
    
    # Get today's date
    today = datetime.now()
    start = today.replace(hour=0, minute=0, second=0)
    end = today.replace(hour=23, minute=59, second=59)
    
    result = await run_check_sum_send_email(
        start_datetime=start.strftime("%Y-%m-%dT%H:%M:%SZ"),
        end_datetime=end.strftime("%Y-%m-%dT%H:%M:%SZ"),
        max_items=100,
        user_question="What were the important emails today?",
        recipient_email="me@example.com"
    )
    
    return result

# Schedule this to run daily at 6 PM
asyncio.run(daily_digest())
```

### Focused Analysis with Custom Questions

```python
import asyncio
from workflow.checkSumSendEmail import run_check_sum_send_email

async def find_action_items():
    """Extract action items and deadlines from emails."""
    
    result = await run_check_sum_send_email(
        start_datetime="2025-10-01T00:00:00Z",
        end_datetime="2025-10-23T23:59:59Z",
        max_items=50,
        user_question="List all action items and deadlines mentioned in these emails. Prioritize by urgency.",
        recipient_email="tasks@example.com"
    )
    
    return result

asyncio.run(find_action_items())
```

### Manager's Weekly Report

```python
import asyncio
from workflow.checkSumSendEmail import run_check_sum_send_email

async def weekly_team_report():
    """Generate weekly report for manager."""
    
    result = await run_check_sum_send_email(
        start_datetime="2025-10-16T00:00:00Z",
        end_datetime="2025-10-20T23:59:59Z",
        max_items=200,
        user_question="""
        Analyze emails from my team this week and provide:
        1. Progress on key projects
        2. Blockers or issues raised
        3. Important decisions made
        4. Items needing my attention
        """,
        recipient_email="manager@example.com"
    )
    
    return result

asyncio.run(weekly_team_report())
```

## Common Questions (FAQ)

### Q: How does it access my emails securely?

**A:** It uses Microsoft's official OAuth 2.0 authentication:
- You log in through Microsoft's official login page
- You explicitly approve what the app can access (Mail.Read permission)
- Token is encrypted and stored locally
- You can revoke access anytime in your Azure AD settings
- No passwords are stored anywhere

### Q: What if I have hundreds of emails?

**A:** Use the `max_items` parameter to limit:
```python
max_items=100  # Only fetch most recent 100 emails
```

The AI can analyze 100+ emails, but it may take longer (15-30 seconds). For huge volumes, consider running separate queries for different date ranges.

### Q: Can I use this with Gmail instead of Outlook?

**A:** Currently it's designed for Microsoft 365 / Outlook. To use with Gmail:
1. You'd need to replace the Email Fetcher with Gmail API integration
2. Use Google OAuth instead of Microsoft OAuth
3. Rest of the workflow (Analyzer, Sender) works the same

### Q: What kind of analysis can the AI do?

**A:** The AI is very versatile! Examples:
- **Summarize**: "Summarize these emails"
- **Extract**: "What are all the deadlines mentioned?"
- **Categorize**: "Group emails by topic"
- **Prioritize**: "Which emails need urgent attention?"
- **Sentiment**: "Are there any concerning or negative emails?"
- **Action Items**: "List all tasks I need to do"

Just put your question in `user_question`!

### Q: How long does it take to run?

**A:** Typical times:
- **Fetching emails**: 1-3 seconds (depends on number)
- **AI Analysis**: 5-10 seconds (depends on email content length)
- **Sending email**: 1-2 seconds
- **Total**: Usually 8-15 seconds for 10-25 emails

### Q: What if authentication fails or token expires?

**A:** Two solutions:
1. **Delete token cache**: `rm .token_cache.bin` then run again (will ask you to re-authenticate)
2. **Check Azure App**: Make sure your app registration has correct permissions

### Q: Can I save the summary to a file instead of email?

**A:** Yes! The workflow returns the summary:

```python
result = await run_check_sum_send_email(...)

# Access the summary text
summary_text = result['output_text']

# Save to file
with open('email_summary.txt', 'w') as f:
    f.write(summary_text)
```

### Q: How much does this cost to run?

**A:** Costs breakdown:
- **Microsoft Graph API**: Free (part of Microsoft 365 subscription)
- **Azure AI (GPT-4)**: ~$0.01-0.05 per run (depends on email volume)
- **Azure Logic App**: ~$0.000025 per email sent
- **Total**: Pennies per run!

### Q: Can I schedule this to run automatically every day?

**A:** Yes! Options:
1. **Windows Task Scheduler**: Schedule the Python script
2. **Cron (Linux/Mac)**: `0 18 * * * python /path/to/checkSumSendEmail.py`
3. **Azure Function**: Deploy as serverless function with timer trigger
4. **GitHub Actions**: Run on schedule in the cloud

### Q: What happens if no emails match the date range?

**A:** The workflow handles this gracefully:
- Email Fetcher returns 0 emails
- AI Analyzer creates a message: "No emails found in this period"
- You still get a summary email saying "No emails to analyze"

### Q: Can I analyze specific email folders (not just Inbox)?

**A:** Currently it fetches from the main mailbox. To filter by folder, you'd need to modify the Email Fetcher executor to specify folder filters in the Microsoft Graph API query.

## Troubleshooting

### Problem: "AADSTS50059: No tenant-identifying information found"

**What it means:** The Azure authentication doesn't know which Microsoft organization you belong to.

**Fix:**
```bash
# Add this to your .env file
AZURE_TENANT_ID=your-tenant-id-here
```

How to find your Tenant ID:
1. Go to Azure Portal → Azure Active Directory
2. Copy the "Tenant ID" value
3. Paste it into your `.env` file

---

### Problem: "Retrieved 0 emails" but I know I have emails

**Possible causes:**

1. **Wrong date range** - Check your dates:
   ```python
   # Make sure dates are correct
   start_datetime="2025-10-16T00:00:00Z"  # Is this the right date?
   end_datetime="2025-10-23T23:59:59Z"
   ```

2. **UTC vs local time** - Your local time might be different from UTC:
   ```bash
   # If you're in PST (UTC-8), add to .env:
   UTC_OFFSET=8
   ```

3. **No permission** - The app needs Mail.Read permission:
   - Go to your Azure App Registration
   - API permissions → Add "Mail.Read"
   - Grant admin consent

---

### Problem: "Token expired and refresh failed"

**What it means:** Your login token is old and can't be refreshed.

**Fix:**
```bash
# Delete the token cache
rm .token_cache.bin

# Run again (will ask you to login)
python -m workflow.checkSumSendEmail
```

---

### Problem: Email delivery fails / Logic App error

**Check these:**

1. **Is LOGIC_APP_EMAIL_URL set?**
   ```bash
   # In .env file
   LOGIC_APP_EMAIL_URL=https://your-logic-app-url.com
   ```

2. **Is Logic App deployed?** - Go to Azure Portal and check if Logic App is running

3. **Test Logic App manually:**
   ```bash
   curl -X POST "https://your-logic-app-url.com" \
        -H "Content-Type: application/json" \
        -d '{"to":"test@example.com","subject":"Test","body":"Test email"}'
   ```

---

### Problem: "ImportError: No module named 'agent_framework'"

**What it means:** Missing Python package.

**Fix:**
```bash
# Install required packages
pip install -r requirements.txt
```

---

### Problem: AI analysis is generic / not helpful

**Improvement tips:**

1. **Be more specific with your question:**
   ```python
   # Bad (too generic)
   user_question="Summarize emails"
   
   # Good (specific)
   user_question="List all project deadlines and who requested them. Highlight any overdue items."
   ```

2. **Ask for structure:**
   ```python
   user_question="""
   Analyze these emails and provide:
   1. Urgent items needing response today
   2. Tasks I can delegate
   3. FYI emails I can archive
   """
   ```

---

### Problem: Execution is slow (takes 30+ seconds)

**Optimization tips:**

1. **Reduce email count:**
   ```python
   max_items=25  # Instead of 100
   ```

2. **Use shorter date ranges:**
   ```python
   # Instead of entire month, try last week
   start_datetime="2025-10-16T00:00:00Z"
   end_datetime="2025-10-20T23:59:59Z"
   ```

3. **Check your internet connection** - Slow network = slow API calls

---

### Problem: OpenTelemetry traces not showing in Streamlit

**Check:**
1. **Are traces being saved?** - Look in `opentele_local/` folder
2. **Run from Streamlit UI** - Traces display automatically there
3. **Check for errors** - Look for errors in console output

---

### Problem: Can't install packages / Permission denied

**Windows Fix:**
```powershell
# Run as administrator or use --user flag
pip install --user -r requirements.txt
```

**Linux/Mac Fix:**
```bash
# Use virtual environment (recommended)
python -m venv venv
source venv/bin/activate  # Mac/Linux
# or
venv\Scripts\activate  # Windows
pip install -r requirements.txt
```

---

### Problem: "No such file or directory: '.env'"

**What it means:** Missing configuration file.

**Fix:**
```bash
# Create .env file from template
cp .env.example .env  # If you have example file

# OR create manually
cat > .env << EOF
AZURE_TENANT_ID=your-tenant-id
AZURE_OPENAI_DEPLOYMENT_NAME=gpt-4o
EMAIL_STARTTIME=2025-10-16T09:00:00
EMAIL_ENDTIME=2025-10-23T18:00:00
UTC_OFFSET=8
DEFAULT_EMAIL_RECIPIENT=your-email@example.com
LOGIC_APP_EMAIL_URL=https://your-logic-app-url.com
EOF
```

## Real-World Use Cases

### 1. Executive Assistant - Daily Briefing
**Scenario:** CEO needs a morning briefing of overnight emails.

```python
# Run this at 8 AM daily
async def morning_briefing():
    yesterday = datetime.now() - timedelta(days=1)
    start = yesterday.replace(hour=17, minute=0)  # 5 PM yesterday
    end = datetime.now()
    
    await run_check_sum_send_email(
        start_datetime=start.isoformat() + "Z",
        end_datetime=end.isoformat() + "Z",
        max_items=50,
        user_question="""
        Categorize emails into:
        1. URGENT: Needs immediate attention
        2. IMPORTANT: Should handle today
        3. FYI: Can read later
        Include sender names and key points for urgent items.
        """,
        recipient_email="ceo@company.com"
    )
```

### 2. Customer Support - Ticket Triage
**Scenario:** Support team needs to prioritize customer emails.

```python
async def support_triage():
    await run_check_sum_send_email(
        start_datetime="2025-10-23T00:00:00Z",
        end_datetime="2025-10-23T23:59:59Z",
        max_items=200,
        user_question="""
        Analyze customer support emails and identify:
        1. Critical issues (service down, data loss)
        2. Billing/payment issues
        3. Feature requests
        4. General questions
        Prioritize by urgency and impact.
        """,
        recipient_email="support-team@company.com"
    )
```

### 3. Sales Team - Lead Follow-up
**Scenario:** Sales manager needs to track deal progress from email.

```python
async def weekly_sales_digest():
    await run_check_sum_send_email(
        start_datetime="2025-10-16T00:00:00Z",
        end_datetime="2025-10-20T23:59:59Z",
        max_items=100,
        user_question="""
        Extract from sales emails:
        1. New leads and their contact info
        2. Deals moving forward (mention company name and deal size)
        3. Deals at risk (concerns or objections raised)
        4. Closed deals this week
        """,
        recipient_email="sales-manager@company.com"
    )
```

### 4. HR - Employee Issues
**Scenario:** HR manager needs to track employee concerns.

```python
async def hr_concerns():
    await run_check_sum_send_email(
        start_datetime="2025-10-01T00:00:00Z",
        end_datetime="2025-10-23T23:59:59Z",
        max_items=50,
        user_question="""
        Identify emails containing:
        1. Employee complaints or concerns
        2. Leave requests
        3. Performance issues
        4. Benefits questions
        Keep this confidential and highlight items needing immediate action.
        """,
        recipient_email="hr-manager@company.com"
    )
```

### 5. Project Manager - Status Updates
**Scenario:** PM needs to compile project updates from team emails.

```python
async def project_status():
    await run_check_sum_send_email(
        start_datetime="2025-10-16T00:00:00Z",
        end_datetime="2025-10-20T23:59:59Z",
        max_items=150,
        user_question="""
        Compile project status from team emails:
        1. Completed tasks and milestones
        2. In-progress work and % complete
        3. Blockers or risks
        4. Upcoming deadlines in next 2 weeks
        Organize by project name.
        """,
        recipient_email="pm@company.com"
    )
```

## Next Steps

### For Beginners
1. ✅ Get it working with the Quick Start guide above
2. 📖 Read through "Understanding the Code" section
3. 🧪 Try the examples in "Using in Your Own Application"
4. 🎯 Customize the AI question for your use case
5. ⏰ Set up daily automation (optional)

### For Developers
1. 📝 Study the workflow code in `workflow/checkSumSendEmail.py`
2. 🔍 Examine executor implementations in `agent/checkemail.py` and `agent/emailwriter.py`
3. 🛠️ Modify the workflow to add custom executors (e.g., save to database)
4. 📊 Build custom UI using the workflow function
5. 🚀 Deploy as Azure Function for serverless execution

### For Automation Engineers
1. ⏱️ Set up scheduled execution (cron, Task Scheduler, Azure Function timer)
2. 📧 Configure multiple recipients for team distribution
3. 🗃️ Add database storage for historical analysis
4. 📈 Build reporting dashboards using trace data
5. 🔔 Add alerting for urgent emails (e.g., Slack notifications)

## Quick Reference

### Command Line Usage
```bash
# Basic usage (uses .env configuration)
python -m workflow.checkSumSendEmail

# Run from workflow directory
python workflow/checkSumSendEmail.py
```

### Python Function Call
```python
from workflow.checkSumSendEmail import run_check_sum_send_email

result = await run_check_sum_send_email(
    start_datetime="2025-10-16T00:00:00Z",
    end_datetime="2025-10-23T23:59:59Z",
    max_items=50,
    user_question="Your analysis question here",
    recipient_email="recipient@example.com"
)
```

### Required Environment Variables
```bash
AZURE_TENANT_ID=your-tenant-id                    # Azure AD tenant
AZURE_OPENAI_DEPLOYMENT_NAME=gpt-4o              # AI model
EMAIL_STARTTIME=2025-10-16T09:00:00              # Start time (local)
EMAIL_ENDTIME=2025-10-23T18:00:00                # End time (local)
UTC_OFFSET=8                                      # Timezone offset
DEFAULT_EMAIL_RECIPIENT=your-email@example.com    # Recipient
LOGIC_APP_EMAIL_URL=https://your-logic-app.com   # Email sender
```

### Quick Debugging
```bash
# Delete token cache and re-authenticate
rm .token_cache.bin

# Check trace files
ls opentele_local/

# Check saved emails
ls emails_local/

# View recent trace
cat opentele_local/checksumsend_*.json | tail -100
```

### Common AI Questions
```python
# Summary
"Summarize these emails in 5 bullet points"

# Action items
"List all action items and their deadlines"

# Prioritization
"Which emails need urgent response? Why?"

# Categorization
"Group emails by: Work, Personal, Marketing, Other"

# Sentiment
"Are there any negative or concerning emails?"

# Extraction
"Extract all meeting times and attendees"
```

### File Locations
- **Workflow code**: `workflow/checkSumSendEmail.py`
- **Email fetcher**: `agent/checkemail.py`
- **Email writer**: `agent/emailwriter.py`
- **Email sender**: `helper/logicappemail.py`
- **Saved emails**: `emails_local/`
- **Traces**: `opentele_local/`
- **Config**: `.env`

---

## Summary

This workflow gives you a personal AI assistant that:
- ✅ Fetches your emails from Microsoft 365
- ✅ Analyzes them with GPT-4 AI
- ✅ Sends you a customized summary email
- ✅ Tracks everything with OpenTelemetry

Perfect for:
- 📊 Daily email digests
- 🎯 Extracting action items
- 📈 Project status tracking
- 🚨 Identifying urgent emails
- 🗂️ Organizing and categorizing

**Ready to try it?** Start with the Quick Start section above! 🚀
