"""Yahoo Search agent tool sample.

This module can be imported as `agent.yahoosearch` or executed directly:

	python -m agent.yahoosearch "your question"
or (from repo root):
	python .\agent\yahoosearch.py "your question"

Agent Behavior:
	The agent uses Yahoo Search helper to retrieve web search results,
	injects search results into the agent's system context as knowledge,
	and generates answers synthesizing information from the Yahoo search results.
"""

import os
import sys
import json
from typing import Callable
from dotenv import load_dotenv
from azure.ai.projects import AIProjectClient
from azure.identity import AzureCliCredential
from azure.ai.agents.models import ListSortOrder, MessageRole


if __name__ == "__main__":
	repo_root = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
	if repo_root not in sys.path:
		sys.path.insert(0, repo_root)

from helper.agent_config_loader import load_agent_config, AgentConfigError
from helper.emitter import create_emitter
from helper.yahoosearch import perform_web_search as yahoo_perform_web_search

load_dotenv()

project_endpoint = os.getenv("PROJECT_ENDPOINT")
model_deployment_name = os.getenv("MODEL_DEPLOYMENT_NAME")

DEFAULT_QUESTION = "tell me something about agunesmusic"


def run_yahoo_search(
    question: str | None = None,
    emitter: Callable[[str], None] | None = None,
    return_mode: str = "answer",
    save_json: str | os.PathLike | None = None,
    tracing_mode: str = "both",
):
    """Run a Yahoo-grounded agent search with structured logging/outputs.

    The agent uses Yahoo Search results injected as context to synthesize answers
    from web information.

    Execution Flow:
    1. Initialize emitter and validate question
    2. Setup OpenTelemetry tracing infrastructure
    3. Validate required environment configuration
    4. Perform Yahoo Search via helper function
    5. Initialize Azure AI Project Client
    6. Load agent configuration from YAML
    7. Create agent with Yahoo search results as injected context
    8. Execute agent conversation (create thread, post message, run agent)
    9. Process run steps and extract details
    10. Gather agent responses
    11. Cleanup resources and collect traces
    12. Format and return results based on return_mode

    Parameters:
        question: User query. Defaults to DEFAULT_QUESTION if blank.
        emitter: Optional callback(line: str) for streaming logs.
        return_mode: Controls return value:
            'answer' -> joined agent answers (fallback to log if none)
            'log'    -> full log text only
            'both'   -> dict { 'answers': [...], 'output_text': str, 'log': str, 'success': bool, 'traces': list, 'trace_summary': dict }
        save_json: Optional path to persist artefacts as JSON.
        tracing_mode: Controls OpenTelemetry tracing destination:
            'both' (default)  -> Enable both Azure Monitor and Console tracing simultaneously
            'auto'           -> Azure Monitor if APPLICATIONINSIGHTS_CONNECTION_STRING is set, else none
            'azure_monitor'  -> Send traces to Azure AI Foundry Portal
            'console'        -> Print traces to console (with gen_ai agent traces)
            'none'           -> Disable tracing

    Returns:
        str | dict depending on return_mode. When return_mode='both', includes 'success' boolean.
    """
    # STEP 1: Initialize output collection and success tracking
    # Why list for output_texts? Agent may produce multiple responses
    # success flag tracks whether search and agent execution completed successfully
    output_texts: list[str] = []
    success = False

    # Create emitter wrapper that handles None emitter gracefully
    # Why wrap? Provides uniform emit() interface regardless of caller
    emit_util = create_emitter(emitter)
    emit = emit_util.emit

    # STEP 2: Validate and normalize question input
    # Why check both None and empty string? Defensive programming
    if question is None or not question.strip():
        question = DEFAULT_QUESTION

    # STEP 3: Setup OpenTelemetry tracing infrastructure
    # Why UnifiedTraceManager? Centralizes tracing setup across agent/workflow modes
    from helper.unified_trace_manager import UnifiedTraceManager
    
    trace_mgr = UnifiedTraceManager(
        tracing_mode=tracing_mode,
        emitter=emit,
        trace_type="agent"
    )
    tracer, span_collector = trace_mgr.setup()

    # STEP 4: Validate required environment configuration
    # Why check early? Fail fast principle - no point proceeding without config
    if not project_endpoint or not model_deployment_name:
        emit("[ERROR] PROJECT_ENDPOINT and MODEL_DEPLOYMENT_NAME must be set")
        log_joined = emit_util.get_log()
        # Graceful degradation: Return error log with success=False
        if return_mode == "both":
            return {
                "answers": [],
                "output_text": log_joined,
                "log": log_joined,
                "success": False,
            }
        return log_joined
    
    # STEP 5: Start parent trace span (if tracing enabled)
    # Why parent span? Creates root of trace tree for this execution
    trace_mgr.start_parent_span(
        span_name=f"run_yahoo_search: {question[:50]}",  # Truncate long questions
        attributes={
            "question": question,
            "tracing_mode": tracing_mode
        }
    )
    
    # STEP 6: Perform Yahoo Search to get web results
    # Why separate step? Yahoo search happens before agent creation
    # Results will be injected as context into agent's instructions
    emit("Performing Yahoo Search")
    
    try:
        # Call Yahoo search helper with error handling
        # Why try/except? Search might fail but agent should still attempt to answer
        yahoo_result = yahoo_perform_web_search(
            query=question,
            num_results=5,  # Get top 5 results for context richness
            emitter=emitter,
            return_mode="both"
        )
        
        # STEP 7: Process Yahoo search results
        # Why check success? Search might fail due to API limits, network issues
        if not yahoo_result.get("success", False):
            emit("[WARN] Yahoo search did not return successful results")
            yahoo_search_context = "No Yahoo search results available."
        else:
            yahoo_search_context = yahoo_result.get("output_text", "")
            emit("[INFO] Yahoo search completed successfully")
    except Exception as yahoo_exc:
        # Graceful degradation: Continue with error message as context
        # Why not abort? Agent can still provide value with limited context
        emit(f"[ERROR] Yahoo search failed: {yahoo_exc}")
        yahoo_search_context = f"Yahoo search error: {yahoo_exc}"
    
    emit("")
    emit("Creating Agent with Yahoo Search Context")
    
    # STEP 8: Initialize Azure AI Project Client
    # Why context manager? Ensures proper cleanup even on errors
    emit("Azure AI Project Client initializing...")
    try:
        with AIProjectClient(endpoint=project_endpoint, credential=AzureCliCredential()) as project_client:
            agents_client = project_client.agents
            
            # STEP 9: Load agent configuration from YAML
            # Why YAML config? Separates prompt engineering from code
            try:
                emit("Loading agent configuration...")
                pyfile_name = os.path.splitext(os.path.basename(__file__))[0]
                agent_name, agent_instructions, agent_description = load_agent_config(pyfile_name)
                # Agent will: (1) Receive Yahoo Search results as injected context
                #             (2) Synthesize information from multiple search results
                #             (3) Generate comprehensive answers based on web knowledge
                emit(f"Loaded agent configuration: {agent_name}")
            except AgentConfigError as cfg_err:
                # Configuration errors are fatal - can't create agent without config
                emit(f"[ERROR] {cfg_err}")
                log_joined = emit_util.get_log()
                if return_mode == "both":
                    return {
                        "answers": [],
                        "output_text": log_joined,
                        "log": log_joined,
                        "success": False,
                    }
                return log_joined

            # STEP 10: Create agent with Yahoo search context injected
            # Why inject in instructions? Provides agent with search results as background knowledge
            # Agent doesn't need tools - knowledge is already in context
            # Inject Yahoo search results as context in agent instructions
            agent = agents_client.create_agent(
                model=model_deployment_name,
                name=agent_name,
                # Critical: Append Yahoo search results to agent instructions
                # This gives agent the web knowledge needed to answer
                instructions=f"{agent_instructions}\n\nYahoo Search Results:\n{yahoo_search_context}",
                description=agent_description,
            )
            emit(f"Created agent ID: {agent.id}")

            # STEP 11: Create conversation thread
            # Why separate thread? Isolates this conversation from others
            thread = agents_client.threads.create()
            emit(f"Created thread ID: {thread.id}")
            
            # STEP 12: Post user message to thread
            user_message = agents_client.messages.create(
                thread_id=thread.id,
                role="user",
                content=question,
            )
            emit(f"Created user message ID: {user_message['id']}")

            # STEP 13: Execute agent run
            # Agent will synthesize answer from Yahoo search context
            run = agents_client.runs.create_and_process(thread_id=thread.id, agent_id=agent.id)
            emit(f"Run finished with status: {run.status}")
            
            # STEP 14: Check run status and update success flag
            if run.status == "failed":
                emit(f"Run failed: {run.last_error}")
            else:
                success = True

            # STEP 15: Extract and log run steps (diagnostic information)
            # Why try/except? Steps are diagnostic - failure shouldn't break main flow
            try:
                run_steps = agents_client.run_steps.list(thread_id=thread.id, run_id=run.id)
                for step in run_steps:
                    emit(f"[STEP] {step['id']} status={step['status']}")
                    # STEP 16: Log any tool calls (shouldn't have any for Yahoo search)
                    # Yahoo search uses context injection, not tool calling
                    if step.type == "tool_calls":
                        for tool_call in getattr(step.step_details, 'tool_calls', []):
                            try:
                                emit("[TOOL CALL]\n" + json.dumps(tool_call.as_dict(), indent=2))
                            except Exception:
                                emit(f"[TOOL CALL RAW] {tool_call}")
                    emit("")
            except Exception as step_exc:
                emit(f"[WARN] Failed to list run steps: {step_exc}")

            # STEP 17: Gather agent responses
            # Why only if success? Don't process messages if run failed
            if success:
                messages = agents_client.messages.list(thread_id=thread.id, order=ListSortOrder.ASCENDING)
                for message in messages:
                    if message.role == MessageRole.AGENT:
                        # No citation expansion needed - Yahoo search doesn't provide citations
                        # Just collect raw answer text
                        for text_part in message.text_messages:
                            answer_text = text_part.text.value
                            output_texts.append(answer_text)
                            emit("[ANSWER OUTPUT]\n" + answer_text)

            # STEP 18: Cleanup agent resource
            agents_client.delete_agent(agent.id)
            emit("Deleted agent")


    except Exception as outer_exc:
        # STEP 19: Handle unexpected exceptions
        # Why broad exception? Many possible failure points
        emit(f"[ERROR] Unexpected exception: {outer_exc}")
        success = False
        trace_mgr.record_exception(outer_exc)
    
    # STEP 20: End parent trace span
    trace_mgr.end_parent_span()
    
    # STEP 21: Retrieve and format collected traces
    trace_lines, trace_summary = trace_mgr.get_traces()
    
    # STEP 22: Display trace summary in logs
    if trace_lines:
        emit("")
        emit("=" * 50)
        emit("OPENTELEMETRY TRACE SUMMARY")
        emit("=" * 50)
        emit(f"Total Spans: {trace_summary.get('total_spans', 0)}")
        emit(f"Agent Spans: {trace_summary.get('agent_spans', 0)}")
        emit(f"Thread Spans: {trace_summary.get('thread_spans', 0)}")
        emit(f"Message Spans: {trace_summary.get('message_spans', 0)}")
        emit(f"Run Spans: {trace_summary.get('run_spans', 0)}")
        emit(f"HTTP Spans: {trace_summary.get('http_spans', 0)}")
        emit(f"Main Elapsed: {trace_summary.get('main_elapsed_ms', 0):.2f}ms")
        emit("")
        for line in trace_lines:
            emit(line)
        emit("=" * 50)

    # STEP 23: Assemble final answer
    answers_joined = "\n\n".join(output_texts)
    log_joined = emit_util.get_log()

    # STEP 24: Format return payload based on return_mode
    if return_mode == "both":
        payload: dict | str = {
            "answers": output_texts,
            "output_text": answers_joined or log_joined,
            "log": log_joined,
            "success": success,
            "traces": trace_lines,
            "trace_summary": trace_summary,
        }
    elif return_mode == "log":
        payload = log_joined
    else:
        payload = answers_joined if answers_joined else log_joined

    # STEP 25: Optionally save to JSON
    if save_json:
        import pathlib
        try:
            path_obj = pathlib.Path(save_json)
            path_obj.parent.mkdir(parents=True, exist_ok=True)
            with path_obj.open('w', encoding='utf-8') as f:
                json.dump(
                    {
                        "answers": output_texts,
                        "output_text": answers_joined,
                        "log": log_joined,
                        "success": success,
                        "traces": trace_lines,
                        "trace_summary": trace_summary,
                    },
                    f,
                    ensure_ascii=False,
                    indent=2,
                )
        except Exception as exc:
            # STEP 26: Handle JSON save failures gracefully
            emit(f"[WARN] Failed to save JSON artefact: {exc}")
            log_joined2 = emit_util.get_log()
            if isinstance(payload, dict):
                payload["log"] = log_joined2
            elif return_mode == "log":
                payload = log_joined2

    return payload


if __name__ == "__main__":
    question = sys.argv[1] if len(sys.argv) > 1 and sys.argv[1].strip() else DEFAULT_QUESTION
    run_yahoo_search(question)
