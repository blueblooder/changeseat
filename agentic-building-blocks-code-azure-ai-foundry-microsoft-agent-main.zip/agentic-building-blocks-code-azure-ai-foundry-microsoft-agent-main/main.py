"""Main Streamlit application for Microsoft Agent Framework & AI Foundry SDK Building Blocks"""

# Standard library imports
import streamlit as st
from dotenv import load_dotenv
import warnings
import logging

# Suppress OpenTelemetry re-instrumentation warnings
# This is safe because the code already checks `is_instrumented()` before instrumenting
# The warning occurs when configure_azure_monitor() is called multiple times (expected in multi-function workflows)
logging.getLogger("opentelemetry.instrumentation.instrumentor").setLevel(logging.ERROR)
warnings.filterwarnings("ignore", message=".*Attempting to instrument while already instrumented.*")

# Load environment variables
load_dotenv()

# Local imports
from helper.emitter import create_streamlit_emitter
from apps.config import AppConfig
from apps.session_manager import SessionStateManager
from apps.ui_manager import UIManager
from apps.query_handlers import QueryModeHandlers

def main():
    """Main application entry point"""
    # Setup
    AppConfig.setup_page()
    st.title(" Agent Framework & AI Foundry SDK Building Blocks")
    
    # Initialize components
    app_config = AppConfig()
    session_manager = SessionStateManager()
    ui_manager = UIManager(session_manager, app_config)
    
    # Handle mode selection and parameters
    query_mode = ui_manager.render_sidebar()
    st.write("Send a question and get results based on the selected query mode.")
    user_question = ui_manager.render_question_input(query_mode)

    if st.button("Send"):
        placeholder = st.empty()
        emitter_util = create_streamlit_emitter(placeholder)
        handler = QueryModeHandlers(emitter_util, app_config)
        
        # Route to appropriate handler
        handler.execute(query_mode, user_question, session_manager.get_email_params())


if __name__ == "__main__":
    main()
