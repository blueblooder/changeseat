More reference source code for building Agent by Agent Framework


[https://github.com/microsoft/agent-framework/tree/main/python/samples/getting_started/agents/azure_ai](https://github.com/microsoft/agent-framework/blob/main/python/samples/getting_started/agents/azure_ai/README.md)