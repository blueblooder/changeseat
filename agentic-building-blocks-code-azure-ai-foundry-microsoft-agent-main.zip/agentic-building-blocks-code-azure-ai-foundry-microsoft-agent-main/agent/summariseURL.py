"""URL Summarization agent tool sample.

This module can be imported as `agent.summariseURL` or executed directly:

	python -m agent.summariseURL "your question with URLs"
or (from repo root):
	python .\agent\summariseURL.py "your question with URLs"

Agent Behavior:
	Uses a two-stage workflow: (1) Understanding agent analyzes the question to identify key aspects
	and extract URLs, (2) Summarizer agents process each URL's content to generate targeted summaries
	addressing the refined question with context awareness.
"""

import os
import re
import sys
import math
import yaml
import json
import pathlib
from typing import List, Dict, Callable, Optional, Union
from dotenv import load_dotenv
from azure.ai.projects import AIProjectClient
from azure.identity import AzureCliCredential
from azure.ai.agents.models import ListSortOrder, MessageRole

if __name__ == "__main__":
	repo_root = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
	if repo_root not in sys.path:
		sys.path.insert(0, repo_root)

import agent
from helper.agent_config_loader import load_agent_config, AgentConfigError
from helper.emitter import create_emitter

from helper.fetchurl import extract_content_from_url

load_dotenv()

project_endpoint = os.getenv("PROJECT_ENDPOINT")
model_deployment_name = os.getenv("MODEL_DEPLOYMENT_NAME")

DEFAULT_QUESTION = "Compare docs.micrsoft.com/azure and aws.amason.com/docmentation for cloud services"
MAX_WORDS_PER_URL = 100  


def safe_truncate_words(text: str, max_words: int) -> str:
    words = text.split()
    if len(words) <= max_words:
        return text
    return " ".join(words[:max_words])


def parse_understanding_response(response_text: str) -> tuple[str, List[str]]:
    """Parse the understanding agent response to extract refined question and URLs.
    
    Returns:
        tuple: (refined_user_question, list_of_urls)
    """
    if not response_text:
        return "", []
    
    import re
    
    refined_question = ""
    urls = []
    
    lines = response_text.split('\n')
    
    in_refined_question = False
    in_repaired_urls = False
    
    for line in lines:
        line = line.strip()
        
        if "**REFINED USER QUESTION:**" in line.upper() or "REFINED USER QUESTION:" in line.upper():
            in_refined_question = True
            in_repaired_urls = False
            continue
        elif "**REPAIRED URLS:**" in line.upper() or "REPAIRED URLS:" in line.upper():
            in_refined_question = False
            in_repaired_urls = True
            continue
        elif line.startswith("**") and line.endswith(":**"):
            in_refined_question = False
            in_repaired_urls = False
            continue
        
        if in_refined_question and line and not line.startswith('[') and not line.endswith(']'):
            if refined_question:
                refined_question += " " + line
            else:
                refined_question = line
        elif in_repaired_urls and line:
            if ',' in line:
                potential_urls = [url.strip() for url in line.split(',')]
                for url in potential_urls:
                    url = url.strip('`*\"\'()[]{}.,;')
                    if url and '.' in url and len(url) > 4:
                        if not url.startswith(('http://', 'https://')):
                            url = 'https://' + url
                        if len(url) > 10 and not url.endswith('.'):
                            urls.append(url)
            else:
                url = line.strip('`*\"\'()[]{}.,;')
                if url and '.' in url and len(url) > 4:
                    if not url.startswith(('http://', 'https://')):
                        url = 'https://' + url
                    if len(url) > 10 and not url.endswith('.'):
                        urls.append(url)
    
    if not urls:
        # Look for any URLs in the response
        url_pattern = r'(?:https?://)?(?:www\.)?[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}(?:[/\w\-._~:/?#@!$&\'()*+,;=%]*)?'
        found_urls = re.findall(url_pattern, response_text)
        
        for url in found_urls:
            url = url.strip('`*\"\'()[]{}.,;')
            if not url.startswith(('http://', 'https://')):
                url = 'https://' + url
            if '.' in url and len(url) > 10 and not url.endswith('.'):
                urls.append(url)
    
    urls = list(dict.fromkeys(urls))
    
    return refined_question.strip(), urls





def build_initial_understanding_prompt(question: str) -> str:
    import yaml
    config_file = os.getenv("AGENT_CONFIG_FILE", "agent_config.yaml")
    with open(config_file, 'r', encoding='utf-8') as f:
        full_cfg = yaml.safe_load(f) or {}
    summarise_section = full_cfg.get('summariseURL', {})
    u_cfg = summarise_section.get('understanding', {})
    instr = u_cfg.get('instructions', "")
    return f"""{instr}

User Question: {question}

Please provide your response in the following structured format:

**REFINED USER QUESTION:**
[Rewrite the user's question by supplementing more potential intentions that may be related to this question, understanding the semantic keyword phrases from URLs to define the targeted domain knowledge needed to answer this question]

**REPAIRED URLS:**
[All URLs as a comma-separated string, including incomplete ones that you repair by adding https://, normalizing formatting, etc.]"""


def build_summary_instruction(url: str, refined_question: str, fetched_meta: Dict[str, str]) -> str:
    """Build summarization instruction with understanding agent context.
    
    Args:
        url: The URL being summarized
        refined_question: Refined user question from understanding agent
        fetched_meta: Metadata about the fetched content
    
    Returns:
        Enhanced instruction string with understanding context integrated
    """
    import yaml
    config_file = os.getenv("AGENT_CONFIG_FILE", "agent_config.yaml")
    with open(config_file, 'r', encoding='utf-8') as f:
        full_cfg = yaml.safe_load(f) or {}
    summarise_section = full_cfg.get('summariseURL', {})
    s_cfg = summarise_section.get('summariser', {})
    instr = s_cfg.get('instructions', "")
    
    enhanced_instruction = instr
  
    return enhanced_instruction.format(url=url, original_question=refined_question, MAX_WORDS_PER_URL=MAX_WORDS_PER_URL, content_type=fetched_meta['content_type'], response_code=fetched_meta['response_code'])


def run_summarise_url(
    question: Optional[str] = None,
    emitter: Optional[Callable[[str], None]] = None,
    return_mode: str = "summary",
    save_json: Optional[Union[str, os.PathLike]] = None,
    tracing_mode: str = "both",
) -> Union[str, dict]:
    """Enhanced URL summarization with integrated understanding and summarizer agents.
    
    Two-stage workflow: Understanding agent analyzes question and extracts URLs,
    then Summarizer agents process each URL's content with targeted context.
    
    Execution Flow:
    1. Initialize output storage and resource counters
    2. Setup emitter for progress tracking
    3. Validate and default question input
    4. Configure OpenTelemetry tracing (Azure Monitor/console/none)
    5. Validate Azure project configuration (endpoint, model)
    6. Connect to Azure AI Project and agents client
    7. Load and validate YAML configuration for understanding/summarizer agents
    8. Create understanding agent for URL extraction and question refinement
    9. Execute understanding agent with initial question analysis
    10. Parse understanding output to extract refined question and URLs
    11. For each URL: create summarizer agent and thread
    12. Fetch URL content and metadata (content_type, HTTP status)
    13. Submit two-message pattern: content first, then instruction
    14. Execute summarizer agent and collect output
    15. Clean up per-URL resources (delete agent)
    16. Collect OpenTelemetry traces and generate summary report
    17. Format return payload based on return_mode (summary/log/both)
    18. Save JSON artifact if requested
    
    Args:
        question: User question containing URLs to analyze
        emitter: Optional callback for progress updates
        return_mode: Output format - 'summary', 'log', or 'both'
        save_json: Optional path to save results as JSON
        tracing_mode: Controls OpenTelemetry tracing destination:
            'auto' (default) -> Azure Monitor if APPLICATIONINSIGHTS_CONNECTION_STRING is set, else none
            'azure_monitor'  -> Send traces to Azure AI Foundry Portal
            'console'        -> Print traces to console (with gen_ai agent traces)
            'none'           -> Disable tracing
    
    Returns:
        Summaries and/or logs based on return_mode
    """
    # STEP 1: Initialize output storage and resource counters
    # Why? Track multiple URL summaries separately and count resource creation for diagnostics
    output_texts: List[str] = []

    agents_created = 0
    threads_created = 0
    messages_created = 0

    # STEP 2: Setup emitter for progress tracking
    # Why? Provides real-time feedback during multi-URL processing and debugging visibility
    emit_util = create_emitter(emitter)
    emit = emit_util.emit

    # STEP 3: Validate and default question input
    # Why? Defensive programming - handle empty/whitespace-only input gracefully
    # STEP 3: Validate and default question input
    # Why? Defensive programming - handle empty/whitespace-only input gracefully
    if not question or not question.strip():
        question = DEFAULT_QUESTION

    # STEP 4: Configure OpenTelemetry tracing (Azure Monitor/console/none)
    # Why? Enables distributed tracing for debugging multi-agent workflows and performance analysis
    from helper.unified_trace_manager import UnifiedTraceManager
    
    trace_mgr = UnifiedTraceManager(
        tracing_mode=tracing_mode,
        emitter=emit,
        trace_type="agent"
    )
    tracer, span_collector = trace_mgr.setup()

    # STEP 5: Validate Azure project configuration (endpoint, model)
    # Why? Fail fast if environment variables missing - prevents confusing downstream errors
    if not project_endpoint or not model_deployment_name:
        emit("[ERROR] PROJECT_ENDPOINT and MODEL_DEPLOYMENT_NAME must be set in environment/.env")
        return emit_util.get_log()

    # STEP 6: Start parent tracing span for entire operation
    # Why? Captures end-to-end latency and attributes for this multi-URL summarization session
    trace_mgr.start_parent_span(
        span_name=f"run_summarise_url: {question[:50]}",
        attributes={
            "question": question,
            "tracing_mode": tracing_mode
        }
    )

    # STEP 7: Connect to Azure AI Project and agents client
    # Why? All agent operations require AIProjectClient connection with proper credentials
    emit("Azure AI Project Client initializing...")
    try:
        with AIProjectClient(endpoint=project_endpoint, credential=AzureCliCredential()) as project_client:
            agents_client = project_client.agents
            
            # STEP 8: Load and validate YAML configuration for understanding/summarizer agents
            # Why? Two-stage workflow requires two distinct agent configurations from YAML
            try:
                import yaml
                import pathlib
                config_file = os.getenv("AGENT_CONFIG_FILE", "agent_config.yaml")
                with open(config_file, 'r', encoding='utf-8') as f:
                    full_cfg = yaml.safe_load(f) or {}
                summarise_section = full_cfg.get('summariseURL', {})
                u_cfg = summarise_section.get('understanding', {})
                s_cfg = summarise_section.get('summariser', {})
                
                # STEP 9: Validate required fields in both agent configurations
                # Why? Missing name/instructions fields will cause agent creation to fail cryptically
                # STEP 9: Validate required fields in both agent configurations
                # Why? Missing name/instructions fields will cause agent creation to fail cryptically
                for label, cfg in [('understanding', u_cfg), ('summariser', s_cfg)]:
                    if not cfg or 'name' not in cfg or 'instructions' not in cfg:
                        raise AgentConfigError(f"Missing required fields for summariseURL {label} agent in YAML")
            except AgentConfigError as cfg_err:
                emit(f"[ERROR] {cfg_err}")
                return emit_util.get_log()
            except Exception as exc:
                emit(f"[ERROR] Failed to load summariseURL agent config: {exc}")
                return emit_util.get_log()

            # STEP 10: Create understanding agent for URL extraction and question refinement
            # Why? First stage of two-stage workflow - analyzes user question and extracts/repairs URLs
            emit(f"[AGENT CREATE] Creating understanding agent with name: {u_cfg['name']}")
            understanding_agent = agents_client.create_agent(
                model=model_deployment_name,
                name=u_cfg['name'],
                description=u_cfg.get('description') or "",
                instructions=u_cfg['instructions'],
            )
            agents_created += 1
            emit(f"Created agent ID: {understanding_agent.id}")
            
            # STEP 11: Create thread for understanding agent
            # Why? Conversation context isolated to understanding phase
            emit("[THREAD CREATE] Creating understanding thread")
            understanding_thread = agents_client.threads.create()
            threads_created += 1
            emit(f"Created thread ID: {understanding_thread.id}")
            
            # STEP 12: Build and submit initial understanding prompt
            # Why? Structured prompt ensures understanding agent returns parseable URL list and refined question
            understanding_prompt = build_initial_understanding_prompt(question)
            emit("[UNDERSTANDING PROMPT]\n" + understanding_prompt)
            emit(f"[MESSAGE CREATE] Creating understanding message in thread {understanding_thread.id}")
            agents_client.messages.create(
                thread_id=understanding_thread.id,
                role="user",
                content=understanding_prompt,
            )
            messages_created += 1
            emit("[MESSAGE] Understanding message created successfully")
            
            # STEP 13: Execute understanding agent and check status
            # Why? Blocks until understanding analysis completes, handles failure scenarios
            run1 = agents_client.runs.create_and_process(thread_id=understanding_thread.id, agent_id=understanding_agent.id)
            emit(f"Initial understanding status: {run1.status}")
            if run1.status == "failed":
                emit(f"Failure: {run1.last_error}")
            
            # STEP 14: Gather understanding agent output for URL extraction
            # Why? Extract refined question and URL list from agent response for next phase
            understanding_context = ""
            understanding_output = ""
            messages1 = agents_client.messages.list(thread_id=understanding_thread.id, order=ListSortOrder.ASCENDING)
            for m in messages1:
                if m.role == MessageRole.AGENT:
                    for t in m.text_messages:
                        understanding_output = t.text.value
                        emit("[UNDERSTANDING OUTPUT]\n" + understanding_output)
                        understanding_context = understanding_output
            
            # STEP 15: Parse understanding output to extract refined question and URLs
            # Why? Structured parsing ensures we extract both refined question and validated URL list
            refined_question, urls = parse_understanding_response(understanding_output)
            emit(f"[REFINED QUESTION] {refined_question}")
            emit(f"[URL EXTRACTION] Found {len(urls)} URLs from understanding agent: {urls}")
            
            # STEP 16: Clean up understanding agent
            # Why? Understanding phase complete - free Azure resources immediately
            agents_client.delete_agent(understanding_agent.id)

            # STEP 17: Validate URL extraction results
            # Why? Skip summarization if no URLs found - prevents wasted processing
            if not urls:
                emit("[INFO] No URLs detected in the question.")
                return emit_util.get_log()

            # STEP 18: Begin fan-in phase - summarize each URL with refined context
            # Why? Each URL gets dedicated summarizer agent with targeted question context
            for url in urls:
                # STEP 19: Fetch URL content and metadata
                # Why? Extract text content and HTTP metadata for summarization and diagnostics
                text, content_type, response_code = extract_content_from_url(url)
                fetched_meta = {
                    'content_type': content_type or 'unknown',
                    'response_code': str(response_code) if response_code is not None else 'unknown'
                }
                if not isinstance(text, str):
                    text = str(text)

                # STEP 20: Calculate content metrics for diagnostics
                # Why? Token estimation helps understand context window usage
                total_words = len(text.split())
                est_tokens = math.ceil(len(text) / 4)
                emit("")
                emit(f"===== SOURCE: {url} =====")
                emit(
                    f"Metadata: content_type={fetched_meta['content_type']}; http_status={fetched_meta['response_code']}; "
                    f"words={total_words}; est_tokens={est_tokens}"
                )
                
                # STEP 21: Create summarizer agent for this URL
                # Why? Each URL gets fresh agent instance for isolation and parallel processing capability
                emit(f"[AGENT CREATE] Creating summarizer agent for URL: {url}")
                summariser_agent = agents_client.create_agent(
                    model=model_deployment_name,
                    name=s_cfg['name'],
                    description=s_cfg.get('description') or "",
                    instructions=s_cfg['instructions'],
                )
                agents_created += 1
                emit(f"Created agent ID: {summariser_agent.id}")

                # STEP 22: Create thread for this summarizer agent
                # Why? Isolated conversation context per URL prevents cross-contamination
                emit(f"[THREAD CREATE] Creating summarizer thread for URL: {url}")
                thread = agents_client.threads.create()
                threads_created += 1
                emit(f"Created thread ID: {thread.id}")

                # STEP 23: Submit two-message pattern - content first, then instruction
                # Why? Separating content and instruction improves agent context processing
                emit(f"[MESSAGE CREATE] Creating content message for URL: {url}")
                agents_client.messages.create(
                    thread_id=thread.id,
                    role="user",
                    content=f"Content for {url}:\n{text}",
                )
                messages_created += 1
                emit(f"[MESSAGE] Created content message successfully")
                
                # STEP 24: Build summary instruction with refined question context
                # Why? Injects understanding agent's refined question for targeted summarization
                effective_question = refined_question if refined_question else question
                summary_instruction = build_summary_instruction(url, effective_question, fetched_meta)
                emit("[SUMMARY PROMPT]\n" + summary_instruction)
                emit(f"[MESSAGE CREATE] Creating summary instruction message for URL: {url}")
                agents_client.messages.create(
                    thread_id=thread.id,
                    role="user",
                    content=summary_instruction,
                )
                messages_created += 1
                emit("[MESSAGE] Summary instruction message created successfully")
                
                # STEP 25: Execute summarizer agent and check status
                # Why? Blocks until summarization completes, handles failures per URL
                run2 = agents_client.runs.create_and_process(thread_id=thread.id, agent_id=summariser_agent.id)
                emit(f"Summary run status ({url}): {run2.status}")
                if run2.status == "failed":
                    emit(f"Run failed: {run2.last_error}")
                
                # STEP 26: Extract summary output from agent response
                # Why? Collect summarized text for this URL and add to output collection
                messages2 = agents_client.messages.list(thread_id=thread.id, order=ListSortOrder.ASCENDING)
                for m in messages2:
                    if m.role == MessageRole.AGENT:
                        for t in m.text_messages:
                            output_text = t.text.value
                            emit("[SUMMARY OUTPUT]\n" + output_text)
                            emit(f"===== END SUMMARY: {url} =====")
                            output_texts.append(output_text)
                
                # STEP 27: Clean up summarizer agent for this URL
                # Why? Free resources after each URL - important for multi-URL processing
                # STEP 27: Clean up summarizer agent for this URL
                # Why? Free resources after each URL - important for multi-URL processing
                agents_client.delete_agent(summariser_agent.id)
            
            # STEP 28: Emit Azure Monitor tracing notification if enabled
            # Why? Inform user where to find distributed traces for debugging
            if tracing_mode == "azure_monitor":
                emit("")
                emit("AZURE MONITOR TRACING")
                emit("✅ Agent traces have been sent to Azure Monitor / Application Insights")
                emit("📊 View traces in Azure AI Foundry Portal: https://ai.azure.com")
                emit("")

    # STEP 29: Handle unexpected exceptions with tracing integration
    # Why? Capture exceptions in OpenTelemetry spans for distributed debugging
    except Exception as outer_exc:
        trace_mgr.record_exception(outer_exc, f"Unexpected exception: {outer_exc}")
        emit(f"[ERROR] Unexpected exception: {outer_exc}")
    finally:
        # STEP 30: End parent tracing span
        # Why? Ensures span is closed even if exception occurred
        trace_mgr.end_parent_span()

    # STEP 31: Collect OpenTelemetry traces and generate summary
    # Why? Provides detailed performance metrics and distributed trace visualization
    # STEP 31: Collect OpenTelemetry traces and generate summary
    # Why? Provides detailed performance metrics and distributed trace visualization
    trace_lines, trace_summary = trace_mgr.get_traces()
    
    # STEP 32: Emit trace summary report if traces collected
    # Why? Console visibility into span hierarchy, latency, and HTTP calls
    if trace_lines:
        emit("")
        emit("=" * 50)
        emit("OPENTELEMETRY TRACE SUMMARY")
        emit("=" * 50)
        emit(f"Total Spans: {trace_summary.get('total_spans', 0)}")
        emit(f"Agent Spans: {trace_summary.get('agent_spans', 0)}")
        emit(f"Thread Spans: {trace_summary.get('thread_spans', 0)}")
        emit(f"Message Spans: {trace_summary.get('message_spans', 0)}")
        emit(f"Run Spans: {trace_summary.get('run_spans', 0)}")
        emit(f"HTTP Spans: {trace_summary.get('http_spans', 0)}")
        emit(f"Main Elapsed: {trace_summary.get('main_elapsed_ms', 0):.2f}ms")
        emit("")
        for line in trace_lines:
            emit(line)
        emit("=" * 50)

    # STEP 33: Emit execution summary with resource creation report
    # Why? Diagnostic visibility into resource usage (agents, threads, messages)
    emit("\n" )
    emit("[EXECUTION SUMMARY] Resource Creation Report")
    emit(f"[SUMMARY] Total Agents Created: {agents_created}")
    emit(f"[SUMMARY] Total Threads Created: {threads_created}")
    emit(f"[SUMMARY] Total Messages Created: {messages_created}")
    emit("\n" )

    # STEP 34: Format summaries and logs for return payload
    # Why? Join multiple URL summaries into single text output
    summary_joined = "\n\n".join(output_texts) if output_texts else ""
    log_joined = emit_util.get_log()

    # STEP 35: Build return payload based on return_mode
    # Why? Flexible output format - summary only, logs only, or both with traces
    if return_mode == "both":
        payload = {
            "summaries": output_texts,
            "output_text": summary_joined or log_joined,
            "log": log_joined,
            "traces": trace_lines,
            "trace_summary": trace_summary,
        }
    elif return_mode == "log":
        payload = log_joined
    else:
        payload = summary_joined if summary_joined else log_joined

    # STEP 36: Save JSON artifact if requested with graceful degradation
    # Why? Persist results for downstream processing, handle save failures gracefully
    if save_json:
        import json, pathlib
        try:
            path_obj = pathlib.Path(save_json)
            path_obj.parent.mkdir(parents=True, exist_ok=True)
            json.dump(
                {
                    "summaries": output_texts,
                    "output_text": summary_joined,
                    "log": log_joined,
                    "traces": trace_lines,
                    "trace_summary": trace_summary,
                },
                path_obj.open('w', encoding='utf-8'),
                ensure_ascii=False,
                indent=2,
            )
        except Exception as exc:
            emit(f"[WARN] Failed to save JSON artefact: {exc}")
            # STEP 37: Update payload with warning if JSON save failed
            # Why? Ensure log reflects save failure for debugging
            if isinstance(payload, dict):
                payload["log"] = emit_util.get_log()
            elif return_mode == "log":
                payload = emit_util.get_log()

    return payload


if __name__ == "__main__":
    user_question = sys.argv[1] if len(sys.argv) > 1 and sys.argv[1].strip() else DEFAULT_QUESTION
    run_summarise_url(user_question)
